
RELEASE NOTES

	Version 2.30.00.0000 (8/18/2011)
	
		1.  Modified the number of maximum shared named global variables
		( MAXSHAREDNAMED ) to 10,000 from 3,000.
		
		2.  Added new functions to utilize the __int64 data type:
			a.  GV_SetInteger64
			b.  GV_GetInteger64
			c.  GV_SetNamedInt64
			d.  GV_ResetAllNmdInt64
			e.  GV_GetNamedInt64
			f.  GV_GetNamedInt64ByNum
			g.  GV_GetInt64NameByNum

	
	Version 2.20.00.0000 (10/28/2004)
	
	
		Added a new type of global variables, Boolean global variables.
		Added functions to demonstrate storage and retrieval of numbered and
		named global variables of Boolean type.

		Added functions to "reset" or "reinitialize" named global variables.
		GV_ResetAllNmd<Type> functions demonstrate how all named global
		variables of a given type name can have their names reset to NULL and
		their values reset to initial values (0 for numeric global variables,
		NULL for string global variables, and FALSE for Boolean global variables).

		Added GV_Get<Type>NameByNum functions to demonstrate retrieval of the
		name of a named variable based on the named variable's element location
		number.

		Added GV_GetNamed<Type>ByNum functions to demonstrate retrieval of
		the value stored in a named variable based on the named variable's
		element location number.

		Modified return type of all functions that return strings so that they
		return BSTR's rather than LPSTR's to demonstrate DLL code that can be
		used with applications that use BSTR's rather than LPSTR's.

		Expanded the interprocess data segment for string global variables
		from 3000 locations to 10,000 locations to better demonstrate storage
		of numbered string global variables.

		Added internal function fnGenRunTimeError to demonstrate the ability
		to generate a run-time error in TradeStation under appropriate 
		circumstances using the functionality included in the EasyLanguage
		Extension SDK (tskit.dll).
		
		Added Version.rc resource file to the DLL project to allow for easy
		retrieval of GlobalVariable.dll version information (for example,
		using Windows Explorer).



	Version 2.10.00.0000 (12/2/2003)

		Added named global variables of all data types.

		Added function to return version number (GV_GetVersion).
		
		Modified Set functions for all data types to return an
		integer value to indicate function success or failure.
		(Provided EL wrapper functions have been modified accordingly.)



	Version 2.00.00.0000 (9/17/2003)

		Added interprocess data segment to allow communication
		of values between applications.



	Version 1.10.00.0000 (8/7/2003)

		Added support for doubles and strings.


	
	Version 1.00.10.0000 (7/15/2003)

		Expanded GV arrays to 10,000 elements of each data type.

		

	Version 1.00.00.0000 (11/28/2002)
		
		Original Release


