/////////////////////////////////////////////////////////
//                                                     
//	This is example code for a TradeStation-compatible
//	DLL.
//                                                         
/////////////////////////////////////////////////////////


#include "StdAfx.h"
#include "SharedDataSegment.h"


/////////////////////////////////////////////////////////
//                                                     
//	DLLMain
//                                                         
/////////////////////////////////////////////////////////

BOOL APIENTRY DllMain
( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch ( ul_reason_for_call )
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
		break;
    }
    return TRUE ;
}



////////////////////////////////////////////////////////
//
//	Example code for functions that set
//	"numbered" global variables  
//
////////////////////////////////////////////////////////

int __stdcall GV_SetBoolean
( int iLocation, BOOL bVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		bShared[iLocation] = bVal ;
		return iLocation ;	// Global location successfully set to value
	}
	else
	{
		return -1 ;	// Error code:  Element location out of range
	}
}



int __stdcall GV_SetInteger
( int iLocation, int iVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		iShared[iLocation] = iVal ;
		return iLocation ;	// Global location successfully set to value
	}
	else
	{
		return -1 ;	// Error code:  Element location out of range
	}
}


int __stdcall GV_SetInteger64
( int iLocation, __int64 iVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		i64Shared[iLocation] = iVal ;
		return iLocation ;	// Global location successfully set to value
	}
	else
	{
		return -1 ;	// Error code:  Element location out of range
	}
}

int __stdcall GV_SetFloat
( int iLocation, float fVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		fShared[iLocation] = fVal ;
		return iLocation ;  // Global location successfully set to value
	}
	else
	{
		return -1 ;  // Error code:  Element location out of range
	}
}


int __stdcall GV_SetDouble
( int iLocation, double dVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		dShared[iLocation] = dVal ;
		return iLocation ;	// Global location successfully set to value
	}
	else
	{
		return -1 ; // Error code:  Element location out of range
	}
}



int __stdcall GV_SetString
( int iLocation, LPSTR sVal )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		int Counter = 0 ;
		LPSTR lpstrTmp = sVal ;

		while ( *lpstrTmp && Counter < MAXSTRINGSIZE )
		{
			sShared[iLocation][Counter] = *lpstrTmp++ ;
			Counter = Counter + 1 ;
		}
		sShared[iLocation][Counter] = NULL ;
		return iLocation ;  // Global location successfully set to value
	}
	else
	{
		return -1 ; // Error code:  Element location out of range
	}
}



////////////////////////////////////////////////////////
//
//	Example code for functions that get
//	"numbered" global variables  
//
////////////////////////////////////////////////////////

BOOL __stdcall GV_GetBoolean
( IEasyLanguageObject * pEL, int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
	    return bShared[iLocation];  // Return Boolean value
	}
	else
	{	
		// Generate run-time error in TradeStation
		// Element location out of range
		fnGenRunTimeError( pEL, GET_BOOLEAN_ELEM_LOC_OUT_OF_RANGE ) ;
		return FALSE ; 
	}
}


int __stdcall GV_GetInteger
( int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
	    return iShared[iLocation];  // Return integer value
	}
	else
	{
		return -1 ; // Error code:  Element location out of range
	}
}


__int64 __stdcall GV_GetInteger64
( int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
	    return i64Shared[iLocation];  // Return integer value
	}
	else
	{
		return -1 ; // Error code:  Element location out of range
	}
}


float __stdcall GV_GetFloat
( int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
	    return fShared[iLocation];  // Return float value
	}
	else
	{
		return -1.0 ;  // Error code:  Element location out of range
	}
}



double __stdcall GV_GetDouble
( int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
	    return dShared[iLocation];  // Return double-precision value
	}
	else
	{
		return -1.0 ;  // Error code:  Element location out of range
	}
}



BSTR __stdcall GV_GetString
( int iLocation )
{
    if ( iLocation >= 0 && iLocation < MAXSHARED )
	{
		return SysAllocString( (OLECHAR*) sShared[iLocation] ) ;
		// Return pointer to string
	}
	else
	{
		return NULL ;  // Error code:  Element location out of range
	}
}



////////////////////////////////////////////////////////
//
//	Example code for functions that set
//	"named" global variables  
//
////////////////////////////////////////////////////////

int __stdcall GV_SetNamedBool
( LPSTR sBoolVarName, BOOL bVal )
{
	if ( fnIsLegalVarName( sBoolVarName ) )
	{
		int iLocation = 0 ;
		
		//	Find previous location of this named variable.
		//	If it was not previously created, then find first available
		//	space to store it.
		while ( sSharedBoolNames[iLocation][0] && 
			strcmp( sSharedBoolNames[iLocation], sBoolVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
			//	If the variable was found, set the variable's value and
			//	return.  If the variable was not found, but a blank location
			//	was found,  Store the variable's name at the blank location,
			//	then set the variable's value, then return.
		}
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedBoolNames[iLocation], sBoolVarName ) != 0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sBoolVarName ;
		
				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedBoolNames[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedBoolNames[iLocation][Counter] = NULL ;
			}
			bSharedNamed[iLocation] = bVal ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;		
			//  Error code:  No more available global named locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}



int __stdcall GV_SetNamedInt
( LPSTR sIntVarName, int iVal )
{
	if ( fnIsLegalVarName( sIntVarName ) )
	{
		int iLocation = 0 ;
		
		// Find previous location of this named variable.
		// If it was not previously created, then find first available
		// space to store it.
		while ( sSharedIntNames[iLocation][0] && 
			strcmp( sSharedIntNames[iLocation], sIntVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		// If the variable was found, set the variable's value and return.
		// If the variable was not found, but a blank location was found,
		// store the variable's name at the blank location, then set
		// the variable's value, then return.
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedIntNames[iLocation], sIntVarName ) != 0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sIntVarName ;
		
				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedIntNames[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedIntNames[iLocation][Counter] = NULL ;
			}
			iSharedNamed[iLocation] = iVal ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;
			//  Error code:  No more available global named locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}


int __stdcall GV_SetNamedInt64
( LPSTR sIntVarName, __int64 iVal )
{
	if ( fnIsLegalVarName( sIntVarName ) )
	{
		int iLocation = 0 ;
		
		// Find previous location of this named variable.
		// If it was not previously created, then find first available
		// space to store it.
		while ( sSharedInt64Names[iLocation][0] && 
			strcmp( sSharedInt64Names[iLocation], sIntVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		// If the variable was found, set the variable's value and return.
		// If the variable was not found, but a blank location was found,
		// store the variable's name at the blank location, then set
		// the variable's value, then return.
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedInt64Names[iLocation], sIntVarName ) != 0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sIntVarName ;
		
				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedInt64Names[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedInt64Names[iLocation][Counter] = NULL ;
			}
			i64SharedNamed[iLocation] = iVal ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;
			//  Error code:  No more available global named locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}

int __stdcall GV_SetNamedFloat
( LPSTR sFloatVarName, float fVal )
{
	if ( fnIsLegalVarName( sFloatVarName ) )
	{
		int iLocation = 0 ;
		
		// Find previous location of this named variable.
		// If it was not previously created, then find first available
		// space to store it.
		while ( sSharedFloatNames[iLocation][0] && 
			strcmp( sSharedFloatNames[iLocation], sFloatVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		// If the variable was found, set the variable's value and return.
		// If the variable was not found, but a blank location was found,
		// store the variable's name at the blank location, then set
		// the variable's value, then return.
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedFloatNames[iLocation], sFloatVarName ) != 0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sFloatVarName ;
		
				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedFloatNames[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedFloatNames[iLocation][Counter] = NULL ;
			}
			fSharedNamed[iLocation] = fVal ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;	//  Error code:  No more available global named
						//	locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}



int __stdcall GV_SetNamedDouble
( LPSTR sDoubleVarName, double dVal )
{
	if ( fnIsLegalVarName( sDoubleVarName ) )
	{
		int iLocation = 0 ;
		
		// Find previous location of this named variable.
		// If it was not previously created, then find first available
		// space to store it.
		while ( sSharedDoubleNames[iLocation][0] && 
			strcmp( sSharedDoubleNames[iLocation], sDoubleVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		// If the variable was found, set the variable's value and return.
		// If the variable was not found, but a blank location was found,
		// store the variable's name at the blank location, then set
		// the variable's value, then return.
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedDoubleNames[iLocation], sDoubleVarName ) !=
				0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sDoubleVarName ;
		
				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedDoubleNames[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedDoubleNames[iLocation][Counter] = NULL ;
			}
			dSharedNamed[iLocation] = dVal ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;	//  Error code:  No more available global named
						//	locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}



int __stdcall GV_SetNamedString
( LPSTR sStringVarName, LPSTR sVal )
{
	if ( fnIsLegalVarName( sStringVarName ) )
	{
		int iLocation = 0 ;
		
		// Find previous location of this named variable.
		// If it was not previously created, then find first available
		// space to store it.
		while ( sSharedStringNames[iLocation][0] && 
			strcmp( sSharedStringNames[iLocation], sStringVarName ) != 0 &&
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		// If the variable was found, set the variable's value and return.
		// If the variable was not found, but a blank location was found,
		// store the variable's name at the blank location, then set
		// the variable's value, then return.
		if ( iLocation < MAXSHAREDNAMED )
		{
			if ( strcmp( sSharedStringNames[iLocation], sStringVarName ) !=
				0 )
			{
				int Counter = 0 ;
				LPSTR lpstrTmp = sStringVarName ;

				while ( *lpstrTmp && Counter < MAXVARNAMELENGTH )
				{
					sSharedStringNames[iLocation][Counter] = *lpstrTmp++ ;
					Counter = Counter + 1 ;
				}
				sSharedStringNames[iLocation][Counter] = NULL ;
			}

			int Counter = 0 ;
			LPSTR lpstrTmp = sVal ;
			
			while ( *lpstrTmp && Counter < MAXSTRINGSIZE - 1 )
			{
				sSharedNamed[iLocation][Counter] = *lpstrTmp++ ;
				Counter = Counter + 1 ;
			}
			sSharedNamed[iLocation][Counter] = NULL ;
			return iLocation ;	//  Global variable found and modified
		}
		else
		{
			return -2 ;	//  Error code:  No more available global named
						//	locations
		}
	}
	else
	{
		return -1 ;	//  Error code:  Global variable name not legal
	}
}



////////////////////////////////////////////////////////
//
//	Example code for functions that "reset"
//	named global variables.  To "reset" a named
//	variable is to reinitialize it - to set its name
//	to NULL and set its value to either zero, in the
//	case of numeric global variables, to NULL, in the
//	case of string global variables, or to FALSE, in the
//	case of Boolean global variables.
//
////////////////////////////////////////////////////////

int __stdcall GV_ResetAllNmdBools
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedBoolNames[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedBoolNames[iLocation][0] = NULL ;
		bSharedNamed[iLocation] = FALSE ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}



int __stdcall GV_ResetAllNmdInts
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedIntNames[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedIntNames[iLocation][0] = NULL ;
		iSharedNamed[iLocation] = 0 ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}


int __stdcall GV_ResetAllNmdInt64
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedInt64Names[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedInt64Names[iLocation][0] = NULL ;
		i64SharedNamed[iLocation] = 0 ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}

int __stdcall GV_ResetAllNmdFlts
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedFloatNames[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedFloatNames[iLocation][0] = NULL ;
		fSharedNamed[iLocation] = 0.0 ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}



int __stdcall GV_ResetAllNmdDbls
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedDoubleNames[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedDoubleNames[iLocation][0] = NULL ;
		dSharedNamed[iLocation] = 0.0 ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}


int __stdcall GV_ResetAllNmdStrs
( void )
{
	int iLocation = 0 ;
	
	while ( sSharedStringNames[iLocation][0] && iLocation < MAXSHAREDNAMED )
	{
		sSharedStringNames[iLocation][0] = NULL ;
		sSharedNamed[iLocation][0] = NULL ;
		iLocation = iLocation + 1 ;
	}
	
	return iLocation ;	//  Return number of named variables reset
}



////////////////////////////////////////////////////////
//
//	Example code for functions that get
//	the values of "named" global variables  
//
////////////////////////////////////////////////////////


BOOL __stdcall GV_GetNamedBool
( IEasyLanguageObject * pEL, LPSTR sBoolVarName )
{
	if ( fnIsLegalVarName( sBoolVarName ) )
	{
		int iLocation = 0 ;

		while ( sSharedBoolNames[iLocation][0] &&
			strcmp( sSharedBoolNames[iLocation], sBoolVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		if ( sSharedBoolNames[iLocation][0] && 
			strcmp( sSharedBoolNames[iLocation], sBoolVarName ) == 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			return bSharedNamed[iLocation] ;
		}
		else
		{
			//  No global variable by that name
			//	Generate appropriate run-time error in TradeStation
			fnGenRunTimeError( pEL, GET_NAMED_BOOL_NO_GV_NAME ) ;
			return FALSE ;
		}
	}
	else
	{
		fnGenRunTimeError( pEL, GET_NAMED_BOOL_ILLEGAL_GV_NAME ) ;
		return FALSE ;  //  Global variable name not legal
	}
}



BOOL __stdcall GV_GetNamedBoolByNum
( IEasyLanguageObject * pEL, int iBoolVarNum )
{
	if ( iBoolVarNum >= 0 && iBoolVarNum < MAXSHAREDNAMED &&
		sSharedBoolNames[iBoolVarNum][0] )
	{
		return bSharedNamed[iBoolVarNum] ;
	}
	else
	{
		fnGenRunTimeError( pEL, GET_NAMED_BOOL_BYNUM_ERR ) ;
		return FALSE ;  // Error code:  Element location out of range  
	}
}



int __stdcall GV_GetNamedInt
( LPSTR sIntVarName, int iErrorCode )
{
	if ( fnIsLegalVarName( sIntVarName ) )
	{
		int iLocation = 0 ;
		
		while ( sSharedIntNames[iLocation][0] &&
			strcmp( sSharedIntNames[iLocation], sIntVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		if ( sSharedIntNames[iLocation][0] && 
			strcmp( sSharedIntNames[iLocation], sIntVarName ) == 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			return iSharedNamed[iLocation] ;
		}
		else
		{
			return iErrorCode ;  //  No global variable by that name
		}
	}
	else
	{
		return iErrorCode ;  //  Global variable name not legal
	}
}


__int64 __stdcall GV_GetNamedInt64
( LPSTR sIntVarName, int iErrorCode )
{
	if ( fnIsLegalVarName( sIntVarName ) )
	{
		int iLocation = 0 ;
		
		while ( sSharedInt64Names[iLocation][0] &&
			strcmp( sSharedInt64Names[iLocation], sIntVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		if ( sSharedInt64Names[iLocation][0] && 
			strcmp( sSharedInt64Names[iLocation], sIntVarName ) == 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			return i64SharedNamed[iLocation] ;
		}
		else
		{
			return iErrorCode ;  //  No global variable by that name
		}
	}
	else
	{
		return iErrorCode ;  //  Global variable name not legal
	}
}


int __stdcall GV_GetNamedIntByNum
( int iIntVarNum, int iErrorCode )
{
	if ( iIntVarNum >= 0 && iIntVarNum < MAXSHAREDNAMED && 
		sSharedIntNames[iIntVarNum][0] )
	{
		return iSharedNamed[iIntVarNum] ;
	}
	else
	{
		return iErrorCode ;  // Error code:  Element location out of range  
	}
}

__int64 __stdcall GV_GetNamedInt64ByNum
( int iIntVarNum, int iErrorCode )
{
	if ( iIntVarNum >= 0 && iIntVarNum < MAXSHAREDNAMED && 
		sSharedInt64Names[iIntVarNum][0] )
	{
		return i64SharedNamed[iIntVarNum] ;
	}
	else
	{
		return iErrorCode ;  // Error code:  Element location out of range  
	}
}

float __stdcall GV_GetNamedFloat
( LPSTR sFloatVarName, float fErrorCode )
{
	if ( fnIsLegalVarName( sFloatVarName ) )
	{
		int iLocation = 0 ;
		
		while ( sSharedFloatNames[iLocation][0] &&
			strcmp( sSharedFloatNames[iLocation], sFloatVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		if ( sSharedFloatNames[iLocation][0] &&
			strcmp( sSharedFloatNames[iLocation], sFloatVarName ) == 0
			&& iLocation < MAXSHAREDNAMED )
		{
			return fSharedNamed[iLocation] ;
		}
		else
		{
			return fErrorCode ;	//  No global variable by that name
		}
	}
	else
	{
		return fErrorCode ;  //  Global variable name not legal
	}
}



float __stdcall GV_GetNamedFltByNum
( int iFloatVarNum, float fErrorCode )
{
	if ( iFloatVarNum >= 0 && iFloatVarNum < MAXSHAREDNAMED &&
		sSharedFloatNames[iFloatVarNum][0] )
	{
		return fSharedNamed[iFloatVarNum] ;
	}
	else
	{
		return fErrorCode ;	// Error code:  Element location out of range  
	}
}



double __stdcall GV_GetNamedDouble
( LPSTR sDoubleVarName, double dErrorCode )
{
	if ( fnIsLegalVarName( sDoubleVarName ) )
	{
		int iLocation = 0 ;

		while ( sSharedDoubleNames[iLocation][0] &&
			strcmp( sSharedDoubleNames[iLocation], sDoubleVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}

		if ( sSharedDoubleNames[iLocation][0] &&
			strcmp( sSharedDoubleNames[iLocation], sDoubleVarName ) == 0
			&& iLocation < MAXSHAREDNAMED )
		{
			return dSharedNamed[iLocation] ; 
		}
		else
		{
			return dErrorCode ;  //  No global variable by that name
		}
	}
	else
	{
		return dErrorCode ;  //  Global variable name not legal
	}
}



double __stdcall GV_GetNamedDblByNum
( int iDblVarNum, double dErrorCode )
{ 
	if ( iDblVarNum >= 0 && iDblVarNum < MAXSHAREDNAMED && 
		sSharedDoubleNames[iDblVarNum][0] )
	{
		return dSharedNamed[iDblVarNum] ;
	}
	else
	{
		return dErrorCode ;  // Error code:  Element location out of range 
	}
}



BSTR __stdcall GV_GetNamedString
( LPSTR sStringVarName, LPSTR sErrorCode )
{
	if ( fnIsLegalVarName( sStringVarName ) && strlen( sErrorCode ) <
		MAXSTRINGSIZE )
	{
		int iLocation = 0 ;
		
		while ( sSharedStringNames[iLocation][0] &&
			strcmp( sSharedStringNames[iLocation], sStringVarName ) != 0 && 
			iLocation < MAXSHAREDNAMED )
		{
			iLocation = iLocation + 1 ;
		}
		if ( sSharedStringNames[iLocation][0] &&
			strcmp( sSharedStringNames[iLocation], sStringVarName ) == 0
			&& iLocation < MAXSHAREDNAMED )
		{
			return SysAllocString( (OLECHAR*) sSharedNamed[iLocation] ) ;
		}
		else
		{
			return SysAllocString( (OLECHAR*) sErrorCode ) ;
			// No global variable by that name
		}
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Global variable name not legal or sErrorCode string too long
	}
}



BSTR __stdcall GV_GetNamedStrByNum
( int iStrVarNum, LPSTR sErrorCode )
{
	if ( iStrVarNum >= 0 && iStrVarNum < MAXSHAREDNAMED && 
		sSharedStringNames[iStrVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedNamed[iStrVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range  
	}
}



////////////////////////////////////////////////////////
//
//	Example code for functions that get
//	the names of named global variables
//	based on their number (every named
//	global variable also has a number).  
//
////////////////////////////////////////////////////////

BSTR __stdcall GV_GetBoolNameByNum
( int iBoolVarNum, LPSTR sErrorCode )
{
	if ( iBoolVarNum >= 0 && iBoolVarNum < MAXSHAREDNAMED && 
		sSharedBoolNames[iBoolVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedBoolNames[iBoolVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}



BSTR __stdcall GV_GetIntNameByNum
( int iIntVarNum, LPSTR sErrorCode )
{
	if ( iIntVarNum >= 0 && iIntVarNum < MAXSHAREDNAMED && 
		sSharedIntNames[iIntVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedIntNames[iIntVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}

BSTR __stdcall GV_GetInt64NameByNum
( int iIntVarNum, LPSTR sErrorCode )
{
	if ( iIntVarNum >= 0 && iIntVarNum < MAXSHAREDNAMED && 
		sSharedInt64Names[iIntVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedInt64Names[iIntVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}

BSTR __stdcall GV_GetFltNameByNum
( int iFloatVarNum, LPSTR sErrorCode )
{
	if ( iFloatVarNum >= 0 && iFloatVarNum < MAXSHAREDNAMED && 
		sSharedFloatNames[iFloatVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedFloatNames[iFloatVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}



BSTR __stdcall GV_GetDblNameByNum
( int iDblVarNum, LPSTR sErrorCode )
{
	if ( iDblVarNum >= 0 && iDblVarNum < MAXSHAREDNAMED && 
		sSharedDoubleNames[iDblVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedDoubleNames[iDblVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}



BSTR __stdcall GV_GetStrNameByNum
( int iStrVarNum, LPSTR sErrorCode )
{
	if ( iStrVarNum >= 0 && iStrVarNum < MAXSHAREDNAMED && 
		sSharedStringNames[iStrVarNum][0] )
	{
		return SysAllocString( (OLECHAR*) sSharedStringNames[iStrVarNum] ) ;
	}
	else
	{
		return SysAllocString( (OLECHAR*) sErrorCode ) ;
		// Error code:  Element location out of range 
		// or no named variable exists with the specified number.
	}
}



////////////////////////////////////////////////////////
//
//	Example code for other exported
//	functions  
//
////////////////////////////////////////////////////////

BSTR __stdcall GV_GetVersion
( void )
{
	return SysAllocString( (OLECHAR*) "2.30.00.0000" ) ;
}



/////////////////////////////////////////////////////////
//        
//	Example code for internal use only functions
//	(not exported)  
//                                                         
/////////////////////////////////////////////////////////


//  Determine whether named variable name is "legal"
BOOL fnIsLegalVarName
( LPSTR sVarName )
{
	int iLenVarName = strlen( sVarName ) ;

	if ( iLenVarName >= 1 && iLenVarName < MAXVARNAMELENGTH )
	{
		return TRUE ;	//  Global variable name is legal
	}
	else
	{
		return FALSE ;	//  Global variable name is not legal
	}
}


//  Generate a run-time error in TradeStation
void fnGenRunTimeError
( IEasyLanguageObject * pEL, int iErrorNum )
{
	TSRuntimeErrorItem tsItem;
	int m_HistErr ;
	tsItem.sCompany = _bstr_t("TradeStation Securities, Inc.").copy();
	tsItem.sErrorLocation = _bstr_t("GlobalVariable.dll Example Code Library").copy();
	tsItem.sErrorCategory = _bstr_t("Error").copy();
	tsItem.sLongString = NULL;
	tsItem.nParameters = 0;
		
    switch ( iErrorNum )
	{
	case GET_BOOLEAN_ELEM_LOC_OUT_OF_RANGE:
		{
			// GV_GetBoolean called with an element number that's
			// out of legal range
			tsItem.sShortString = _bstr_t("Error - Global variable element"
				" lcoation out of range. DLL function"
				" GV_GetBoolean.").copy();
			tsItem.sSourceString = _bstr_t("Attempted to retrieve a global"
				" variable using an element location that is either negative"
				" or greater than the largest possible element number. DLL "
				"function GV_GetBoolean.").copy();
			tsItem.nErrorCode = GET_BOOLEAN_ELEM_LOC_OUT_OF_RANGE ;
		}
		break ;
		case GET_NAMED_BOOL_NO_GV_NAME: 
		{
			// GV_GetNamedBool called but no GV by that name
			tsItem.sShortString = _bstr_t("Error - No global variable by"
				" that name. DLL function GV_GetNamedBool.").copy();
			tsItem.sSourceString = _bstr_t("Attempted to retrieve a named"
				" Boolean GV that does not exist.  Check global variable"
				" name. DLL function GV_GetNamedBool.").copy();
			tsItem.nErrorCode = GET_NAMED_BOOL_NO_GV_NAME ;
		}
		break ;
		case GET_NAMED_BOOL_ILLEGAL_GV_NAME:
		{
			// GV_GetNamedBool called with illegal GV name
			tsItem.sShortString = _bstr_t("Error - Illegal global variable"
				" name. DLL function GV_GetNamedBool.").copy();
			tsItem.sSourceString = _bstr_t("Attempted to retrieve a variable"
				" with an illegal name - either NULL or too long. DLL "
				"function GV_GetNamedBool.").copy();
			tsItem.nErrorCode = GET_NAMED_BOOL_ILLEGAL_GV_NAME ;
		}
		break ;
		case GET_NAMED_BOOL_BYNUM_ERR:
		{
			// GV_GetNamedBoolByNum called with illegal GV number
			// Number out of range or no named GV exists with that
			// element number.
			tsItem.sShortString = _bstr_t("Error - Illegal global variable"
				" element number. DLL function GV_GetNamedBoolByNum.").copy();
			tsItem.sSourceString = _bstr_t("Attempted to retrieve a variable"
				" using a global variable number that is either out of range"
				" or which refers to an unnamed gv location. DLL function "
				"GV_GetNamedBoolByNum.").copy();
			tsItem.nErrorCode = GET_NAMED_BOOL_BYNUM_ERR ;
		}
		break ;
		default:
		{
			// Generate a run-time error of undefined type or origin
			tsItem.sShortString = _bstr_t("Undefined error in "
				"GlobalVariable.dll.").copy();
			tsItem.sSourceString = _bstr_t("Error origin undefined.").copy();
			tsItem.nErrorCode = UNDEFINED_ERROR ;
		}
	}

	m_HistErr = pEL->Errors->RegisterError( &tsItem ) ;
	pEL->Errors->RaiseRuntimeError( m_HistErr ) ;
}
