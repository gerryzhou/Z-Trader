
#pragma once

#define MAXSHARED 10000
#define MAXSHAREDNAMED 10000
#define MAXSTRINGS 10000
#define MAXSTRINGSIZE 250
#define MAXVARNAMELENGTH 100
#define UNDEFINED_ERROR 10
#define GET_BOOLEAN_ELEM_LOC_OUT_OF_RANGE 20
#define GET_NAMED_BOOL_NO_GV_NAME 30
#define GET_NAMED_BOOL_ILLEGAL_GV_NAME 40
#define GET_NAMED_BOOL_BYNUM_ERR 50



////////////////////////////////////////////////////////
//                                                     
//	Function prototypes
//                                                         
/////////////////////////////////////////////////////////

BOOL fnIsLegalVarName
( LPSTR sVarName ) ;

void fnGenRunTimeError
( IEasyLanguageObject * pEL, int iErrorNum ) ;
