
#pragma once

#import "C:\tskit.dll" no_namespace

#include "GV23.h"


/////////////////////////////////////////////////////////
//                                                     //    
//  Shared data segment declarations                   //   
//	(Declare data segment to be shared by various      //
//	applications that run as separate processes.       //
//	All applications that call this DLL share this     //
//  data segment - allowing values to be shared        //   
//  between Charting, RadarScreen, OptionStation, and  //
//  third-party applications such as Microsoft Excel.  //
//                                                     //   
/////////////////////////////////////////////////////////

#pragma data_seg( ".IPC" )  // Beginning of shared data segment declarations

//
// First, declare shared global arrays in which values are
// referenced by "element location", which is the same as 
// array index, rather than by "name".
//

BOOL bShared[MAXSHARED] = { FALSE } ;
int iShared[MAXSHARED] = { 0 } ;
__int64 i64Shared[MAXSHARED] = { 0 } ;
float fShared[MAXSHARED] = { 0.0 } ;
double dShared[MAXSHARED] = { 0.0 } ; 
char sShared[MAXSTRINGS][MAXSTRINGSIZE + 1] = { NULL } ;


//
// Now declare global arrays that will store the "names"
// of "named global variables".  
//

char sSharedBoolNames[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;
char sSharedIntNames[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;
char sSharedInt64Names[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;
char sSharedFloatNames[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;
char sSharedDoubleNames[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;
char sSharedStringNames[MAXSHAREDNAMED][MAXVARNAMELENGTH + 1] = { NULL } ;


//
// Finally, declare global arrays to hold the values
// of "named" global variables.
//

BOOL bSharedNamed[MAXSHAREDNAMED] = { FALSE } ;
int iSharedNamed[MAXSHAREDNAMED] = { 0 } ;
__int64 i64SharedNamed[MAXSHAREDNAMED] = { 0 } ;
float fSharedNamed[MAXSHAREDNAMED] = { 0.0 } ;
double dSharedNamed[MAXSHAREDNAMED] = { 0.0 } ;
char sSharedNamed[MAXSHAREDNAMED][MAXSTRINGSIZE + 1] = { NULL } ;

#pragma data_seg()  // End of shared data segment declarations


