#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class mkHarmonics : Indicator
	{
		#region Variables
        
		// Tolerance Parameters
		private double retTolerance    	   = 2.0;
		private double extTolerance    	   = 2.0;
		private double maxPrzTolerance 	   = 8.0;
		private double timeTolerance   	   = 30.0;
		// Brush Parameters
		private Brush  bullishPatternBrush = Brushes.Green;
		private Brush  bullishOutlineBrush = Brushes.Green;
		private Brush  bearishPatternBrush = Brushes.Red;
		private Brush  bearishOutlineBrush = Brushes.Red;
		private Brush  developPatternBrush = Brushes.Yellow;
		private Brush  developOutlineBrush = Brushes.Yellow;
		private int	   patternOpacity  	   = 2;
		private	Brush  textBrush       	   = Brushes.Gray;
		// Font Parameters
		private SimpleFont   textFont        	   = new SimpleFont("Arial", 7);
		private SimpleFont   labelFont           = new SimpleFont("Arial", 7);
		// Visibility Parameters
		private bool   showTargetArea      = true;
		private bool   showPrz			   = false;
		private bool   showDots            = true;
		private bool   showLabels          = true;
		private bool   showInfo        	   = true;
		private bool   showAlerts	   	   = true;
		private int    maxBars         	   = 500;
		// Pattern Parameters
		private bool   showBat		   	   = true;
		private bool   showAltBat	   	   = true;
		private bool   showGartley	   	   = true;
		private bool   showCrab  	   	   = true;
		private bool   showDeepCrab    	   = true;
		private bool   showButterfly   	   = true;
		private bool   showABCD		   	   = true;
		private bool   showFiveZero   	   = true;
		private bool   showCypher		   = true;
		private bool   showShark           = true;
		// Adcanced Parameters
		private bool   round2TickSize  	   = true;
		private int    minTicksImpulse 	   = 15;
		private double leftMargin		   = 0.30;
		private double minWidthDivider     = 0.25;
		private double maxWidthMulti	   = 4.0;
		
		// other vars
		private int    executions     	   = 0;
		private int    swingCount     	   = 0;
		
		// calculation vars
		private List<int> upperFractals,lowerFractals,allFractals;
		private int       upSwingBar,dnSwingBar,swingBar,lookBackBars,cnt,dev;
		private int       xInd,aInd,bInd,cInd,dInd;
		private int       posOne,posTwo;
		private double    dist,retr,exte,proj,rati,calc,tick,modu,exact,minRatio,maxRatio,upper,lower,min,max,lowerPrz,upperPrz,minRange,maxRange,tolerance,tolValue;
		private double    minRetValue,maxRetValue,minExtValue,maxExtValue,exactLowerPrz,exactUpperPrz;
		private double    exactRet_0500,exactRet_0786,exactRet_0886,exactRet_1130;
		private double    exactExt_1130,exactExt_1270,exactExt_1410,exactExt_1618,exactExt_2000,exactExt_2240,exactExt_2618;
		private double    minExt1270,maxExt1270,minExt1410,maxExt1410,distOne,distTwo;
		private bool      ab_exte_1130,bc_exte_2000,bc_exte_2240,xc_retr_0886,xc_retr_1000,bc_exte_1618,xc_retr_1130;
		private double    lastUpperFractalValue,lastLowerFractalValue,currHi,currLo;
		private bool      ab_ext_1130,ab_ext_1270,ab_ext_1410,ab_ext_1618,ab_ext_2000,ab_ext_2240,ab_ext_2618,ab_ext_3140,ab_ext_3618;
		private bool      isHi,isLo,left,right;
		private bool      bat,alt_bat,butterfly,crab,deep_crab,gartley,abcd;
		private bool      xa_retr_0382,xa_retr_0500,xa_retr_0618,xa_retr_0707,xa_retr_0786,xa_retr_0886;
		private bool      ab_retr_0382,ab_retr_0500,ab_retr_0618,ab_retr_0707,ab_retr_0786,ab_retr_0886;
		private bool      xa_exte_1130,xa_exte_1270,xa_exte_1410,xa_exte_1618,ab_exte_1618,ab_exte_2000,ab_exte_2240;
		private string    objName,objNameOne,objNameTwo,objNameDev,objNameOneDev;
		
		// alert vars
		private bool      alert         = false;
		private ArrayList alertPatterns = new ArrayList();
        
        #endregion
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Detect and Plot Harmonic Patterns";
				Name										= "mkHarmonics";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Hash, "Bullish");
				AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Hash, "Bearish");
				upperFractals = new List<int>();
				lowerFractals = new List<int>();
				allFractals   = new List<int>();
				
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if(CurrentBar == 0)
			{
				return;
			}
			
			if(showAlerts && alert)
			{
				Alert("newPattern", Priority.High, getAlertPatternString(), "Alert4.wav", 10, Brushes.White, Brushes.Black);
				
				alertPatterns.Clear();
				alert = false;
			}
			
			if(
			(Calculate == Calculate.OnBarClose && CurrentBar == Count-2) ||
			((Calculate != Calculate.OnBarClose && CurrentBar == Count-1 && executions < 1) || (State != State.Historical && IsFirstTickOfBar))
			) {
				Bullish[0] = (0);
				Bearish[0] = (0);
				
				executions++;
				
				cnt = 0;
				dev = 0;
				
				RemoveDrawObjects();
				
				findFractals();
				
				findBearishPattern();
				findBullishPattern();
				
				if(showInfo)
				{
					if(cnt > 0)
					{
						Draw.TextFixed(this, "output","\n "+swingCount+" Swings\n "+cnt+" ("+dev+") Pattern found",TextPosition.TopLeft,textBrush,textFont,Brushes.Transparent,Brushes.Transparent,0);
					}
					else
					{
						Draw.TextFixed(this, "output","\n "+swingCount+" Swings\n 0 Pattern found",TextPosition.TopLeft,textBrush,textFont,Brushes.Transparent,Brushes.Transparent,0);
					}
				}
			}
		}
		
		#region swings
		
		private void findFractals()
		{
			upperFractals.Clear();
			lowerFractals.Clear();
			allFractals.Clear();
			
			lastUpperFractalValue = 0.0;
			lastLowerFractalValue = 0.0;
			
			lookBackBars = (maxBars == 0) ? CurrentBar-15 : Math.Min(maxBars, CurrentBar-15);
			
			for(int i=lookBackBars;i>=3;i--)
			{
				if(isUpperFractal(i))
				{
					if(High[i] != lastUpperFractalValue)
					{
						upperFractals.Add(i);
						allFractals.Add(i);
						
						lastUpperFractalValue = High[i];
						lastLowerFractalValue = 0.0;
					}
				}
				if(isLowerFractal(i))
				{
					if(Low[i] != lastLowerFractalValue)
					{
						lowerFractals.Add(i);
						allFractals.Add(i);
						
						lastUpperFractalValue = 0.0;
						lastLowerFractalValue = Low[i];
					}
				}
			}
			
			swingCount = allFractals.Count;
			
			upperFractals.Sort();
			lowerFractals.Sort();
			allFractals.Sort();
		}
		
		private bool isUpperFractal(int index)
		{
			currHi = High[index];
			left   = false;
			right  = false;
			
			for(int i=index;i<Math.Min(CurrentBar,index+10);i++)
			{
				if(High[i] > currHi)
				{
					break;
				}
				if(High[i] < currHi && i > index+1)
				{
					left = true;
					break;
				}
			}
			
			if(left == true)
			{
				for(int i=index;i>=0;i--)
				{
					if(High[i] > currHi)
					{
						break;
					}
					if(High[i] < currHi && i < index-1)
					{
						right = true;
						break;
					}
				}
			}
			
			return (left && right);
		}
		
		private bool isLowerFractal(int index)
		{
			currLo = Low[index];
			left   = false;
			right  = false;
			
			for(int i=index;i<Math.Min(CurrentBar,index+10);i++)
			{
				if(Low[i] < currLo)
				{
					break;
				}
				if(Low[i] > currLo && i > index+1)
				{
					left = true;
					break;
				}
			}
			
			if(left == true)
			{
				for(int i=index;i>=0;i--)
				{
					if(Low[i] < currLo)
					{
						break;
					}
					if(Low[i] > currLo && i < index-1)
					{
						right = true;
						break;
					}
				}
			}
			
			return (left && right);
		}
		
		private bool isHiSwing(int index)
		{
			return upperFractals.Contains(allFractals[index]);
		}
		
		private bool isLoSwing(int index)
		{
			return lowerFractals.Contains(allFractals[index]);
		}
		
		private double getLowestLow(int indexOne, int indexTwo)
		{
			return findLowestLow(indexOne, indexTwo);
		}
		
		private double findLowestLow(int indexOne, int indexTwo)
		{
			double ll = Low[indexOne];
			
			for(int i=indexOne;i<=indexTwo;i++)
			{
				if(Low[i] < ll)
				{
					ll = Low[i];
				}
			}
			
			return ll;
		}
		
		private double getHighestHigh(int indexOne, int indexTwo)
		{
			return findHighestHigh(indexOne, indexTwo);
		}
		
		private double findHighestHigh(int indexOne, int indexTwo)
		{
			double hh = High[indexOne];
			
			for(int i=indexOne;i<=indexTwo;i++)
			{
				if(High[i] > hh)
				{
					hh = High[i];
				}
			}
			
			return hh;
		}
		
		#endregion
		
		#region fib
		
		private double getRetracement(double swing, double ratio)
		{
			return swing*ratio;
		}
		
		private double getExactTickValue(double swing, double ratio)
		{
			calc  = swing*ratio;
			modu  = calc%TickSize;
			tick  = Math.Floor(calc/TickSize);
			upper = TickSize-modu;
			lower = modu;
			exact = (upper < lower) ? (tick+1)*TickSize : tick*TickSize;
			
			return exact;
		}
		
		private bool isRetracement(double swing, double retracement, double ratio)
		{
			minRatio = ratio-((ratio/100)*retTolerance);
			maxRatio = ratio+((ratio/100)*retTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			retracement >= min &&
			retracement <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private bool isMinRetracement(double swing, double retracement, double ratio)
		{
			minRatio = ratio-((ratio/100)*retTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			if(
			retracement >= min
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private double getMinRetracement(double swing, double ratio)
		{
			minRatio = ratio-((ratio/100)*retTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			return min;
		}
		private double getMinRetracement(double swing, double ratio, double tolerance)
		{
			minRatio = ratio-((ratio/100)*tolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			return min;
		}
		
		private bool isMaxRetracement(double swing, double retracement, double ratio)
		{
			maxRatio = ratio+((ratio/100)*retTolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			retracement <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private double getMaxRetracement(double swing, double ratio)
		{
			maxRatio = ratio+((ratio/100)*retTolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			return max;
		}
		private double getMaxRetracement(double swing, double ratio, double tolerance)
		{
			maxRatio = ratio+((ratio/100)*tolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			return max;
		}
		
		private bool retracementIsBetween(double swing, double retracement, double minimumRatio, double maximumRatio)
		{
			minRatio = minimumRatio-((minimumRatio/100)*retTolerance);
			maxRatio = maximumRatio+((maximumRatio/100)*retTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			retracement >= min &&
			retracement <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private double getExtension(double swing, double ratio)
		{
			return swing*ratio;
		}
		
		private bool isExtension(double swing, double extension, double ratio)
		{
			minRatio = ratio-((ratio/100)*extTolerance);
			maxRatio = ratio+((ratio/100)*extTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			extension >= min &&
			extension <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private bool isMinExtension(double swing, double extension, double ratio)
		{
			minRatio = ratio-((ratio/100)*extTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			if(
			extension >= min
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private double getMinExtension(double swing, double ratio)
		{
			minRatio = ratio-((ratio/100)*extTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			return min;
		}
		private double getMinExtension(double swing, double ratio, double tolerance)
		{
			minRatio = ratio-((ratio/100)*tolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			
			return min;
		}
		
		private bool isMaxExtension(double swing, double extension, double ratio)
		{
			maxRatio = ratio+((ratio/100)*extTolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			extension <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private double getMaxExtension(double swing, double ratio)
		{
			maxRatio = ratio+((ratio/100)*extTolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			return max;
		}
		private double getMaxExtension(double swing, double ratio, double tolerance)
		{
			maxRatio = ratio+((ratio/100)*tolerance);
			
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			return max;
		}
		
		private bool extensionIsBetween(double swing, double extension, double minimumRatio, double maximumRatio)
		{
			minRatio = minimumRatio-((minimumRatio/100)*extTolerance);
			maxRatio = maximumRatio+((maximumRatio/100)*extTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			extension >= min &&
			extension <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		private bool isProjection(double swing, double projection, double ratio)
		{
			minRatio = ratio-((ratio/100)*extTolerance);
			maxRatio = ratio+((ratio/100)*extTolerance);
			
			min = (round2TickSize) ? getExactTickValue(swing, minRatio) : swing*minRatio;
			max = (round2TickSize) ? getExactTickValue(swing, maxRatio) : swing*maxRatio;
			
			if(
			projection >= min &&
			projection <= max
			) {
				return true;
			}
			else
			{
				return false;
			}
		}
		
		#endregion
		
		#region draw
		
		private void drawTriangle(string tag, int pos1, double val1, int pos2, double val2, int pos3, double val3, Brush areaBrush, Brush outlineBrush)
		{
			Draw.Triangle(this, tag,false,pos1,val1,pos2,val2,pos3,val3,outlineBrush,areaBrush,patternOpacity);
		}
		
		private void drawTempTriangle(string tag, int pos1, double val1, int pos2, double val2, int pos3, double val3)
		{
			Draw.Triangle(this, tag,false,pos1,val1,pos2,val2,pos3,val3,developOutlineBrush,developPatternBrush,patternOpacity);
		}
		
		private void drawTextCenter(string tag, string text, int pos, double val)
		{
			try
			{
				Draw.Text(this, tag,false,text,pos,val,0,textBrush,textFont,TextAlignment.Center,Brushes.Transparent,ChartControl.Properties.ChartBackground,10);
			} catch (Exception e) {}
		}
		
		private void drawTextNear(string tag, string text, int pos, double val)
		{
			try
			{
				Draw.Text(this, tag,false,text,pos,val,0,textBrush,textFont,TextAlignment.Left,Brushes.Transparent,ChartControl.Properties.ChartBackground,10);
			} catch (Exception e) {}
		}
		
		private void drawTextFar(string tag, string text, int pos, double val)
		{
			try
			{
				Draw.Text(this, tag,false,text,pos,val,0,textBrush,textFont,TextAlignment.Right,Brushes.Transparent,ChartControl.Properties.ChartBackground,10);
			} catch (Exception e) {}
		}
		
		private void drawLabel(string tag, string text, int pos, double val, int offset, Brush color)
		{
			if(showLabels)
			{
				Draw.Text(this, tag,false,text,pos,val,offset,color,labelFont,TextAlignment.Left,Brushes.Transparent,Brushes.Transparent,0);
			}
		}
		
		private void drawDot(string tag, int pos, double value, Brush color)
		{
			color = (showDots) ? color : Brushes.Transparent;
			Draw.Dot(this, tag,false,pos,value,color);
		}
		
		private void drawPrz(string tag, int pos, double upper, double lower, Brush color)
		{
			if(showPrz)
			{
				Draw.Rectangle(this, tag,false,pos+4,upper,pos-4,lower,color,Brushes.Transparent,0);
			}
		}
		
		private void drawTargetArea(string tag, int pos, double upper, double lower, Brush color)
		{
			if(showTargetArea)
			{
				Draw.Rectangle(this, tag,false,pos+4,upper,pos-4,lower,Brushes.Transparent,color,patternOpacity);
			}
		}
		
		private bool drawObjectExists(string tag)
		{
			bool exists = false;
			
			foreach(DrawingTool draw in DrawObjects)
			{
				if(draw.Tag == tag)
				{
					exists = true;
					break;
				}
			}
			
			return exists;
		}
		
		private string getLabel(bool bat_found, bool alt_bat_found, bool butterfly_found, bool crab_found, bool deep_crab_found, bool gartley_found, bool five_zero_found, bool cypher_found, bool shark_found)
		{
			string ret = "";
			
			if(bat_found)
			{
				ret = "Bat";
			}
			if(alt_bat_found)
			{
				if(bat_found)
				{
					ret += ", ";
				}
				ret += "Alt Bat";
			}
			if(butterfly_found)
			{
				if(bat_found || alt_bat_found)
				{
					ret += ", ";
				}
				ret += "Butterfly";
			}
			if(crab_found)
			{
				if(bat_found || alt_bat_found || butterfly_found)
				{
					ret += ", ";
				}
				ret += "Crab";
			}
			if(deep_crab_found)
			{
				if(bat_found || alt_bat_found || butterfly_found || crab_found)
				{
					ret += ", ";
				}
				ret += "Deep Crab";
			}
			if(gartley_found)
			{
				if(bat_found || alt_bat_found || butterfly_found || crab_found || deep_crab_found)
				{
					ret += ", ";
				}
				ret += "Gartley";
			}
			if(five_zero_found)
			{
				if(bat_found || alt_bat_found || butterfly_found || crab_found || deep_crab_found || gartley_found)
				{
					ret += ", ";
				}
				ret += "5-0";
			}
			if(cypher_found)
			{
				if(bat_found || alt_bat_found || butterfly_found || crab_found || deep_crab_found || gartley_found || five_zero_found)
				{
					ret += ", ";
				}
				ret += "Cypher";
			}
			if(shark_found)
			{
				if(bat_found || alt_bat_found || butterfly_found || crab_found || deep_crab_found || gartley_found || five_zero_found || cypher_found)
				{
					ret += ", ";
				}
				ret += "Shark";
			}
			
			return ret;
		}
		
		#endregion
		
		#region misc
		
		private string getAlertPatternString()
		{
			int    cur = 0;
			string ret = "";
			
			foreach(string pattern in alertPatterns)
			{
				cur++;
				
				ret += pattern;
				
				if(cur < alertPatterns.Count)
				{
					ret += ", ";
				}
			}
			
			return ret;
		}
		
		public override string ToString()
		{
			return Name;
		}
		
		#endregion
		
		
		#region findBearishPattern
		
		private void findBearishPattern()
		{
			int xPos = 0;
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double xVal = 0.0;
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// X
			for(xInd=allFractals.Count-1;xInd>=0;xInd--)
			{
				xPos = allFractals[xInd];
				
				bool bat_found		 = false;
				bool alt_bat_found	 = false;
				bool butterfly_found = false;
				bool crab_found		 = false;
				bool deep_crab_found = false;
				bool gartley_found	 = false;
				bool abcd_found		 = false;
				bool five_zero_found = false;
				bool cypher_found	 = false;
				bool shark_found     = false;
				
				if(isHiSwing(xInd))
				{
					xVal = High[xPos];
					
					bat_found 	    = findBearishBat(xInd, xPos, xVal);
					alt_bat_found   = findBearishAltBat(xInd, xPos, xVal);
					butterfly_found = findBearishButterfly(xInd, xPos, xVal);
					crab_found      = findBearishCrab(xInd, xPos, xVal);
					deep_crab_found = findBearishDeepCrab(xInd, xPos, xVal);
					gartley_found   = findBearishGartley(xInd, xPos, xVal);
					abcd_found      = findBearishABCD(xInd, xPos, xVal);
					five_zero_found = findBearishFiveZero(xInd, xPos, xVal);
					cypher_found	= findBearishCypher(xInd, xPos, xVal);
					shark_found     = findBearishShark(xInd, xPos, xVal);
				}
				
				if(
				bat_found		== true ||
				alt_bat_found	== true ||
				butterfly_found	== true ||
				crab_found		== true ||
				deep_crab_found	== true ||
				gartley_found	== true ||
				five_zero_found	== true ||
				cypher_found	== true ||
				shark_found		== true
				) {
					string label = getLabel(bat_found,alt_bat_found,butterfly_found,crab_found,deep_crab_found,gartley_found,five_zero_found,cypher_found,shark_found);
					drawLabel(xPos+"_bearish_label2",label,xPos,xVal,12,bearishPatternBrush);
				}
			}
		}
		
		#endregion
		
		#region findBearishBat
		
		private bool findBearishBat(int xInd, int xPos, double xVal)
		{
			if(!showBat)
			{
				return false;
			}
			
			bool batFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(aPos == bPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.500))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							ab_retr_0500 = isRetracement(dist,retr,0.500);
							
							if(
							!ab_retr_0382 &&
							!ab_retr_0500
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(getLowestLow(dPos,cPos) < cVal)
										{
											break;
										}
										
										if(dVal > xVal)
										{
											break;
										}
										
										maxRetValue = aVal+getMaxRetracement(xVal-aVal,0.886,maxPrzTolerance);
											
										if(getHighestHigh(dPos,cPos) > maxRetValue)
										{
											break;
										}
										
										objName    = "bearish_bat_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = aVal+getMinRetracement(xVal-aVal,0.886);
										maxRetValue = aVal+getMaxRetracement(xVal-aVal,0.886,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,1.618);
										exactUpperPrz = cVal+getExtension(bVal-cVal,2.618);
										exactRet_0886 = aVal+getRetracement(xVal-aVal,0.886);
										
										if(getHighestHigh(dPos,cPos) <= maxRetValue)
										{
											if(
											exactRet_0886 >= exactLowerPrz &&
											exactRet_0886 <= exactUpperPrz
											) {
												if(getHighestHigh(0,cPos) < minRetValue && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															batFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
														
														Draw.Line(this, objName+"xaRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaRet_0886_txt","0.886 XA | Bat",dPos+5,exactRet_0886);
													}
												}
												
												if(
												dVal <= xVal &&
												dVal >= minRetValue &&
												dVal <= maxRetValue &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bearishPatternBrush);
														
														Draw.Line(this, objName+"xaRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaRet_0886_txt","0.886 XA | Bat",dPos+5,exactRet_0886);
														
														cnt++;
														batFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Bat"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return batFound;
		}
		
		#endregion
		
		#region findBearishAltBat
		
		private bool findBearishAltBat(int xInd, int xPos, double xVal)
		{
			if(!showAltBat)
			{
				return false;
			}
			
			bool altBatFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.382))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							
							if(
							!ab_retr_0382
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(Low[dPos] < cVal)
										{
											break;
										}
										
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.130,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > maxExtValue)
										{
											break;
										}
										
										objName    = "bearish_alt_bat_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal+getMinExtension(xVal-aVal,1.130);
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.130,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,2.000);
										exactUpperPrz = cVal+getExtension(bVal-cVal,3.618);
										exactExt_1130 = aVal+getExtension(xVal-aVal,1.130);
										
										if(getHighestHigh(dPos,cPos) <= maxExtValue)
										{
											if(
											exactExt_1130 >= exactLowerPrz &&
											exactExt_1130 <= exactUpperPrz
											) {
												if(getHighestHigh(0,cPos) < minExtValue && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															altBatFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1130_txt","1.130 XA | Alt Bat",dPos+5,exactExt_1130);
													}
												}
												
												if(
												dVal >= xVal &&
												dVal >= minExtValue &&
												dVal <= maxExtValue &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bearishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1130_txt","1.130 XA | Alt Bat",dPos+5,exactExt_1130);
														
														cnt++;
														altBatFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Alt Bat"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return altBatFound;
		}
		
		#endregion
		
		#region findBearishButterfly
		
		private bool findBearishButterfly(int xInd, int xPos, double xVal)
		{
			if(!showButterfly)
			{
				return false;
			}
			
			bool butterflyFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.786))
							{
								break;
							}
							
							ab_retr_0786 = isRetracement(dist,retr,0.786);
							
							if(
							!ab_retr_0786
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(Low[dPos] < cVal)
										{
											break;
										}
										
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.410,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > maxExtValue)
										{
											break;
										}
										
										objName    = "bearish_butterfly_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExt1270 = aVal+getMinExtension(xVal-aVal,1.270);
										maxExt1270 = aVal+getMaxExtension(xVal-aVal,1.270,maxPrzTolerance);
										
										minExt1410 = aVal+getMinExtension(xVal-aVal,1.410);
										maxExt1410 = aVal+getMaxExtension(xVal-aVal,1.410,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,1.618);
										exactUpperPrz = cVal+getExtension(bVal-cVal,2.240);
										
										exactExt_1270 = aVal+getExtension(xVal-aVal,1.270);
										exactExt_1410 = aVal+getExtension(xVal-aVal,1.410);
										
										if(getHighestHigh(dPos,cPos) <= maxExt1410)
										{
											if((
											exactExt_1270 >= exactLowerPrz &&
											exactExt_1270 <= exactUpperPrz
											) || (
											exactExt_1410 >= exactLowerPrz &&
											exactExt_1410 <= exactUpperPrz
											)) {
												if(getHighestHigh(0,cPos) < minExt1270 && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															butterflyFound = true;
														}
														
														if(exactExt_1270 >= exactLowerPrz && exactExt_1270 <= exactUpperPrz)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1270, maxExt1270, developPatternBrush);
															
															Draw.Line(this, objNameDev+"xaExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,developPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objNameDev+"xaExt_1270_txt","1.270 XA | Butterfly",dPos+5,exactExt_1270);
														}
														if(exactExt_1410 >= exactLowerPrz && exactExt_1410 <= exactUpperPrz)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1410, maxExt1410, developPatternBrush);
															
															Draw.Line(this, objNameDev+"xaExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,developPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objNameDev+"xaExt_1410_txt","1.410 XA | Butterfly",dPos+5,exactExt_1410);
														}
													}
												}
												
												if(
												dVal >= xVal &&
												((dVal >= minExt1270 && dVal <= maxExt1270) || (dVal >= minExt1410 && dVal <= maxExt1410)) &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														if(dVal >= minExt1270 && dVal <= maxExt1270)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1270, maxExt1270, bearishPatternBrush);
															
															Draw.Line(this, objName+"xaExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,bearishPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objName+"xaExt_1270_txt","1.270 XA | Butterfly",dPos+5,exactExt_1270);
														}
														if(dVal >= minExt1410 && dVal <= maxExt1410)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1410, maxExt1410, bearishPatternBrush);
															
															Draw.Line(this, objName+"xaExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,bearishPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objName+"xaExt_1410_txt","1.410 XA | Butterfly",dPos+5,exactExt_1410);
														}
														
														cnt++;
														butterflyFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Butterfly"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return butterflyFound;
		}
		
		#endregion
		
		#region findBearishCrab
		
		private bool findBearishCrab(int xInd, int xPos, double xVal)
		{
			if(!showCrab)
			{
				return false;
			}
			
			bool crabFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							ab_retr_0500 = isRetracement(dist,retr,0.500);
							ab_retr_0618 = isRetracement(dist,retr,0.618);
							
							if(
							!ab_retr_0382 &&
							!ab_retr_0500 &&
							!ab_retr_0618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(getLowestLow(dPos,cPos) < cVal)
										{
											break;
										}
										
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.618,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > maxExtValue)
										{
											break;
										}
										
										objName    = "bearish_crab_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal+getMinExtension(xVal-aVal,1.618);
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.618,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,2.618);
										exactUpperPrz = cVal+getExtension(bVal-cVal,3.618);
										
										exactExt_1618 = aVal+getExtension(xVal-aVal,1.618);
										
										if(getHighestHigh(dPos,cPos) <= maxExtValue)
										{
											if(
											exactExt_1618 >= exactLowerPrz &&
											exactExt_1618 <= exactUpperPrz
											) {
												if(getHighestHigh(0,cPos) < minExtValue && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															crabFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaExt_1618_txt","1.618 XA | Crab",dPos+5,exactExt_1618);
													}
												}
												
												if(
												dVal >= xVal &&
												dVal >= minExtValue &&
												dVal <= maxExtValue &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bearishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1618_txt","1.618 XA | Crab",dPos+5,exactExt_1618);
														
														cnt++;
														crabFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Crab"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return crabFound;
		}
		
		#endregion
		
		#region findBearishDeepCrab
		
		private bool findBearishDeepCrab(int xInd, int xPos, double xVal)
		{
			if(!showDeepCrab)
			{
				return false;
			}
			
			bool deepCrabFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.886))
							{
								break;
							}
							
							ab_retr_0886 = isRetracement(dist,retr,0.886);
							
							if(
							!ab_retr_0886
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(Low[dPos] < cVal)
										{
											break;
										}
										
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.618,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > maxExtValue)
										{
											break;
										}
										
										objName    = "bearish_deep_crab_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal+getMinExtension(xVal-aVal,1.618);
										maxExtValue = aVal+getMaxExtension(xVal-aVal,1.618,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,2.000);
										exactUpperPrz = cVal+getExtension(bVal-cVal,3.618);
										
										exactExt_1618 = aVal+getExtension(xVal-aVal,1.618);
										
										if(getHighestHigh(dPos,cPos) <= maxExtValue)
										{
											if(
											exactExt_1618 >= exactLowerPrz &&
											exactExt_1618 <= exactUpperPrz
											) {
												if(getHighestHigh(0,cPos) < minExtValue && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															deepCrabFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaExt_1618_txt","1.618 XA | Deep Crab",dPos+5,exactExt_1618);
													}
												}
												
												if(
												dVal >= xVal &&
												dVal >= minExtValue &&
												dVal <= maxExtValue &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bearishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1618_txt","1.618 XA | Deep Crab",dPos+5,exactExt_1618);
														
														cnt++;
														deepCrabFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Deep Crab"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return deepCrabFound;
		}
		
		#endregion
		
		#region findBearishGartley
		
		private bool findBearishGartley(int xInd, int xPos, double xVal)
		{
			if(!showGartley)
			{
				return false;
			}
			
			bool gartleyFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							ab_retr_0618 = isRetracement(dist,retr,0.618);
							
							if(
							!ab_retr_0618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(Low[dPos] < cVal)
										{
											break;
										}
										
										if(dVal > xVal)
										{
											break;
										}
										
										maxRetValue = aVal+getMaxRetracement(xVal-aVal,0.786,maxPrzTolerance);
											
										if(getHighestHigh(dPos,cPos) > maxRetValue)
										{
											break;
										}
										
										objName    = "bearish_gartley_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = aVal+getMinRetracement(xVal-aVal,0.786);
										maxRetValue = aVal+getMaxRetracement(xVal-aVal,0.786,maxPrzTolerance);
										
										exactLowerPrz = cVal+getExtension(bVal-cVal,1.130);
										exactUpperPrz = cVal+getExtension(bVal-cVal,1.618);
										exactRet_0786 = aVal+getRetracement(xVal-aVal,0.786);
										
										if(getHighestHigh(dPos,cPos) <= maxRetValue)
										{
											if(
											exactRet_0786 >= exactLowerPrz &&
											exactRet_0786 <= exactUpperPrz
											) {
												if(getHighestHigh(0,cPos) < minRetValue && getLowestLow(0,cPos) >= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															gartleyFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaRet_0786_txt","0.786 XA | Gartley",dPos+5,exactRet_0786);
													}
												}
												
												if(
												dVal <= xVal &&
												dVal >= minRetValue &&
												dVal <= maxRetValue &&
												dVal == getHighestHigh(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bearishPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bearishPatternBrush);
														
														Draw.Line(this, objName+"xaRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaRet_0786_txt","0.786 XA | Gartley",dPos+5,exactRet_0786);
														
														cnt++;
														gartleyFound = true;
														
														if(dPos <= 1)
														{
															Bearish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bearish Gartley"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return gartleyFound;
		}
		
		#endregion
		
		#region findBearishABCD
		
		private bool findBearishABCD(int xInd, int xPos, double xVal)
		{
			if(!showABCD)
			{
				return false;
			}
			
			bool abcdFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal-aVal < (minTicksImpulse*TickSize))
							{
								continue;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							posOne = aPos;
							posTwo = aPos+(int)(Math.Ceiling((aPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(aVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < aVal)
									{
										break;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									if(aVal > getLowestLow(cPos,aPos))
									{
										break;
									}
									
									dist = bVal-aVal;
									retr = bVal-cVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									} 
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne  = aPos-bPos;
										distTwo  = cPos-dPos;
										
										minRange = distOne-((distOne/100)*timeTolerance);
										maxRange = distOne+((distOne/100)*timeTolerance);
										
										if(distTwo < minRange)
										{
											continue;
										}
										
										if(distTwo > maxRange)
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(Low[dPos] < cVal)
										{
											break;
										}
										
										maxExtValue = aVal+getMaxExtension(bVal-aVal,2.618,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > maxExtValue)
										{
											break;
										}
										
										objName    = "bearish_abcd_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+aVal+"_"+bVal+"_"+cVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										if(ab_retr_0382)
										{
											minExtValue = cVal+getMinExtension(bVal-aVal,2.240);
											maxExtValue = cVal+getMaxExtension(bVal-aVal,2.618);
											
											exactExt_2240 = cVal+getExtension(bVal-aVal,2.240);
											exactExt_2618 = cVal+getExtension(bVal-aVal,2.618);
										}
										if(ab_retr_0500)
										{
											minExtValue   = cVal+getMinExtension(bVal-aVal,2.000);
											maxExtValue   = cVal+getMaxExtension(bVal-aVal,2.000);
											
											exactExt_2000 = cVal+getExtension(bVal-aVal,2.000);
										}
										if(ab_retr_0618)
										{
											minExtValue   = cVal+getMinExtension(bVal-aVal,1.618);
											maxExtValue   = cVal+getMaxExtension(bVal-aVal,1.618);
											
											exactExt_1618 = cVal+getExtension(bVal-aVal,1.618);
										}
										if(ab_retr_0707)
										{
											minExtValue   = cVal+getMinExtension(bVal-aVal,1.410);
											maxExtValue   = cVal+getMaxExtension(bVal-aVal,1.410);
											
											exactExt_1410 = cVal+getExtension(bVal-aVal,1.410);
										}
										if(ab_retr_0786)
										{
											minExtValue   = cVal+getMinExtension(bVal-aVal,1.270);
											maxExtValue   = cVal+getMaxExtension(bVal-aVal,1.270);
											
											exactExt_1270 = cVal+getExtension(bVal-aVal,1.270);
										}
										if(ab_retr_0886)
										{
											minExtValue   = cVal+getMinExtension(bVal-aVal,1.130);
											maxExtValue   = cVal+getMaxExtension(bVal-aVal,1.130);
											
											exactExt_1130 = cVal+getExtension(bVal-aVal,1.130);
										}
										
										if(getHighestHigh(dPos,cPos) < maxExtValue)
										{
											if(getHighestHigh(0,cPos) < minExtValue && getLowestLow(0,cPos) >= cVal)
											{
												distOne  = aPos-bPos;
												distTwo  = cPos;
												
												minRange = distOne-((distOne/100)*timeTolerance);
												maxRange = distOne+((distOne/100)*timeTolerance);
												
												if(distTwo >= minRange && distTwo <= maxRange)
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,aPos,aVal,bPos,bVal,cPos,cVal);
														
														cnt++;
														dev++;
														abcdFound = true;
													}
													
													drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
													
													if(ab_retr_0382)
													{
														Draw.Line(this, objNameDev+"abExt_2240",false,dPos+4,exactExt_2240,dPos-4,exactExt_2240,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2240_txt","2.240 AB | AB=CD",dPos+5,exactExt_2240);
														
														Draw.Line(this, objNameDev+"abExt_2618",false,dPos+4,exactExt_2618,dPos-4,exactExt_2618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2618_txt","2.618 AB | AB=CD",dPos+5,exactExt_2618);
													}
													if(ab_retr_0500)
													{
														Draw.Line(this, objNameDev+"abExt_2000",false,dPos+4,exactExt_2000,dPos-4,exactExt_2000,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2000_txt","2.000 AB | AB=CD",dPos+5,exactExt_2000);
													}
													if(ab_retr_0618)
													{
														Draw.Line(this, objNameDev+"abExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1618_txt","1.618 AB | AB=CD",dPos+5,exactExt_1618);
													}
													if(ab_retr_0707)
													{
														Draw.Line(this, objNameDev+"abExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1410_txt","1.410 AB | AB=CD",dPos+5,exactExt_1410);
													}
													if(ab_retr_0786)
													{
														Draw.Line(this, objNameDev+"abExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1270_txt","1.270 AB | AB=CD",dPos+5,exactExt_1270);
													}
													if(ab_retr_0886)
													{
														Draw.Line(this, objNameDev+"abExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1130_txt","1.130 AB | AB=CD",dPos+5,exactExt_1130);
													}
													
													drawLabel(aPos+"_bearish_label1","AB=CD",aPos,aVal,-24,bearishPatternBrush);
												}
											}
											
											if(
											dVal >= bVal &&
											dVal >= minExtValue &&
											dVal <= maxExtValue &&
											dVal == getHighestHigh(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,aPos,aVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
														drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
														
														drawTriangle(objNameOne,aPos,aVal,bPos,bVal,cPos,cVal,bearishPatternBrush,bearishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
													}
													
													drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bearishPatternBrush);
													
													if(ab_retr_0382)
													{
														Draw.Line(this, objName+"abExt_2240",false,dPos+4,exactExt_2240,dPos-4,exactExt_2240,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2240_txt","2.240 AB | AB=CD",dPos+5,exactExt_2240);
														
														Draw.Line(this, objName+"abExt_2618",false,dPos+4,exactExt_2618,dPos-4,exactExt_2618,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2618_txt","2.618 AB | AB=CD",dPos+5,exactExt_2618);
													}
													if(ab_retr_0500)
													{
														Draw.Line(this, objName+"abExt_2000",false,dPos+4,exactExt_2000,dPos-4,exactExt_2000,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2000_txt","2.000 AB | AB=CD",dPos+5,exactExt_2000);
													}
													if(ab_retr_0618)
													{
														Draw.Line(this, objName+"abExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1618_txt","1.618 AB | AB=CD",dPos+5,exactExt_1618);
													}
													if(ab_retr_0707)
													{
														Draw.Line(this, objName+"abExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1410_txt","1.410 AB | AB=CD",dPos+5,exactExt_1410);
													}
													if(ab_retr_0786)
													{
														Draw.Line(this, objName+"abExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1270_txt","1.270 AB | AB=CD",dPos+5,exactExt_1270);
													}
													if(ab_retr_0886)
													{
														Draw.Line(this, objName+"abExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,bearishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1130_txt","1.130 AB | AB=CD",dPos+5,exactExt_1130);
													}
													
													cnt++;
													abcdFound = true;
													
													drawLabel(aPos+"_bearish_label1","AB=CD",aPos,aVal,-24,bearishPatternBrush);
													
													if(dPos <= 1)
													{
														Bearish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bearish AB=CD"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return abcdFound;
		}
		
		#endregion
		
		#region findBearishFiveZero
		
		private bool findBearishFiveZero(int xInd, int xPos, double xVal)
		{
			if(!showFiveZero)
			{
				return false;
			}
			
			bool fiveZeroFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(aPos == bPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal < xVal)
							{
								continue;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							exte = bVal-aVal;
							
							if(!isMinExtension(dist,exte,1.130))
							{
								continue;
							}
							
							if(!isMaxExtension(dist,exte,1.618))
							{
								break;
							}
							
							xa_exte_1130 = isExtension(dist,exte,1.130);
							xa_exte_1270 = isExtension(dist,exte,1.270);
							xa_exte_1410 = isExtension(dist,exte,1.410);
							xa_exte_1618 = isExtension(dist,exte,1.618);
							
							if(
							!xa_exte_1130 &&
							!xa_exte_1270 &&
							!xa_exte_1410 &&
							!xa_exte_1618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal > aVal)
									{
										continue;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									dist = bVal-aVal;
									exte = bVal-cVal;
									
									if(!isMinExtension(dist,exte,1.618))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,2.240))
									{
										break;
									}
									
									ab_exte_1618 = isRetracement(dist,exte,1.618);
									ab_exte_2000 = isRetracement(dist,exte,2.000);
									ab_exte_2240 = isRetracement(dist,exte,2.240);
									
									if(
									!ab_exte_1618 &&
									!ab_exte_2000 &&
									!ab_exte_2240
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(dVal > bVal)
										{
											break;
										}
										
										maxRetValue = cVal+getMaxRetracement(bVal-cVal,0.500,maxPrzTolerance);
											
										if(getHighestHigh(dPos,cPos) > maxRetValue)
										{
											break;
										}
										
										objName    = "bearish_five_zero_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal+getMinRetracement(bVal-cVal,0.500);
										maxRetValue = cVal+getMaxRetracement(bVal-cVal,0.500,maxPrzTolerance);
										
										exactRet_0500 = cVal+getRetracement(bVal-cVal,0.500);
										
										if(getHighestHigh(dPos,cPos) <= maxRetValue)
										{
											if(getHighestHigh(0,cPos) < minRetValue && getLowestLow(0,cPos) >= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														fiveZeroFound = true;
													}
													
													drawTargetArea(objName+"prz", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objName+"bcRet_0500",false,dPos+4,exactRet_0500,dPos-4,exactRet_0500,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"bcRet_0500_txt","0.500 BC | 5-0",dPos+5,exactRet_0500);
												}
											}
											
											if(
											dVal >= minRetValue &&
											dVal <= maxRetValue &&
											dVal == getHighestHigh(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
													}
													
													drawTargetArea(objName+"prz", dPos, minRetValue, maxRetValue, bearishPatternBrush);
													
													Draw.Line(this, objName+"bcRet_0500",false,dPos+4,exactRet_0500,dPos-4,exactRet_0500,bearishPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"bcRet_0500_txt","0.500 BC | 5-0",dPos+5,exactRet_0500);
													
													cnt++;
													fiveZeroFound = true;
													
													if(dPos <= 1)
													{
														Bearish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bearish 5-0"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return fiveZeroFound;
		}
		
		#endregion
		
		#region findBearishCypher
		
		private bool findBearishCypher(int xInd, int xPos, double xVal)
		{
			if(!showCypher)
			{
				return false;
			}
			
			bool cypherFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(aPos == bPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMinRetracement(dist,retr,0.382))
							{
								continue;
							}
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal > aVal)
									{
										continue;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									dist = xVal-aVal;
									exte = xVal-cVal;
									
									if(!isMinExtension(dist,exte,1.272))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,1.414))
									{
										break;
									}
									
									xa_exte_1270 = isExtension(dist,exte,1.272);
									xa_exte_1410 = isExtension(dist,exte,1.414);
									
									if(
									!xa_exte_1270 &&
									!xa_exte_1410
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(getLowestLow(dPos,cPos) < cVal)
										{
											break;
										}
										
										if(dVal > xVal)
										{
											break;
										}
										
										maxRetValue = cVal+getMaxRetracement(xVal-cVal,0.786,maxPrzTolerance);
											
										if(getHighestHigh(dPos,cPos) > maxRetValue)
										{
											break;
										}
										
										objName    = "bearish_cypher_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal+getMinRetracement(xVal-cVal,0.786);
										maxRetValue = cVal+getMaxRetracement(xVal-cVal,0.786,maxPrzTolerance);
										
										exactRet_0786 = cVal+getRetracement(xVal-cVal,0.786);
										
										if(getHighestHigh(dPos,cPos) <= maxRetValue)
										{
											if(getHighestHigh(0,cPos) < minRetValue && getLowestLow(0,cPos) >= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														cypherFound = true;
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0786_txt","0.786 XC | Cypher",dPos+5,exactRet_0786);
												}
											}
											
											if(
											dVal <= xVal &&
											dVal >= minRetValue &&
											dVal <= maxRetValue &&
											dVal == getHighestHigh(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bearishPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,bearishPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0786_txt","0.786 XC | Cypher",dPos+5,exactRet_0786);
													
													cnt++;
													cypherFound = true;
													
													if(dPos <= 1)
													{
														Bearish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bearish Cypher"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return cypherFound;
		}
		
		#endregion
		
		#region findBearishShark
		
		private bool findBearishShark(int xInd, int xPos, double xVal)
		{
			if(!showShark)
			{
				return false;
			}
			
			bool sharkFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal > xVal)
					{
						break;
					}
				}
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(xVal-aVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal > getLowestLow(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(aPos == bPos) continue;
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < aVal)
							{
								break;
							}
						}
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > xVal)
							{
								break;
							}
							
							if(bVal < getHighestHigh(bPos,aPos))
							{
								continue;
							}
							
							if(xVal < getHighestHigh(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							dist = xVal-aVal;
							retr = bVal-aVal;
							
							if(!isMinRetracement(dist,retr,0.236))
							{
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > bVal)
									{
										break;
									}
								}
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal > aVal)
									{
										continue;
									}
									
									if(cVal > getLowestLow(cPos,bPos))
									{
										continue;
									}
									
									dist = xVal-aVal;
									exte = xVal-cVal;
									
									if(!isMinExtension(dist,exte,1.130))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,1.618))
									{
										break;
									}
									
									xa_exte_1130 = isExtension(dist,exte,1.130);
									xa_exte_1270 = isExtension(dist,exte,1.270);
									xa_exte_1410 = isExtension(dist,exte,1.410);
									xa_exte_1618 = isExtension(dist,exte,1.618);
									
									if(
									!xa_exte_1130 &&
									!xa_exte_1270 &&
									!xa_exte_1410 &&
									!xa_exte_1618
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = High[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal > getLowestLow(dPos,cPos))
										{
											break;
										}
										
										if(getLowestLow(dPos,cPos) < cVal)
										{
											break;
										}
										
										dist = bVal-cVal;
										exte = dVal-cVal;
										
										if(!isMinExtension(dist,exte,1.618))
										{
											continue;
										}
										
										if(!isMaxExtension(dist,exte,2.240))
										{
											break;
										}
										
										bc_exte_1618 = isExtension(dist,exte,1.618);
										bc_exte_2000 = isExtension(dist,exte,2.000);
										bc_exte_2240 = isExtension(dist,exte,2.240);
										
										if(
										!bc_exte_1618 &&
										!bc_exte_2000 &&
										!bc_exte_2240
										) {
											continue;
										}
										
										dist = xVal-cVal;
										retr = dVal-cVal;
										
										if(!isMinRetracement(dist,retr,0.886))
										{
											continue;
										}
										
										if(!isMaxExtension(dist,retr,1.130))
										{
											break;
										}
										
										xc_retr_0886 = isRetracement(dist,exte,0.886);
										xc_retr_1130 = isRetracement(dist,exte,1.130);
										
										if(
										!xc_retr_0886 &&
										!xc_retr_1130
										) {
											continue;
										}
										
										maxRetValue = cVal+getMaxRetracement(xVal-cVal,1.130,maxPrzTolerance);
										maxExtValue = cVal+getMaxRetracement(bVal-cVal,2.240,maxPrzTolerance);
										
										if(getHighestHigh(dPos,cPos) > Math.Max(maxRetValue,maxExtValue))
										{
											break;
										}
										
										objName    = "bearish_shark_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bearish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bearish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal+getMinRetracement(xVal-cVal,0.886);
										maxRetValue = cVal+getMaxRetracement(xVal-cVal,1.130,maxPrzTolerance);
										
										exactRet_0886 = cVal+getRetracement(xVal-cVal,0.886);
										exactRet_1130 = cVal+getRetracement(xVal-cVal,1.130);
										
										if(getHighestHigh(dPos,cPos) <= maxRetValue)
										{
											if(getHighestHigh(0,cPos) < minRetValue && getLowestLow(0,cPos) >= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														sharkFound = true;
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0886_txt","0.886 XC | Shark",dPos+5,exactRet_0886);
													
													Draw.Line(this, objName+"xcRet_1130",false,dPos+4,exactRet_1130,dPos-4,exactRet_1130,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_1130_txt","1.130 XC | Shark",dPos+5,exactRet_1130);
												}
											}
											
											if(
											dVal >= minRetValue &&
											dVal <= maxRetValue &&
											dVal == getHighestHigh(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bearishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bearishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bearishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bearishPatternBrush,bearishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bearishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bearishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bearishPatternBrush,bearishOutlineBrush);
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bearishPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,bearishOutlineBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0886_txt","0.886 XC | Shark",dPos+5,exactRet_0886);
													
													Draw.Line(this, objName+"xcRet_1130",false,dPos+4,exactRet_1130,dPos-4,exactRet_1130,bearishOutlineBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_1130_txt","1.130 XC | Shark",dPos+5,exactRet_1130);
													
													cnt++;
													sharkFound = true;
													
													if(dPos <= 1)
													{
														Bearish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bearish Shark"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return sharkFound;
		}
		
		#endregion
		
		#region findBullishPattern
		
		private void findBullishPattern()
		{
			int xPos = 0;
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double xVal = 0.0;
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// X
			for(xInd=allFractals.Count-1;xInd>=0;xInd--)
			{
				xPos = allFractals[xInd];
				
				bool bat_found		 = false;
				bool alt_bat_found	 = false;
				bool butterfly_found = false;
				bool crab_found		 = false;
				bool deep_crab_found = false;
				bool gartley_found	 = false;
				bool abcd_found		 = false;
				bool five_zero_found = false;
				bool cypher_found	 = false;
				bool shark_found     = false;
				
				if(isLoSwing(xInd))
				{
					xVal = Low[xPos];
					
					bat_found 	    = findBullishBat(xInd, xPos, xVal);
					alt_bat_found   = findBullishAltBat(xInd, xPos, xVal);
					butterfly_found = findBullishButterfly(xInd, xPos, xVal);
					crab_found      = findBullishCrab(xInd, xPos, xVal);
					deep_crab_found = findBullishDeepCrab(xInd, xPos, xVal);
					gartley_found   = findBullishGartley(xInd, xPos, xVal);
					abcd_found      = findBullishABCD(xInd, xPos, xVal);
					five_zero_found = findBullishFiveZero(xInd, xPos, xVal);
					cypher_found	= findBullishCypher(xInd, xPos, xVal);
					shark_found     = findBullishShark(xInd, xPos, xVal);
				}
				
				if(
				bat_found		== true ||
				alt_bat_found	== true ||
				butterfly_found	== true ||
				crab_found		== true ||
				deep_crab_found	== true ||
				gartley_found	== true ||
				five_zero_found == true ||
				cypher_found    == true ||
				shark_found     == true
				) {
					string label = getLabel(bat_found,alt_bat_found,butterfly_found,crab_found,deep_crab_found,gartley_found,five_zero_found,cypher_found,shark_found);
					drawLabel(xPos+"_bullish_label2",label,xPos,xVal,-12,bullishPatternBrush);
				}
			}
		}
		
		#endregion
		
		#region findBullishBat
		
		private bool findBullishBat(int xInd, int xPos, double xVal)
		{
			if(!showBat)
			{
				return false;
			}
			
			bool batFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.500))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							ab_retr_0500 = isRetracement(dist,retr,0.500);
							
							if(
							!ab_retr_0382 &&
							!ab_retr_0500
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										if(dVal < xVal)
										{
											break;
										}
										
										maxRetValue = aVal-getMaxRetracement(aVal-xVal,0.886,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxRetValue)
										{
											break;
										}
										
										objName    = "bullish_bat_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = aVal-getMinRetracement(aVal-xVal,0.886);
										maxRetValue = aVal-getMaxRetracement(aVal-xVal,0.886,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,1.618);
										exactLowerPrz = cVal-getExtension(cVal-bVal,2.618);
										
										exactRet_0886 = aVal-getRetracement(aVal-xVal,0.886);
										
										if(getLowestLow(dPos,cPos) >= maxRetValue)
										{
											if(
											exactRet_0886 <= exactUpperPrz &&
											exactRet_0886 >= exactLowerPrz
											) {
												if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															batFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaRet_0886_txt","0.886 XA | Bat",dPos+5,exactRet_0886);
													}
												}
												
												if(
												dVal >= xVal &&
												dVal <= minRetValue &&
												dVal >= maxRetValue &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bullishPatternBrush);
														
														Draw.Line(this, objName+"xaRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaRet_0886_txt","0.886 XA | Bat",dPos+5,exactRet_0886);
														
														cnt++;
														batFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Bat"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return batFound;
		}
		
		#endregion
		
		#region findBullishAltBat
		
		private bool findBullishAltBat(int xInd, int xPos, double xVal)
		{
			if(!showAltBat)
			{
				return false;
			}
			
			bool altBatFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.382))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							
							if(
							!ab_retr_0382
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.130,maxPrzTolerance);
										
										if(getLowestLow(dPos,cPos) < maxExtValue)
										{
											break;
										}
										
										objName    = "bullish_alt_bat_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal-getMinExtension(aVal-xVal,1.130);
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.130,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,2.000);
										exactLowerPrz = cVal-getExtension(cVal-bVal,3.618);
										
										exactExt_1130 = aVal-getExtension(aVal-xVal,1.130);
										
										if(getLowestLow(dPos,cPos) >= maxExtValue)
										{
											if(
											exactExt_1130 <= exactUpperPrz &&
											exactExt_1130 >= exactLowerPrz
											) {
												if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															altBatFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaExt_1130_txt","1.130 XA | Alt Bat",dPos+5,exactExt_1130);
													}
												}
												
												if(
												dVal <= xVal &&
												dVal <= minExtValue &&
												dVal >= maxExtValue &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bullishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1130_txt","1.130 XA | Alt Bat",dPos+5,exactExt_1130);
														
														cnt++;
														altBatFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Alt Bat"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return altBatFound;
		}
		
		#endregion
		
		#region findBullishButterfly
		
		private bool findBullishButterfly(int xInd, int xPos, double xVal)
		{
			if(!showButterfly)
			{
				return false;
			}
			
			bool butterflyFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.786))
							{
								break;
							}
							
							ab_retr_0786 = isRetracement(dist,retr,0.786);
							
							if(
							!ab_retr_0786
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(dVal > High[dPos])
										{
											break;
										}
										
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.410,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxExtValue)
										{
											break;
										}
										
										objName    = "bullish_butterfly_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExt1270 = aVal-getMinExtension(aVal-xVal,1.270);
										maxExt1270 = aVal-getMaxExtension(aVal-xVal,1.270,maxPrzTolerance);
										
										minExt1410 = aVal-getMinExtension(aVal-xVal,1.410);
										maxExt1410 = aVal-getMaxExtension(aVal-xVal,1.410,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,1.618);
										exactLowerPrz = cVal-getExtension(cVal-bVal,2.240);
										
										exactExt_1270 = aVal-getExtension(aVal-xVal,1.270);
										exactExt_1410 = aVal-getExtension(aVal-xVal,1.410);
										
										if(getLowestLow(dPos,cPos) >= maxExt1410)
										{
											if((
											exactExt_1270 <= exactUpperPrz &&
											exactExt_1270 >= exactLowerPrz
											) || (
											exactExt_1410 <= exactUpperPrz &&
											exactExt_1410 >= exactLowerPrz
											)) {
												if(getLowestLow(0,cPos) > minExt1270 && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															butterflyFound = true;
														}
														
														if(exactExt_1270 <= exactUpperPrz && exactExt_1270 >= exactLowerPrz)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1270, maxExt1270, developPatternBrush);
															
															Draw.Line(this, objNameDev+"xaExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,developPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objNameDev+"xaExt_1270_txt","1.270 XA | Butterfly",dPos+5,exactExt_1270);
														}
														if(exactExt_1410 <= exactUpperPrz && exactExt_1410 >= exactLowerPrz)
														{
															drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
															drawTargetArea(objName+"target", dPos, minExt1410, maxExt1410, developPatternBrush);
															
															Draw.Line(this, objNameDev+"xaExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,developPatternBrush,DashStyleHelper.Solid,2);
															drawTextFar(objNameDev+"xaExt_1410_txt","1.410 XA | Butterfly",dPos+5,exactExt_1410);
														}
													}
												}
												
												if(
												dVal <= xVal &&
												((dVal <= minExt1270 && dVal >= maxExt1270) || (dVal <= minExt1410 && dVal >= maxExt1410)) &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														if(exactExt_1270 <= exactUpperPrz && exactExt_1270 >= exactLowerPrz)
														{
															if(dVal <= minExt1270 && dVal >= maxExt1270)
															{
																drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
																drawTargetArea(objName+"target", dPos, minExt1270, maxExt1270, bullishPatternBrush);
																
																Draw.Line(this, objName+"xaExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,bullishPatternBrush,DashStyleHelper.Solid,2);
																drawTextFar(objName+"xaExt_1270_txt","1.270 XA | Butterfly",dPos+5,exactExt_1270);
															}
														}
														if(exactExt_1410 <= exactUpperPrz && exactExt_1410 >= exactLowerPrz)
														{
															if(dVal <= minExt1410 && dVal >= maxExt1410)
															{
																drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
																drawTargetArea(objName+"target", dPos, minExt1410, maxExt1410, bullishPatternBrush);
																
																Draw.Line(this, objName+"xaExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,bullishPatternBrush,DashStyleHelper.Solid,2);
																drawTextFar(objName+"xaExt_1410_txt","1.410 XA | Butterfly",dPos+5,exactExt_1410);
															}
														}
														
														cnt++;
														butterflyFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Butterfly"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return butterflyFound;
		}
		
		#endregion
		
		#region findBullishCrab
		
		private bool findBullishCrab(int xInd, int xPos, double xVal)
		{
			if(!showCrab)
			{
				return false;
			}
			
			bool crabFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				

				if(xPos == aPos) continue;
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							ab_retr_0382 = isRetracement(dist,retr,0.382);
							ab_retr_0500 = isRetracement(dist,retr,0.500);
							ab_retr_0618 = isRetracement(dist,retr,0.618);
							
							if(
							!ab_retr_0382 &&
							!ab_retr_0500 &&
							!ab_retr_0618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.618,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxExtValue)
										{
											break;
										}
										
										objName    = "bullish_crab_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal-getMinExtension(aVal-xVal,1.618);
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.618,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,2.618);
										exactLowerPrz = cVal-getExtension(cVal-bVal,3.618);
										
										exactExt_1618 = aVal-getExtension(aVal-xVal,1.618);
										
										if(getLowestLow(dPos,cPos) >= maxExtValue)
										{
											if(
											exactExt_1618 <= exactUpperPrz &&
											exactExt_1618 >= exactLowerPrz
											) {
												if(getLowestLow(0,cPos) > minExtValue && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															crabFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaExt_1618_txt","1.618 XA | Crab",dPos+5,exactExt_1618);
													}
												}
												
												if(
												dVal <= xVal &&
												dVal <= minExtValue &&
												dVal >= maxExtValue &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bullishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1618_txt","1.618 XA | Crab",dPos+5,exactExt_1618);
														
														cnt++;
														crabFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Crab"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return crabFound;
		}
		
		#endregion
		
		#region findBullishDeepCrab
		
		private bool findBullishDeepCrab(int xInd, int xPos, double xVal)
		{
			if(!showDeepCrab)
			{
				return false;
			}
			
			bool deepCrabFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.886))
							{
								break;
							}
							
							ab_retr_0886 = isRetracement(dist,retr,0.886);
							
							if(
							!ab_retr_0886
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.618,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxExtValue)
										{
											break;
										}
										
										objName    = "bullish_deep_crab_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minExtValue = aVal-getMinExtension(aVal-xVal,1.618);
										maxExtValue = aVal-getMaxExtension(aVal-xVal,1.618,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,2.000);
										exactLowerPrz = cVal-getExtension(cVal-bVal,3.618);
										
										exactExt_1618 = aVal-getExtension(aVal-xVal,1.618);
										
										if(getLowestLow(dPos,cPos) >= maxExtValue)
										{
											if(
											exactExt_1618 <= exactUpperPrz &&
											exactExt_1618 >= exactLowerPrz
											) {
												if(getLowestLow(0,cPos) > minExtValue && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															deepCrabFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaExt_1618_txt","1.618 XA | Deep Crab",dPos+5,exactExt_1618);
													}
												}
												
												if(
												dVal <= xVal &&
												dVal <= minExtValue &&
												dVal >= maxExtValue &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
														drawTargetArea(objName+"target", dPos, minExtValue, maxExtValue, bullishPatternBrush);
														
														Draw.Line(this, objName+"xaExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaExt_1618_txt","1.618 XA | Deep Crab",dPos+5,exactExt_1618);
														
														cnt++;
														deepCrabFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Deep Crab"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return deepCrabFound;
		}
		
		#endregion
		
		#region findBullishGartley
		
		private bool findBullishGartley(int xInd, int xPos, double xVal)
		{
			if(!showGartley)
			{
				return false;
			}
			
			bool gartleyFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							ab_retr_0618 = isRetracement(dist,retr,0.618);
							
							if(
							!ab_retr_0618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										if(dVal < xVal)
										{
											break;
										}
										
										maxRetValue = aVal-getMaxRetracement(aVal-xVal,0.886,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxRetValue)
										{
											break;
										}
										
										objName    = "bullish_gartley_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = aVal-getMinRetracement(aVal-xVal,0.786);
										maxRetValue = aVal-getMaxRetracement(aVal-xVal,0.786,maxPrzTolerance);
										
										exactUpperPrz = cVal-getExtension(cVal-bVal,1.130);
										exactLowerPrz = cVal-getExtension(cVal-bVal,1.618);
										
										exactRet_0786 = aVal-getRetracement(aVal-xVal,0.786);
										
										if(getLowestLow(dPos,cPos) >= maxRetValue)
										{
											if(
											exactRet_0786 <= exactUpperPrz &&
											exactRet_0786 >= exactLowerPrz
											) {
												if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
												{
													distOne = xPos-bPos;
													distTwo = bPos;
													
													if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
													{
														objNameDev    = objName+"_dev";
														objNameOneDev = objNameOne+"_dev";
														
														if(!drawObjectExists(objNameDev))
														{
															Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
															
															drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
															drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
															drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
															
															drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
															
															drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
															
															cnt++;
															dev++;
															gartleyFound = true;
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, developPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
														
														Draw.Line(this, objNameDev+"xaRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"xaRet_0786_txt","0.786 XA | Gartley",dPos+5,exactRet_0786);
													}
												}
												
												if(
												dVal >= xVal &&
												dVal <= minRetValue &&
												dVal >= maxRetValue &&
												dVal == getLowestLow(dPos,cPos)
												) {
													if(!drawObjectExists(objName))
													{
														Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
														
														if(!drawObjectExists(objNameOne))
														{
															drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
															drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
															drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
															
															drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
														}
														if(!drawObjectExists(objNameTwo))
														{
															drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
															drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
															
															drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
														}
														
														drawPrz(objName+"prz", dPos, exactLowerPrz, exactUpperPrz, bullishPatternBrush);
														drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bullishPatternBrush);
														
														Draw.Line(this, objName+"xaRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"xaRet_0786_txt","0.786 XA | Gartley",dPos+5,exactRet_0786);
														
														cnt++;
														gartleyFound = true;
														
														if(dPos <= 1)
														{
															Bullish[0] = (1);
														}
														
														if(dPos == 0)
														{
															alertPatterns.Add((string)("Bullish Gartley"));
															alert = true;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return gartleyFound;
		}
		
		#endregion
		
		#region findBullishABCD
		
		private bool findBullishABCD(int xInd, int xPos, double xVal)
		{
			if(!showABCD)
			{
				return false;
			}
			
			bool abcdFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(aVal-bVal < (minTicksImpulse*TickSize))
							{
								continue;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							posOne = aPos;
							posTwo = aPos+(int)(Math.Ceiling((aPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(aVal < getHighestHigh(posOne,posTwo))
							{
								break;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal > aVal)
									{
										break;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									if(aVal < getHighestHigh(cPos,aPos))
									{
										break;
									}
									
									dist = aVal-bVal;
									retr = cVal-bVal;
									
									if(!isMinRetracement(dist,retr,0.382))
									{
										continue;
									}
									
									if(!isMaxRetracement(dist,retr,0.886))
									{
										break;
									}
									
									ab_retr_0382 = isRetracement(dist,retr,0.382);
									ab_retr_0500 = isRetracement(dist,retr,0.500);
									ab_retr_0618 = isRetracement(dist,retr,0.618);
									ab_retr_0707 = isRetracement(dist,retr,0.707);
									ab_retr_0786 = isRetracement(dist,retr,0.786);
									ab_retr_0886 = isRetracement(dist,retr,0.886);
									
									if(
									!ab_retr_0382 &&
									!ab_retr_0500 &&
									!ab_retr_0618 &&
									!ab_retr_0707 &&
									!ab_retr_0786 &&
									!ab_retr_0886
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
													
										dVal = Low[dPos];
										
										distOne  = aPos-bPos;
										distTwo  = cPos-dPos;
										
										minRange = distOne-((distOne/100)*timeTolerance);
										maxRange = distOne+((distOne/100)*timeTolerance);
										
										if(distTwo < minRange)
										{
											continue;
										}
										
										if(distTwo > maxRange)
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										maxExtValue = aVal-getMaxExtension(aVal-bVal,2.618,maxPrzTolerance);
										
										if(getLowestLow(dPos,cPos) < maxExtValue)
										{
											break;
										}
										
										objName    = "bullish_abcd_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+aVal+"_"+bVal+"_"+cVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										if(ab_retr_0382)
										{
											minExtValue = cVal-getMinExtension(aVal-bVal,2.240);
											maxExtValue = cVal-getMaxExtension(aVal-bVal,2.618);
											
											exactExt_2240 = cVal-getExtension(aVal-bVal,2.240);
											exactExt_2618 = cVal-getExtension(aVal-bVal,2.618);
										}
										if(ab_retr_0500)
										{
											minExtValue   = cVal-getMinExtension(aVal-bVal,2.000);
											maxExtValue   = cVal-getMaxExtension(aVal-bVal,2.000);
											
											exactExt_2000 = cVal-getExtension(aVal-bVal,2.000);
										}
										if(ab_retr_0618)
										{
											minExtValue   = cVal-getMinExtension(aVal-bVal,1.618);
											maxExtValue   = cVal-getMaxExtension(aVal-bVal,1.618);
											
											exactExt_1618 = cVal-getExtension(aVal-bVal,1.618);
										}
										if(ab_retr_0707)
										{
											minExtValue   = cVal-getMinExtension(aVal-bVal,1.410);
											maxExtValue   = cVal-getMaxExtension(aVal-bVal,1.410);
											
											exactExt_1410 = cVal-getExtension(aVal-bVal,1.410);
										}
										if(ab_retr_0786)
										{
											minExtValue   = cVal-getMinExtension(aVal-bVal,1.270);
											maxExtValue   = cVal-getMaxExtension(aVal-bVal,1.270);
											
											exactExt_1270 = cVal-getExtension(aVal-bVal,1.270);
										}
										if(ab_retr_0886)
										{
											minExtValue   = cVal-getMinExtension(aVal-bVal,1.130);
											maxExtValue   = cVal-getMaxExtension(aVal-bVal,1.130);
											
											exactExt_1130 = cVal-getExtension(aVal-bVal,1.130);
										}
										
										if(getLowestLow(dPos,cPos) > maxExtValue)
										{
											if(getLowestLow(0,cPos) > minExtValue && getHighestHigh(0,cPos) <= cVal)
											{
												distOne  = aPos-bPos;
												distTwo  = cPos;
												
												minRange = distOne-((distOne/100)*timeTolerance);
												maxRange = distOne+((distOne/100)*timeTolerance);
												
												if(distTwo >= minRange && distTwo <= maxRange)
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,aPos,aVal,bPos,bVal,cPos,cVal);
														
														cnt++;
														dev++;
														abcdFound = true;
													}
													
													drawTargetArea(objNameDev+"prz", dPos, minExtValue, maxExtValue, developPatternBrush);
													
													if(ab_retr_0382)
													{
														Draw.Line(this, objNameDev+"abExt_2240",false,dPos+4,exactExt_2240,dPos-4,exactExt_2240,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2240_txt","2.240 AB | AB=CD",dPos+5,exactExt_2240);
														
														Draw.Line(this, objNameDev+"abExt_2618",false,dPos+4,exactExt_2618,dPos-4,exactExt_2618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2618_txt","2.618 AB | AB=CD",dPos+5,exactExt_2618);
													}
													if(ab_retr_0500)
													{
														Draw.Line(this, objNameDev+"abExt_2000",false,dPos+4,exactExt_2000,dPos-4,exactExt_2000,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_2000_txt","2.000 AB | AB=CD",dPos+5,exactExt_2000);
													}
													if(ab_retr_0618)
													{
														Draw.Line(this, objNameDev+"abExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1618_txt","1.618 AB | AB=CD",dPos+5,exactExt_1618);
													}
													if(ab_retr_0707)
													{
														Draw.Line(this, objNameDev+"abExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1410_txt","1.410 AB | AB=CD",dPos+5,exactExt_1410);
													}
													if(ab_retr_0786)
													{
														Draw.Line(this, objNameDev+"abExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1270_txt","1.270 AB | AB=CD",dPos+5,exactExt_1270);
													}
													if(ab_retr_0886)
													{
														Draw.Line(this, objNameDev+"abExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,developPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objNameDev+"abExt_1130_txt","1.130 AB | AB=CD",dPos+5,exactExt_1130);
													}
													
													drawLabel(aPos+"_bullish_label1","AB=CD",aPos,aVal,24,bullishPatternBrush);
												}
											}
											
											if(
											dVal <= bVal &&
											dVal <= minExtValue &&
											dVal >= maxExtValue &&
											dVal == getLowestLow(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,aPos,aVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
														drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
														
														drawTriangle(objNameOne,aPos,aVal,bPos,bVal,cPos,cVal,bullishPatternBrush,bullishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
													}
													
													drawTargetArea(objName+"prz", dPos, minExtValue, maxExtValue, bullishPatternBrush);
													
													if(ab_retr_0382)
													{
														Draw.Line(this, objName+"abExt_2240",false,dPos+4,exactExt_2240,dPos-4,exactExt_2240,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2240_txt","2.240 AB | AB=CD",dPos+5,exactExt_2240);
														
														Draw.Line(this, objName+"abExt_2618",false,dPos+4,exactExt_2618,dPos-4,exactExt_2618,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2618_txt","2.618 AB | AB=CD",dPos+5,exactExt_2618);
													}
													if(ab_retr_0500)
													{
														Draw.Line(this, objName+"abExt_2000",false,dPos+4,exactExt_2000,dPos-4,exactExt_2000,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_2000_txt","2.000 AB | AB=CD",dPos+5,exactExt_2000);
													}
													if(ab_retr_0618)
													{
														Draw.Line(this, objName+"abExt_1618",false,dPos+4,exactExt_1618,dPos-4,exactExt_1618,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1618_txt","1.618 AB | AB=CD",dPos+5,exactExt_1618);
													}
													if(ab_retr_0707)
													{
														Draw.Line(this, objName+"abExt_1410",false,dPos+4,exactExt_1410,dPos-4,exactExt_1410,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1410_txt","1.410 AB | AB=CD",dPos+5,exactExt_1410);
													}
													if(ab_retr_0786)
													{
														Draw.Line(this, objName+"abExt_1270",false,dPos+4,exactExt_1270,dPos-4,exactExt_1270,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1270_txt","1.270 AB | AB=CD",dPos+5,exactExt_1270);
													}
													if(ab_retr_0886)
													{
														Draw.Line(this, objName+"abExt_1130",false,dPos+4,exactExt_1130,dPos-4,exactExt_1130,bullishPatternBrush,DashStyleHelper.Solid,2);
														drawTextFar(objName+"abExt_1130_txt","1.130 AB | AB=CD",dPos+5,exactExt_1130);
													}
													
													cnt++;
													abcdFound = true;
													
													drawLabel(aPos+"_bullish_label1","AB=CD",aPos,aVal,24,bullishPatternBrush);
													
													if(dPos <= 1)
													{
														Bullish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bullish AB=CD"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return abcdFound;
		}
		
		#endregion
		
		#region findBullishFiveZero
		
		private bool findBullishFiveZero(int xInd, int xPos, double xVal)
		{
			if(!showFiveZero)
			{
				return false;
			}
			
			bool fiveZeroFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(aPos == bPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal > xVal)
							{
								continue;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							exte = aVal-bVal;
							
							if(!isMinExtension(dist,exte,1.130))
							{
								continue;
							}
							
							if(!isMaxExtension(dist,exte,1.618))
							{
								break;
							}
							
							xa_exte_1130 = isExtension(dist,exte,1.130);
							xa_exte_1270 = isExtension(dist,exte,1.270);
							xa_exte_1410 = isExtension(dist,exte,1.410);
							xa_exte_1618 = isExtension(dist,exte,1.618);
							
							if(
							!xa_exte_1130 &&
							!xa_exte_1270 &&
							!xa_exte_1410 &&
							!xa_exte_1618
							) {
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal < aVal)
									{
										continue;
									}
									
									if(cVal < getHighestHigh(cPos,bPos))
									{
										continue;
									}
									
									dist = aVal-bVal;
									exte = cVal-bVal;
									
									if(!isMinExtension(dist,exte,1.618))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,2.240))
									{
										break;
									}
									
									ab_exte_1618 = isRetracement(dist,exte,1.618);
									ab_exte_2000 = isRetracement(dist,exte,2.000);
									ab_exte_2240 = isRetracement(dist,exte,2.240);
									
									if(
									!ab_exte_1618 &&
									!ab_exte_2000 &&
									!ab_exte_2240
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(dVal < bVal)
										{
											break;
										}
										
										maxRetValue = cVal-getMaxRetracement(cVal-bVal,0.500,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxRetValue)
										{
											break;
										}
										
										objName    = "bullish_five_zero_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal-getMinRetracement(cVal-bVal,0.500);
										maxRetValue = cVal-getMaxRetracement(cVal-bVal,0.500,maxPrzTolerance);
										
										exactRet_0500 = cVal-getRetracement(cVal-bVal,0.500);
										
										if(getLowestLow(dPos,cPos) >= maxRetValue)
										{
											if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														fiveZeroFound = true;
													}
													
													drawTargetArea(objName+"prz", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objName+"bcRet_0500",false,dPos+4,exactRet_0500,dPos-4,exactRet_0500,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"bcRet_0500_txt","0.500 BC | 5-0",dPos+5,exactRet_0500);
												}
											}
											
											if(
											dVal <= minRetValue &&
											dVal >= maxRetValue &&
											dVal == getLowestLow(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
													}
													
													drawTargetArea(objName+"prz", dPos, minRetValue, maxRetValue, bullishPatternBrush);
													
													Draw.Line(this, objName+"bcRet_0500",false,dPos+4,exactRet_0500,dPos-4,exactRet_0500,bullishOutlineBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"bcRet_0500_txt","0.500 BC | 5-0",dPos+5,exactRet_0500);
													
													cnt++;
													fiveZeroFound = true;
													
													if(dPos <= 1)
													{
														Bullish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bullish 5-0"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return fiveZeroFound;
		}
		
		#endregion
		
		#region findBullishCypher
		
		private bool findBullishCypher(int xInd, int xPos, double xVal)
		{
			if(!showCypher)
			{
				return false;
			}
			
			bool cypherFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMinRetracement(dist,retr,0.382))
							{
								continue;
							}
							
							if(!isMaxRetracement(dist,retr,0.618))
							{
								break;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal < aVal)
									{
										continue;
									}
									
									if(cVal < getHighestHigh(cPos,aPos))
									{
										continue;
									}
									
									dist = aVal-xVal;
									exte = cVal-xVal;
									
									if(!isMinExtension(dist,exte,1.272))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,1.414))
									{
										break;
									}
									
									xa_exte_1270 = isExtension(dist,exte,1.272);
									xa_exte_1410 = isExtension(dist,exte,1.414);
									
									if(
									!xa_exte_1270 &&
									!xa_exte_1410
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(High[dPos] > cVal)
										{
											break;
										}
										
										if(dVal < xVal)
										{
											break;
										}
										
										maxRetValue = cVal-getMaxRetracement(cVal-xVal,0.786,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < maxRetValue)
										{
											break;
										}
										
										objName    = "bullish_cypher_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal-getMinRetracement(cVal-xVal,0.786);
										maxRetValue = cVal-getMaxRetracement(cVal-xVal,0.786,maxPrzTolerance);
										
										exactRet_0786 = cVal-getRetracement(cVal-xVal,0.786);
										
										if(getLowestLow(dPos,cPos) >= maxRetValue)
										{
											if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														cypherFound = true;
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objNameDev+"xcRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objNameDev+"xcRet_0786_txt","0.786 XC | Cypher",dPos+5,exactRet_0786);
												}
											}
											
											if(
											dVal >= xVal &&
											dVal <= minRetValue &&
											dVal >= maxRetValue &&
											dVal == getLowestLow(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bullishPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0786",false,dPos+4,exactRet_0786,dPos-4,exactRet_0786,bullishPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0786_txt","0.786 XC | Cypher",dPos+5,exactRet_0786);
													
													cnt++;
													cypherFound = true;
													
													if(dPos <= 1)
													{
														Bullish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bullish Cypher"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return cypherFound;
		}
		
		#endregion
		
		#region findBullishShark
		
		private bool findBullishShark(int xInd, int xPos, double xVal)
		{
			if(!showShark)
			{
				return false;
			}
			
			bool sharkFound = false;
			
			int aPos = 0;
			int bPos = 0;
			int cPos = 0;
			int dPos = 0;
			
			double aVal = 0.0;
			double bVal = 0.0;
			double cVal = 0.0;
			double dVal = 0.0;
			
			// A
			for(aInd=xInd-1;aInd>=0;aInd--)
			{
				aPos = allFractals[aInd];
				
				if(xPos == aPos) continue;
				
				if(isLoSwing(aInd))
				{
					aVal = Low[aPos];
					
					if(aVal < xVal)
					{
						break;
					}
				}
				
				if(isHiSwing(aInd))
				{
					aVal = High[aPos];
					
					if(aVal-xVal < (minTicksImpulse*TickSize))
					{
						continue;
					}
					
					if(aVal < getHighestHigh(aPos,xPos))
					{
						continue;
					}
					
					// B
					for(bInd=aInd-1;bInd>=0;bInd--)
					{
						bPos = allFractals[bInd];
						
						if(bPos == aPos) continue;
						
						if(isHiSwing(bInd))
						{
							bVal = High[bPos];
							
							if(bVal > aVal)
							{
								break;
							}
						}
						
						if(isLoSwing(bInd))
						{
							bVal = Low[bPos];
							
							if(bVal < xVal)
							{
								break;
							}
							
							if(bVal > getLowestLow(bPos,aPos))
							{
								continue;
							}
							
							if(xVal > getLowestLow(bPos,xPos))
							{
								break;
							}
							
							posOne = xPos;
							posTwo = xPos+(int)(Math.Ceiling((xPos-bPos)*leftMargin));
							posTwo = Math.Min(posTwo,CurrentBar);
							
							if(xVal > getLowestLow(posOne,posTwo))
							{
								break;
							}
							
							dist = aVal-xVal;
							retr = aVal-bVal;
							
							if(!isMinRetracement(dist,retr,0.236))
							{
								continue;
							}
							
							// C
							for(cInd=bInd-1;cInd>=0;cInd--)
							{
								cPos = allFractals[cInd];
								
								if(cPos == bPos) continue;
								
								if(isLoSwing(cInd))
								{
									cVal = Low[cPos];
									
									if(cVal < bVal)
									{
										break;
									}
								}
								
								if(isHiSwing(cInd))
								{
									cVal = High[cPos];
									
									if(cVal < aVal)
									{
										continue;
									}
									
									if(cVal < getHighestHigh(cPos,aPos))
									{
										continue;
									}
									
									dist = aVal-xVal;
									exte = cVal-xVal;
									
									if(!isMinExtension(dist,exte,1.130))
									{
										continue;
									}
									
									if(!isMaxExtension(dist,exte,1.618))
									{
										break;
									}
									
									xa_exte_1130 = isExtension(dist,exte,1.130);
									xa_exte_1270 = isExtension(dist,exte,1.270);
									xa_exte_1410 = isExtension(dist,exte,1.410);
									xa_exte_1618 = isExtension(dist,exte,1.618);
									
									if(
									!xa_exte_1130 &&
									!xa_exte_1270 &&
									!xa_exte_1410 &&
									!xa_exte_1618
									) {
										continue;
									}
									
									// D
									for(dPos=cPos-1;dPos>=0;dPos--)
									{
										if(dPos == cPos) continue;
										
										dVal = Low[dPos];
										
										distOne = xPos-bPos;
										distTwo = bPos-dPos;
										
										if(distTwo < Math.Ceiling(distOne*minWidthDivider))
										{
											continue;
										}
										
										if(distTwo > Math.Ceiling(distOne*maxWidthMulti))
										{
											break;
										}
										
										if(cVal < getHighestHigh(dPos,cPos))
										{
											break;
										}
										
										if(getHighestHigh(dPos,cPos) > cVal)
										{
											break;
										}
										
										dist = cVal-bVal;
										exte = cVal-dVal;
										
										if(!isMinExtension(dist,exte,1.618))
										{
											continue;
										}
										
										if(!isMaxExtension(dist,exte,2.240))
										{
											break;
										}
										
										bc_exte_1618 = isExtension(dist,exte,1.618);
										bc_exte_2000 = isExtension(dist,exte,2.000);
										bc_exte_2240 = isExtension(dist,exte,2.240);
										
										if(
										!bc_exte_1618 &&
										!bc_exte_2000 &&
										!bc_exte_2240
										) {
											continue;
										}
										
										dist = cVal-xVal;
										retr = cVal-dVal;
										
										if(!isMinRetracement(dist,retr,0.886))
										{
											continue;
										}
										
										if(!isMaxExtension(dist,retr,1.130))
										{
											break;
										}
										
										xc_retr_0886 = isRetracement(dist,exte,0.886);
										xc_retr_1130 = isRetracement(dist,exte,1.130);
										
										if(
										!xc_retr_0886 &&
										!xc_retr_1130
										) {
											continue;
										}
										
										maxRetValue = cVal-getMaxRetracement(cVal-xVal,1.130,maxPrzTolerance);
										maxExtValue = cVal-getMaxRetracement(cVal-bVal,2.240,maxPrzTolerance);
											
										if(getLowestLow(dPos,cPos) < Math.Min(maxRetValue,maxExtValue))
										{
											break;
										}
										
										objName    = "bullish_shark_"+xVal+"_"+aVal+"_"+bVal+"_"+cVal;
										objNameOne = "bullish_"+xVal+"_"+aVal+"_"+bVal;
										objNameTwo = "bullish_"+bVal+"_"+cVal+"_"+dVal;
										
										minRetValue = cVal-getMinRetracement(cVal-xVal,0.886);
										maxRetValue = cVal-getMaxRetracement(cVal-xVal,1.130,maxPrzTolerance);
										
										exactRet_0886 = cVal-getRetracement(cVal-xVal,0.886);
										exactRet_1130 = cVal-getRetracement(cVal-xVal,1.130);
										
										if(getLowestLow(dPos,cPos) >= maxRetValue)
										{
											if(getLowestLow(0,cPos) > minRetValue && getHighestHigh(0,cPos) <= cVal)
											{
												distOne = xPos-bPos;
												distTwo = bPos;
												
												if(distTwo >= Math.Ceiling(distOne*minWidthDivider) && distTwo <= Math.Ceiling(distOne*maxWidthMulti))
												{
													objNameDev    = objName+"_dev";
													objNameOneDev = objNameOne+"_dev";
													
													if(!drawObjectExists(objNameDev))
													{
														Draw.Dot(this, objNameDev,false,xPos,xVal,Brushes.Transparent);
														
														drawDot(objNameDev+"xDot",xPos,xVal,developPatternBrush);
														drawDot(objNameDev+"aDot",aPos,aVal,developPatternBrush);
														drawDot(objNameDev+"bDot",bPos,bVal,developPatternBrush);
														
														drawTempTriangle(objNameOneDev,xPos,xVal,aPos,aVal,bPos,bVal);
														
														drawDot(objNameDev+"cDot",cPos,cVal,developPatternBrush);
														
														cnt++;
														dev++;
														sharkFound = true;
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, developPatternBrush);
													
													Draw.Line(this, objNameDev+"xcRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objNameDev+"xcRet_0886_txt","0.886 XC | Shark",dPos+5,exactRet_0886);
													
													Draw.Line(this, objNameDev+"xcRet_1130",false,dPos+4,exactRet_1130,dPos-4,exactRet_1130,developPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objNameDev+"xcRet_1130_txt","1.130 XC | Shark",dPos+5,exactRet_1130);
												}
											}
											
											if(
											dVal <= minRetValue &&
											dVal >= maxRetValue &&
											dVal == getLowestLow(dPos,cPos)
											) {
												if(!drawObjectExists(objName))
												{
													Draw.Dot(this, objName,false,xPos,xVal,Brushes.Transparent);
													
													if(!drawObjectExists(objNameOne))
													{
														drawDot(objName+"xDot",xPos,xVal,bullishPatternBrush);
														drawDot(objName+"aDot",aPos,aVal,bullishPatternBrush);
														drawDot(objName+"bDot",bPos,bVal,bullishPatternBrush);
														
														drawTriangle(objNameOne,xPos,xVal,aPos,aVal,bPos,bVal,bullishPatternBrush,bullishOutlineBrush);
													}
													if(!drawObjectExists(objNameTwo))
													{
														drawDot(objName+"cDot",cPos,cVal,bullishPatternBrush);
														drawDot(objName+"dDot",dPos,dVal,bullishPatternBrush);
														
														drawTriangle(objNameTwo,bPos,bVal,cPos,cVal,dPos,dVal,bullishPatternBrush,bullishOutlineBrush);
													}
													
													drawTargetArea(objName+"target", dPos, minRetValue, maxRetValue, bullishPatternBrush);
													
													Draw.Line(this, objName+"xcRet_0886",false,dPos+4,exactRet_0886,dPos-4,exactRet_0886,bullishPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objName+"xcRet_0886_txt","0.886 XC | Shark",dPos+5,exactRet_0886);
													
													Draw.Line(this, objNameDev+"xcRet_1130",false,dPos+4,exactRet_1130,dPos-4,exactRet_1130,bullishPatternBrush,DashStyleHelper.Solid,2);
													drawTextFar(objNameDev+"xcRet_1130_txt","1.130 XC | Shark",dPos+5,exactRet_1130);
													
													cnt++;
													sharkFound = true;
													
													if(dPos <= 1)
													{
														Bullish[0] = (1);
													}
													
													if(dPos == 0)
													{
														alertPatterns.Add((string)("Bullish Shark"));
														alert = true;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return sharkFound;
		}
		
		#endregion

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Bullish
		{
			get { 
				Update();
				return Values[0]; 
			}
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Bearish
		{
			get { 
				Update();
				return Values[1]; 
			}
		}
		#endregion
		
		
		#region Properties
		// Tolerance Parameters
		
		[NinjaScriptProperty]
		[Display(Name ="01. % Retracement Tolerance", Description = "", GroupName = "02. Tolerance Parameters", Order = 1)]	
        public double RetTolerance
        {
            get { return retTolerance; }
            set { retTolerance = Math.Max(0.0, value); }
        }
			
		[NinjaScriptProperty]
		[Display(Name = "02. % Extension Tolerance", Description = "", GroupName = "02. Tolerance Parameters", Order = 2)]	
        public double ExtTolerance
        {
            get { return extTolerance; }
            set { extTolerance = Math.Max(0.0, value); }
        }
			
		[NinjaScriptProperty]
		[Display(Name = "03. % Max PRZ Tolerance", Description = "", GroupName = "02. Tolerance Parameters", Order = 3)]	
        public double MaxPrzTolerance
        {
            get { return maxPrzTolerance; }
            set { maxPrzTolerance = Math.Max(0.0, value); }
        }
			
		[NinjaScriptProperty]
		[Display(Name = "04. % Time Tolerance", Description = "", GroupName = "02. Tolerance Parameters", Order = 4)]	
        public double TarsTolerance
        {
            get { return timeTolerance; }
            set { timeTolerance = Math.Max(0.0, value); }
        }
			
		// Brush Parameters

		[NinjaScriptProperty]
		[Display(Name = "01. Bullish Pattern Brush", Description = "", GroupName = "03. Brush Parameters", Order = 5)]	
		public Brush BullishPatternBrush
		{
			get { return bullishPatternBrush; }
			set { bullishPatternBrush = value; }
		}
		
		[Browsable(false)]
        public string BullishPatternBrushSerialize
        {
            get { return Serialize.BrushToString(bullishPatternBrush); }
            set { bullishPatternBrush = Serialize.StringToBrush(value); }
        }
		
		

		[NinjaScriptProperty]
		[Display(Name = "02. Bullish Outline Brush", Description = "", GroupName = "03. Brush Parameters", Order = 6)]
		public Brush BullishOutlineBrush
		{
			get { return bullishOutlineBrush; }
			set { bullishOutlineBrush = value; }
		}
		[Browsable(false)]
        public string BullishOutlineBrushSerialize
        {
            get { return Serialize.BrushToString(bullishOutlineBrush); }
            set { bullishOutlineBrush = Serialize.StringToBrush(value); }
        }
		
		

		[NinjaScriptProperty]
		[Display(Name = "03. Bearish Pattern Brush", Description = "", GroupName = "03. Brush Parameters", Order = 7)]
		public Brush BearishPatternBrush
		{
			get { return bearishPatternBrush; }
			set { bearishPatternBrush = value; }
		}
		
		[Browsable(false)]
        public string BearishPatternBrushSerialize
        {
            get { return Serialize.BrushToString(bearishPatternBrush); }
            set { bearishPatternBrush = Serialize.StringToBrush(value); }
        }

		[NinjaScriptProperty]
		[Display(Name = "04. Bearish Outline Brush", Description = "", GroupName = "03. Brush Parameters", Order = 8)]
		public Brush BearishOutlineBrush
		{
			get { return bearishOutlineBrush; }
			set { bearishOutlineBrush = value; }
		}
		[Browsable(false)]
        public string BearishOutlineBrushSerialize
        {
            get { return Serialize.BrushToString(bearishOutlineBrush); }
            set { bearishOutlineBrush = Serialize.StringToBrush(value); }
        }

		[NinjaScriptProperty]
		[Display(Name = "05. Developing Pattern Brush", Description = "", GroupName = "03. Brush Parameters", Order = 9)]
		public Brush DevelopPatternBrush
		{
			get { return developPatternBrush; }
			set { developPatternBrush = value; }
		}
		
		
		[Browsable(false)]
        public string DevelopPatternBrushSerialize
        {
            get { return Serialize.BrushToString(developPatternBrush); }
            set { developPatternBrush = Serialize.StringToBrush(value); }
        }

		[NinjaScriptProperty]
		[Display(Name = "06. Developing Outline Brush", Description = "", GroupName = "03. Brush Parameters", Order = 10)]
		public Brush DevelopOutlineBrush
		{
			get { return developOutlineBrush; }
			set { developOutlineBrush = value; }
		}
		
		[Browsable(false)]
        public string DevelopOutlineBrushSerialize
        {
            get { return Serialize.BrushToString(developOutlineBrush); }
            set { developOutlineBrush = Serialize.StringToBrush(value); }
        }
			
		[NinjaScriptProperty]
		[Display(Name = "07. Pattern Opacity", Description = "", GroupName = "03. Brush Parameters", Order = 11)]
		public int PatternOpacity
		{
			get { return patternOpacity; }
			set { patternOpacity = Math.Max(0, value); }
		}
			
		[NinjaScriptProperty]
		[Display(Name = "08. Text color", Description = "", GroupName = "03. Brush Parameters", Order = 12)]
		public Brush TextBrush
		{
			get { return textBrush; }
			set { textBrush = value; }
		}
		
		[Browsable(false)]
        public string TextBrushSerialize
        {
            get { return Serialize.BrushToString(textBrush); }
            set { textBrush = Serialize.StringToBrush(value); }
        }

		// Font Parameters

		[XmlIgnore()]
		[NinjaScriptProperty]
		[Display(Name = "01. Text Font", Description = "", GroupName = "04. Font Parameters", Order = 12)]
		public SimpleFont TextFont
		{
			get { return textFont; }
			set { textFont = value; }
		}
		

		[XmlIgnore()]
		[NinjaScriptProperty]
		[Display(Name = "02. Label Font", Description = "", GroupName = "04. Font Parameters", Order = 13)]
		public SimpleFont LabelFont
		{
			get { return labelFont; }
			set { labelFont = value; }
		}
		
		// Visibility Parameters

		[NinjaScriptProperty]
		[Display(Name = "01. Show Target Area", Description = "", GroupName = "05. Visibility Parameters", Order = 14)]
		public bool ShowTargetArea
		{
			get { return showTargetArea; }
			set { showTargetArea = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "02. Show PRZ", Description = "", GroupName = "05. Visibility Parameters", Order = 15)]
		public bool ShowPrz
		{
			get { return showPrz; }
			set { showPrz = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "03. Show Dots", Description = "", GroupName = "05. Visibility Parameters", Order = 16)]
		public bool ShowDots
		{
			get { return showDots; }
			set { showDots = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "04. Show Labels", Description = "", GroupName = "05. Visibility Parameters", Order = 17)]
		public bool ShowLabels
		{
			get { return showLabels; }
			set { showLabels = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "05. Show Info", Description = "", GroupName = "05. Visibility Parameters", Order = 18)]
		public bool ShowInfo
		{
			get { return showInfo; }
			set { showInfo = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "06. Show Alerts", Description = "", GroupName = "05. Visibility Parameters", Order = 19)]
		public bool ShowAlerts
		{
			get { return showAlerts; }
			set { showAlerts = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "07. Max Bars", Description = "", GroupName = "05. Visibility Parameters", Order = 20)]
		public int Maxbars
		{
			get { return maxBars; }
			set { maxBars = Math.Max(0, value); }
		}

		// Pattern Parameters

		[NinjaScriptProperty]
		[Display(Name = "01. Show Bat", Description = "", GroupName = "06. Pattern Parameters", Order = 21)]
		public bool ShowBat
		{
			get { return showBat; }
			set { showBat = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "02. Show Alt Bat", Description = "", GroupName = "06. Pattern Parameters", Order = 22)]
		public bool ShowAltBat
		{
			get { return showAltBat; }
			set { showAltBat = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "03. Show Butterfly", Description = "", GroupName = "06. Pattern Parameters", Order = 23)]
		public bool ShowButterfly
		{
			get { return showButterfly; }
			set { showButterfly = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "04. Show Crab", Description = "", GroupName = "06. Pattern Parameters", Order = 24)]
		public bool ShowCrab
		{
			get { return showCrab; }
			set { showCrab = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "05. Show Deep Crab", Description = "", GroupName = "06. Pattern Parameters", Order = 25)]
		public bool ShowDeepCrab
		{
			get { return showDeepCrab; }
			set { showDeepCrab = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "06. Show Gartley", Description = "", GroupName = "06. Pattern Parameters", Order = 26)]
		public bool ShowGartley
		{
			get { return showGartley; }
			set { showGartley = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "07. Show AB=CD", Description = "", GroupName = "06. Pattern Parameters", Order = 27)]
		public bool ShowABCD
		{
			get { return showABCD; }
			set { showABCD = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "08. Show 5-0", Description = "", GroupName = "06. Pattern Parameters", Order = 28)]
		 bool ShowFiveZero
		{
			get { return showFiveZero; }
			set { showFiveZero = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "09. Show Cypher", Description = "", GroupName = "06. Pattern Parameters", Order = 29)]
		public bool ShowCypher
		{
			get { return showCypher; }
			set { showCypher = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "10. Show Shark", Description = "", GroupName = "06. Pattern Parameters", Order = 30)]
		public bool ShowShark
		{
			get { return showShark; }
			set { showShark = value; }
		}

		// Advanced Parameters

		[NinjaScriptProperty]
		[Display(Name = "01. Round to TickSize", Description = "", GroupName = "07. Advanced Parameters", Order = 31)]
		public bool Round2TickSize
		{
			get { return round2TickSize; }
			set { round2TickSize = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "02. Min. Ticks Impulse", Description = "Min. Ticks Height of first Leg.", GroupName = "07. Advanced Parameters", Order = 32)]
		public int MinTicksImpulse
		{
			get { return minTicksImpulse; }
			set { minTicksImpulse = Math.Max(1, value); }
		}

		[NinjaScriptProperty]
		[Display(Name = "03. Left Margin", Description = "Left Margin based on the width of the first Triangle.", GroupName = "07. Advanced Parameters", Order = 33)]
		public double LeftMargin
		{
			get { return leftMargin; }
			set { leftMargin = Math.Max(0.01, value); }
		}

		[NinjaScriptProperty]
		[Display(Name = "4. Min. Width Divider", Description = "Min. width of second Triangle based on the width of the first Triangle.", GroupName = "07. Advanced Parameters", Order = 34)]
		public double MinWidthDivider
		{
			get { return minWidthDivider; }
			set { minWidthDivider = Math.Max(0.01, value); }
		}

		
		[NinjaScriptProperty]
		[Display(Name = "05. Max. Width Multiplier", Description = "Max. width of second Triangle based on the width of the first Triangle.", GroupName = "Parameters", Order = 35)]
		public double MaxWidthMulti
		{
			get { return maxWidthMulti; }
			set { maxWidthMulti = Math.Max(0.01, value); }
		}
		
        #endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private mkHarmonics[] cachemkHarmonics;
		public mkHarmonics mkHarmonics(double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			return mkHarmonics(Input, retTolerance, extTolerance, maxPrzTolerance, tarsTolerance, bullishPatternBrush, bullishOutlineBrush, bearishPatternBrush, bearishOutlineBrush, developPatternBrush, developOutlineBrush, patternOpacity, textBrush, textFont, labelFont, showTargetArea, showPrz, showDots, showLabels, showInfo, showAlerts, maxbars, showBat, showAltBat, showButterfly, showCrab, showDeepCrab, showGartley, showABCD, showCypher, showShark, round2TickSize, minTicksImpulse, leftMargin, minWidthDivider, maxWidthMulti);
		}

		public mkHarmonics mkHarmonics(ISeries<double> input, double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			if (cachemkHarmonics != null)
				for (int idx = 0; idx < cachemkHarmonics.Length; idx++)
					if (cachemkHarmonics[idx] != null && cachemkHarmonics[idx].RetTolerance == retTolerance && cachemkHarmonics[idx].ExtTolerance == extTolerance && cachemkHarmonics[idx].MaxPrzTolerance == maxPrzTolerance && cachemkHarmonics[idx].TarsTolerance == tarsTolerance && cachemkHarmonics[idx].BullishPatternBrush == bullishPatternBrush && cachemkHarmonics[idx].BullishOutlineBrush == bullishOutlineBrush && cachemkHarmonics[idx].BearishPatternBrush == bearishPatternBrush && cachemkHarmonics[idx].BearishOutlineBrush == bearishOutlineBrush && cachemkHarmonics[idx].DevelopPatternBrush == developPatternBrush && cachemkHarmonics[idx].DevelopOutlineBrush == developOutlineBrush && cachemkHarmonics[idx].PatternOpacity == patternOpacity && cachemkHarmonics[idx].TextBrush == textBrush && cachemkHarmonics[idx].TextFont == textFont && cachemkHarmonics[idx].LabelFont == labelFont && cachemkHarmonics[idx].ShowTargetArea == showTargetArea && cachemkHarmonics[idx].ShowPrz == showPrz && cachemkHarmonics[idx].ShowDots == showDots && cachemkHarmonics[idx].ShowLabels == showLabels && cachemkHarmonics[idx].ShowInfo == showInfo && cachemkHarmonics[idx].ShowAlerts == showAlerts && cachemkHarmonics[idx].Maxbars == maxbars && cachemkHarmonics[idx].ShowBat == showBat && cachemkHarmonics[idx].ShowAltBat == showAltBat && cachemkHarmonics[idx].ShowButterfly == showButterfly && cachemkHarmonics[idx].ShowCrab == showCrab && cachemkHarmonics[idx].ShowDeepCrab == showDeepCrab && cachemkHarmonics[idx].ShowGartley == showGartley && cachemkHarmonics[idx].ShowABCD == showABCD && cachemkHarmonics[idx].ShowCypher == showCypher && cachemkHarmonics[idx].ShowShark == showShark && cachemkHarmonics[idx].Round2TickSize == round2TickSize && cachemkHarmonics[idx].MinTicksImpulse == minTicksImpulse && cachemkHarmonics[idx].LeftMargin == leftMargin && cachemkHarmonics[idx].MinWidthDivider == minWidthDivider && cachemkHarmonics[idx].MaxWidthMulti == maxWidthMulti && cachemkHarmonics[idx].EqualsInput(input))
						return cachemkHarmonics[idx];
			return CacheIndicator<mkHarmonics>(new mkHarmonics(){ RetTolerance = retTolerance, ExtTolerance = extTolerance, MaxPrzTolerance = maxPrzTolerance, TarsTolerance = tarsTolerance, BullishPatternBrush = bullishPatternBrush, BullishOutlineBrush = bullishOutlineBrush, BearishPatternBrush = bearishPatternBrush, BearishOutlineBrush = bearishOutlineBrush, DevelopPatternBrush = developPatternBrush, DevelopOutlineBrush = developOutlineBrush, PatternOpacity = patternOpacity, TextBrush = textBrush, TextFont = textFont, LabelFont = labelFont, ShowTargetArea = showTargetArea, ShowPrz = showPrz, ShowDots = showDots, ShowLabels = showLabels, ShowInfo = showInfo, ShowAlerts = showAlerts, Maxbars = maxbars, ShowBat = showBat, ShowAltBat = showAltBat, ShowButterfly = showButterfly, ShowCrab = showCrab, ShowDeepCrab = showDeepCrab, ShowGartley = showGartley, ShowABCD = showABCD, ShowCypher = showCypher, ShowShark = showShark, Round2TickSize = round2TickSize, MinTicksImpulse = minTicksImpulse, LeftMargin = leftMargin, MinWidthDivider = minWidthDivider, MaxWidthMulti = maxWidthMulti }, input, ref cachemkHarmonics);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.mkHarmonics mkHarmonics(double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			return indicator.mkHarmonics(Input, retTolerance, extTolerance, maxPrzTolerance, tarsTolerance, bullishPatternBrush, bullishOutlineBrush, bearishPatternBrush, bearishOutlineBrush, developPatternBrush, developOutlineBrush, patternOpacity, textBrush, textFont, labelFont, showTargetArea, showPrz, showDots, showLabels, showInfo, showAlerts, maxbars, showBat, showAltBat, showButterfly, showCrab, showDeepCrab, showGartley, showABCD, showCypher, showShark, round2TickSize, minTicksImpulse, leftMargin, minWidthDivider, maxWidthMulti);
		}

		public Indicators.mkHarmonics mkHarmonics(ISeries<double> input , double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			return indicator.mkHarmonics(input, retTolerance, extTolerance, maxPrzTolerance, tarsTolerance, bullishPatternBrush, bullishOutlineBrush, bearishPatternBrush, bearishOutlineBrush, developPatternBrush, developOutlineBrush, patternOpacity, textBrush, textFont, labelFont, showTargetArea, showPrz, showDots, showLabels, showInfo, showAlerts, maxbars, showBat, showAltBat, showButterfly, showCrab, showDeepCrab, showGartley, showABCD, showCypher, showShark, round2TickSize, minTicksImpulse, leftMargin, minWidthDivider, maxWidthMulti);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.mkHarmonics mkHarmonics(double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			return indicator.mkHarmonics(Input, retTolerance, extTolerance, maxPrzTolerance, tarsTolerance, bullishPatternBrush, bullishOutlineBrush, bearishPatternBrush, bearishOutlineBrush, developPatternBrush, developOutlineBrush, patternOpacity, textBrush, textFont, labelFont, showTargetArea, showPrz, showDots, showLabels, showInfo, showAlerts, maxbars, showBat, showAltBat, showButterfly, showCrab, showDeepCrab, showGartley, showABCD, showCypher, showShark, round2TickSize, minTicksImpulse, leftMargin, minWidthDivider, maxWidthMulti);
		}

		public Indicators.mkHarmonics mkHarmonics(ISeries<double> input , double retTolerance, double extTolerance, double maxPrzTolerance, double tarsTolerance, Brush bullishPatternBrush, Brush bullishOutlineBrush, Brush bearishPatternBrush, Brush bearishOutlineBrush, Brush developPatternBrush, Brush developOutlineBrush, int patternOpacity, Brush textBrush, SimpleFont textFont, SimpleFont labelFont, bool showTargetArea, bool showPrz, bool showDots, bool showLabels, bool showInfo, bool showAlerts, int maxbars, bool showBat, bool showAltBat, bool showButterfly, bool showCrab, bool showDeepCrab, bool showGartley, bool showABCD, bool showCypher, bool showShark, bool round2TickSize, int minTicksImpulse, double leftMargin, double minWidthDivider, double maxWidthMulti)
		{
			return indicator.mkHarmonics(input, retTolerance, extTolerance, maxPrzTolerance, tarsTolerance, bullishPatternBrush, bullishOutlineBrush, bearishPatternBrush, bearishOutlineBrush, developPatternBrush, developOutlineBrush, patternOpacity, textBrush, textFont, labelFont, showTargetArea, showPrz, showDots, showLabels, showInfo, showAlerts, maxbars, showBat, showAltBat, showButterfly, showCrab, showDeepCrab, showGartley, showABCD, showCypher, showShark, round2TickSize, minTicksImpulse, leftMargin, minWidthDivider, maxWidthMulti);
		}
	}
}

#endregion
