#region Using declarations
using NinjaTrader.Gui;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class EhlersQuotientTransform : Indicator
    {

        private double alpha1;
        private double a1;
        private double b1;
        private double c1;
        private double c2;
        private double c3;
        private double x;
        private double quotientFastLong;
        private double quotientSlowLong;
        private double quotientFastShort;
        private double quotientSlowShort;
        private double kFastLong = 0.40;
        private double kSlowLong = 0.90;
        private double kFastShort = -0.40;
        private double kSlowShort = -0.90;
        private int lPPeriod = 20;
        private Series<double> HP;
        private Series<double> Filt;
        private Series<double> Peak;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"John F. Ehlers : 'Early Trend Detection, The Quotient Transform' - TASC August 2014";
                Name = "Ehlers Quotient Transform";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;

                HP = new Series<double>(this);
                Filt = new Series<double>(this);
                Peak = new Series<double>(this);

                AddPlot(new Stroke(Brushes.LightGreen, 1), PlotStyle.Line, "QTFastLong");
                AddPlot(new Stroke(Brushes.Green, 1), PlotStyle.Line, "QTSlowLong");
                AddPlot(new Stroke(Brushes.IndianRed, 1), PlotStyle.Line, "QTFastShort");
                AddPlot(new Stroke(Brushes.Red, 1), PlotStyle.Line, "QTSlowShort");
                AddLine(Brushes.Yellow, 0.0, "Zero");

                for (int index = 0; index < 4; index++)
                {
                    Plots[index].Width = 2;
                }
                Lines[0].Width = 2;

            }
            else if (State == State.DataLoaded)
            {
                alpha1 = ((Math.Cos(((.707 * 360 / 100) * Math.PI) / 180)) + (Math.Sin(((.707 * 360 / 100) * Math.PI) / 180)) - 1) / (Math.Cos(((.707 * 360 / 100) * Math.PI) / 180));
                a1 = Math.Exp(-1.414 * 3.14159 / LPPeriod);
                b1 = 2 * a1 * (Math.Cos(((1.414 * 180 / LPPeriod) * Math.PI) / 180));
                c2 = b1;
                c3 = (a1 * -1) * a1;
                c1 = 1 - c2 - c3;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < LPPeriod)
            {
                HP[0] = (0);
                Filt[0] = (0);
                Peak[0] = (0);
                return;
            }

            HP[0] = ((1 - alpha1 / 2) * (1 - alpha1 / 2) * (Input[0] - 2 * Input[1] + Input[2]) + 2 * (1 - alpha1) * HP[1] - (1 - alpha1) * (1 - alpha1) * HP[2]);
            Filt[0] = (c1 * (HP[0] + HP[1]) / 2 + c2 * Filt[1] + c3 * Filt[2]);

            Peak[0] = (Peak[1] * 0.991);

            if (Math.Abs(Filt[0]) > Peak[0])
                Peak[0] = (Math.Abs(Filt[0]));

            if (Peak[0] < 0.0 || Peak[0] > 0.0)
                x = (Filt[0] / Peak[0]);

            quotientFastLong = (x + KFastLong) / (KFastLong * x + 1);
            quotientSlowLong = (x + KSlowLong) / (KSlowLong * x + 1);
            quotientFastShort = (x + KFastShort) / (KFastShort * x + 1);
            quotientSlowShort = (x + KSlowShort) / (KSlowShort * x + 1);

            QTFastLong[0] = (quotientFastLong);
            QTSlowLong[0] = (quotientSlowLong);
            QTFastShort[0] = (quotientFastShort);
            QTSlowShort[0] = (quotientSlowShort);
        }

        #region Properties

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> QTFastLong
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> QTSlowLong
        {
            get { return Values[1]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> QTFastShort
        {
            get { return Values[2]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public Series<double> QTSlowShort
        {
            get { return Values[3]; }
        }

        [NinjaScriptProperty]
        [Display(Name = "KFastLong", Description = "Fast quotient K value", Order = 1, GroupName = "Parameters")]
        public double KFastLong
        {
            get { return kFastLong; }
            set { kFastLong = Math.Max(0.01, Math.Min(value, 0.999)); }
        }

        [NinjaScriptProperty]
        [Display(Name = "KSlowLong", Description = "Slow quotient K value", Order = 2, GroupName = "Parameters")]
        public double KSlowLong
        {
            get { return kSlowLong; }
            set { kSlowLong = Math.Max(0.01, Math.Min(value, 0.999)); }
        }

        [NinjaScriptProperty]
        [Display(Name = "KFastShort", Description = "Fast quotient K value", Order = 3, GroupName = "Parameters")]
        public double KFastShort
        {
            get { return kFastShort; }
            set { kFastShort = Math.Min(-0.01, Math.Max(value, -0.999)); }
        }

        [NinjaScriptProperty]
        [Display(Name = "KSlowShort", Description = "Slow quotient K value", Order = 4, GroupName = "Parameters")]
        public double KSlowShort
        {
            get { return kSlowShort; }
            set { kSlowShort = Math.Min(-0.01, Math.Max(value, -0.999)); }
        }

        [NinjaScriptProperty]
        [Display(Name = "LPPeriod", Description = "Low Pass filter Period", Order = 5, GroupName = "Parameters")]
        public int LPPeriod
        {
            get { return lPPeriod; }
            set { lPPeriod = Math.Max(1, value); }
        }

        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EhlersQuotientTransform[] cacheEhlersQuotientTransform;
		public EhlersQuotientTransform EhlersQuotientTransform(double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			return EhlersQuotientTransform(Input, kFastLong, kSlowLong, kFastShort, kSlowShort, lPPeriod);
		}

		public EhlersQuotientTransform EhlersQuotientTransform(ISeries<double> input, double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			if (cacheEhlersQuotientTransform != null)
				for (int idx = 0; idx < cacheEhlersQuotientTransform.Length; idx++)
					if (cacheEhlersQuotientTransform[idx] != null && cacheEhlersQuotientTransform[idx].KFastLong == kFastLong && cacheEhlersQuotientTransform[idx].KSlowLong == kSlowLong && cacheEhlersQuotientTransform[idx].KFastShort == kFastShort && cacheEhlersQuotientTransform[idx].KSlowShort == kSlowShort && cacheEhlersQuotientTransform[idx].LPPeriod == lPPeriod && cacheEhlersQuotientTransform[idx].EqualsInput(input))
						return cacheEhlersQuotientTransform[idx];
			return CacheIndicator<EhlersQuotientTransform>(new EhlersQuotientTransform(){ KFastLong = kFastLong, KSlowLong = kSlowLong, KFastShort = kFastShort, KSlowShort = kSlowShort, LPPeriod = lPPeriod }, input, ref cacheEhlersQuotientTransform);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EhlersQuotientTransform EhlersQuotientTransform(double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			return indicator.EhlersQuotientTransform(Input, kFastLong, kSlowLong, kFastShort, kSlowShort, lPPeriod);
		}

		public Indicators.EhlersQuotientTransform EhlersQuotientTransform(ISeries<double> input , double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			return indicator.EhlersQuotientTransform(input, kFastLong, kSlowLong, kFastShort, kSlowShort, lPPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EhlersQuotientTransform EhlersQuotientTransform(double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			return indicator.EhlersQuotientTransform(Input, kFastLong, kSlowLong, kFastShort, kSlowShort, lPPeriod);
		}

		public Indicators.EhlersQuotientTransform EhlersQuotientTransform(ISeries<double> input , double kFastLong, double kSlowLong, double kFastShort, double kSlowShort, int lPPeriod)
		{
			return indicator.EhlersQuotientTransform(input, kFastLong, kSlowLong, kFastShort, kSlowShort, lPPeriod);
		}
	}
}

#endregion
