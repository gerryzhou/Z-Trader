// 
// Copyright (C) 2018, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

#region Using declarations

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Point = System.Windows.Point;
using TextAlignment = System.Windows.TextAlignment;

#endregion

namespace NinjaTrader.NinjaScript.DrawingTools
{
    public class DegreeDetails
    {
        public Dictionary<string, string> Labels { get; set; }
        public System.Windows.Media.Brush Color { get; set; }
    }

    public enum DegreeType
    {
        GrandSuperCycle,
        Supercycle,
        Cycle,

        Primary,
        Intermediate,
        Minor,

        Minute,
        Minuette,
        SubMinuette,

        Micro,
        Submicro,
        Miniscule
    }

    public abstract class ElliottWaveBase : DrawingTool
    {
        protected const int CursorSensitivity = 15;
        protected ChartAnchor editingAnchor;

        protected Dictionary<DegreeType, DegreeDetails> Degrees = new Dictionary<DegreeType, DegreeDetails>
        {
            {
                DegreeType.GrandSuperCycle, new DegreeDetails
                {
                    Color=Brushes.Aqua,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "[I]" },{"2", "[II]" },{"3", "[III]" },{"4", "[IV]" },{"5", "[V]" },
                        {"a", "[a]" },{"b", "[b]" },{"c", "[c]" },{"d]", "[d]" },{"e", "[e]" },{"f", "[f]" },
                        {"w", "[w]" },{"x", "[x]" },{"y", "[y]" },{"z]", "[z]" }
                    }
                }
            },

            {
                DegreeType.Supercycle, new DegreeDetails
                {
                    Color=Brushes.Lime,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "(I)" },{"2", "(II)" },{"3", "(III)" },{"4", "(IV)" },{"5", "(V)" },
                        {"a", "(a)" },{"b", "(b)" },{"c", "(c)" },{"d)", "(d)" },{"e", "(e)" },{"f", "(f)" },
                        {"w", "(w)" },{"x", "(x)" },{"y", "(y)" },{"z)", "(z)" }
                    }
                }
            },

            {
                DegreeType.Cycle, new DegreeDetails
                {
                    Color=Brushes.HotPink,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "I" },{"2", "II" },{"3", "III" },{"4", "IV" },{"5", "V" },
                        {"a", "a" },{"b", "b" },{"c", "c" },{"d", "d" },{"e", "e" },{"f", "f" },
                        {"w", "w" },{"x", "x" },{"y", "y" },{"z", "z" }
                    }
                }
            },

            {
                DegreeType.Primary, new DegreeDetails
                {
                    Color=Brushes.White,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "[1]" },{"2", "[2]" },{"3", "[3]" },{"4", "[4]" },{"5", "[5]" },
                        {"a", "[A]" },{"b", "[B]" },{"c", "[C]" },{"d", "[D]" },{"e", "[E]" },{"f", "[F]" },
                        {"w", "[W]" },{"x", "[X]" },{"y", "[Y]" },{"z", "[Z]" }
                    }
                }
            },

            {
                DegreeType.Intermediate, new DegreeDetails
                {
                    Color=Brushes.Red,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "(1)" },{"2", "(2)" },{"3", "(3)" },{"4", "(4)" },{"5", "(5)" },
                        {"a", "(A)" },{"b", "(B)" },{"c", "(C)" },{"d", "(D)" },{"e", "(E)" },{"f", "(F)" },
                        {"w", "(w)" },{"x", "(X)" },{"y", "(Y)" },{"z", "(Z)" }
                    }
                }
            },

            {
                DegreeType.Minor, new DegreeDetails
                {
                    Color=Brushes.Aqua,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "1" },{"2", "2" },{"3", "3" },{"4", "4" },{"5", "5" },
                        {"a", "A" },{"b", "B" },{"c", "C" },{"d", "D" },{"e", "E" },{"f", "F" },
                        {"w", "W" },{"x", "X" },{"y", "Y" },{"z", "Z" }
                    }
                }
            },

            {
                DegreeType.Minute, new DegreeDetails
                {
                    Color=Brushes.Lime,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "i" },{"2", "ii" },{"3", "iii" },{"4", "iv" },{"5", "v" },
                        {"a", "a" },{"b", "b" },{"c", "c" },{"d", "d" },{"e", "e" },{"f", "f" },
                        {"w", "w" },{"x", "x" },{"y", "y" },{"z", "z" }
                    }
                }

            },

            {
                DegreeType.Minuette, new DegreeDetails
                {
                    Color=Brushes.HotPink,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "(i)" },{"2", "(ii)" },{"3", "(iii)" },{"4", "(iv)" },{"5", "(v)" },
                        {"a", "(a)" },{"b", "(b)" },{"c", "(c)" },{"d", "(d)" },{"e", "(e)" },{"f", "(f)" },
                        {"w", "(w)" },{"x", "(x)" },{"y", "(y)" },{"z", "(z)" }
                    }
                }
            },

            {
                DegreeType.SubMinuette, new DegreeDetails
                {
                    Color=Brushes.White,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "i" },{"2", "ii" },{"3", "iii" },{"4", "iv" },{"5", "v" },
                        {"a", "a" },{"b", "b" },{"c", "c" },{"d", "d" },{"e", "e" },{"f", "f" },
                        {"w", "w" },{"x", "x" },{"y", "y" },{"z", "z" }
                    }
                }
            },

            {
                DegreeType.Micro, new DegreeDetails
                {
                    Color=Brushes.Red,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "1" },{"2", "2" },{"3", "3" },{"4", "4" },{"5", "5" },
                        {"a", "A" },{"b", "B" },{"c", "C" },{"d", "D" },{"e", "E" },{"f", "F" },
                        {"w", "W" },{"x", "X" },{"y", "Y" },{"z", "Z" }
                    }
                }

            },

            {
                DegreeType.Submicro, new DegreeDetails
                {
                    Color=Brushes.Aqua,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "(1)" },{"2", "(2)" },{"3", "(3)" },{"4", "(4)" },{"5", "(5)" },
                        {"a", "(A)" },{"b", "(B)" },{"c", "(C)" },{"d", "(D)" },{"e", "(E)" },{"f", "(F)" },
                        {"w", "(W)" },{"x", "(X)" },{"y", "(Y)" },{"z", "(Z)" }
                    }
                }

            },

            {
                DegreeType.Miniscule, new DegreeDetails
                {
                    Color=Brushes.Lime,
                    Labels = new Dictionary<string, string>
                    {
                        {"1", "1" },{"2", "2" },{"3", "3" },{"4", "4" },{"5", "5" },
                        {"a", "A" },{"b", "B" },{"c", "C" },{"d", "D" },{"e", "E" },{"f", "F" },
                        {"w", "W" },{"x", "X" },{"y", "Y" },{"z", "Z" }
                    }
                }
            },
        };

        [Display(Order = 1, Name = "Show Wave", GroupName = "Elliot")]
        public bool DrawWaves { get; set; }

        [Display(Order = 2, GroupName = "Elliot")]
        public DegreeType Degree { get; set; }

        [Display(Order = 1, GroupName = "Points")]
        public ChartAnchor AnchorStart { get; set; }

        [Display(Order = 2, GroupName = "Points")]
        public ChartAnchor AnchorWave1 { get; set; }

        [Display(Order = 3, GroupName = "Points")]
        public ChartAnchor AnchorWave2 { get; set; }

        [Display(Order = 4, GroupName = "Points")]
        public ChartAnchor AnchorWave3 { get; set; }

        [Display(Order = 5, GroupName = "Points")]
        public ChartAnchor AnchorWave4 { get; set; }

        [Display(Order = 6, GroupName = "Points")]
        public ChartAnchor AnchorWave5 { get; set; }

        public override bool SupportsAlerts
        {
            get
            {
                return false;
            }
        }

        protected virtual string[] Labels
        {
            get
            {
                return new string[] { };
            }
        }

        public override Cursor GetCursor(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, Point point)
        {
            switch (DrawingState)
            {
                case DrawingState.Building: return Cursors.Pen;
                case DrawingState.Moving: return IsLocked ? Cursors.No : Cursors.SizeAll;
                case DrawingState.Editing:
                    if (IsLocked)
                    {
                        return Cursors.No;
                    }

                    return editingAnchor == AnchorStart ? Cursors.SizeNESW : Cursors.SizeNWSE;
                default:
                    // draw move cursor if cursor is near line path anywhere
                    var startAnchorPixelPoint = AnchorStart.GetPoint(chartControl, chartPanel, chartScale);

                    var closest = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);
                    if (closest != null)
                    {
                        if (IsLocked)
                        {
                            return null;
                        }

                        return closest == AnchorStart ? Cursors.SizeNESW : Cursors.SizeNWSE;
                    }

                    var totalVector = AnchorWave1.GetPoint(chartControl, chartPanel, chartScale) - startAnchorPixelPoint;
                    return MathHelper.IsPointAlongVector(point, startAnchorPixelPoint, totalVector, CursorSensitivity)
                        ? IsLocked ? Cursors.Arrow : Cursors.SizeAll
                        : null;
            }
        }

        public override Point[] GetSelectionPoints(ChartControl chartControl, ChartScale chartScale)
        {
            var chartPanel = chartControl.ChartPanels[PanelIndex];
            var pointStart = AnchorStart.GetPoint(chartControl, chartPanel, chartScale);
            var point1 = AnchorWave1.GetPoint(chartControl, chartPanel, chartScale);
            var point2 = AnchorWave2.GetPoint(chartControl, chartPanel, chartScale);
            var point3 = AnchorWave3.GetPoint(chartControl, chartPanel, chartScale);
            var point4 = AnchorWave4.GetPoint(chartControl, chartPanel, chartScale);
            var point5 = AnchorWave5.GetPoint(chartControl, chartPanel, chartScale);
            if (Anchors.Count() == 6)
            {
                return new[] { pointStart, point1, point2, point3, point4, point5 };
            }
            else
            {
                return new[] { pointStart, point1, point2, point3 };
            }
        }

        public override void OnMouseDown(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            switch (DrawingState)
            {
                case DrawingState.Building:
                    if (AnchorStart.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorStart);
                        dataPoint.CopyDataValues(AnchorWave1);
                        dataPoint.CopyDataValues(AnchorWave2);
                        dataPoint.CopyDataValues(AnchorWave3);
                        dataPoint.CopyDataValues(AnchorWave4);
                        dataPoint.CopyDataValues(AnchorWave5);
                        AnchorStart.IsEditing = false;
                    }
                    else if (AnchorWave1.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorWave1);
                        dataPoint.CopyDataValues(AnchorWave2);
                        dataPoint.CopyDataValues(AnchorWave3);
                        dataPoint.CopyDataValues(AnchorWave4);
                        dataPoint.CopyDataValues(AnchorWave5);

                        AnchorWave1.IsEditing = false;
                    }
                    else if (AnchorWave2.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorWave2);
                        dataPoint.CopyDataValues(AnchorWave3);
                        dataPoint.CopyDataValues(AnchorWave4);
                        dataPoint.CopyDataValues(AnchorWave5);
                        AnchorWave2.IsEditing = false;
                    }
                    else if (AnchorWave3.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorWave3);
                        dataPoint.CopyDataValues(AnchorWave4);
                        dataPoint.CopyDataValues(AnchorWave5);
                        AnchorWave3.IsEditing = false;
                    }
                    else if (AnchorWave4.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorWave4);
                        dataPoint.CopyDataValues(AnchorWave5);
                        AnchorWave4.IsEditing = false;
                    }
                    else if (AnchorWave5.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorWave5);
                        AnchorWave5.IsEditing = false;
                    }

                    // is initial building done (both anchors set)
                    if (Anchors.Count() == 6)
                    {
                        if (!AnchorStart.IsEditing && !AnchorWave1.IsEditing && !AnchorWave2.IsEditing && !AnchorWave3.IsEditing &&
                            !AnchorWave4.IsEditing && !AnchorWave5.IsEditing)
                        {
                            DrawingState = DrawingState.Normal;
                            IsSelected = false;
                        }
                    }
                    else
                    {
                        if (!AnchorStart.IsEditing && !AnchorWave1.IsEditing && !AnchorWave2.IsEditing && !AnchorWave3.IsEditing)
                        {
                            DrawingState = DrawingState.Normal;
                            IsSelected = false;
                        }
                    }

                    break;
                case DrawingState.Normal:
                    var point = dataPoint.GetPoint(chartControl, chartPanel, chartScale);
                    editingAnchor = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);
                    if (editingAnchor != null)
                    {
                        editingAnchor.IsEditing = true;
                        DrawingState = DrawingState.Editing;
                    }
                    else if (editingAnchor == null || IsLocked)
                    {
                        // or if they didnt click particulary close to either, move (they still clicked close to our line)
                        // set it to moving even if locked so we know to change cursor
                        if (GetCursor(chartControl, chartPanel, chartScale, point) != null)
                        {
                            DrawingState = DrawingState.Moving;
                        }
                        else
                        {
                            IsSelected = false;
                        }
                    }

                    break;
            }
        }

        public override void OnMouseMove(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            if (IsLocked && DrawingState != DrawingState.Building)
            {
                return;
            }

            if (DrawingState == DrawingState.Building)
            {
                // start anchor will not be editing here because we start building as soon as user clicks, which
                // plops down a start anchor right away
                if (AnchorWave1.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave1);
                    dataPoint.CopyDataValues(AnchorWave2);
                    dataPoint.CopyDataValues(AnchorWave3);
                    dataPoint.CopyDataValues(AnchorWave4);
                    dataPoint.CopyDataValues(AnchorWave5);
                }
                else if (AnchorWave2.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave2);
                    dataPoint.CopyDataValues(AnchorWave3);
                    dataPoint.CopyDataValues(AnchorWave4);
                    dataPoint.CopyDataValues(AnchorWave5);
                }
                else if (AnchorWave3.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave3);
                    dataPoint.CopyDataValues(AnchorWave4);
                    dataPoint.CopyDataValues(AnchorWave5);
                }
                else if (AnchorWave4.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave4);
                    dataPoint.CopyDataValues(AnchorWave5);
                }
                else if (AnchorWave5.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave5);
                }
            }
            else if (DrawingState == DrawingState.Editing && editingAnchor != null)
            {
                if (AnchorStart.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorStart);
                }
                else if (AnchorWave1.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave1);
                }
                else if (AnchorWave2.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave2);
                }
                else if (AnchorWave3.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave3);
                }
                else if (AnchorWave4.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave4);
                }
                else if (AnchorWave5.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorWave5);
                }
            }
            else if (DrawingState == DrawingState.Moving)
            {
                foreach (var anchor in Anchors)
                {
                    anchor.MoveAnchor(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
                }
            }
        }

        public override void OnMouseUp(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            // simply end whatever moving
            if (DrawingState == DrawingState.Editing || DrawingState == DrawingState.Moving)
            {
                DrawingState = DrawingState.Normal;
            }

            if (editingAnchor != null)
            {
                editingAnchor.IsEditing = false;
            }

            editingAnchor = null;
        }

        private void DrawTextLabel(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor anchor, string label, float yoffset)
        {
            var degree = Degrees[Degree];
            var degreeLabel = degree.Labels[label];
            var wpfFont = chartPanel.ChartControl.Properties.LabelFont ?? new SimpleFont();
            var textFormat = wpfFont.ToDirectWriteTextFormat();
            textFormat.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
            textFormat.WordWrapping = WordWrapping.NoWrap;

            var point = anchor.GetPoint(chartControl, chartPanel, chartScale);
            var textLayout = new TextLayout(Globals.DirectWriteFactory, degreeLabel, textFormat, 200, textFormat.FontSize);
            var textBrush = degree.Color.ToDxBrush(RenderTarget);
            RenderTarget.DrawTextLayout(new Vector2((float)point.X - 100, (float)point.Y + yoffset), textLayout, textBrush, DrawTextOptions.NoSnap);

            textBrush.Dispose();
            textFormat.Dispose();
            textLayout.Dispose();
        }

        public override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            // nothing is drawn yet
            if (Anchors.All(a => a.IsEditing))
            {
                return;
            }

            RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
            var chartPanel = chartControl.ChartPanels[PanelIndex];

            var pointStart = AnchorStart.GetPoint(chartControl, chartPanel, chartScale);
            var point1 = AnchorWave1.GetPoint(chartControl, chartPanel, chartScale);
            var point2 = AnchorWave2.GetPoint(chartControl, chartPanel, chartScale);
            var point3 = AnchorWave3.GetPoint(chartControl, chartPanel, chartScale);
            var point4 = AnchorWave4.GetPoint(chartControl, chartPanel, chartScale);
            var point5 = AnchorWave5.GetPoint(chartControl, chartPanel, chartScale);

            var degree = Degrees[Degree];
            if (DrawWaves)
            {
                var tmpBrush = IsInHitTest ? chartControl.SelectionBrush : degree.Color.ToDxBrush(RenderTarget);
                var stroke = new Stroke(degree.Color);
                RenderTarget.DrawLine(pointStart.ToVector2(), point1.ToVector2(), tmpBrush, 2, stroke.StrokeStyle);
                RenderTarget.DrawLine(point1.ToVector2(), point2.ToVector2(), tmpBrush, 2, stroke.StrokeStyle);
                RenderTarget.DrawLine(point2.ToVector2(), point3.ToVector2(), tmpBrush, 2, stroke.StrokeStyle);

                if (Anchors.Count() == 6)
                {
                    RenderTarget.DrawLine(point3.ToVector2(), point4.ToVector2(), tmpBrush, 2, stroke.StrokeStyle);
                    RenderTarget.DrawLine(point4.ToVector2(), point5.ToVector2(), tmpBrush, 2, stroke.StrokeStyle);
                }
                tmpBrush.Dispose();
            }

            var off1 = -40f;
            var off2 = 20f;
            if (AnchorWave2.Price > AnchorWave1.Price)
            {
                off1 = 20f;
                off2 = -40f;
            }

            DrawTextLabel(chartControl, chartPanel, chartScale, AnchorWave1, Labels[0], off1);
            if (!AnchorWave1.IsEditing)
                DrawTextLabel(chartControl, chartPanel, chartScale, AnchorWave2, Labels[1], off2);
            if (!AnchorWave2.IsEditing)
                DrawTextLabel(chartControl, chartPanel, chartScale, AnchorWave3, Labels[2], off1);
            if (Anchors.Count() == 6)
            {
                if (!AnchorWave3.IsEditing)
                    DrawTextLabel(chartControl, chartPanel, chartScale, AnchorWave4, Labels[3], off2);
                if (!AnchorWave4.IsEditing)
                    DrawTextLabel(chartControl, chartPanel, chartScale, AnchorWave5, Labels[4], off1);
            }
        }
    }

    [EditorBrowsable(EditorBrowsableState.Always)]
    public class ElliottWave5 : ElliottWaveBase
    {
        protected override string[] Labels
        {
            get
            {
                return new string[] { "1", "2", "3", "4", "5" };

            }
        }

        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { AnchorStart, AnchorWave1, AnchorWave2, AnchorWave3, AnchorWave4, AnchorWave5 };
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EW 12345";
                AnchorStart = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave1 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave2 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave3 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave4 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave5 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorStart.DisplayName = "0";
                AnchorWave1.DisplayName = "1";
                AnchorWave2.DisplayName = "2";
                AnchorWave3.DisplayName = "3";
                AnchorWave4.DisplayName = "4";
                AnchorWave5.DisplayName = "5";
                DrawWaves = true;
                Degree = DegreeType.Submicro;
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

    public class ElliottWaveABC : ElliottWaveBase
    {
        protected override string[] Labels
        {
            get
            {
                return new string[] { "a", "b", "c" };

            }
        }
        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { AnchorStart, AnchorWave1, AnchorWave2, AnchorWave3 };
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EW ABC";
                AnchorStart = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave1 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave2 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave3 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave4 = new ChartAnchor { IsEditing = false, DrawingTool = this };
                AnchorWave5 = new ChartAnchor { IsEditing = false, DrawingTool = this };
                AnchorStart.DisplayName = "0";
                AnchorWave1.DisplayName = "A";
                AnchorWave2.DisplayName = "B";
                AnchorWave3.DisplayName = "C";
                Degree = DegreeType.Submicro;
                DrawWaves = true;
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

    public class ElliottWaveWXY : ElliottWaveBase
    {
        protected override string[] Labels
        {
            get
            {
                return new string[] { "w", "x", "y" };

            }
        }
        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { AnchorStart, AnchorWave1, AnchorWave2, AnchorWave3 };
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EW WXY";
                AnchorStart = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave1 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave2 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave3 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave4 = new ChartAnchor { IsEditing = false, DrawingTool = this };
                AnchorWave5 = new ChartAnchor { IsEditing = false, DrawingTool = this };
                AnchorStart.DisplayName = "0";
                AnchorWave1.DisplayName = "W";
                AnchorWave2.DisplayName = "X";
                AnchorWave3.DisplayName = "Y";
                Degree = DegreeType.Submicro;
                DrawWaves = true;
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

    public class ElliottWaveABCDE : ElliottWaveBase
    {
        protected override string[] Labels
        {
            get
            {
                return new string[] { "a", "b", "c", "d", "e" };

            }
        }
        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { AnchorStart, AnchorWave1, AnchorWave2, AnchorWave3, AnchorWave4, AnchorWave5 };
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EW ABCDE";
                AnchorStart = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave1 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave2 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave3 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave4 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave5 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorStart.DisplayName = "0";
                AnchorWave1.DisplayName = "A";
                AnchorWave2.DisplayName = "B";
                AnchorWave3.DisplayName = "C";
                AnchorWave4.DisplayName = "D";
                AnchorWave5.DisplayName = "E";
                Degree = DegreeType.Submicro;
                DrawWaves = true;
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

    public class ElliottWaveWXYXZ : ElliottWaveBase
    {
        protected override string[] Labels
        {
            get
            {
                return new string[] { "w", "x", "y", "x", "z" };

            }
        }
        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { AnchorStart, AnchorWave1, AnchorWave2, AnchorWave3, AnchorWave4, AnchorWave5 };
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "EW WXYXZ";
                AnchorStart = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave1 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave2 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave3 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave4 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorWave5 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorStart.DisplayName = "0";
                AnchorWave1.DisplayName = "W";
                AnchorWave2.DisplayName = "X";
                AnchorWave3.DisplayName = "Y";
                AnchorWave4.DisplayName = "X";
                AnchorWave5.DisplayName = "Z";
                Degree = DegreeType.Submicro;
                DrawWaves = true;
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

}