#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Cheech
{

	/// <summary>
    /// Enter the description of your new custom indicator here
	///
	/// Original Author: NinjaTrader
	/// Credits To: John F. Ehlers
	/// Source: Stocks and Commoditites Magazine: Sept, 2017
	/// Original Article title: The Reverse EMA Indicator
	/// Enhancement by: Cheech
	/// Original Enhancement Date: 8/24/2017
	///  
	/// Enhancement:
	/// 1. Combines 2 REMAs in a single region, one for trends and one for cycles.
	/// 2. Provides the input parameter for both the Cycle nad Trend plots
	/// 
	/// Revision Date: 1/30/2018
	/// 1. Updated for NinjaTrader 8
    /// </summary>
	/// 
	
	[Gui.CategoryOrder("Input Parameters", 5)]
	[Gui.CategoryOrder("Data Series", 10)]
	[Gui.CategoryOrder("Lines", 15)]
	[Gui.CategoryOrder("Plots", 20)]	
	
	public class fpgMultiREMA : Indicator
	{
		private		double 			tAlpha 			= 0.1;  // Default setting for TrendAlpha
		private 	double 			cAlpha 			= 0.3;  // Default setting for CycleAlpha
	
		private		int				plot0Width		= 2;
		private		PlotStyle		plot0Style		= PlotStyle.Line;
		private 	DashStyleHelper	dash0Style		= DashStyleHelper.Solid;
		
		private		int				plot1Width		= 2;
		private		PlotStyle		plot1Style		= PlotStyle.Line;
		private		DashStyleHelper	dash1Style		= DashStyleHelper.Solid;
		
		private		int				line0Width		= 1;
		private		PlotStyle		line0Style		= PlotStyle.Line;
		private 	DashStyleHelper	zeroLineStyle	= DashStyleHelper.DashDot;
		
		private 	Brush			trendLineBrush	= Brushes.Magenta;
		private		Brush			cycleLineBrush	= Brushes.Cyan;
		private		Brush			zeroLineBrush	= Brushes.WhiteSmoke;
						
		private 	REMA			trema;
		private		REMA			crema;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This indicator is the NT8 version of the NT7 version of the same name.  The indicator will display 2 REMA plots, one for the Trend and the other for the Cycle.  The algoritm was designed by Ehlers and published in the August edition of S&C magazine.  The REMA indicator was written by Ninjatrader personnel and is called from this indicator.";
				Name										= "fpgMultiREMA";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= true;
				ArePlotsConfigurable						= false;
				AreLinesConfigurable 						= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AddPlot(new Stroke(Brushes.Magenta, 2),	PlotStyle.Line, 	"TrendREMA");
				AddPlot(new Stroke(Brushes.Cyan, 2),	PlotStyle.Line,		"CycleREMA");
				AddLine(Brushes.Gray, 0, "Zero Line");

			}
			else if (State == State.Configure)
			{
				//trema = REMA(Input, tAlpha);
				//crema = REMA(Input, cAlpha);
							
				Plots[0].Width				= plot0Width;
				Plots[0].PlotStyle 			= plot0Style;
				Plots[0].DashStyleHelper	= dash0Style;
				Plots[0].Brush 				= trendLineBrush;
				
				Plots[1].Width				= plot1Width;
				Plots[1].PlotStyle 			= plot1Style;
				Plots[1].DashStyleHelper	= dash1Style;
				Plots[1].Brush 				= cycleLineBrush;
				
				Lines[0].Width				= line0Width;
				Lines[0].DashStyleHelper	= zeroLineStyle;
				Lines[0].Brush				= zeroLineBrush;
				
			}
			
			else if (State == State.DataLoaded)
			{
				trema = REMA(Input, tAlpha);
				crema = REMA(Input, cAlpha);
				//trigger = LinReg(Input, triggerPeriod);
				//triggerAverage = EMA(trigger, avgPeriod);
				//if(Input is PriceSeries)
				//	calculateFromPriceData = true;
				//else
				//	calculateFromPriceData = false;
			}
		}
		
		protected override void OnBarUpdate()
		{
			if (CurrentBar < 1)
			{
				this.TrendREMA[0]	= 0;
				this.CycleREMA[0]	= 0;
				return;
			}
			
			this.TrendREMA[0]	= (trema[0]);
			this.CycleREMA[0]	= (crema[0]);
		}

		#region Properties

		#region Data Series
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TrendREMA
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CycleREMA
		{
			get { return Values[1]; }
		}
		
		#endregion Data Series
		
		#region Input Parameters
		//[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Trend Alpha", Description="Modifies the coefficient used in the EMA for the Trend REMA. Decrease the value to show more trend", Order=1, GroupName="Input Parameters")]
		public double TAlpha
		{ 
			get { return tAlpha; } 
			set { tAlpha = value; }
		}
		
		[Range(0, double.MaxValue)]
		[Display(Name="Cycle Alpha", Description="Modifies the coefficient used in the EMA for the Cycle REMA. Increase the value to show more Cycle", Order=2, GroupName="Input Parameters")]
		public double CAlpha
		{ 
			get { return cAlpha; } 
			set { cAlpha = value; }
		}
		#endregion Input Parameters
		
		#region Lines
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zero Line", Description = "Sets the color for the zeroline", GroupName = "Lines", Order = 0)]
		public Brush ZeroLineBrush
		{ 
			get {return zeroLineBrush;}
			set {zeroLineBrush = value;}
		}

		[Browsable(false)]
		public string ZeroLineBrushSerializable
		{
			get { return Serialize.BrushToString(zeroLineBrush); }
			set { zeroLineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zero Line width", Description = "Sets the plot width for the zero line", GroupName = "Lines", Order = 1)]
		public int Line0Width
		{	
            get { return line0Width; }
            set { line0Width = value; }
		}

		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style Zero Line", Description = "Sets the plot style for the Zero Line", GroupName = "Lines", Order = 2)]
		public PlotStyle Line0Style
		{	
            get { return line0Style; }
            set { line0Style = value; }
		}	
		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style", Description = "Sets the dash style for the zero line", GroupName = "Lines", Order = 3)]
		public DashStyleHelper ZeroLineStyle
		{
			get { return zeroLineStyle; }
			set { zeroLineStyle = value; }
		}
		
		
		
		
		#endregion Lines
		
		#region Plots
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend line", Description = "Sets the color for the Trend PLot", GroupName = "Plots", Order = 0)]
		public Brush TrendLineBrush
		{ 
			get {return trendLineBrush;}
			set {trendLineBrush = value;}
		}

		[Browsable(false)]
		public string TrendLineBrushSerializable
		{
			get { return Serialize.BrushToString(trendLineBrush); }
			set { trendLineBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Cycle line", Description = "Sets the color for the Cycle plot", GroupName = "Plots", Order = 1)]
		public Brush CycleLineBrush
		{ 
			get {return cycleLineBrush;}
			set {cycleLineBrush = value;}
		}

		[Browsable(false)]
		public string CycleLineBrushSerializable
		{
			get { return Serialize.BrushToString(cycleLineBrush); }
			set { cycleLineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width Trend", Description = "Sets the plot width for the Trend Line", GroupName = "Plots", Order = 2)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style Trend", Description = "Sets the plot style for the Trend", GroupName = "Plots", Order = 3)]
		public PlotStyle Plot0Style
		{	
            get { return plot0Style; }
            set { plot0Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style Trend", Description = "Sets the dash style for the Trend plot", GroupName = "Plots", Order = 4)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
			
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width Cycle", Description = "Sets the plot width for the Cycle plot", GroupName = "Plots", Order = 5)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style Cycle", Description = "Sets the plot style for the Cycle line", GroupName = "Plots", Order = 6)]
		public PlotStyle Plot1Style
		{	
            get { return plot1Style; }
            set { plot1Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style Cycle", Description = "Sets the dash style for the Cycle plot", GroupName = "Plots", Order = 7)]
		public DashStyleHelper Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		}
		
		
		#endregion Plots
		
		#endregion Properties

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Cheech.fpgMultiREMA[] cachefpgMultiREMA;
		public Cheech.fpgMultiREMA fpgMultiREMA()
		{
			return fpgMultiREMA(Input);
		}

		public Cheech.fpgMultiREMA fpgMultiREMA(ISeries<double> input)
		{
			if (cachefpgMultiREMA != null)
				for (int idx = 0; idx < cachefpgMultiREMA.Length; idx++)
					if (cachefpgMultiREMA[idx] != null &&  cachefpgMultiREMA[idx].EqualsInput(input))
						return cachefpgMultiREMA[idx];
			return CacheIndicator<Cheech.fpgMultiREMA>(new Cheech.fpgMultiREMA(), input, ref cachefpgMultiREMA);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Cheech.fpgMultiREMA fpgMultiREMA()
		{
			return indicator.fpgMultiREMA(Input);
		}

		public Indicators.Cheech.fpgMultiREMA fpgMultiREMA(ISeries<double> input )
		{
			return indicator.fpgMultiREMA(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Cheech.fpgMultiREMA fpgMultiREMA()
		{
			return indicator.fpgMultiREMA(Input);
		}

		public Indicators.Cheech.fpgMultiREMA fpgMultiREMA(ISeries<double> input )
		{
			return indicator.fpgMultiREMA(input);
		}
	}
}

#endregion
