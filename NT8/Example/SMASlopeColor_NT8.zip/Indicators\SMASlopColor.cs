#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SMASlopColor : Indicator
	{
		private double priorSum;
		private double sum;
		private bool    slopeColor  =true;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "SMASlopColor";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Period					= 50;
				UpTrend					= Brushes.ForestGreen;
				DownTrend					= Brushes.Red;
				AddPlot(Brushes.Orange, "SlopColor");
			}
			else if (State == State.Configure)
			{
				priorSum	= 0;
				sum			= 0;
			}
		}

		protected override void OnBarUpdate()
		{
			//Add your custom indicator logic here.
			if (BarsArray[0].BarsType.IsRemoveLastBarSupported)
			{
				if (CurrentBar == 0)
					Value[0] = Input[0];
				else
				{
					double last = Value[1] * Math.Min(CurrentBar, Period);

					if (CurrentBar >= Period)
						Value[0] = (last + Input[0] - Input[Period]) / Math.Min(CurrentBar, Period);
					else
						Value[0] = ((last + Input[0]) / (Math.Min(CurrentBar, Period) + 1));
				}
			}
			else
			{
				if (IsFirstTickOfBar)
					priorSum = sum;

				sum = priorSum + Input[0] - (CurrentBar >= Period ? Input[Period] : 0);
				Value[0] = sum / (CurrentBar < Period ? CurrentBar + 1 : Period);
			}
			
			if(IsRising(Value))
			{
			if(slopeColor)
			PlotBrushes[0][0] = UpTrend;
			}
			if(IsFalling(Value))
			{
			if(slopeColor)
			PlotBrushes[0][0] = DownTrend;
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Period", Order=1, GroupName="Parameters")]
		public int Period
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="UpTrend", Order=2, GroupName="Parameters")]
		public Brush UpTrend
		{ get; set; }

		[Browsable(false)]
		public string UpTrendSerializable
		{
			get { return Serialize.BrushToString(UpTrend); }
			set { UpTrend = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="DownTrend", Order=3, GroupName="Parameters")]
		public Brush DownTrend
		{ get; set; }

		[Browsable(false)]
		public string DownTrendSerializable
		{
			get { return Serialize.BrushToString(DownTrend); }
			set { DownTrend = Serialize.StringToBrush(value); }
		}			

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SlopColor
		{
			get { return Values[0]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SMASlopColor[] cacheSMASlopColor;
		public SMASlopColor SMASlopColor(int period, Brush upTrend, Brush downTrend)
		{
			return SMASlopColor(Input, period, upTrend, downTrend);
		}

		public SMASlopColor SMASlopColor(ISeries<double> input, int period, Brush upTrend, Brush downTrend)
		{
			if (cacheSMASlopColor != null)
				for (int idx = 0; idx < cacheSMASlopColor.Length; idx++)
					if (cacheSMASlopColor[idx] != null && cacheSMASlopColor[idx].Period == period && cacheSMASlopColor[idx].UpTrend == upTrend && cacheSMASlopColor[idx].DownTrend == downTrend && cacheSMASlopColor[idx].EqualsInput(input))
						return cacheSMASlopColor[idx];
			return CacheIndicator<SMASlopColor>(new SMASlopColor(){ Period = period, UpTrend = upTrend, DownTrend = downTrend }, input, ref cacheSMASlopColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SMASlopColor SMASlopColor(int period, Brush upTrend, Brush downTrend)
		{
			return indicator.SMASlopColor(Input, period, upTrend, downTrend);
		}

		public Indicators.SMASlopColor SMASlopColor(ISeries<double> input , int period, Brush upTrend, Brush downTrend)
		{
			return indicator.SMASlopColor(input, period, upTrend, downTrend);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SMASlopColor SMASlopColor(int period, Brush upTrend, Brush downTrend)
		{
			return indicator.SMASlopColor(Input, period, upTrend, downTrend);
		}

		public Indicators.SMASlopColor SMASlopColor(ISeries<double> input , int period, Brush upTrend, Brush downTrend)
		{
			return indicator.SMASlopColor(input, period, upTrend, downTrend);
		}
	}
}

#endregion
