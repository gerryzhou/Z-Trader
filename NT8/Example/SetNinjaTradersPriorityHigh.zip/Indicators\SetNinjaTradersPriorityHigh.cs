#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SetNinjaTradersPriorityHigh : Indicator
	{
		private PriorityClassJW3 priority = PriorityClassJW3.High;
		
		private string DebugSaveState = "";
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)			
			{
				Description							= @"Sets Ninja Trader's Priority to High or Selected Value";
				Name								= "SetNinjaTradersPriorityHigh";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= false;
				DrawOnPricePanel					= true;
				PaintPriceMarkers					= false;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;
				HideIndicatorName					= false;
				ShowNTPriority                      = true;
				Debug				            	= false;
				/*
				if (Debug) { 
					  Print ("SetNinjaTradersPriorityHigh: NinjaTrader's Priority at State.SetDefaults is " + System.Diagnostics.Process.GetCurrentProcess().PriorityClass);				
 	                  Process thisProc = Process.GetCurrentProcess();
				      Print("ProcessName:"+ thisProc.ProcessName);
				      Print("Process: " + thisProc.StartTime + " ID: " + thisProc.Id);
				      Print("    CPU time: " + thisProc.TotalProcessorTime);
				      Print("    priority class: " + thisProc.PriorityClass + " priority: " + thisProc.BasePriority);
				      Print("    virtual memory: " + thisProc.VirtualMemorySize);
				      Print("    private memory: " + thisProc.PrivateMemorySize);
				      Print("    physical memory: " + thisProc.WorkingSet);
			    }
				*/
			} 
			else if (State == State.Configure || State == State.Terminated)
			{   
				// https://msdn.microsoft.com/en-us/library/z3w4xdc9%28v=vs.110%29.aspx
				// https://msdn.microsoft.com/en-us/library/76fkb36k%28v=vs.110%29.aspx
			    Process thisProc = Process.GetCurrentProcess();
				if (thisProc.PriorityClass.ToString() == Priority.ToString()) {
			    	if (Debug)
				        Print ("SetNinjaTradersPriorityHigh: (" + State + ") NinjaTrader's Priority already " + priority);				
				}	
				else {							
					if (Debug) 
					    DebugSaveState = thisProc.PriorityClass.ToString();	
						switch (Priority)
					{
						case PriorityClassJW3.High:
						{
							System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
							break;
						}				
						case PriorityClassJW3.AboveNormal:
						{
							System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.AboveNormal;
							break;
						}
			    		case PriorityClassJW3.Normal:
						{
							System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.Normal;
							break;
						}			
						case PriorityClassJW3.BelowNormal:
						{
							System.Diagnostics.Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.BelowNormal;
							break;
						}		
					}
		    		if (Debug)
				        Print ("SetNinjaTradersPriorityHigh: (" + State + ") NinjaTrader's Priority changed from " + DebugSaveState + " to " + priority);
				}
				thisProc = null;
			}  
	    }

		public override string DisplayName
		{
		    get { 
				string rtn = "";
			   	if (!HideIndicatorName) 
					rtn += Name;
				if (ShowNTPriority)
					rtn +=  "(NT Priority=" + Priority + ")";
                return rtn;		
			}
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Select Priority", Description="If changed then must change in all instances of Priority in Indicators\nLEDOnMarketDataLast, LEDOnMarketDataBidAsk, or DataFeedMonitor.\nOtherwise, last Priority in Workspace will prevail.", Order=1, GroupName="Parameters")]
		public PriorityClassJW3 Priority
		{ 
			get { return priority; }
			set { priority = value; }
		}		
		[NinjaScriptProperty]
		[Display(Name="Hide Indicator Name", Description="Prevent display of Indicator's name at top of chart", Order=2, GroupName="Parameters")]
		public bool HideIndicatorName
		{ get; set; }
		[NinjaScriptProperty]
		[Display(Name="Show NT Priority", Description="Display NT's Process Priority at top of chart", Order=3, GroupName="Parameters")]
		public bool ShowNTPriority
		{ get; set; }
		[NinjaScriptProperty]
		[Display(Name="Debug message to\nOutput Window", Description="If true then debugging Output messages printed", Order=4, GroupName="Parameters")]
		public bool Debug
		{ get; set; }		
		#endregion
	
	}
}

public enum PriorityClassJW3
{
	High,
	AboveNormal,
	Normal, 
	BelowNormal,
}	

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SetNinjaTradersPriorityHigh[] cacheSetNinjaTradersPriorityHigh;
		public SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			return SetNinjaTradersPriorityHigh(Input, priority, hideIndicatorName, showNTPriority, debug);
		}

		public SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(ISeries<double> input, PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			if (cacheSetNinjaTradersPriorityHigh != null)
				for (int idx = 0; idx < cacheSetNinjaTradersPriorityHigh.Length; idx++)
					if (cacheSetNinjaTradersPriorityHigh[idx] != null && cacheSetNinjaTradersPriorityHigh[idx].Priority == priority && cacheSetNinjaTradersPriorityHigh[idx].HideIndicatorName == hideIndicatorName && cacheSetNinjaTradersPriorityHigh[idx].ShowNTPriority == showNTPriority && cacheSetNinjaTradersPriorityHigh[idx].Debug == debug && cacheSetNinjaTradersPriorityHigh[idx].EqualsInput(input))
						return cacheSetNinjaTradersPriorityHigh[idx];
			return CacheIndicator<SetNinjaTradersPriorityHigh>(new SetNinjaTradersPriorityHigh(){ Priority = priority, HideIndicatorName = hideIndicatorName, ShowNTPriority = showNTPriority, Debug = debug }, input, ref cacheSetNinjaTradersPriorityHigh);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			return indicator.SetNinjaTradersPriorityHigh(Input, priority, hideIndicatorName, showNTPriority, debug);
		}

		public Indicators.SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(ISeries<double> input , PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			return indicator.SetNinjaTradersPriorityHigh(input, priority, hideIndicatorName, showNTPriority, debug);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			return indicator.SetNinjaTradersPriorityHigh(Input, priority, hideIndicatorName, showNTPriority, debug);
		}

		public Indicators.SetNinjaTradersPriorityHigh SetNinjaTradersPriorityHigh(ISeries<double> input , PriorityClassJW3 priority, bool hideIndicatorName, bool showNTPriority, bool debug)
		{
			return indicator.SetNinjaTradersPriorityHigh(input, priority, hideIndicatorName, showNTPriority, debug);
		}
	}
}

#endregion
