#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.Infinity
{
	public class ReversalBarCloseMarker : Indicator
	{
		private int barPeriodValue = 0;
		
		protected override void OnStateChange()
		{
			if(State == State.SetDefaults)
			{
				Description					= @"";
				Name						= "ReversalBarCloseMarker";
				Calculate					= Calculate.OnEachTick;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				PaintPriceMarkers			= false;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive	= true;
				
				markColor	= Brushes.Orange;
				markWidth	= 1;
				markLength	= 10;
				markMargin	= 1;
			}
			else if(State == State.Configure)
			{
				if(BarsPeriod.BarsPeriodTypeName == "90")
				{
					barPeriodValue = BarsPeriod.Value;
				}
			}
		}

		protected override void OnBarUpdate() {}
		
		// OnRender
		//
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if(Bars == null || Bars.Instrument == null || IsInHitTest) { return; }
			
			base.OnRender(chartControl, chartScale);
			
			drawCloseMarker(chartControl, chartScale);
		}
		
		private void drawCloseMarker(ChartControl chartControl, ChartScale chartScale)
		{
			if(barPeriodValue == 0) { return; }
			
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode						 = SharpDX.Direct2D1.AntialiasMode.Aliased;
			
			// ---
			
			double currO = Bars.GetOpen(CurrentBar);
			double currH = Bars.GetHigh(CurrentBar);
			double currL = Bars.GetLow(CurrentBar);
			double currC = Bars.GetClose(CurrentBar);
			double markV = 0.0;
			
			if(currH >= currO + barPeriodValue * TickSize)
			{
				markV = currH - barPeriodValue * TickSize;
			}
			
			if(currL <= currO - barPeriodValue * TickSize)
			{
				markV = currL + barPeriodValue * TickSize;
			}
			
			if(markV != 0.0)
			{
				SharpDX.Direct2D1.Brush markBrush = markColor.ToDxBrush(RenderTarget);
				
				int barFullWidth = chartControl.GetBarPaintWidth(ChartBars);
				int barHalfWidth = ((barFullWidth - 1) / 2);
				
				int x = chartControl.GetXByBarIndex(ChartBars, CurrentBar);
				int y = chartScale.GetYByValue(markV);
				
				SharpDX.Vector2 vec1 = new SharpDX.Vector2();
				SharpDX.Vector2 vec2 = new SharpDX.Vector2();
				
				vec1.X = (float)(x + barHalfWidth + markMargin);
				vec1.Y = (float)y;
				
				vec2.X = (float)(x + barHalfWidth + markMargin + markLength);
				vec2.Y = (float)y;
				
				RenderTarget.DrawLine(vec1, vec2, markBrush, (float)markWidth);
				
				markBrush.Dispose();
			}
			
			// ---
			
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}
		
		#region Properties
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Color", GroupName = "Parameters", Order = 0)]
		public Brush markColor
		{ get; set; }
		
		[Browsable(false)]
		public string markColorSerializable
		{
			get { return Serialize.BrushToString(markColor); }
			set { markColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Width", GroupName = "Parameters", Order = 1)]
		public int markWidth
		{ get; set; }
		
		// ---
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Length", GroupName = "Parameters", Order = 2)]
		public int markLength
		{ get; set; }
		
		// ---
		
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Left Margin", GroupName = "Parameters", Order = 3)]
		public int markMargin
		{ get; set; }
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Infinity.ReversalBarCloseMarker[] cacheReversalBarCloseMarker;
		public Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(Brush markColor, int markWidth, int markLength, int markMargin)
		{
			return ReversalBarCloseMarker(Input, markColor, markWidth, markLength, markMargin);
		}

		public Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(ISeries<double> input, Brush markColor, int markWidth, int markLength, int markMargin)
		{
			if (cacheReversalBarCloseMarker != null)
				for (int idx = 0; idx < cacheReversalBarCloseMarker.Length; idx++)
					if (cacheReversalBarCloseMarker[idx] != null && cacheReversalBarCloseMarker[idx].markColor == markColor && cacheReversalBarCloseMarker[idx].markWidth == markWidth && cacheReversalBarCloseMarker[idx].markLength == markLength && cacheReversalBarCloseMarker[idx].markMargin == markMargin && cacheReversalBarCloseMarker[idx].EqualsInput(input))
						return cacheReversalBarCloseMarker[idx];
			return CacheIndicator<Infinity.ReversalBarCloseMarker>(new Infinity.ReversalBarCloseMarker(){ markColor = markColor, markWidth = markWidth, markLength = markLength, markMargin = markMargin }, input, ref cacheReversalBarCloseMarker);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(Brush markColor, int markWidth, int markLength, int markMargin)
		{
			return indicator.ReversalBarCloseMarker(Input, markColor, markWidth, markLength, markMargin);
		}

		public Indicators.Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(ISeries<double> input , Brush markColor, int markWidth, int markLength, int markMargin)
		{
			return indicator.ReversalBarCloseMarker(input, markColor, markWidth, markLength, markMargin);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(Brush markColor, int markWidth, int markLength, int markMargin)
		{
			return indicator.ReversalBarCloseMarker(Input, markColor, markWidth, markLength, markMargin);
		}

		public Indicators.Infinity.ReversalBarCloseMarker ReversalBarCloseMarker(ISeries<double> input , Brush markColor, int markWidth, int markLength, int markMargin)
		{
			return indicator.ReversalBarCloseMarker(input, markColor, markWidth, markLength, markMargin);
		}
	}
}

#endregion
