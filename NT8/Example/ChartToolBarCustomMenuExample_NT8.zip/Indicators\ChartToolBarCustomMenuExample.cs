#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartToolBarCustomMenuExample : Indicator
	{
		private NinjaTrader.Gui.Chart.ChartTab		chartTab;
		private NinjaTrader.Gui.Chart.Chart			chartWindow;
		private bool								isToolBarButtonAdded;
		private System.Windows.DependencyObject		searchObject;
		private System.Windows.Controls.TabItem		tabItem;
		private System.Windows.Controls.Menu		theMenu;
		private NinjaTrader.Gui.Tools.NTMenuItem	topMenuItem;
		private NinjaTrader.Gui.Tools.NTMenuItem	topMenuItemSubItem1;
		private NinjaTrader.Gui.Tools.NTMenuItem	topMenuItemSubItem2;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{				
				Name						= "ChartToolBarCustomMenuExample";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive	= true;
			}			
			else if (State == State.Historical)
			{
				if (ChartControl != null && !isToolBarButtonAdded)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						InsertWPFControls();
					}));
				}
			}
			else if (State == State.Terminated)
			{
				if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						RemoveWPFControls();
					}));
				}
			}
		}

		protected void InsertWPFControls()
		{
			chartWindow = System.Windows.Window.GetWindow(ChartControl.Parent) as Chart;

			foreach (System.Windows.DependencyObject item in chartWindow.MainMenu)
				if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == "ChartToolbarExampleMenu")
					return;

			// this is the actual object that you add to the chart windows Main Menu
			// which will act as a container for all the menu items
			theMenu = new System.Windows.Controls.Menu
			{
				// important to set the alignment, otherwise you will never see the menu populated
				VerticalAlignment			= VerticalAlignment.Top,
				VerticalContentAlignment	= VerticalAlignment.Top,

				// make sure to style as a System Menu	
				Style						= System.Windows.Application.Current.TryFindResource("SystemMenuStyle") as Style
			};

			System.Windows.Automation.AutomationProperties.SetAutomationId(theMenu, "ChartToolbarExampleMenu");

			// thanks to Jesse for these figures to use for the icon
			System.Windows.Media.Geometry topMenuItem1Icon = System.Windows.Media.Geometry.Parse("m 70.5 173.91921 c -4.306263 -1.68968 -4.466646 -2.46776 -4.466646 -21.66921 0 -23.88964 -1.364418 -22.5 22.091646 -22.5 23.43572 0 22.08568 -1.36412 22.10832 22.33888 0.0184 19.29356 -0.19638 20.3043 -4.64473 21.85501 -2.91036 1.01455 -32.493061 0.99375 -35.08859 -0.0247 z M 21 152.25 l 0 -7.5 20.25 0 20.25 0 0 7.5 0 7.5 -20.25 0 -20.25 0 0 -7.5 z m 93.75 0 0 -7.5 42.75 0 42.75 0 0 7.5 0 7.5 -42.75 0 -42.75 0 0 -7.5 z m 15.75 -38.33079 c -4.30626 -1.68968 -4.46665 -2.46775 -4.46665 -21.66921 0 -23.889638 -1.36441 -22.5 22.09165 -22.5 23.43572 0 22.08568 -1.364116 22.10832 22.338885 0.0185 19.293555 -0.19638 20.304295 -4.64473 21.855005 -2.91036 1.01455 -32.49306 0.99375 -35.08859 -0.0247 z M 21 92.25 l 0 -7.5 50.25 0 50.25 0 0 7.5 0 7.5 -50.25 0 -50.25 0 0 -7.5 z m 153.75 0 0 -7.5 12.75 0 12.75 0 0 7.5 0 7.5 -12.75 0 -12.75 0 0 -7.5 z M 55.5 53.919211 C 51.193737 52.229528 51.033354 51.451456 51.033354 32.25 51.033354 8.3603617 49.668936 9.75 73.125 9.75 96.560723 9.75 95.210685 8.3858835 95.23332 32.088887 95.25177 51.382441 95.03694 52.393181 90.588593 53.943883 87.678232 54.95844 58.095529 54.93764 55.5 53.919211 Z M 21 32.25 l 0 -7.5 12.75 0 12.75 0 0 7.5 0 7.5 -12.75 0 -12.75 0 0 -7.5 z m 78.75 0 0 -7.5 50.25 0 50.25 0 0 7.5 0 7.5 -50.25 0 -50.25 0 0 -7.5 z");

			// this is the menu item which will appear on the chart's Main Menu
			topMenuItem = new Gui.Tools.NTMenuItem()
			{
				Header				= "Menu 1",
				Foreground			= Brushes.PowderBlue,
				Icon				= topMenuItem1Icon,
				Margin				= new System.Windows.Thickness(0),
				Padding				= new System.Windows.Thickness(1),
				VerticalAlignment	= VerticalAlignment.Center,
				Style				= System.Windows.Application.Current.TryFindResource("MainMenuItem") as Style
			};

			theMenu.Items.Add(topMenuItem);

			topMenuItemSubItem1 = new Gui.Tools.NTMenuItem()
			{
				BorderThickness		= new System.Windows.Thickness(0),
				Header				= "Submenu Item 1",
				Style				= System.Windows.Application.Current.TryFindResource("InstrumentMenuItem") as Style
			};

			topMenuItemSubItem1.Click += TopMenuItem1SubItem1_Click;
			topMenuItem.Items.Add(topMenuItemSubItem1);

			topMenuItemSubItem2 = new Gui.Tools.NTMenuItem()
			{
				Header				= "Submenu Item 2",
				Style				= System.Windows.Application.Current.TryFindResource("InstrumentMenuItem") as Style
			};

			topMenuItemSubItem2.Click += TopMenuItem1SubItem2_Click;
			topMenuItem.Items.Add(topMenuItemSubItem2);			

			// add the menu which contains all menu items to the chart
			chartWindow.MainMenu.Add(theMenu);

			foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items)
				if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
					topMenuItem.Visibility = Visibility.Visible;

			chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
		}

		private void MySelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null)
				return;

			chartTab = tabItem.Content as NinjaTrader.Gui.Chart.ChartTab; 
			if (chartTab != null)
				if (topMenuItem != null)
					topMenuItem.Visibility = chartTab.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}

		protected override void OnBarUpdate() { }

		protected void RemoveWPFControls()
		{
			if (topMenuItemSubItem1 != null)
				topMenuItemSubItem1.Click -= TopMenuItem1SubItem1_Click;

			if (topMenuItemSubItem2 != null)
				topMenuItemSubItem2.Click -= TopMenuItem1SubItem2_Click;

			if (theMenu != null)
				chartWindow.MainMenu.Remove(theMenu);

			chartWindow.MainTabControl.SelectionChanged -= MySelectionChangedHandler;
		}

		protected void TopMenuItem1SubItem1_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M1I1 - Top menu subitem 1 selected", TextPosition.BottomLeft, Brushes.Green, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		protected void TopMenuItem1SubItem2_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			Draw.TextFixed(this, "infobox", "M1I2 - Top menu subitem 2 selected", TextPosition.BottomLeft, Brushes.ForestGreen, new Gui.Tools.SimpleFont("Arial", 25), Brushes.Transparent, Brushes.Transparent, 100);
			ChartControl.InvalidateVisual();
		}

		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartToolBarCustomMenuExample[] cacheChartToolBarCustomMenuExample;
		public ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample()
		{
			return ChartToolBarCustomMenuExample(Input);
		}

		public ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample(ISeries<double> input)
		{
			if (cacheChartToolBarCustomMenuExample != null)
				for (int idx = 0; idx < cacheChartToolBarCustomMenuExample.Length; idx++)
					if (cacheChartToolBarCustomMenuExample[idx] != null &&  cacheChartToolBarCustomMenuExample[idx].EqualsInput(input))
						return cacheChartToolBarCustomMenuExample[idx];
			return CacheIndicator<ChartToolBarCustomMenuExample>(new ChartToolBarCustomMenuExample(), input, ref cacheChartToolBarCustomMenuExample);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample()
		{
			return indicator.ChartToolBarCustomMenuExample(Input);
		}

		public Indicators.ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample(ISeries<double> input )
		{
			return indicator.ChartToolBarCustomMenuExample(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample()
		{
			return indicator.ChartToolBarCustomMenuExample(Input);
		}

		public Indicators.ChartToolBarCustomMenuExample ChartToolBarCustomMenuExample(ISeries<double> input )
		{
			return indicator.ChartToolBarCustomMenuExample(input);
		}
	}
}

#endregion
