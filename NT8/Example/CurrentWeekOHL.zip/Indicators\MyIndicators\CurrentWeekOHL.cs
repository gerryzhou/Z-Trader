#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyIndicators
{
	public class CurrentWeekOHL : Indicator
	{
		private DayOfWeek				startWeekFromDay	=	DayOfWeek.Monday;
		private DateTime 				currentDate 		=	Core.Globals.MinDate;
		private DateTime				lastDate			= 	Core.Globals.MinDate;
		private double					currentWeekOpen		=	0;
		private double					currentWeekHigh		=	0;
		private double					currentWeekLow		=	0;
		private	Data.SessionIterator	sessionIterator;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"CurrentWeekOHL based on CurrentDayOHL indicator";
				Name										= "CurrentWeekOHL";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				IsAutoScale									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// Parameters
				ShowCurrentWeekOpen							= true;
				ShowCurrentWeekHigh							= true;
				ShowCurrentWeekLow							= true;
				StartWeekFromDay							= DayOfWeek.Monday;
				// Plots
				AddPlot(new Stroke(Brushes.DarkGoldenrod, DashStyleHelper.Dot, 3), PlotStyle.Square, "CurrentWeekOpen");
				AddPlot(new Stroke(Brushes.DarkGreen, DashStyleHelper.Dot, 3), PlotStyle.Square, "CurrentWeekHigh");
				AddPlot(new Stroke(Brushes.IndianRed, DashStyleHelper.Dot, 3), PlotStyle.Square, "CurrentWeekLow");
			}
			else if (State == State.Configure)
			{
				currentDate 	    = Core.Globals.MinDate;
				currentWeekOpen		= double.MinValue;
				currentWeekHigh		= double.MinValue;
				currentWeekLow		= double.MaxValue;
				sessionIterator		= null;
			}
			else if (State == State.DataLoaded)
			{
				sessionIterator = new Data.SessionIterator(Bars);
			}
		}

		protected override void OnBarUpdate()
		{
			if (!Bars.BarsType.IsIntraday) return;
			lastDate = currentDate;
			if (sessionIterator.GetTradingDay(Time[0]).DayOfWeek == startWeekFromDay) {
				currentDate = sessionIterator.GetTradingDay(Time[0]);
			}
			if (lastDate != currentDate || currentWeekOpen == double.MinValue){
				currentWeekOpen = Open[0];
				currentWeekHigh	= High[0];
				currentWeekLow	= Low[0];
			}
			currentWeekHigh = Math.Max(currentWeekHigh, High[0]);
			currentWeekLow = Math.Min(currentWeekLow, Low[0]);
			if (ShowCurrentWeekOpen) { CurrentWeekOpen[0] = currentWeekOpen; }
			if (ShowCurrentWeekHigh) { CurrentWeekHigh[0] = currentWeekHigh; }
			if (ShowCurrentWeekLow)  { CurrentWeekLow[0] = currentWeekLow; }
		}
		
		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CurrentWeekOpen
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CurrentWeekHigh
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CurrentWeekLow
		{
			get { return Values[2]; }
		}
		
		[NinjaScriptProperty]
		[Display(Name="ShowCurrentWeekOpen", Order=1, GroupName="Parameters")]
		public bool ShowCurrentWeekOpen
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowCurrentWeekHigh", Order=2, GroupName="Parameters")]
		public bool ShowCurrentWeekHigh
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowCurrentWeekLow", Order=3, GroupName="Parameters")]
		public bool ShowCurrentWeekLow
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="StartWeekFromDay", Order=5, GroupName="Parameters")]
		public DayOfWeek StartWeekFromDay
		{
			get { return startWeekFromDay; }
			set { startWeekFromDay = value; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyIndicators.CurrentWeekOHL[] cacheCurrentWeekOHL;
		public MyIndicators.CurrentWeekOHL CurrentWeekOHL(bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			return CurrentWeekOHL(Input, showCurrentWeekOpen, showCurrentWeekHigh, showCurrentWeekLow, startWeekFromDay);
		}

		public MyIndicators.CurrentWeekOHL CurrentWeekOHL(ISeries<double> input, bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			if (cacheCurrentWeekOHL != null)
				for (int idx = 0; idx < cacheCurrentWeekOHL.Length; idx++)
					if (cacheCurrentWeekOHL[idx] != null && cacheCurrentWeekOHL[idx].ShowCurrentWeekOpen == showCurrentWeekOpen && cacheCurrentWeekOHL[idx].ShowCurrentWeekHigh == showCurrentWeekHigh && cacheCurrentWeekOHL[idx].ShowCurrentWeekLow == showCurrentWeekLow && cacheCurrentWeekOHL[idx].StartWeekFromDay == startWeekFromDay && cacheCurrentWeekOHL[idx].EqualsInput(input))
						return cacheCurrentWeekOHL[idx];
			return CacheIndicator<MyIndicators.CurrentWeekOHL>(new MyIndicators.CurrentWeekOHL(){ ShowCurrentWeekOpen = showCurrentWeekOpen, ShowCurrentWeekHigh = showCurrentWeekHigh, ShowCurrentWeekLow = showCurrentWeekLow, StartWeekFromDay = startWeekFromDay }, input, ref cacheCurrentWeekOHL);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyIndicators.CurrentWeekOHL CurrentWeekOHL(bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			return indicator.CurrentWeekOHL(Input, showCurrentWeekOpen, showCurrentWeekHigh, showCurrentWeekLow, startWeekFromDay);
		}

		public Indicators.MyIndicators.CurrentWeekOHL CurrentWeekOHL(ISeries<double> input , bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			return indicator.CurrentWeekOHL(input, showCurrentWeekOpen, showCurrentWeekHigh, showCurrentWeekLow, startWeekFromDay);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyIndicators.CurrentWeekOHL CurrentWeekOHL(bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			return indicator.CurrentWeekOHL(Input, showCurrentWeekOpen, showCurrentWeekHigh, showCurrentWeekLow, startWeekFromDay);
		}

		public Indicators.MyIndicators.CurrentWeekOHL CurrentWeekOHL(ISeries<double> input , bool showCurrentWeekOpen, bool showCurrentWeekHigh, bool showCurrentWeekLow, DayOfWeek startWeekFromDay)
		{
			return indicator.CurrentWeekOHL(input, showCurrentWeekOpen, showCurrentWeekHigh, showCurrentWeekLow, startWeekFromDay);
		}
	}
}

#endregion
