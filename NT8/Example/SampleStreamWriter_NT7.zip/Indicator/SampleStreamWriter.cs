// 
// Copyright (C) 2007, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// Add this to your declarations to use StreamWriter
using System.IO;

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// A quick sample demonstrating StreamWriter properties. The techniques used in this indicator are also applicable to strategies.
    /// </summary>
    [Description("A quick sample demonstrating StreamWriter properties.")]
    [Gui.Design.DisplayName("SampleStreamWriter")]
    public class SampleStreamWriter : Indicator
    {
        #region Variables
		private int		date			= 0;
		private double	currentOpen		= 0;
		private double	currentHigh		= 0;
		private double	currentLow		= 0;
		private double	currentClose	= 0;
		private bool	currentOpenSaved = false;
		private bool	currentLowSaved = false;
		
		// This sets the path in which the text file will be created.
		private string path 			= Cbi.Core.UserDataDir.ToString() + "MyTestFile.txt";
		
		// Creates a StreamWriter and a StreamReader object
		private System.IO.StreamWriter sw;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose	= true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			/* The try-catch block is used for error handling.
			In this case it is used to ensure you only have one stream object operating on the same file at any given moment. */
			try
			{
				// If file at 'path' doesn't exist it will create the file. If it does exist it will append the file.
				if (CurrentBar == 0)
					sw = File.AppendText(path);
				
				// This is the output of all lines.	The output format is as follows: Date Open High Low Close
				sw.WriteLine(ToDay(Time[0]) + " " + Open[0] + " " + High[0] + " " + Low[0] + " " + Close[0]);
			}
			
			catch (Exception e)
			{
				// Outputs the error to the log
				Log("You cannot write and read from the same file at the same time. Please remove SampleStreamReader.", NinjaTrader.Cbi.LogLevel.Error);
				throw;
			}
		}

		// Necessary to call in order to clean up resources used by the StreamWriter object
		protected override void OnTermination() 
		{
			// Disposes resources used by the StreamWriter
			if (sw != null)
			{
				sw.Dispose();
				sw = null;
			}
		}
		
        #region Properties

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private SampleStreamWriter[] cacheSampleStreamWriter = null;

        private static SampleStreamWriter checkSampleStreamWriter = new SampleStreamWriter();

        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        public SampleStreamWriter SampleStreamWriter()
        {
            return SampleStreamWriter(Input);
        }

        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        public SampleStreamWriter SampleStreamWriter(Data.IDataSeries input)
        {
            if (cacheSampleStreamWriter != null)
                for (int idx = 0; idx < cacheSampleStreamWriter.Length; idx++)
                    if (cacheSampleStreamWriter[idx].EqualsInput(input))
                        return cacheSampleStreamWriter[idx];

            lock (checkSampleStreamWriter)
            {
                if (cacheSampleStreamWriter != null)
                    for (int idx = 0; idx < cacheSampleStreamWriter.Length; idx++)
                        if (cacheSampleStreamWriter[idx].EqualsInput(input))
                            return cacheSampleStreamWriter[idx];

                SampleStreamWriter indicator = new SampleStreamWriter();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                Indicators.Add(indicator);
                indicator.SetUp();

                SampleStreamWriter[] tmp = new SampleStreamWriter[cacheSampleStreamWriter == null ? 1 : cacheSampleStreamWriter.Length + 1];
                if (cacheSampleStreamWriter != null)
                    cacheSampleStreamWriter.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheSampleStreamWriter = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.SampleStreamWriter SampleStreamWriter()
        {
            return _indicator.SampleStreamWriter(Input);
        }

        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        public Indicator.SampleStreamWriter SampleStreamWriter(Data.IDataSeries input)
        {
            return _indicator.SampleStreamWriter(input);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.SampleStreamWriter SampleStreamWriter()
        {
            return _indicator.SampleStreamWriter(Input);
        }

        /// <summary>
        /// A quick sample demonstrating StreamWriter properties.
        /// </summary>
        /// <returns></returns>
        public Indicator.SampleStreamWriter SampleStreamWriter(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.SampleStreamWriter(input);
        }
    }
}
#endregion
