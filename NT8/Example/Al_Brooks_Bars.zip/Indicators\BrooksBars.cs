#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	//  Ver 1.5   01/25/2011   Photog53)   BrooksBars....for learning Al Brooks system
	//   Converted to NT8b5 by Ninjascript team
	public class BrooksBars : Indicator
	{
		private int 	H = 0;
		private int 	L = 0;
		private int 	brooksH 	= 0;
		private int 	brooksHprev = 0;
		private int 	brooksL 	= 0;
		private int 	brooksLprev = 0;
		private string 	LabelH 		= "H";
		private string 	LabelL 		= "L";
		private bool 	drawLabel	= true; 		// drawLabel on/off
		private int 	numofLabels = 3; 			// x labels on Cart
		private bool	outsidebar 	= false; 		// Outsidebar labeling depends on prior bars on/off 
		private int 	textTicksOffset = 2; 		// Default setting for text ticks offset from bars
		private	Gui.Tools.SimpleFont textFont;
		private Brush textColorH = Brushes.DimGray; // Color of H
		private Brush textColorL = Brushes.DimGray; // Color of L
		//===== Inside Bar =====================
		private bool drawInsideBar		= true;
		private int insideOffset		= 0;
		private int insideCalc			= 2;
		private Brush insideColor		= Brushes.Gray;
		private Brush empty				= Brushes.Transparent;
		private double insidePosL		= 0;
		private double insidePosH		= 0;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"BrooksBars....for learning Al Brooks system";
				Name								= "BrooksBars";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= true;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= false;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive			= true;
				textFont							= new Gui.Tools.SimpleFont("Arial", 12);
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar == 0)
			{
				return;
			}

			if (drawLabel == true) // show all history labels
			{
				LabelH = "H"+CurrentBar;
				LabelL = "L"+CurrentBar;
			}
			else // drawLabel on
			{
				{
					if (brooksHprev == numofLabels)
					{
						brooksH = 1;
					}
					else
					{
						brooksH = brooksHprev + 1;
					}
						LabelH = "H"+brooksH;
				}
				{
					if (brooksLprev == numofLabels)
					{
						brooksL = 1;
					}
					else
					{
						brooksL = brooksLprev + 1;
					}
						LabelL = "L"+brooksL;
				}
			}
			//===============================  OUTSIDEBAR
			if (High[0] > High[1] && Low[0] < Low[1] && IsFirstTickOfBar) // outside bar
			{
				if ( outsidebar == true) // Outsidebar labeling depends on prior labeling
				{
					if (L == 1 && Close[0] > Open[0] && IsFirstTickOfBar) // outside H
					{
						Draw.Text(this, LabelH, false, "H", 0, High[0] + (TextTicksOffset+2) * TickSize, 0, textColorH, textFont, TextAlignment.Center, empty, empty, 0);
						Draw.Text(this, LabelL, false, "O", 0, Low[0] - TextTicksOffset * TickSize, 0, textColorL, textFont, TextAlignment.Center, empty, empty, 0);
						H = 1;
						L = 0;
						brooksHprev = brooksH;
					}
					else if (H == 1 && Close[0] < Open[0] && IsFirstTickOfBar)// outside L
					{	
						Draw.Text(this, LabelL, false, "L", 0, Low[0] - TextTicksOffset * TickSize, 0, textColorL, textFont, TextAlignment.Center, empty, empty, 0);
						Draw.Text(this, LabelH, false, "O", 0, High[0] + (TextTicksOffset+2) * TickSize, 0, textColorH, textFont, TextAlignment.Center, empty, empty, 0);
						H = 0;
						L = 1;
						brooksLprev = brooksL;
					}
					else  if (IsFirstTickOfBar) // Outsidebar labeling starts neutral with H and L
					{
						Draw.Text(this, LabelH, false, "O", 0, High[0] + (TextTicksOffset+2) * TickSize, 0, textColorH, textFont, TextAlignment.Center, empty, empty, 0);
						Draw.Text(this, LabelL, false, "O", 0, Low[0] - TextTicksOffset * TickSize, 0, textColorL, textFont, TextAlignment.Center, empty, empty, 0);
						H = 1;
						L = 1;
						brooksHprev = brooksH;
						brooksLprev = brooksL;	
					}
				}
				else if (IsFirstTickOfBar) // Outsidebar labeling starts neutral with H and L
				{
					Draw.Text(this, LabelH, false, "O", 0, High[0] + (TextTicksOffset+2) * TickSize, 0, textColorH, textFont, TextAlignment.Center, empty, empty, 0);
					Draw.Text(this, LabelL, false, "O", 0, Low[0] - TextTicksOffset * TickSize, 0, textColorL, textFont, TextAlignment.Center, empty, empty, 0);
					H = 1;
					L = 1;
					brooksHprev = brooksH;	
					brooksLprev = brooksL;	
				}	
			}
			//======================= "H" BARS ===========================================
			else if (High[0] > High[1] && L == 1 && IsFirstTickOfBar) // H bar
			{
				Draw.Text(this, LabelH, false, "H", 0, High[0] + (TextTicksOffset+2) * TickSize, 0, textColorH, textFont, TextAlignment.Center, empty, empty, 0);
				H = 1;
				L = 0;
				brooksHprev = brooksH;	
			}
			//================== "L" BARS   ===============================================
			else if (Low[0] < Low[1] && H == 1 && IsFirstTickOfBar) // L bar
			{
				Draw.Text(this, LabelL, false, "L", 0, Low[0] - TextTicksOffset * TickSize, 0, textColorL, textFont, TextAlignment.Center, empty, empty, 0);
				H = 0;
				L = 1;
				brooksLprev = brooksL;
			}
			
			//================= INSIDE BAR ==============
			if (drawInsideBar)
			{
				insidePosL = Low[1] + (insideCalc * TickSize);
				insidePosH = High[1] - (insideCalc * TickSize);
			
				if (High[0] < High[1] && Low[0] > Low[1])
				{
					Draw.TriangleDown(this, "Insidedn" + CurrentBar, false, 0, High[0] + (insideOffset * TickSize), insideColor);
					Draw.TriangleUp(this, "Insideup" + CurrentBar, false, 0, Low[0] - (insideOffset * TickSize), insideColor);
				}
				else
				{
					if ((High[0] == High[1]) && (Low [0] >= insidePosL))
					{
						//DrawText("Inside1"+CurrentBar,false, "I", 0, insidePos, 0, textColorL, textFont, StringAlignment.Center, empty, empty, 0);
						Draw.TriangleDown(this, "Insidedn"+CurrentBar,false,0, High[0]+(insideOffset * TickSize),insideColor);
						Draw.TriangleUp(this, "Insideup"+CurrentBar,false,0,Low[0]-(insideOffset * TickSize),insideColor);
					}
					if ((Low[0] == Low[1]) && (High[0] <= insidePosH))
					{
						//DrawText("test1"+CurrentBar,false, insidePosH.ToString(), 0, High[0], 0, textColorL, textFont, StringAlignment.Center, empty, empty, 0);
						Draw.TriangleDown(this, "Insidedn"+CurrentBar,false,0, High[0]+(insideOffset * TickSize),insideColor);
						Draw.TriangleUp(this, "Insideup"+CurrentBar,false,0,Low[0]-(insideOffset * TickSize),insideColor);					
					}
				}
			}
		//----last 
		}	//	OnBarUpdate()

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Draw All Labels", Description="True: Labels all bars, False limits to # below", Order=1, GroupName="Chart Set-up")]
		public bool DrawLabel
		{ 
			get{return drawLabel;}
			set{drawLabel = value;}
		}

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Number of labels", Description="Number of labels to show when Drall all labels is false", Order=2, GroupName="Chart Set-up")]
		public int NumOfLabels
		{ 
			get {return numofLabels;}
			set {numofLabels = value;}
		}

		[NinjaScriptProperty]
		[Display(Name="Draw Inside Bar", Description="Flag Inside bars?", Order=3, GroupName="Chart Set-up")]
		public bool DrawInsideBar
		{ 
			get {return drawInsideBar;}
			set {drawInsideBar = value;}
		}

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Inside Calc", Description="Number of ticks difference for Inside Bar calc", Order=4, GroupName="Chart Set-up")]
		public int InsideCalc
		{ 
			get {return insideCalc;}
			set {insideCalc = value;}
		}

		[NinjaScriptProperty]
		[Display(Name="Outsidebar", Description="Default Prints 'O' at High/Low on all outside bars....True = indicator tries to select H or L value based on prior bar....", Order=5, GroupName="Chart Set-up")]
		public bool Outsidebar
		{ 
			get {return outsidebar;}
			set {outsidebar = value;}
		}

		[Range(-1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Inside Flag Offset", Description="# of Ticks...Move Inside Bar flag 'x' # of ticks from High/Low of the bar", Order=6, GroupName="Chart Set-up")]
		public int InsideOffset
		{ 
			get {return insideOffset;}
			set {insideOffset = value;}
		}

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Text Label Offset", Description="Moves Brooks Text # of ticks from high/low of the bar", Order=7, GroupName="Chart Set-up")]
		public int TextTicksOffset
		{
			get {return textTicksOffset;}
			set {textTicksOffset = value;}
		}
		
		[Display(Name = "Text Font", Description= "select font, style, size to display on chart", GroupName= "Chart Set-up", Order= 8)]
		public Gui.Tools.SimpleFont TextFont
		{
			get { return textFont; }
			set { textFont = value; }
		}		
		[XmlIgnore]
		[Display(Name="Text Color H", Description="Color of H", Order=9, GroupName="Chart Set-up")]		
		public Brush TextColorH 
		{
			get { return textColorH; }
			set { textColorH = value;; }
		}	
		[Browsable(false)]
		public string TextColorHSerializable
		{
			get { return Serialize.BrushToString(textColorH); }
			set { textColorH = Serialize.StringToBrush(value); }
		}	
		[XmlIgnore]
		[Display(Name="Text Color L", Description="Color of L", Order=10, GroupName="Chart Set-up")]		
		public Brush TextColorL 
		{
			get { return textColorL; }
			set { textColorL = value;; }
		}	
		[Browsable(false)]
		public string TextColorLSerializable
		{
			get { return Serialize.BrushToString(textColorL); }
			set { textColorL = Serialize.StringToBrush(value); }
		}	
		[XmlIgnore]
		[Display(Name="InsideBar Color", Description="Color of Inside Bar Flag ", Order=11, GroupName="Chart Set-up")]		
		public Brush InsideColor 
		{
			get { return insideColor; }
			set { insideColor = value;; }
		}	
		[Browsable(false)]
		public string InsideColorSerializable
		{
			get { return Serialize.BrushToString(insideColor); }
			set { insideColor = Serialize.StringToBrush(value); }
		}	
		
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BrooksBars[] cacheBrooksBars;
		public BrooksBars BrooksBars(bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			return BrooksBars(Input, drawLabel, numOfLabels, drawInsideBar, insideCalc, outsidebar, insideOffset, textTicksOffset);
		}

		public BrooksBars BrooksBars(ISeries<double> input, bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			if (cacheBrooksBars != null)
				for (int idx = 0; idx < cacheBrooksBars.Length; idx++)
					if (cacheBrooksBars[idx] != null && cacheBrooksBars[idx].DrawLabel == drawLabel && cacheBrooksBars[idx].NumOfLabels == numOfLabels && cacheBrooksBars[idx].DrawInsideBar == drawInsideBar && cacheBrooksBars[idx].InsideCalc == insideCalc && cacheBrooksBars[idx].Outsidebar == outsidebar && cacheBrooksBars[idx].InsideOffset == insideOffset && cacheBrooksBars[idx].TextTicksOffset == textTicksOffset && cacheBrooksBars[idx].EqualsInput(input))
						return cacheBrooksBars[idx];
			return CacheIndicator<BrooksBars>(new BrooksBars(){ DrawLabel = drawLabel, NumOfLabels = numOfLabels, DrawInsideBar = drawInsideBar, InsideCalc = insideCalc, Outsidebar = outsidebar, InsideOffset = insideOffset, TextTicksOffset = textTicksOffset }, input, ref cacheBrooksBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BrooksBars BrooksBars(bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			return indicator.BrooksBars(Input, drawLabel, numOfLabels, drawInsideBar, insideCalc, outsidebar, insideOffset, textTicksOffset);
		}

		public Indicators.BrooksBars BrooksBars(ISeries<double> input , bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			return indicator.BrooksBars(input, drawLabel, numOfLabels, drawInsideBar, insideCalc, outsidebar, insideOffset, textTicksOffset);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BrooksBars BrooksBars(bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			return indicator.BrooksBars(Input, drawLabel, numOfLabels, drawInsideBar, insideCalc, outsidebar, insideOffset, textTicksOffset);
		}

		public Indicators.BrooksBars BrooksBars(ISeries<double> input , bool drawLabel, int numOfLabels, bool drawInsideBar, int insideCalc, bool outsidebar, int insideOffset, int textTicksOffset)
		{
			return indicator.BrooksBars(input, drawLabel, numOfLabels, drawInsideBar, insideCalc, outsidebar, insideOffset, textTicksOffset);
		}
	}
}

#endregion
