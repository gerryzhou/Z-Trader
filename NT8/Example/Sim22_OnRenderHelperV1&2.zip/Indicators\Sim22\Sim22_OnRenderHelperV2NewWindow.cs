#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

using SharpDX;
using SharpDX.DirectWrite;
using SharpDX.Direct2D1;

using System.IO;
using System.Windows.Automation;
using System.Windows.Automation.Provider;
using System.Windows.Controls;
using System.Windows.Markup;
using NinjaTrader.Gui.Tools;
using System.Windows.Documents;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
	/// <summary>
	/// OnRender value helper using a new NT window.
	/// This was made in an effort to understand the actual values used to plot indicators.
	/// It has certainly saved my sanity once or twice!
	/// 
	/// Known issue: If the chart is modified in any way the window will cease to update it's values. You must close it and reopen it again with the button.
	/// 
	/// Sim22 March 2016 NT8b10. simterann22@gmx.com
	/// </summary>
	public class Sim22_OnRenderHelperV2NewWindow : Indicator
	{
		private Chart					chartWindow;
		private DependencyObject		searchObject;
		private bool					isToolBarButtonAdded;
		private Button					newWindowButton;
		private NTWindow				newWindow;
		string	panelNum				= "";
		string	autoPropertiesIDName	= null;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"OnRender value helper. Sim22 Mar 2016 NT8b10.";
				Name						= "Sim22_OnRenderHelperV2_NewWindow";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				DrawHorizontalGridLines		= true;
				DrawVerticalGridLines		= true;
				PaintPriceMarkers			= false;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Overlay;
				IsSuspendedWhileInactive	= true;
				IsAutoScale					= false;
				
				AddPlot(Brushes.CornflowerBlue, "Current-Bar");
			}
			else if (State == State.Configure)
			{
				// make sure these values are not changed
				IsAutoScale					= false;
				PaintPriceMarkers			= false;
				DisplayInDataBox			= true;
			}
			else if (State == State.Historical)
			{
				// bars must be loaded first
				panelNum	= (ChartPanel.PanelIndex + 1).ToString();
				
				InstallButton();
			}
			 
			else if (State == State.Terminated)
			{
				RemoveButton_Window();
			}
		}
		
		public override string DisplayName
		{
		    get { 
					return (String.Format("Sim22_OnRenderHelper(Panel{0})", panelNum));
				}
		}
		
		protected override void OnBarUpdate()
		{
			Values[0][0] 	= CurrentBar;
		}
		
		#region Button
		protected void	InstallButton()
		{
			if (!isToolBarButtonAdded) 
					Dispatcher.BeginInvoke((Action)(() => {
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;
						
						chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
						foreach (DependencyObject item in chartWindow.MainMenu)
						{
							if (AutomationProperties.GetAutomationId(item) == autoPropertiesIDName)
							{
								isToolBarButtonAdded = true;
							}
						}

						if (!isToolBarButtonAdded)
						{
							newWindowButton = new Button { Content = "ORHelp" + panelNum, Background = Brushes.CornflowerBlue, Foreground = Brushes.AliceBlue, Visibility = Visibility.Collapsed };
							foreach (TabItem tab in chartWindow.MainTabControl.Items)
								if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem)
									newWindowButton.Visibility = Visibility.Visible;

							chartWindow.MainMenu.Add(newWindowButton);
							chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
							newWindowButton.Click += NewWindowButtonClick;
							
							//make a random number for the ID. Prevents tab/name problems
							Random rnd	= new Random();
							autoPropertiesIDName	= rnd.Next(100000).ToString();
								
							AutomationProperties.SetAutomationId(newWindowButton, autoPropertiesIDName);
						}
					}));
		}
		protected void	RemoveButton_Window()
		{
			if(chartWindow != null)
			{					
				if (newWindowButton != null)
				{
					Dispatcher.Invoke((Action)(() =>
					{
						chartWindow.MainMenu.Remove(newWindowButton);						
						newWindowButton.Click -= NewWindowButtonClick;
						newWindowButton = null;
						
						// just in case newWindow is left open
						if (newWindow != null)
						{
							newWindow.Close();
							newWindow = null;
						}
					}));
				}
				chartWindow.MainTabControl.SelectionChanged -= MySelectionChangedHandler;
				chartWindow = null;
			}
			
		}
		#endregion
		
		#region Events	
		
		private void NewWindowButtonClick(object sender, RoutedEventArgs e)
		{
			if (newWindow == null || !newWindow.IsLoaded)
			{
				newWindow = new NTWindow();
				newWindow.Caption	= "OnRender Helper for panel #" + panelNum;
				newWindow.Show();
				ForceRefresh();
			}
		}
		
		private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab; 
			if (temp != null)
			{
				if (newWindowButton != null)
					newWindowButton.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
			}
		}
		
		public void linkToNTHelp_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://ninjatrader.com/support/helpGuides/nt8/en-us/?chart.htm");
		}
		 #endregion
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if( Bars == null || ChartControl == null || Bars.Instrument == null || !IsVisible ) 
			{
				return;
			}
			
			/*
				Note: There may be an easier way of accomplishing this by using a more direct call to 'properties' and listing the entire contents possibly via an array?
				I'd appreciate an email if you have a better way, thanks. simterann22@gmx.com
			*/

			try
			{
				string 	bw		= chartControl.BarWidth.ToString();
				string	sp		= chartControl.SlotsPainted.ToString();
				string	lsp		= chartControl.LastSlotPainted.ToString();
				string	fi		= ChartBars.FromIndex.ToString();
				string	ti		= ChartBars.ToIndex.ToString();
				string	co		= ChartBars.Count.ToString();
				string	gbpw	= chartControl.GetBarPaintWidth(ChartBars).ToString();
				string	cl		= chartControl.CanvasLeft.ToString();
				string 	cr		= chartControl.CanvasRight.ToString();
				string	bd		= chartControl.Properties.BarDistance.ToString();
				string	bmr		= chartControl.Properties.BarMarginRight.ToString();
				string	cch		= chartControl.ActualHeight.ToString();
				string	ccw		= chartControl.ActualWidth.ToString();
				string 	cpx		= ChartPanel.X.ToString();
				string 	cpy		= ChartPanel.Y.ToString();
				string 	cpw		= ChartPanel.W.ToString();
				string 	cph		= ChartPanel.H.ToString();
				string 	cpmax	= ChartPanel.MaxValue.ToString();
				string 	cpmin	= ChartPanel.MinValue.ToString();
				string	csgp	= chartScale.GetPixelsForDistance(TickSize).ToString();
				string	csgy	= chartScale.GetYByValue(Close[0]).ToString();
				string	csh		= chartScale.Height.ToString();
				string csmm		= chartScale.MaxMinusMin.ToString();
				string	csmx	= chartScale.MaxValue.ToString();
				string	csmn	= chartScale.MinValue.ToString();
				string	csw		= chartScale.Width.ToString();
				
				string	barNumbers		= String.Format(" Bar Numbers: \n\n ChartControl.SlotsPainted \t\t= {0} \n ChartControl.LastSlotPainted \t\t= {1} \n ChartBars.FromIndex \t\t\t= {2} \n ChartBars.ToIndex \t\t\t= {3} \n ChartBars.Count \t\t\t= {4}\n\n", sp, lsp, fi, ti, co);
				string	barFormatting	=  String.Format(" Bar Formatting: \n\n ChartControl.BarWidth \t\t\t= {0} \n ChartControl.GetBarPaintWidth() \t\t= {1} \n ChartControl.Properties.BarDistance \t= {2} \n ChartControl.Properties.BarMarginRight \t= {3}\n\n", bw, gbpw, bd, bmr);
				string	canvas			= String.Format(" Chart Properties: \n\n ChartControl.CanvasLeft \t\t\t= {0} \n ChartControl.CanvasRight \t\t= {1} \n ChartControl.ActualHeight \t\t= {2} \n ChartControl.ActualWidth \t\t= {3}\n\n", cl, cr, cch, ccw);
				string	chartpanel		= String.Format(" Panel Properties: \n\n ChartPanel.X \t\t\t\t= {0} \n ChartPanel.Y \t\t\t\t= {1} \n ChartPanel.W \t\t\t\t= {2} \n ChartPanel.H \t\t\t\t= {3} \n ChartPanel.MaxValue \t\t\t= {4} \n ChartPanel.MinValue \t\t\t= {5}\n\n", cpx, cpy, cpw, cph, cpmax, cpmin);
				string 	chartscale		= String.Format(" Chart Scale: \n\n ChartScale.GetPixelsForDistance(TickSize) \t= {0} \n ChartScale.GetYByValue(Close[0])\t\t= {1} \n ChartScale.Height\t\t\t= {2} \n ChartScale.Max\t\t\t\t= {3} \n ChartScale.Min\t\t\t\t= {4} \n ChartScale.MaxMinusMin\t\t\t= {5} \n ChartScale.Width\t\t\t= {6}\n\n", csgp, csgy, csh, csmx, csmn, csmm, csw);
				
				// create and run a hyperlink to NT8 help.
				Run run3 = new Run("here");
				Hyperlink hyperl = new Hyperlink(run3);
				hyperl.Click 	+= (linkToNTHelp_Click);
				
				TextBlock txtBlock1 = new TextBlock();  
			   	txtBlock1.Text = "\n\n" + barNumbers + barFormatting + canvas + chartpanel + chartscale + "\nMake sure you place the indicator in the panel you wish to assess. \n\nIf you refresh 'F5' the chart the window will close.\n\nPlease see the NT8 help for definitions.....";
			    txtBlock1.FontSize = 14;
			    txtBlock1.FontWeight = FontWeights.Regular;  
			    txtBlock1.Foreground = Brushes.Black;
			    txtBlock1.VerticalAlignment = VerticalAlignment.Top; 
				txtBlock1.HorizontalAlignment = HorizontalAlignment.Left;
				txtBlock1.Inlines.Add(hyperl);
				newWindow.Content = txtBlock1;
			}
			catch
			{}
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_OnRenderHelperV2NewWindow[] cacheSim22_OnRenderHelperV2NewWindow;
		public Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow()
		{
			return Sim22_OnRenderHelperV2NewWindow(Input);
		}

		public Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow(ISeries<double> input)
		{
			if (cacheSim22_OnRenderHelperV2NewWindow != null)
				for (int idx = 0; idx < cacheSim22_OnRenderHelperV2NewWindow.Length; idx++)
					if (cacheSim22_OnRenderHelperV2NewWindow[idx] != null &&  cacheSim22_OnRenderHelperV2NewWindow[idx].EqualsInput(input))
						return cacheSim22_OnRenderHelperV2NewWindow[idx];
			return CacheIndicator<Sim22.Sim22_OnRenderHelperV2NewWindow>(new Sim22.Sim22_OnRenderHelperV2NewWindow(), input, ref cacheSim22_OnRenderHelperV2NewWindow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow()
		{
			return indicator.Sim22_OnRenderHelperV2NewWindow(Input);
		}

		public Indicators.Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow(ISeries<double> input )
		{
			return indicator.Sim22_OnRenderHelperV2NewWindow(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow()
		{
			return indicator.Sim22_OnRenderHelperV2NewWindow(Input);
		}

		public Indicators.Sim22.Sim22_OnRenderHelperV2NewWindow Sim22_OnRenderHelperV2NewWindow(ISeries<double> input )
		{
			return indicator.Sim22_OnRenderHelperV2NewWindow(input);
		}
	}
}

#endregion
