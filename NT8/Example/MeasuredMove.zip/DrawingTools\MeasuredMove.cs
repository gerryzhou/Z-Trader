// 
// Copyright (C) 2018, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

#region Using declarations

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Point = System.Windows.Point;
using TextAlignment = SharpDX.DirectWrite.TextAlignment;

#endregion

namespace NinjaTrader.NinjaScript.DrawingTools
{
    public abstract class MeasuredMoveLevels : PriceLevelContainer
    {
        protected const int CursorSensitivity = 15;
        protected ChartAnchor editingAnchor;
        private int priceLevelOpacity;

        [Display(ResourceType = typeof(Custom.Resource), Name = "LineStroke", GroupName = "NinjaScriptLines", Order = 1)]
        public Stroke AnchorLineStroke { get; set; }

        // fib tools have a start and end at very least
        [Display(Order = 1)]
        public ChartAnchor StartAnchor { get; set; }

        [Display(Order = 2)]
        public ChartAnchor EndAnchor { get; set; }

        [Display(Order = 3)]
        public ChartAnchor Anchor50 { get; set; }

        [Display(Order = 4)]
        public ChartAnchor AnchorTarget { get; set; }

        [Range(0, 100)]
        [Display(ResourceType = typeof(Custom.Resource), Name = "Opacity", GroupName = "NinjaScriptGeneral")]
        public int PriceLevelOpacity
        {
            get { return priceLevelOpacity; }
            set { priceLevelOpacity = Math.Max(0, Math.Min(100, value)); }
        }

        [Display(Order = 4)]
        public bool TextVisible { get; set; }

        public override IEnumerable<ChartAnchor> Anchors
        {
            get
            {
                return new[] { StartAnchor, EndAnchor, Anchor50, AnchorTarget };
            }
        }

        public override bool SupportsAlerts
        {
            get
            {
                return true;
            }
        }

        public override IEnumerable<AlertConditionItem> GetAlertConditionItems()
        {
            if (PriceLevels == null || PriceLevels.Count == 0)
            {
                yield break;
            }

            foreach (var priceLevel in PriceLevels)
            {
                yield return new AlertConditionItem
                {
                    Name = priceLevel.Name,
                    ShouldOnlyDisplayName = true,
                    // stuff our actual price level in the tag so we can easily find it in the alert callback
                    Tag = priceLevel
                };
            }
        }
    }

    /// <summary>
    /// Represents an interface that exposes information regarding a MeasuredMove Retracements IDrawingTool.
    /// </summary>
    [EditorBrowsable(EditorBrowsableState.Always)]
    public class MeasuredMove : MeasuredMoveLevels
    {
        [Display(ResourceType = typeof(Custom.Resource), Name = "ExtendLinesRight", GroupName = "NinjaScriptLines")]
        public bool IsExtendedLinesRight { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "ExtendLinesLeft", GroupName = "NinjaScriptLines")]
        public bool IsExtendedLinesLeft { get; set; }

        [Display(ResourceType = typeof(Custom.Resource), Name = "TextLocation", GroupName = "NinjaScriptGeneral")]
        public TextLocation TextLocation { get; set; }

        protected bool CheckAlertRetracementLine(Condition condition, Point lineStartPoint, Point lineEndPoint,
            ChartControl chartControl, ChartScale chartScale, ChartAlertValue[] values)
        {
            // not completely drawn yet?
            if (Anchors.Count(a => a.IsEditing) > 1)
            {
                return false;
            }

            if (values[0].ValueType == ChartAlertValueType.StaticTime)
            {
                var checkX = chartControl.GetXByTime(values[0].Time);
                return lineStartPoint.X >= checkX || lineEndPoint.X >= checkX;
            }

            double firstBarX = chartControl.GetXByTime(values[0].Time);
            double firstBarY = chartScale.GetYByValue(values[0].Value);
            var barPoint = new Point(firstBarX, firstBarY);

            // bars passed our drawing tool line
            if (lineEndPoint.X < firstBarX)
            {
                return false;
            }

            // bars not yet to our drawing tool line
            if (lineStartPoint.X > firstBarX)
            {
                return false;
            }

            // NOTE: 'left / right' is relative to if line was vertical. it can end up backwards too
            var pointLocation = MathHelper.GetPointLineLocation(lineStartPoint, lineEndPoint, barPoint);
            // for vertical things, think of a vertical line rotated 90 degrees to lay flat, where it's normal vector is 'up'
            switch (condition)
            {
                case Condition.Greater: return pointLocation == MathHelper.PointLineLocation.LeftOrAbove;
                case Condition.GreaterEqual:
                    return pointLocation == MathHelper.PointLineLocation.LeftOrAbove ||
                           pointLocation == MathHelper.PointLineLocation.DirectlyOnLine;
                case Condition.Less: return pointLocation == MathHelper.PointLineLocation.RightOrBelow;
                case Condition.LessEqual:
                    return pointLocation == MathHelper.PointLineLocation.RightOrBelow ||
                           pointLocation == MathHelper.PointLineLocation.DirectlyOnLine;
                case Condition.Equals: return pointLocation == MathHelper.PointLineLocation.DirectlyOnLine;
                case Condition.NotEqual: return pointLocation != MathHelper.PointLineLocation.DirectlyOnLine;
                case Condition.CrossAbove:
                case Condition.CrossBelow:
                    Predicate<ChartAlertValue> predicate = v =>
                    {
                        if (v.Time == Globals.MinDate)
                        {
                            return false;
                        }

                        double barX = chartControl.GetXByTime(v.Time);
                        double barY = chartScale.GetYByValue(v.Value);
                        var stepBarPoint = new Point(barX, barY);
                        // NOTE: 'left / right' is relative to if line was vertical. it can end up backwards too
                        var ptLocation = MathHelper.GetPointLineLocation(lineStartPoint, lineEndPoint, stepBarPoint);
                        if (condition == Condition.CrossAbove)
                        {
                            return ptLocation == MathHelper.PointLineLocation.LeftOrAbove;
                        }

                        return ptLocation == MathHelper.PointLineLocation.RightOrBelow;
                    };
                    return MathHelper.DidPredicateCross(values, predicate);
            }

            return false;
        }

        protected void DrawPriceLevelText(ChartPanel chartPanel, ChartScale chartScale, double minX, double maxX, double y, double price,
            PriceLevel priceLevel)
        {
            if (TextLocation == TextLocation.Off || priceLevel == null || priceLevel.Stroke == null || priceLevel.Stroke.BrushDX == null)
            {
                return;
            }

            // make a rectangle that sits right at our line, depending on text alignment settings
            var wpfFont = chartPanel.ChartControl.Properties.LabelFont ?? new SimpleFont();
            var textFormat = wpfFont.ToDirectWriteTextFormat();
            textFormat.TextAlignment = TextAlignment.Leading;
            textFormat.WordWrapping = WordWrapping.NoWrap;

            var str = GetPriceString(price, priceLevel);

            // when using extreme alignments, give a few pixels of padding on the text so we dont end up right on the edge
            const double edgePadding = 2f;
            var layoutWidth = (float)Math.Abs(maxX - minX); // always give entire available width for layout
            // dont use max x for max text width here, that can break inside left/right when extended lines are on
            var textLayout = new TextLayout(Globals.DirectWriteFactory, str, textFormat, layoutWidth, textFormat.FontSize);

            double drawAtX;

            if (IsExtendedLinesLeft && TextLocation == TextLocation.ExtremeLeft)
            {
                drawAtX = chartPanel.X + edgePadding;
            }
            else if (IsExtendedLinesRight && TextLocation == TextLocation.ExtremeRight)
            {
                drawAtX = chartPanel.X + chartPanel.W - textLayout.Metrics.Width;
            }
            else
            {
                if (TextLocation == TextLocation.InsideLeft || TextLocation == TextLocation.ExtremeLeft)
                {
                    drawAtX = minX - 1;
                }
                else
                {
                    drawAtX = maxX - 1 - textLayout.Metrics.Width;
                }
            }

            // we also move our y value up by text height so we draw label above line like NT7.
            RenderTarget.DrawTextLayout(new Vector2((float)drawAtX, (float)(y - textFormat.FontSize - edgePadding)), textLayout,
                priceLevel.Stroke.BrushDX, DrawTextOptions.NoSnap);

            textFormat.Dispose();
            textLayout.Dispose();
        }

        public override Cursor GetCursor(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, Point point)
        {
            switch (DrawingState)
            {
                case DrawingState.Building: return Cursors.Pen;
                case DrawingState.Moving: return IsLocked ? Cursors.No : Cursors.SizeAll;
                case DrawingState.Editing:
                    if (IsLocked)
                    {
                        return Cursors.No;
                    }

                    return editingAnchor == StartAnchor ? Cursors.SizeNESW : Cursors.SizeNWSE;
                default:
                    // draw move cursor if cursor is near line path anywhere
                    var startAnchorPixelPoint = StartAnchor.GetPoint(chartControl, chartPanel, chartScale);

                    var closest = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);
                    if (closest != null)
                    {
                        if (IsLocked)
                        {
                            return null;
                        }

                        return closest == StartAnchor ? Cursors.SizeNESW : Cursors.SizeNWSE;
                    }

                    var totalVector = EndAnchor.GetPoint(chartControl, chartPanel, chartScale) - startAnchorPixelPoint;
                    return MathHelper.IsPointAlongVector(point, startAnchorPixelPoint, totalVector, CursorSensitivity)
                        ? IsLocked ? Cursors.Arrow : Cursors.SizeAll
                        : null;
            }
        }

        // Item1 = leftmost point, Item2 rightmost point of line
        protected Tuple<Point, Point> GetPriceLevelLinePoints(PriceLevel priceLevel, ChartControl chartControl, ChartScale chartScale,
            bool isInverted)
        {
            var chartPanel = chartControl.ChartPanels[PanelIndex];
            var anchorStartPoint = StartAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var anchorEndPoint = EndAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var targetEndPoint = AnchorTarget.GetPoint(chartControl, chartPanel, chartScale);

            var totalPriceRange = EndAnchor.Price - StartAnchor.Price;
            // dont forget user could start/end draw backwards
            var anchorMinX = Math.Min(anchorStartPoint.X, targetEndPoint.X);
            var anchorMaxX = Math.Max(anchorStartPoint.X, targetEndPoint.X);
            var lineStartX = IsExtendedLinesLeft ? chartPanel.X : anchorMinX;
            var lineEndX = IsExtendedLinesRight ? chartPanel.X + chartPanel.W : anchorMaxX;
            double levelY = priceLevel.GetY(chartScale, StartAnchor.Price, totalPriceRange, isInverted);
            return new Tuple<Point, Point>(new Point(lineStartX, levelY), new Point(lineEndX, levelY));
        }

        private string GetPriceString(double price, PriceLevel priceLevel)
        {
            // note, dont use MasterInstrument.FormatPrice() as it will round value to ticksize which we do not want
            var priceStr = price.ToString(Globals.GetTickFormatString(AttachedTo.Instrument.MasterInstrument.TickSize));
            var pct = priceLevel.Value / 100d;
            var str = string.Format("{0} ({1})", pct.ToString("P", Globals.GeneralOptions.CurrentCulture), priceStr);
            return str;
        }

        public override Point[] GetSelectionPoints(ChartControl chartControl, ChartScale chartScale)
        {
            var chartPanel = chartControl.ChartPanels[PanelIndex];

            var startPoint = StartAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var endPoint = EndAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var midPoint = new Point((startPoint.X + endPoint.X) / 2, (startPoint.Y + endPoint.Y) / 2);
            var point50 = Anchor50.GetPoint(chartControl, chartPanel, chartScale);
            var pointTarget = AnchorTarget.GetPoint(chartControl, chartPanel, chartScale);

            return new[] { startPoint, midPoint, endPoint , point50 ,pointTarget};
        }


        public override bool IsAlertConditionTrue(AlertConditionItem conditionItem, Condition condition, ChartAlertValue[] values,
            ChartControl chartControl, ChartScale chartScale)
        {
            var priceLevel = conditionItem.Tag as PriceLevel;
            if (priceLevel == null)
            {
                return false;
            }

            var plp = GetPriceLevelLinePoints(priceLevel, chartControl, chartScale, true);
            return CheckAlertRetracementLine(condition, plp.Item1, plp.Item2, chartControl, chartScale, values);
        }

        public override bool IsVisibleOnChart(ChartControl chartControl, ChartScale chartScale, DateTime firstTimeOnChart,
            DateTime lastTimeOnChart)
        {
            if (DrawingState == DrawingState.Building)
            {
                return true;
            }

            var minTime = Globals.MaxDate;
            var maxTime = Globals.MinDate;
            foreach (var anchor in Anchors)
            {
                if (anchor.Time < minTime)
                {
                    minTime = anchor.Time;
                }

                if (anchor.Time > maxTime)
                {
                    maxTime = anchor.Time;
                }
            }

            if (!IsExtendedLinesLeft && !IsExtendedLinesRight)
            {
                return new[] { minTime, maxTime }.Any(t => t >= firstTimeOnChart && t <= lastTimeOnChart) ||
                       minTime < firstTimeOnChart && maxTime > lastTimeOnChart;
            }

            return true;
        }

        public override void OnCalculateMinMax()
        {
            MinValue = double.MaxValue;
            MaxValue = double.MinValue;

            if (!IsVisible)
            {
                return;
            }

            // make sure *something* is drawn yet, but dont blow up if editing just a single anchor
            if (Anchors.All(a => a.IsEditing))
            {
                return;
            }

            var totalPriceRange = EndAnchor.Price - StartAnchor.Price;
            var startPrice = StartAnchor.Price; // + yPriceOffset;
            foreach (var priceLevel in PriceLevels.Where(pl => pl.IsVisible && pl.Stroke != null))
            {
                var levelPrice = startPrice + (1 - priceLevel.Value / 100) * totalPriceRange;
                MinValue = Math.Min(MinValue, levelPrice);
                MaxValue = Math.Max(MaxValue, levelPrice);
            }
        }

        public override void OnMouseDown(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            switch (DrawingState)
            {
                case DrawingState.Building:
                    if (StartAnchor.IsEditing)
                    {
                        dataPoint.CopyDataValues(StartAnchor);
                        // give end anchor something to start with so we dont try to render it with bad values right away
                        dataPoint.CopyDataValues(EndAnchor);
                        StartAnchor.IsEditing = false;
                    }
                    else if (EndAnchor.IsEditing)
                    {
                        dataPoint.CopyDataValues(EndAnchor);
                        dataPoint.CopyDataValues(Anchor50);
                        dataPoint.CopyDataValues(AnchorTarget);
                        Anchor50.Price = Math.Abs(StartAnchor.Price + EndAnchor.Price) / 2.0;
                        if (EndAnchor.Price > StartAnchor.Price)
                        {
                            AnchorTarget.Price = StartAnchor.Price + (EndAnchor.Price - StartAnchor.Price) * 1.23f;
                        }
                        else
                        {
                            AnchorTarget.Price = StartAnchor.Price - (StartAnchor.Price - EndAnchor.Price) * 1.23f;
                        }
                        EndAnchor.IsEditing = false;
                    }
                    else if (Anchor50.IsEditing)
                    {
                        dataPoint.CopyDataValues(Anchor50);
                       // AnchorWave2.Price = Math.Abs(AnchorStart.Price + AnchorWave1.Price) / 2.0;
                        dataPoint.CopyDataValues(AnchorTarget);
                        if (EndAnchor.Price > StartAnchor.Price)
                        {
                            AnchorTarget.Price = StartAnchor.Price + (EndAnchor.Price - StartAnchor.Price) * 1.23f;
                        }
                        else
                        {
                            AnchorTarget.Price = StartAnchor.Price - (StartAnchor.Price - EndAnchor.Price) * 1.23f;
                        }
                        Anchor50.IsEditing = false;
                    }
                    else if (AnchorTarget.IsEditing)
                    {
                        dataPoint.CopyDataValues(AnchorTarget);
                        /*
                        if (AnchorWave1.Price > AnchorStart.Price)
                        {
                            AnchorWave3.Price = AnchorStart.Price + (AnchorWave1.Price - AnchorStart.Price) * 1.23f;
                        }
                        else
                        {
                            AnchorWave3.Price = AnchorStart.Price - (AnchorStart.Price - AnchorWave1.Price) * 1.23f;
                        }*/
                        AnchorTarget.IsEditing = false;
                    }

                    // is initial building done (both anchors set)
                    if (!StartAnchor.IsEditing && !EndAnchor.IsEditing && !Anchor50.IsEditing && !AnchorTarget.IsEditing)
                    { 
                        DrawingState = DrawingState.Normal;
                        IsSelected = false;
                    }

                    break;
                case DrawingState.Normal:
                    var point = dataPoint.GetPoint(chartControl, chartPanel, chartScale);
                    editingAnchor = GetClosestAnchor(chartControl, chartPanel, chartScale, CursorSensitivity, point);
                    if (editingAnchor != null)
                    {
                        editingAnchor.IsEditing = true;
                        DrawingState = DrawingState.Editing;
                    }
                    else if (editingAnchor == null || IsLocked)
                    {
                        // or if they didnt click particulary close to either, move (they still clicked close to our line)
                        // set it to moving even if locked so we know to change cursor
                        if (GetCursor(chartControl, chartPanel, chartScale, point) != null)
                        {
                            DrawingState = DrawingState.Moving;
                        }
                        else
                        {
                            IsSelected = false;
                        }
                    }

                    break;
            }
        }

        public override void OnMouseMove(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            if (IsLocked && DrawingState != DrawingState.Building)
            {
                return;
            }

            if (DrawingState == DrawingState.Building)
            {
                // start anchor will not be editing here because we start building as soon as user clicks, which
                // plops down a start anchor right away
                if (EndAnchor.IsEditing)
                {
                    dataPoint.CopyDataValues(EndAnchor);
                    dataPoint.CopyDataValues(AnchorTarget);
                    dataPoint.CopyDataValues(Anchor50);
                    Anchor50.Price = Math.Abs(StartAnchor.Price + EndAnchor.Price) / 2.0;
                    if (EndAnchor.Price > StartAnchor.Price)
                    {
                        AnchorTarget.Price = StartAnchor.Price + (EndAnchor.Price - StartAnchor.Price) * 1.23f;
                    }
                    else
                    {
                        AnchorTarget.Price = StartAnchor.Price - (StartAnchor.Price - EndAnchor.Price) * 1.23f;
                    }
                }
                else if (Anchor50.IsEditing)
                {
                    dataPoint.CopyDataValues(Anchor50);
                    dataPoint.CopyDataValues(AnchorTarget);
                 //   AnchorWave2.Price = Math.Abs(AnchorStart.Price + AnchorWave1.Price) / 2.0;
                    if (EndAnchor.Price > StartAnchor.Price)
                    {
                        AnchorTarget.Price = StartAnchor.Price + (EndAnchor.Price - StartAnchor.Price) * 1.23f;
                    }
                    else
                    {
                        AnchorTarget.Price = StartAnchor.Price - (StartAnchor.Price - EndAnchor.Price) * 1.23f;
                    }
                }
                else if (AnchorTarget.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorTarget);
                   /* if (AnchorWave1.Price > AnchorStart.Price)
                    {
                        AnchorWave3.Price = AnchorStart.Price + (AnchorWave1.Price - AnchorStart.Price) * 1.23f;
                    }
                    else
                    {
                        AnchorWave3.Price = AnchorStart.Price - (AnchorStart.Price - AnchorWave1.Price) * 1.23f;
                    }*/
                }
            }
            else if (DrawingState == DrawingState.Editing && editingAnchor != null)
            {
                if (StartAnchor.IsEditing)
                {
                    dataPoint.CopyDataValues(StartAnchor);
                }
                if (EndAnchor.IsEditing)
                {
                    dataPoint.CopyDataValues(EndAnchor);
                }
                else if (Anchor50.IsEditing)
                {
                    dataPoint.CopyDataValues(Anchor50);
                }
                else if (AnchorTarget.IsEditing)
                {
                    dataPoint.CopyDataValues(AnchorTarget);
                }
                /*
                if (AnchorWave1.Price > AnchorStart.Price)
                {
                    AnchorWave3.Price = AnchorStart.Price + (AnchorWave1.Price - AnchorStart.Price) * 1.23f;
                }
                else
                {
                    AnchorWave3.Price = AnchorStart.Price - (AnchorStart.Price - AnchorWave1.Price) * 1.23f;
                }
                AnchorWave2.Price = Math.Abs(AnchorStart.Price + AnchorWave1.Price) / 2.0;*/
            }
            else if (DrawingState == DrawingState.Moving)
            {
                foreach (var anchor in Anchors)
                {
                    anchor.MoveAnchor(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
                }
            }
        }
       
        public override void OnMouseUp(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
        {
            // simply end whatever moving
            if (DrawingState == DrawingState.Editing || DrawingState == DrawingState.Moving)
            {
                DrawingState = DrawingState.Normal;
            }

            if (editingAnchor != null)
            {
                editingAnchor.IsEditing = false;
            }

            editingAnchor = null;
        }

        public override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            // nothing is drawn yet
            if (Anchors.All(a => a.IsEditing))
            {
                return;
            }

            RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
            var chartPanel = chartControl.ChartPanels[PanelIndex];
            // get x distance of the line, this will be basis for our levels
            // unless extend left/right is also on
            var anchorStartPoint = StartAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var anchorEndPoint = EndAnchor.GetPoint(chartControl, chartPanel, chartScale);
            var anchor50Point = Anchor50.GetPoint(chartControl, chartPanel, chartScale);
            var anchorTargetPoint = AnchorTarget.GetPoint(chartControl, chartPanel, chartScale);

            AnchorLineStroke.RenderTarget = RenderTarget;

            var tmpBrush = IsInHitTest ? chartControl.SelectionBrush : AnchorLineStroke.BrushDX;
            RenderTarget.DrawLine(anchorStartPoint.ToVector2(), anchorEndPoint.ToVector2(), tmpBrush, AnchorLineStroke.Width, AnchorLineStroke.StrokeStyle);
            RenderTarget.DrawLine(anchorEndPoint.ToVector2(), anchor50Point.ToVector2(), tmpBrush, AnchorLineStroke.Width, AnchorLineStroke.StrokeStyle);
            RenderTarget.DrawLine(anchor50Point.ToVector2(), anchorTargetPoint.ToVector2(), tmpBrush, AnchorLineStroke.Width, AnchorLineStroke.StrokeStyle);

            // if we're doing a hit test pass, dont draw price levels at all, we dont want those to count for 
            // hit testing (match NT7)
            if (IsInHitTest || PriceLevels == null || !PriceLevels.Any())
            {
                return;
            }

            SetAllPriceLevelsRenderTarget();

            var lastStartPoint = new Point(0, 0);
            Stroke lastStroke = null;

            foreach (var priceLevel in PriceLevels.Where(pl => pl.IsVisible && pl.Stroke != null).OrderBy(p => p.Value))
            {
                var plp = GetPriceLevelLinePoints(priceLevel, chartControl, chartScale, true);

                // align to full pixel to avoid unneeded aliasing
                var strokePixAdj = (priceLevel.Stroke.Width % 2.0).ApproxCompare(0) == 0 ? 0.5d : 0d;
                var pixelAdjustVec = new Vector(strokePixAdj, strokePixAdj);

                RenderTarget.DrawLine((plp.Item1 + pixelAdjustVec).ToVector2(), (plp.Item2 + pixelAdjustVec).ToVector2(),
                    priceLevel.Stroke.BrushDX, priceLevel.Stroke.Width, priceLevel.Stroke.StrokeStyle);

                if (lastStroke == null)
                {
                    lastStroke = new Stroke();
                }
                else
                {
                    var borderBox = new RectangleF((float)lastStartPoint.X, (float)lastStartPoint.Y,
                        (float)(plp.Item2.X + strokePixAdj - lastStartPoint.X), (float)(plp.Item2.Y - lastStartPoint.Y));

                    RenderTarget.FillRectangle(borderBox, lastStroke.BrushDX);
                }

                priceLevel.Stroke.CopyTo(lastStroke);
                lastStroke.Opacity = PriceLevelOpacity;
                lastStartPoint = plp.Item1 + pixelAdjustVec;
            }

            if (TextVisible)
            {
                // Render price text after background colors have rendered so the price text is on top
                foreach (var priceLevel in PriceLevels.Where(pl => pl.IsVisible && pl.Stroke != null))
                {
                    var plp = GetPriceLevelLinePoints(priceLevel, chartControl, chartScale, true);
                    // dont always draw the text at min/max x the line renders at, pass anchor min max
                    // in case text alignment is not extreme
                    var plPixAdjust = (priceLevel.Stroke.Width % 2.0).ApproxCompare(0) == 0 ? 0.5f : 0f;
                    var anchorMinX = Math.Min(anchorStartPoint.X, anchorTargetPoint.X);
                    var anchorMaxX = Math.Max(anchorStartPoint.X, anchorTargetPoint.X) + plPixAdjust;

                    var totalPriceRange = EndAnchor.Price - StartAnchor.Price;
                    var price = priceLevel.GetPrice(StartAnchor.Price, totalPriceRange, true);
                    DrawPriceLevelText(chartPanel, chartScale, anchorMinX, anchorMaxX, plp.Item1.Y, price, priceLevel);
                }
            }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                AnchorLineStroke = new Stroke(Brushes.White, DashStyleHelper.Solid, 2f, 100);
                Name = "Measured Move";
                PriceLevelOpacity = 0;
                StartAnchor = new ChartAnchor { IsEditing = true, DrawingTool = this };
                EndAnchor = new ChartAnchor { IsEditing = true, DrawingTool = this };
                Anchor50 = new ChartAnchor { IsEditing = true, DrawingTool = this };
                AnchorTarget = new ChartAnchor { IsEditing = true, DrawingTool = this };
                StartAnchor.DisplayName = "Start";
                EndAnchor.DisplayName = "End";
                Anchor50.DisplayName = "50";
                AnchorTarget.DisplayName = "Target";
                TextLocation = TextLocation.InsideRight;
                TextVisible = false;
            }
            else if (State == State.Configure)
            {
                if (PriceLevels.Count == 0)
                {
                    PriceLevels.Add(new PriceLevel(0, Brushes.DarkGray));
                    PriceLevels.Add(new PriceLevel(-23.6, Brushes.Green));
                    PriceLevels.Add(new PriceLevel(50, Brushes.Red));
                    PriceLevels.Add(new PriceLevel(61.8, Brushes.Yellow));
                    PriceLevels.Add(new PriceLevel(65, Brushes.Gold));
                    PriceLevels.Add(new PriceLevel(100, Brushes.DarkGray));
                }
            }
            else if (State == State.Terminated)
            {
                Dispose();
            }
        }
    }

    public static partial class Draw
    {
        private static T MeasuredMoveCore<T>(NinjaScriptBase owner, bool isAutoScale, string tag,
            int startBarsAgo, DateTime startTime, double startY,
            int endBarsAgo, DateTime endTime, double endY, bool isGlobal, string templateName) where T : MeasuredMoveLevels
        {
            if (owner == null)
            {
                throw new ArgumentException("owner");
            }

            if (startTime == Globals.MinDate && endTime == Globals.MinDate && startBarsAgo == int.MinValue && endBarsAgo == int.MinValue)
            {
                throw new ArgumentException("bad start/end date/time");
            }

            if (string.IsNullOrWhiteSpace(tag))
            {
                throw new ArgumentException("tag cant be null or empty");
            }

            if (isGlobal && tag[0] != GlobalDrawingToolManager.GlobalDrawingToolTagPrefix)
            {
                tag = string.Format("{0}{1}", GlobalDrawingToolManager.GlobalDrawingToolTagPrefix, tag);
            }

            var fibBase = DrawingTool.GetByTagOrNew(owner, typeof(T), tag, templateName) as T;
            if (fibBase == null)
            {
                return null;
            }

            DrawingTool.SetDrawingToolCommonValues(fibBase, tag, isAutoScale, owner, isGlobal);

            // dont nuke existing anchor refs 
            var startAnchor = DrawingTool.CreateChartAnchor(owner, startBarsAgo, startTime, startY);
            var endAnchor = DrawingTool.CreateChartAnchor(owner, endBarsAgo, endTime, endY);

            startAnchor.CopyDataValues(fibBase.StartAnchor);
            endAnchor.CopyDataValues(fibBase.EndAnchor);
            fibBase.SetState(State.Active);
            return fibBase;
        }

        /// <summary>
        /// Draws a MeasuredMove retracement.
        /// </summary>
        /// <param name="owner">The hosting NinjaScript object which is calling the draw method</param>
        /// <param name="tag">A user defined unique id used to reference the draw object</param>
        /// <param name="isAutoScale">Determines if the draw object will be included in the y-axis scale</param>
        /// <param name="startTime">The starting time where the draw object will be drawn.</param>
        /// <param name="startY">The starting y value co-ordinate where the draw object will be drawn</param>
        /// <param name="endTime">The end time where the draw object will terminate</param>
        /// <param name="endY">The end y value co-ordinate where the draw object will terminate</param>
        /// <returns></returns>
        public static MeasuredMove MeasuredMove(NinjaScriptBase owner, string tag, bool isAutoScale,
            DateTime startTime, double startY, DateTime endTime, double endY)
        {
            return MeasuredMoveCore<MeasuredMove>(owner, isAutoScale, tag, int.MinValue, startTime, startY, int.MinValue,
                endTime, endY, false, null);
        }

        /// <summary>
        /// Draws a MeasuredMove retracement.
        /// </summary>
        /// <param name="owner">The hosting NinjaScript object which is calling the draw method</param>
        /// <param name="tag">A user defined unique id used to reference the draw object</param>
        /// <param name="isAutoScale">Determines if the draw object will be included in the y-axis scale</param>
        /// <param name="startBarsAgo">
        /// The starting bar (x axis co-ordinate) where the draw object will be drawn. For example, a
        /// value of 10 would paint the draw object 10 bars back.
        /// </param>
        /// <param name="startY">The starting y value co-ordinate where the draw object will be drawn</param>
        /// <param name="endBarsAgo">The end bar (x axis co-ordinate) where the draw object will terminate</param>
        /// <param name="endY">The end y value co-ordinate where the draw object will terminate</param>
        /// <returns></returns>
        public static MeasuredMove MeasuredMove(NinjaScriptBase owner, string tag, bool isAutoScale,
            int startBarsAgo, double startY, int endBarsAgo, double endY)
        {
            return MeasuredMoveCore<MeasuredMove>(owner, isAutoScale, tag, startBarsAgo, Globals.MinDate, startY, endBarsAgo,
                Globals.MinDate, endY, false, null);
        }

        /// <summary>
        /// Draws a MeasuredMove retracement.
        /// </summary>
        /// <param name="owner">The hosting NinjaScript object which is calling the draw method</param>
        /// <param name="tag">A user defined unique id used to reference the draw object</param>
        /// <param name="isAutoScale">Determines if the draw object will be included in the y-axis scale</param>
        /// <param name="startTime">The starting time where the draw object will be drawn.</param>
        /// <param name="startY">The starting y value co-ordinate where the draw object will be drawn</param>
        /// <param name="endTime">The end time where the draw object will terminate</param>
        /// <param name="endY">The end y value co-ordinate where the draw object will terminate</param>
        /// <param name="isGlobal">Determines if the draw object will be global across all charts which match the instrument</param>
        /// <param name="templateName">
        /// The name of the drawing tool template the object will use to determine various visual
        /// properties
        /// </param>
        /// <returns></returns>
        public static MeasuredMove MeasuredMove(NinjaScriptBase owner, string tag, bool isAutoScale,
            DateTime startTime, double startY, DateTime endTime, double endY, bool isGlobal, string templateName)
        {
            return MeasuredMoveCore<MeasuredMove>(owner, isAutoScale, tag, int.MinValue, startTime, startY, int.MinValue,
                endTime, endY, isGlobal, templateName);
        }

        /// <summary>
        /// Draws a MeasuredMove retracement.
        /// </summary>
        /// <param name="owner">The hosting NinjaScript object which is calling the draw method</param>
        /// <param name="tag">A user defined unique id used to reference the draw object</param>
        /// <param name="isAutoScale">Determines if the draw object will be included in the y-axis scale</param>
        /// <param name="startBarsAgo">
        /// The starting bar (x axis co-ordinate) where the draw object will be drawn. For example, a
        /// value of 10 would paint the draw object 10 bars back.
        /// </param>
        /// <param name="startY">The starting y value co-ordinate where the draw object will be drawn</param>
        /// <param name="endBarsAgo">The end bar (x axis co-ordinate) where the draw object will terminate</param>
        /// <param name="endY">The end y value co-ordinate where the draw object will terminate</param>
        /// <param name="isGlobal">Determines if the draw object will be global across all charts which match the instrument</param>
        /// <param name="templateName">
        /// The name of the drawing tool template the object will use to determine various visual
        /// properties
        /// </param>
        /// <returns></returns>
        public static MeasuredMove MeasuredMove(NinjaScriptBase owner, string tag, bool isAutoScale,
            int startBarsAgo, double startY, int endBarsAgo, double endY, bool isGlobal, string templateName)
        {
            return MeasuredMoveCore<MeasuredMove>(owner, isAutoScale, tag, startBarsAgo, Globals.MinDate, startY, endBarsAgo,
                Globals.MinDate, endY, isGlobal, templateName);
        }
    }
}