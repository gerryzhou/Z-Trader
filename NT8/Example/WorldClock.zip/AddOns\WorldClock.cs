#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Xml.Linq;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.Gui.NinjaScript
{
    public class WorldClock : AddOnBase
    {
        private NTMenuItem worldClockMenuItem;
        private NTMenuItem existingMenuItemInControlCenter;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Example AddOn demonstrating some of the framework's capabilities";
                Name = "AddOn Framework";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            ControlCenter cc = window as ControlCenter;
            if (cc == null)
                return;

            existingMenuItemInControlCenter = cc.FindFirst("ControlCenterMenuItemNew") as NTMenuItem;
            if (existingMenuItemInControlCenter == null)
                return;

            worldClockMenuItem = new NTMenuItem { Header = "World Clock", Style = Application.Current.TryFindResource("MainMenuItem") as Style };

            existingMenuItemInControlCenter.Items.Add(worldClockMenuItem);

            worldClockMenuItem.Click += OnMenuItemClick;
        }

        protected override void OnWindowDestroyed(Window window)
        {
            if (worldClockMenuItem != null && window is ControlCenter)
            {
                if (existingMenuItemInControlCenter != null && existingMenuItemInControlCenter.Items.Contains(worldClockMenuItem))
                    existingMenuItemInControlCenter.Items.Remove(worldClockMenuItem);

                worldClockMenuItem.Click -= OnMenuItemClick;
                worldClockMenuItem = null;
            }
        }

        private void OnMenuItemClick(object sender, RoutedEventArgs e)
        {
            Core.Globals.RandomDispatcher.BeginInvoke(new Action(() => new WorldClockWindow().Show()));
        }
    }

    public class WorldClockWindowFactory : INTTabFactory
    {
        public NTWindow CreateParentWindow()
        {
            return new WorldClockWindow();
        }

        // creates the WorldClock tab
        public NTTabPage CreateTabPage(string typeName, bool isTrue)
        {
            return new WorldClockFrameworkTab();
        }
  
	}

    public class WorldClockWindow : NTWindow, IWorkspacePersistence
    {
        public WorldClockWindow()
        {
            Caption = "World Clock";

            // Set the default dimensions of the window
            Width = 1085;
            Height = 800;

            // TabControl should be created for window content if tab features are wanted
            TabControl tc = new TabControl();

            // Attached properties defined in TabControlManager class should be set to achieve tab moving, adding/removing tabs
            TabControlManager.SetIsMovable(tc, true);
            TabControlManager.SetCanAddTabs(tc, false);
            TabControlManager.SetCanRemoveTabs(tc, false);

            // if ability to add new tabs is desired, TabControl has to have attached property "Factory" set.
            TabControlManager.SetFactory(tc, new WorldClockWindowFactory());
            Content = tc;

            tc.AddNTTabPage(new WorldClockFrameworkTab());
			
            Loaded += (o, e) =>
            {
                if (WorkspaceOptions == null)
                    //WorkspaceOptions = new WorkspaceOptions("WorldClockFramework-" + Guid.NewGuid().ToString("N"), this);
					WorkspaceOptions = new WorkspaceOptions("WorldClockFramework", this);
            };
        }

        // IWorkspacePersistence member. Required for restoring window from workspace
        public void Restore(XDocument document, XElement element)
        {
            if (MainTabControl != null)
                MainTabControl.RestoreFromXElement(element);
        }

        // IWorkspacePersistence member. Required for saving window to workspace
        public void Save(XDocument document, XElement element)
        {
            if (MainTabControl != null)
                MainTabControl.SaveToXElement(element);
        }

        // IWorkspacePersistence member
        public WorkspaceOptions WorkspaceOptions { get; set; }
    }

    public class WorldClockFrameworkTab : NTTabPage
	{

	   	// time zone dictionary and timer
		static readonly Dictionary<string, TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones().ToDictionary(z => z.DisplayName);
    	private System.Windows.Forms.Timer timer1 = new System.Windows.Forms.Timer();

		// clock labels
		private Label clock_label1;
		private Label clock_label2;
		private Label clock_label3;
		private Label clock_label4;
		private Label clock_label5;
		private Label clock_time1;
		private Label clock_time2;
		private Label clock_time3;
		private Label clock_time4;
		private Label clock_time5;
		
		// timezone check boxes
		private CheckBox tz_checkBox2;
		private CheckBox tz_checkBox3;
		private CheckBox tz_checkBox4;
		private CheckBox tz_checkBox5;
		
        // timezone text boxes
		private TextBox tz_textBox1;
        private TextBox tz_textBox2;
        private TextBox tz_textBox3;
        private TextBox tz_textBox4;
        private TextBox tz_textBox5;

        // combo boxes
		private ComboBox tz_comboBox1;
        private ComboBox tz_comboBox2;
        private ComboBox tz_comboBox3;
        private ComboBox tz_comboBox4;
        private ComboBox tz_comboBox5;
        private ComboBox fontFamily_comboBox;
		private ComboBox fontSize_comboBox;
		private ComboBox fontColor_comboBox;
		private ComboBox timeFormat_comboBox;
		private ComboBox fontWeight_comboBox;

        public WorldClockFrameworkTab()
        {
            // load the XAML tools to the tab form
			Content = LoadXAML();
			
			if (Content == null)
				return;
			
            // set the tab name
            TabName = "World Clock";
						
			// init the timer to one second and set the event handler
			timer1.Interval = 1000;
        	timer1.Enabled = true;
			timer1.Tick += new EventHandler(OnTimedEvent);

            // add colors to the color comboBox and select Black as default
            fontColor_comboBox.ItemsSource = typeof(Colors).GetProperties();
            fontColor_comboBox.SelectedIndex = 7;			
        }

        private void OnTimedEvent(Object source, EventArgs e)
        {
            DateTime currentTime = DateTime.Now;

            // TimeZone 1
            try
            {
                clock_label1.Content = tz_textBox1.Text;

                TimeZoneInfo timeZone = zones[tz_comboBox1.SelectedValue.ToString()];
                clock_time1.Content = TimeZoneInfo.ConvertTime(currentTime, timeZone).ToString(timeFormat_comboBox.Text);
            }
            catch (System.InvalidOperationException)
            {
                timer1.Stop();
                timer1.Dispose();
            }

            // TimeZone 2
            if (tz_checkBox2.IsChecked.Value)
            {
                try
                {
                    clock_label2.Content = tz_textBox2.Text;

                    TimeZoneInfo timeZone = zones[tz_comboBox2.SelectedValue.ToString()];
                    clock_time2.Content = TimeZoneInfo.ConvertTime(currentTime, timeZone).ToString(timeFormat_comboBox.Text);
                }
                catch (System.InvalidOperationException)
                {
                    timer1.Stop();
                    timer1.Dispose();
                }
            }

            // TimeZone 3
            if (tz_checkBox3.IsChecked.Value)
            {
                try
                {
                    clock_label3.Content = tz_textBox3.Text;

                    TimeZoneInfo timeZone = zones[tz_comboBox3.SelectedValue.ToString()];
                    clock_time3.Content = TimeZoneInfo.ConvertTime(currentTime, timeZone).ToString(timeFormat_comboBox.Text);
                }
                catch (System.InvalidOperationException)
                {
                    timer1.Stop();
                    timer1.Dispose();
                }
            }

            // TimeZone 4
            if (tz_checkBox4.IsChecked.Value)
            {
                try
                {
                    clock_label4.Content = tz_textBox4.Text;

                    TimeZoneInfo timeZone = zones[tz_comboBox4.SelectedValue.ToString()];
                    clock_time4.Content = TimeZoneInfo.ConvertTime(currentTime, timeZone).ToString(timeFormat_comboBox.Text);
                }
                catch (System.InvalidOperationException)
                {
                    timer1.Stop();
                    timer1.Dispose();
                }
            }

            // TimeZone 5
            if (tz_checkBox5.IsChecked.Value)
            {
                try
                {
                    clock_label5.Content = tz_textBox5.Text;

                    TimeZoneInfo timeZone = zones[tz_comboBox5.SelectedValue.ToString()];
                    clock_time5.Content = TimeZoneInfo.ConvertTime(currentTime, timeZone).ToString(timeFormat_comboBox.Text);
                }
                catch (System.InvalidOperationException)
                {
                    timer1.Stop();
                    timer1.Dispose();
                }
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;

            if (cb != null && ReferenceEquals(cb, tz_checkBox2))
            {
                if (cb.IsChecked.Value)
                {
                    tz_textBox2.IsEnabled = true;
                    tz_comboBox2.IsEnabled = true;
                    clock_label2.Visibility = System.Windows.Visibility.Visible;
                    clock_time2.Visibility = System.Windows.Visibility.Visible;
               }
                else
                {
                    tz_textBox2.IsEnabled = false;
                    tz_comboBox2.IsEnabled = false;
                    clock_label2.Visibility = System.Windows.Visibility.Hidden;
                    clock_time2.Visibility = System.Windows.Visibility.Hidden;
               }
            }

            if (cb != null && ReferenceEquals(cb, tz_checkBox3))
            {
                if (cb.IsChecked.Value)
                {
                    tz_textBox3.IsEnabled = true;
                    tz_comboBox3.IsEnabled = true;
                    clock_label3.Visibility = System.Windows.Visibility.Visible;
                    clock_time3.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    tz_textBox3.IsEnabled = false;
                    tz_comboBox3.IsEnabled = false;
                    clock_label3.Visibility = System.Windows.Visibility.Hidden;
                    clock_time3.Visibility = System.Windows.Visibility.Hidden;
                }
            }

            if (cb != null && ReferenceEquals(cb, tz_checkBox4))
            {
                if (cb.IsChecked.Value)
                {
                    tz_textBox4.IsEnabled = true;
                    tz_comboBox4.IsEnabled = true;
                    clock_label4.Visibility = System.Windows.Visibility.Visible;
                    clock_time4.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    tz_textBox4.IsEnabled = false;
                    tz_comboBox4.IsEnabled = false;
                    clock_label4.Visibility = System.Windows.Visibility.Hidden;
                    clock_time4.Visibility = System.Windows.Visibility.Hidden;
                }
            }

            if (cb != null && ReferenceEquals(cb, tz_checkBox5))
            {
                if (cb.IsChecked.Value)
                {
                    tz_textBox5.IsEnabled = true;
                    tz_comboBox5.IsEnabled = true;
                    clock_label5.Visibility = System.Windows.Visibility.Visible;
                    clock_time5.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    tz_textBox5.IsEnabled = false;
                    tz_comboBox5.IsEnabled = false;
                    clock_label5.Visibility = System.Windows.Visibility.Hidden;
                    clock_time5.Visibility = System.Windows.Visibility.Hidden;
                }
            }
        }

		private void fontSize_DropDownClosed(object sender, EventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;

            // get the selected size from the font_combobox
            double fontSize = Convert.ToDouble(comboBox.Text);

            // set the fontsize for all the clock labels
            clock_label1.FontSize = fontSize;
            clock_label2.FontSize = fontSize;
            clock_label3.FontSize = fontSize;
            clock_label4.FontSize = fontSize;
            clock_label5.FontSize = fontSize;

            // set the fontsize for all the clock times
            clock_time1.FontSize = fontSize;
            clock_time2.FontSize = fontSize;
            clock_time3.FontSize = fontSize;
            clock_time4.FontSize = fontSize;
            clock_time5.FontSize = fontSize;
        }

        private void fontFamily_DropDownClosed(object sender, EventArgs e)
        {
            ComboBox comboBox = sender as ComboBox;

            // set the font family for all the clock labels
            clock_label1.FontFamily = new FontFamily(comboBox.Text);
            clock_label2.FontFamily = new FontFamily(comboBox.Text);
            clock_label3.FontFamily = new FontFamily(comboBox.Text);
            clock_label4.FontFamily = new FontFamily(comboBox.Text);
            clock_label5.FontFamily = new FontFamily(comboBox.Text);

            // set the font family for all the clock times
            clock_time1.FontFamily = new FontFamily(comboBox.Text);
            clock_time2.FontFamily = new FontFamily(comboBox.Text);
            clock_time3.FontFamily = new FontFamily(comboBox.Text);
            clock_time4.FontFamily = new FontFamily(comboBox.Text);
            clock_time5.FontFamily = new FontFamily(comboBox.Text);
        }

        private void fontColor_DropDownClosed(object sender, EventArgs e)
        {
            var comboBox = sender as ComboBox;

            if (comboBox.Text == "")
                return;

            String[] colors = comboBox.Text.Split(new Char[] { ' ' });
            SolidColorBrush fontColor = (SolidColorBrush)new BrushConverter().ConvertFromString(colors[1]);

            // set the font color for all the clock labels
            clock_label1.Foreground = fontColor;
            clock_label2.Foreground = fontColor;
            clock_label3.Foreground = fontColor;
            clock_label4.Foreground = fontColor;
            clock_label5.Foreground = fontColor;

            // set the font color for all the clock times
            clock_time1.Foreground = fontColor;
            clock_time2.Foreground = fontColor;
            clock_time3.Foreground = fontColor;
            clock_time4.Foreground = fontColor;
            clock_time5.Foreground = fontColor;
        }

		private void fontWeight_DropDownClosed(object sender, EventArgs e)
        {
            var comboBox = sender as ComboBox;

            // set the font weight for all the clock labels
			if (comboBox.Text == "Bold") {
	            clock_label1.FontWeight = FontWeights.Bold;
	            clock_label2.FontWeight = FontWeights.Bold;
	            clock_label3.FontWeight = FontWeights.Bold;
	            clock_label4.FontWeight = FontWeights.Bold;
	            clock_label5.FontWeight = FontWeights.Bold;

	            // set the font color for all the clock times
	            clock_time1.FontWeight = FontWeights.Bold;
	            clock_time2.FontWeight = FontWeights.Bold;
	            clock_time3.FontWeight = FontWeights.Bold;
	            clock_time4.FontWeight = FontWeights.Bold;
	            clock_time5.FontWeight = FontWeights.Bold;
			} else {
	            clock_label1.FontWeight = FontWeights.Normal;
	            clock_label2.FontWeight = FontWeights.Normal;
	            clock_label3.FontWeight = FontWeights.Normal;
	            clock_label4.FontWeight = FontWeights.Normal;
	            clock_label5.FontWeight = FontWeights.Normal;

	            // set the font color for all the clock times
	            clock_time1.FontWeight = FontWeights.Normal;
	            clock_time2.FontWeight = FontWeights.Normal;
	            clock_time3.FontWeight = FontWeights.Normal;
	            clock_time4.FontWeight = FontWeights.Normal;
	            clock_time5.FontWeight = FontWeights.Normal;
			}
        }
		
        private DependencyObject LoadXAML()
        {
            try
            {
                using (System.IO.Stream assemblyResourceStream = GetManifestResourceStream("AddOns.WorldClockTab.xaml"))
                {
                    if (assemblyResourceStream == null)
                        return null;
                    System.IO.StreamReader streamReader = new System.IO.StreamReader(assemblyResourceStream);

                    Window page = System.Windows.Markup.XamlReader.Load(streamReader.BaseStream) as Window;
                    DependencyObject pageContent = null;
					
                    if (page != null)
                    {
                        pageContent = page.Content as DependencyObject;

                        // load the TimeZone ComboBoxes
                        tz_comboBox1 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_comboBox1") as ComboBox;
                        tz_comboBox2 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_comboBox2") as ComboBox;
                        tz_comboBox3 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_comboBox3") as ComboBox;
                        tz_comboBox4 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_comboBox4") as ComboBox;
                        tz_comboBox5 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_comboBox5") as ComboBox;

                        // load the TimeZone TextBoxes
                        tz_textBox1 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_textBox1") as TextBox;
                        tz_textBox2 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_textBox2") as TextBox;
                        tz_textBox3 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_textBox3") as TextBox;
                        tz_textBox4 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_textBox4") as TextBox;
                        tz_textBox5 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_textBox5") as TextBox;

                        // load the TimeZone Labels
                        clock_label1 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_label1") as Label;
						clock_label2 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_label2") as Label;
						clock_label3 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_label3") as Label;
						clock_label4 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_label4") as Label;
						clock_label5 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_label5") as Label;
						clock_time1 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_time1") as Label;
						clock_time2 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_time2") as Label;
						clock_time3 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_time3") as Label;
						clock_time4 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_time4") as Label;
						clock_time5 = LogicalTreeHelper.FindLogicalNode(pageContent, "clock_time5") as Label;
						
						// load the TimeZone checkboxes
						tz_checkBox2 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_checkBox2") as CheckBox;
						tz_checkBox3 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_checkBox3") as CheckBox;
						tz_checkBox4 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_checkBox4") as CheckBox;
						tz_checkBox5 = LogicalTreeHelper.FindLogicalNode(pageContent, "tz_checkBox5") as CheckBox;
						
						// add handler to the checkboxes
						tz_checkBox2.Checked += CheckBox_Checked;
						tz_checkBox2.Unchecked += CheckBox_Checked;
						tz_checkBox3.Checked += CheckBox_Checked;
						tz_checkBox3.Unchecked += CheckBox_Checked;
						tz_checkBox4.Checked += CheckBox_Checked;
						tz_checkBox4.Unchecked += CheckBox_Checked;
						tz_checkBox5.Checked += CheckBox_Checked;
						tz_checkBox5.Unchecked += CheckBox_Checked;
						
						// load the font family, size, and color combo boxes
						fontFamily_comboBox = LogicalTreeHelper.FindLogicalNode(pageContent, "fontFamily_comboBox") as ComboBox;
						fontSize_comboBox = LogicalTreeHelper.FindLogicalNode(pageContent, "fontSize_comboBox") as ComboBox;
						fontColor_comboBox = LogicalTreeHelper.FindLogicalNode(pageContent, "fontColor_comboBox") as ComboBox;
						fontWeight_comboBox = LogicalTreeHelper.FindLogicalNode(pageContent, "fontWeight_comboBox") as ComboBox;
						timeFormat_comboBox = LogicalTreeHelper.FindLogicalNode(pageContent, "timeFormat_comboBox") as ComboBox;
						
						// add handlers to the font combo boxes
						fontFamily_comboBox.DropDownClosed += fontFamily_DropDownClosed;
						fontSize_comboBox.DropDownClosed += fontSize_DropDownClosed;
						fontColor_comboBox.DropDownClosed += fontColor_DropDownClosed;
						fontWeight_comboBox.DropDownClosed += fontWeight_DropDownClosed;
						
                        // get a Collection of TimeZones
                        ReadOnlyCollection<TimeZoneInfo> tzCollection;
                        tzCollection = TimeZoneInfo.GetSystemTimeZones();

                        // set each of the TimeZone comboBoxes to the timezone collection						
                        tz_comboBox1.ItemsSource = tzCollection;
                        tz_comboBox2.ItemsSource = tzCollection;
                        tz_comboBox3.ItemsSource = tzCollection;
                        tz_comboBox4.ItemsSource = tzCollection;
                        tz_comboBox5.ItemsSource = tzCollection;
                    }

                    return pageContent;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
				return null;
            }
        }

        // NTTabPage member. Required to determine the text for the tab header name
        protected override string GetHeaderPart(string variable)
        {
            return variable;
        }

        // NTTabPage member. Required for restoring elements from workspace
        protected override void Restore(XElement element)
        {
            if (element == null)
            {
                return;
            }

            // TimeZone 1
            XElement restoreElement = element.Element("TextBox1");
            if (tz_textBox1 != null && restoreElement != null)
                tz_textBox1.Text = restoreElement.Value;
			
			restoreElement = element.Element("TimeZone1");
            if (tz_comboBox1 != null && restoreElement != null)
                tz_comboBox1.SelectedIndex = Convert.ToInt32(restoreElement.Value);
			
            // TimeZone 2
			restoreElement = element.Element("CheckBox2");
			if (tz_checkBox2 != null && restoreElement != null) {
				if (restoreElement.Value == "True") {
					restoreElement = element.Element("TextBox2");
	            	if (tz_textBox2 != null && restoreElement != null)
	                	tz_textBox2.Text = restoreElement.Value;			

					restoreElement = element.Element("TimeZone2");
            		if (tz_comboBox2 != null && restoreElement != null)
                		tz_comboBox2.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				
					tz_checkBox2.IsChecked = true;
				}
			}

            // TimeZone 3
			restoreElement = element.Element("CheckBox3");
			if (tz_checkBox3 != null && restoreElement != null) {
				if (restoreElement.Value == "True") {
					restoreElement = element.Element("TextBox3");
	            	if (tz_textBox3 != null && restoreElement != null)
	                	tz_textBox3.Text = restoreElement.Value;			

					restoreElement = element.Element("TimeZone3");
            		if (tz_comboBox3 != null && restoreElement != null)
                		tz_comboBox3.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				
					tz_checkBox3.IsChecked = true;
				}
			}

            // TimeZone 4
			restoreElement = element.Element("CheckBox4");
			if (tz_checkBox4 != null && restoreElement != null) {
				if (restoreElement.Value == "True") {
					restoreElement = element.Element("TextBox4");
	            	if (tz_textBox4 != null && restoreElement != null)
	                	tz_textBox4.Text = restoreElement.Value;			

					restoreElement = element.Element("TimeZone4");
            		if (tz_comboBox4 != null && restoreElement != null)
                		tz_comboBox4.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				
					tz_checkBox4.IsChecked = true;
				}
			}

            // TimeZone 5
			restoreElement = element.Element("CheckBox5");
			if (tz_checkBox5 != null && restoreElement != null) {
				if (restoreElement.Value == "True") {
					restoreElement = element.Element("TextBox5");
	            	if (tz_textBox5 != null && restoreElement != null)
	                	tz_textBox5.Text = restoreElement.Value;			

					restoreElement = element.Element("TimeZone5");
            		if (tz_comboBox5 != null && restoreElement != null)
                		tz_comboBox5.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				
					tz_checkBox5.IsChecked = true;
				}
			}
			
			// font selections
			restoreElement = element.Element("FontFamily");
			if (fontFamily_comboBox != null && restoreElement != null) {
				fontFamily_comboBox.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				fontFamily_DropDownClosed(fontFamily_comboBox, new EventArgs());
			}

			restoreElement = element.Element("FontSize");
			if (fontSize_comboBox != null && restoreElement != null) {
				fontSize_comboBox.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				fontSize_DropDownClosed(fontSize_comboBox, new EventArgs());
			}
	
			restoreElement = element.Element("FontColor");
			if (fontColor_comboBox != null && restoreElement != null) {
				fontColor_comboBox.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				fontColor_DropDownClosed(fontColor_comboBox, new EventArgs());
			}
			
			restoreElement = element.Element("FontWeight");
			if (fontWeight_comboBox != null && restoreElement != null) {
				fontWeight_comboBox.SelectedIndex = Convert.ToInt32(restoreElement.Value);
				fontWeight_DropDownClosed(fontWeight_comboBox, new EventArgs());
			}
			
			restoreElement = element.Element("TimeFormat");
			if (timeFormat_comboBox != null && restoreElement != null)
				timeFormat_comboBox.SelectedIndex = Convert.ToInt32(restoreElement.Value);
		}

        // NTTabPage member. Required for storing elements to workspace
        protected override void Save(XElement element)
        {
            if (element == null)
                return;
            
			// save the TimeZone settings to the Workspace
			element.Add(new XElement("TimeZone1") { Value = tz_comboBox1.SelectedIndex.ToString() });
			element.Add(new XElement("TextBox1") { Value = tz_textBox1.Text });
			
			if (tz_checkBox2.IsChecked.Value) {
            	element.Add(new XElement("TimeZone2") { Value = tz_comboBox2.SelectedIndex.ToString() });
				element.Add(new XElement("TextBox2") { Value = tz_textBox2.Text });
				element.Add(new XElement("CheckBox2") { Value = tz_checkBox2.IsEnabled.ToString() });
			}

			if (tz_checkBox3.IsChecked.Value) {
            	element.Add(new XElement("TimeZone3") { Value = tz_comboBox3.SelectedIndex.ToString() });
				element.Add(new XElement("TextBox3") { Value = tz_textBox3.Text });
				element.Add(new XElement("CheckBox3") { Value = tz_checkBox3.IsEnabled.ToString() });
			}
			
			if (tz_checkBox4.IsChecked.Value) {
            	element.Add(new XElement("TimeZone4") { Value = tz_comboBox4.SelectedIndex.ToString() });
				element.Add(new XElement("TextBox4") { Value = tz_textBox4.Text });
				element.Add(new XElement("CheckBox4") { Value = tz_checkBox3.IsEnabled.ToString() });
			}
			
			if (tz_checkBox5.IsChecked.Value) {
            	element.Add(new XElement("TimeZone5") { Value = tz_comboBox5.SelectedIndex.ToString() });
				element.Add(new XElement("TextBox5") { Value = tz_textBox5.Text });
				element.Add(new XElement("CheckBox5") { Value = tz_checkBox3.IsEnabled.ToString() });
			}
			
			// save the font selections to the workspace
			element.Add(new XElement("FontFamily") { Value = fontFamily_comboBox.SelectedIndex.ToString() });
			element.Add(new XElement("FontSize") { Value = fontSize_comboBox.SelectedIndex.ToString() });
			element.Add(new XElement("FontColor") { Value = fontColor_comboBox.SelectedIndex.ToString() });
			element.Add(new XElement("FontWeight") { Value = fontWeight_comboBox.SelectedIndex.ToString() });
			element.Add(new XElement("TimeFormat") { Value = timeFormat_comboBox.SelectedIndex.ToString() });
        }
		
		public override void Cleanup()
		{
			timer1.Stop();
			timer1.Dispose();
		}
    }
}