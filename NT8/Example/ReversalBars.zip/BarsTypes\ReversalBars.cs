#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds Bars types in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.BarsTypes
{
	public class ReversalBars : BarsType
	{
		private double 	 offset;
		private double 	 o,h,l,c;
		private double 	 pClose;
		private DateTime t;
		private	long     v;
		private	double   lowerMin;
		private	double   upperMin;
		private	double	 lowerRev;
		private	double	 upperRev;
		private	int		 dir = 1;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description		= @"";
				Name			= "Reversal Bars";
				BarsPeriod		= new BarsPeriod { BarsPeriodType = (BarsPeriodType) 90, BarsPeriodTypeName = "ReversalBars(90)", Value = 1 };
				BuiltFrom		= BarsPeriodType.Tick;
				DaysToLoad		= 3;
				IsIntraday		= true;
				IsTimeBased		= false;
			}
			else if (State == State.Configure)
			{
				Properties.Remove(Properties.Find("BaseBarsPeriodType",			true));
				Properties.Remove(Properties.Find("BaseBarsPeriodValue",		true));
				Properties.Remove(Properties.Find("PointAndFigurePriceType",	true));
				Properties.Remove(Properties.Find("ReversalType",				true));
				Properties.Remove(Properties.Find("Value2",						true));
				
				SetPropertyName("Value", "Reversal Ticks");
			}
		}

		public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack)
		{
			return 1;
		}
		
		public override bool IsRemoveLastBarSupported { get { return false; } }

		protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
		{
			offset = bars.BarsPeriod.Value * bars.Instrument.MasterInstrument.TickSize;
			pClose = (pClose == null) ? close : pClose;
			
			if(bars.Count == 0 || Math.Abs(close - pClose) > offset)
			{
				o = close;
				h = close;
				l = close;
				c = close;
				t = time;
				v = (volume > 0) ? volume : 1;
				
				AddBar(bars, o, h, l, c, t, v);
				
				dir = 0;
			}
			else
			{
				lowerMin = bars.GetOpen(bars.Count - 1) - offset;
				upperMin = bars.GetOpen(bars.Count - 1) + offset;
				
				lowerRev = bars.GetLow(bars.Count - 1)  + offset;
				upperRev = bars.GetHigh(bars.Count - 1) - offset;
				
				o = bars.GetOpen(bars.Count - 1);
				h = (close > bars.GetHigh(bars.Count - 1)) ? close : bars.GetHigh(bars.Count - 1);
				l = (close < bars.GetLow(bars.Count - 1))  ? close : bars.GetLow(bars.Count - 1);
				c = close;
				t = time;
				v = volume;
				
				UpdateBar(bars, h, l, c, t, v);
				
				if(dir == 0)
				{
					if(close.ApproxCompare(lowerMin) <= 0) // close is less than or equal lowerMin
					{
						dir = -1;
					}
					
					if(close.ApproxCompare(upperMin) >= 0) // close is more than or equal upperMin
					{
						dir = 1;
					}
				}
				
				if(dir == -1)
				{
					if(close.ApproxCompare(lowerRev) >= 0) // close is more than or equal lowerRev
					{
						o = close;
						h = close;
						l = close;
						c = close;
						t = time;
						v = 1;
						
						AddBar(bars, o, h, l, c, t, v);
						
						dir = 0;
					}
				}
				
				if(dir == 1)
				{
					if(close.ApproxCompare(upperRev) <= 0) // close is less than or equal upperRev
					{
						o = close;
						h = close;
						l = close;
						c = close;
						t = time;
						v = 1;
						
						AddBar(bars, o, h, l, c, t, v);
						
						dir = 0;
					}
				}
			}
			
			pClose = close;
		}

		public override void ApplyDefaultBasePeriodValue(BarsPeriod period)
		{
			
		}

		public override void ApplyDefaultValue(BarsPeriod period)
		{
			period.Value = 3;
		}

		public override string ChartLabel(DateTime dateTime)
		{
			return dateTime.ToString("HH:mm:ss");
		}

		public override double GetPercentComplete(Bars bars, DateTime now)
		{
			return 1.0d;
		}
	}
}
