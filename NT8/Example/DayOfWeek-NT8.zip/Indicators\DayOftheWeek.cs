#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
    /// <summary>
    /// Enter the description of your new custom indicator here
    /// </summary>
    public class DayOftheWeek : Indicator
    {
		private string timeZone = "Eastern Standard Time";
        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        private void Initialize()
        {
            IsOverlay				= true;
        }

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "DayOftheWeek";
                    Description = "Plot the day of the week into the chart";
                    Initialize();
                    break;
             }
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {	
			if (CurrentBar < 1)
				return;
			
			DateTime currentTimeToEasternTime = TimeZoneInfo.ConvertTimeFromUtc(Time[0].ToUniversalTime(), TimeZoneInfo.FindSystemTimeZoneById(timeZone));
			DateTime previousTimeToEasternTime = TimeZoneInfo.ConvertTimeFromUtc(Time[1].ToUniversalTime(), TimeZoneInfo.FindSystemTimeZoneById(timeZone));
			
			if (currentTimeToEasternTime.DayOfWeek != previousTimeToEasternTime.DayOfWeek)
				Draw.Text(this,"DayOftheWeek" + CurrentBar, currentTimeToEasternTime.DayOfWeek.ToString(), 0, High[0] + 75 * TickSize, Brushes.DimGray);
        }
		
		[NinjaScriptProperty]		
		[Display(Description = "Time zone to convert to", GroupName = "Parameters", Order = 1)]		
		public string TimeZone
		{
			get { return timeZone; }
			set { timeZone = value; }
		}
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private DayOftheWeek[] cacheDayOftheWeek;
		public DayOftheWeek DayOftheWeek(string timeZone)
		{
			return DayOftheWeek(Input, timeZone);
		}

		public DayOftheWeek DayOftheWeek(ISeries<double> input, string timeZone)
		{
			if (cacheDayOftheWeek != null)
				for (int idx = 0; idx < cacheDayOftheWeek.Length; idx++)
					if (cacheDayOftheWeek[idx] != null && cacheDayOftheWeek[idx].TimeZone == timeZone && cacheDayOftheWeek[idx].EqualsInput(input))
						return cacheDayOftheWeek[idx];
			return CacheIndicator<DayOftheWeek>(new DayOftheWeek(){ TimeZone = timeZone }, input, ref cacheDayOftheWeek);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.DayOftheWeek DayOftheWeek(string timeZone)
		{
			return indicator.DayOftheWeek(Input, timeZone);
		}

		public Indicators.DayOftheWeek DayOftheWeek(ISeries<double> input , string timeZone)
		{
			return indicator.DayOftheWeek(input, timeZone);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.DayOftheWeek DayOftheWeek(string timeZone)
		{
			return indicator.DayOftheWeek(Input, timeZone);
		}

		public Indicators.DayOftheWeek DayOftheWeek(ISeries<double> input , string timeZone)
		{
			return indicator.DayOftheWeek(input, timeZone);
		}
	}
}

#endregion
