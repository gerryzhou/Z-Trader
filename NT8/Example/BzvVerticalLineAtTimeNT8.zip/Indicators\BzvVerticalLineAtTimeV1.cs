/* COPYRIGHT NOTICE
Portions Copyright (C) 2017 Scott H. Daggett

Find out more about this indicator at ninjalaunchpad.com/downloads.html.

This program is free software: you can redistribute it and/or modify it under the terms of
the GNU General Public License version 3 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.
If not, see https://www.gnu.org/licenses/gpl-3.0.en.html.

You must include this full COPYRIGHT NOTICE at the beginning of any copies of the file that you redistribute.
*/

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BzvVerticalLineAtTimeV1 : Indicator
	{
		#region Variables
		
		private const int LINE_LENGTH_TICKS = 100000;
		private const string TAG_SUFFIX = "_VertLineAtTime";
		
		#endregion
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Draws a vertical line at a specified time. Same line will appear on all days---designed for intraday charts.";
				Name										= "BzvVerticalLineAtTimeV1";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= false;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				LineTime						= DateTime.Parse("9:30 AM");
				LineColor						= Brushes.Red;
				LineDashStyle					= DashStyleHelper.DashDotDot;
				LineThickness					= 2;
				BarToLineOffsetInTicks			= 1;
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.Historical)
			{
		      // Make sure our object plots behind the chart bars
				if (ZOrder != -1) SetZOrder(-1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 2) return;
			// So here's the deal...we don't know what type of chart it is, and I don't want to write code
			// to detect and support a whole bunch of chart types. So, when we get a new bar, we'll look at
			// the current bar and the one previous to it. If the current bar's time is equal to or
			// later than the line's time, AND [the previous bar is earlier than the line's time but on the
			// same date OR the previous bar is on the previous date], then we'll draw the line on the current
			// bar. Let's see how that works.
			
			// TODO: Probably ought to test the boundary conditions, but I don't have those as a requirement. ;-)
			//		 (Tested boundaries on a 10 minute chart. Worked.)
			
			DateTime todayLineTime = Time[0].Date.Add(LineTime.TimeOfDay);
			if (Time[0] >= todayLineTime && ((Time[1].TimeOfDay < LineTime.TimeOfDay && Time[0].Date.Equals(Time[1].Date)) || Time[1].Date == Time[0].Date.AddDays(-1)))
			{
				string tag = Time[0].ToString() + TAG_SUFFIX + "AboveBar";
				double startY = High[0] + (BarToLineOffsetInTicks * TickSize);
				double endY = High[0] + (LINE_LENGTH_TICKS * TickSize);
				Draw.Line(this, tag, false, 0,  startY, 0, endY, LineColor, LineDashStyle, LineThickness);
				tag = Time[0].ToString() + TAG_SUFFIX + "BelowBar";
				startY = 0;
				endY = Low[0] - (BarToLineOffsetInTicks * TickSize);
				Draw.Line(this, tag, false, 0,  startY, 0, endY, LineColor, LineDashStyle, LineThickness);
			}

		}

		#region Properties
		
		[NinjaScriptProperty]
		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="LineTime", Description="The time to draw the line for.", Order=1, GroupName="Parameters")]
		public DateTime LineTime
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="LineColor", Description="Color of the vertical line", Order=2, GroupName="Parameters")]
		public Brush LineColor
		{ get; set; }

		[Browsable(false)]
		public string LineColorSerializable
		{
			get { return Serialize.BrushToString(LineColor); }
			set { LineColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="LineDashStyle", Description="Dash style of the line.", Order=3, GroupName="Parameters")]
		public DashStyleHelper LineDashStyle
		{ get; set; }

		[Browsable(false)]
		public string LineDashStyleSerializable
		{
			get { return LineDashStyle.ToString(); }
			set { LineDashStyle = DeSerializeDashStyle(value); }
		}			

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="LineThickness", Description="Vertical line's thickness", Order=4, GroupName="Parameters")]
		public int LineThickness
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BarToLineOffsetInTicks", Description="Space between the bar and the line.", Order=5, GroupName="Parameters")]
		public int BarToLineOffsetInTicks
		{ get; set; }
		
		// DashStyle DeSerializer
		public DashStyleHelper DeSerializeDashStyle(string dashStyle)
		{
			if (dashStyle == null) return DashStyleHelper.Solid;
			
			if (dashStyle.Equals("Dash")) return DashStyleHelper.Dash;
			else if (dashStyle.Equals("DashDot")) return DashStyleHelper.DashDot;
			else if (dashStyle.Equals("DashDotDot")) return DashStyleHelper.DashDotDot;
			else if (dashStyle.Equals("Dot")) return DashStyleHelper.Dot;
			else if (dashStyle.Equals("Solid")) return DashStyleHelper.Solid;
			return DashStyleHelper.Solid;	// Deafult if XML is messed up
		}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BzvVerticalLineAtTimeV1[] cacheBzvVerticalLineAtTimeV1;
		public BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			return BzvVerticalLineAtTimeV1(Input, lineTime, lineColor, lineDashStyle, lineThickness, barToLineOffsetInTicks);
		}

		public BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(ISeries<double> input, DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			if (cacheBzvVerticalLineAtTimeV1 != null)
				for (int idx = 0; idx < cacheBzvVerticalLineAtTimeV1.Length; idx++)
					if (cacheBzvVerticalLineAtTimeV1[idx] != null && cacheBzvVerticalLineAtTimeV1[idx].LineTime == lineTime && cacheBzvVerticalLineAtTimeV1[idx].LineColor == lineColor && cacheBzvVerticalLineAtTimeV1[idx].LineDashStyle == lineDashStyle && cacheBzvVerticalLineAtTimeV1[idx].LineThickness == lineThickness && cacheBzvVerticalLineAtTimeV1[idx].BarToLineOffsetInTicks == barToLineOffsetInTicks && cacheBzvVerticalLineAtTimeV1[idx].EqualsInput(input))
						return cacheBzvVerticalLineAtTimeV1[idx];
			return CacheIndicator<BzvVerticalLineAtTimeV1>(new BzvVerticalLineAtTimeV1(){ LineTime = lineTime, LineColor = lineColor, LineDashStyle = lineDashStyle, LineThickness = lineThickness, BarToLineOffsetInTicks = barToLineOffsetInTicks }, input, ref cacheBzvVerticalLineAtTimeV1);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			return indicator.BzvVerticalLineAtTimeV1(Input, lineTime, lineColor, lineDashStyle, lineThickness, barToLineOffsetInTicks);
		}

		public Indicators.BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(ISeries<double> input , DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			return indicator.BzvVerticalLineAtTimeV1(input, lineTime, lineColor, lineDashStyle, lineThickness, barToLineOffsetInTicks);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			return indicator.BzvVerticalLineAtTimeV1(Input, lineTime, lineColor, lineDashStyle, lineThickness, barToLineOffsetInTicks);
		}

		public Indicators.BzvVerticalLineAtTimeV1 BzvVerticalLineAtTimeV1(ISeries<double> input , DateTime lineTime, Brush lineColor, DashStyleHelper lineDashStyle, int lineThickness, int barToLineOffsetInTicks)
		{
			return indicator.BzvVerticalLineAtTimeV1(input, lineTime, lineColor, lineDashStyle, lineThickness, barToLineOffsetInTicks);
		}
	}
}

#endregion
