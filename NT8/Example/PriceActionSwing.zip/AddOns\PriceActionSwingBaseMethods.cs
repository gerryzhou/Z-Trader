#region Using declarations
using NinjaTrader.Data;
using NinjaTrader.Gui;
using System;
using System.Collections.Generic;
using System.Windows.Media;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
//using System.Drawing.Drawing2D;
using PriceActionSwing.Base;
#endregion

namespace PriceActionSwing.Base
{
	#region public class SwingValues
    //=============================================================================================
    public class Swings
    {
        #region Current values
        //-----------------------------------------------------------------------------------------
        /// <summary>
        /// Represents the price of the current swing.
        /// </summary>
        public double CurPrice { get; set; }
        /// <summary>
        /// Represents the bar number of the highest/lowest bar of the current swing.
        /// </summary>
        public int CurBar { get; set; }
        /// <summary>
        /// Represents the duration as time values of the current swing.
        /// </summary>
        public DateTime CurDateTime { get; set; }
        /// <summary>
        /// Represents the duration in bars of the current swing.
        /// </summary>
        public int CurDuration { get; set; }
        /// <summary>
        /// Represents the swing length in ticks of the current swing.
        /// </summary>
        public int CurLength { get; set; }
        /// <summary>
        /// Represents the percentage in relation between the last swing and the current swing. 
        /// E. g. 61.8% fib retracement.
        /// </summary>
        public double CurPercent { get; set; }
        /// <summary>
        /// Represents the duration as integer in HHMMSS of the current swing.
        /// </summary>
        public int CurTime { get; set; }
        /// <summary>
        /// Represents the entire volume of the current swing.
        /// </summary>
        public long CurVolume { get; set; }
        /// <summary>
        /// Represents the relation to the previous swing.
        /// -1 = Lower High | 0 = Double Top | 1 = Higher High
        /// </summary>
        public int CurRelation { get; set; }
        //-----------------------------------------------------------------------------------------
        #endregion

        #region Last values
        //-----------------------------------------------------------------------------------------
        /// <summary>
        /// Represents the price of the last swing.
        /// </summary>
        public double LastPrice { get; set; }
        /// <summary>
        /// Represents the bar number of the highest/lowest bar of the last swing.
        /// </summary>
        public int LastBar { get; set; }
        /// <summary>
        /// Represents the duration as time values of the last swing.
        /// </summary>
        public DateTime LastDateTime { get; set; }
        /// <summary>
        /// Represents the duration in bars of the last swing.
        /// </summary>
        public int LastDuration { get; set; }
        /// <summary>
        /// Represents the swing length in ticks of the last swing.
        /// </summary>
        public int LastLength { get; set; }
        /// <summary>
        /// Represents the percentage in relation between the previous swing and the last swing. 
        /// E. g. 61.8% fib retracement.
        /// </summary>
        public double LastPercent { get; set; }
        /// <summary>
        /// Represents the duration as integer in HHMMSS of the last swing.
        /// </summary>
        public int LastTime { get; set; }
        /// <summary>
        /// Represents the entire volume of the last swing.
        /// </summary>
        public long LastVolume { get; set; }
        /// <summary>
        /// Represents the relation to the previous swing.
        /// -1 = Lower High | 0 = Double Top | 1 = Higher High
        /// </summary>
        public int LastRelation { get; set; }
        //-----------------------------------------------------------------------------------------
        #endregion

        #region Other values
        //-----------------------------------------------------------------------------------------
        /// <summary>
        /// Represents the number of swings.
        /// </summary>
        public int Counter { get; set; }
        /// <summary>
        /// Indicates if a new swing is found.
        /// </summary>
        public bool New { get; set; }
        /// <summary>
        /// Indicates if a the current swing is updated.
        /// </summary>
        public bool Update { get; set; }
        /// <summary>
        /// Represents the volume of the signal bar for the swing.
        /// </summary>
        public double SignalBarVolume { get; set; }
        /// <summary>
        /// Represents the number of the last swing in the swing list.
        /// </summary>
        public int ListCount { get; set; }
        //-----------------------------------------------------------------------------------------
        #endregion
    }
    //=============================================================================================
    #endregion

    #region public class CurrentSwing
    //=============================================================================================
    public class SwingCurrent
    {
        /// <summary>
        /// Represents the swing slope direction. -1 = down | 0 = init | 1 = up.
        /// </summary>
        public int SwingSlope { get; set; }
        /// <summary>
        /// Represents the bar number of the swing slope change bar.
        /// </summary>
        public int SwingSlopeChangeBar { get; set; }
        /// <summary>
        /// Indicates if a new swing is found. And whether it is a swing high or a swing low.
        /// Used to control, that either a swing high or a swing low is set for each bar.
        /// 0 = no swing | -1 = down swing | 1 = up swing
        /// </summary>
        public int NewSwing { get; set; }
        /// <summary>
        /// Represents the number of consecutives up/down bars.
        /// </summary>
        public int ConsecutiveBars { get; set; }
        /// <summary>
        /// Represents the bar number of the last bar which was counted to the 
        /// consecutives up/down bars.
        /// </summary>
        public int ConsecutiveBarNumber { get; set; }
        /// <summary>
        /// Represents the high/low of the last consecutive bar.
        /// </summary>
        public double ConsecutiveBarValue { get; set; }
        /// <summary>
        /// Indicates if the outside bar calculation is stopped. Used to avoid an up swing and 
        /// a down swing in one bar.
        /// </summary>
        public bool StopOutsideBarCalc { get; set; }
    }
    //=============================================================================================
    #endregion

    #region public class SwingProperties
    //=============================================================================================
    public class SwingProperties
    {
        public SwingProperties(double swingSize, int dtbStrength)
        {
            SwingSize = swingSize;
            DtbStrength = dtbStrength;
        }

        public SwingProperties(SwingStyle swingType, double swingSize, int dtbStrength,
            SwingLengthStyle swingLengthType, SwingDurationStyle swingDurationType, 
            bool showSwingPrice, bool showSwingLabel, bool showSwingPercent,
            SwingTimeStyle swingTimeType, SwingVolumeStyle swingVolumeType, 
            VisualizationStyle visualizationType, bool useBreakouts, bool ignoreInsideBars, 
            bool useAutoScale, Brush zigZagColorUp, Brush zigZagColorDn,
            DashStyleHelper zigZagStyle, int zigZagWidth, Brush textColorHigherHigh,
            Brush textColorLowerHigh, Brush textColorDoubleTop, Brush textColorHigherLow,
            Brush textColorLowerLow, Brush textColorDoubleBottom, NinjaTrader.Gui.Tools.SimpleFont textFont, 
            int textOffsetLength, int textOffsetPercent, int textOffsetPrice, int textOffsetLabel,
            int textOffsetTime, int textOffsetVolume, bool useCloseValues)
        {
            SwingType = swingType;
            SwingSize = swingSize;
            DtbStrength = dtbStrength;
            SwingLengthType = swingLengthType;
            SwingDurationType = swingDurationType;
            ShowSwingPrice = showSwingPrice;
            ShowSwingLabel = showSwingLabel;
            ShowSwingPercent = showSwingPercent;
            SwingTimeType = swingTimeType;
            SwingVolumeType = swingVolumeType;
            VisualizationType = visualizationType;
            UseBreakouts = useBreakouts;
            IgnoreInsideBars = ignoreInsideBars;
            UseAutoScale = useAutoScale;
            ZigZagColorUp = zigZagColorUp;
            ZigZagColorDn = zigZagColorDn;
            ZigZagStyle = zigZagStyle;
            ZigZagWidth = zigZagWidth;
            TextColorHigherHigh = textColorHigherHigh;
            TextColorLowerHigh = textColorLowerHigh;
            TextColorDoubleTop = textColorDoubleTop;
            TextColorHigherLow = textColorHigherLow;
            TextColorLowerLow = textColorLowerLow;
            TextColorDoubleBottom = textColorDoubleBottom;
            TextFont = textFont;
            TextOffsetLength = textOffsetLength;
            TextOffsetPercent = textOffsetPercent;
            TextOffsetPrice = textOffsetPrice;
            TextOffsetLabel = textOffsetLabel;
            TextOffsetTime = textOffsetTime;
            TextOffsetVolume = textOffsetVolume;
            UseCloseValues = useCloseValues;
        }

        /// <summary>
        /// Represents the swing type.
        /// </summary>
        public SwingStyle SwingType { get; set; }
        /// <summary>
        /// Represents the swing size. e.g. 1 = small swings and 5 = bigger swings.
        /// </summary>
        public double SwingSize { get; set; }
        /// <summary>
        /// Represents the double top and double bottom strength.
        /// </summary>
        public int DtbStrength { get; set; }
        /// <summary>
        /// Represents the swing length visualization type.
        /// </summary>
        public SwingLengthStyle SwingLengthType { get; set; }
        /// <summary>
        /// Represents the swing duration visualization type.
        /// </summary>
        public SwingDurationStyle SwingDurationType { get; set; }
        /// <summary>
        /// Indicates if the swing price is shown.
        /// </summary>
        public bool ShowSwingPrice { get; set; }
        /// <summary>
        /// Indicates if the swing label is shown.
        /// </summary>
        public bool ShowSwingLabel { get; set; }
        /// <summary>
        /// Indicates if the swing percentage in relation to the last swing is shown.
        /// </summary>
        public bool ShowSwingPercent { get; set; }
        /// <summary>
        /// Represents the swing time visualization type.
        /// </summary>
        public SwingTimeStyle SwingTimeType { get; set; }
        /// <summary>
        /// Represents the swing volume visualization type.
        /// </summary>
        public SwingVolumeStyle SwingVolumeType { get; set; }
        /// <summary>
        /// Represents the swing visualization type. 
        /// </summary>
        public VisualizationStyle VisualizationType { get; set; }
        /// <summary>
        /// Indicates if the Gann swings are updated if the last swing high/low is broken.
        /// </summary>
        public bool UseBreakouts { get; set; }
        /// <summary>
        /// Indicates if inside bars are ignored for the Gann swing calculation. If set to true 
        /// it is possible that between consecutive up/down bars are inside bars.
        /// </summary>
        public bool IgnoreInsideBars { get; set; }
        /// <summary>
        /// Indicates if AutoScale is used. 
        /// </summary>
        public bool UseAutoScale { get; set; }
        /// <summary>
        /// Represents the colour of the zig-zag up lines.
        /// </summary>
        public Brush ZigZagColorUp { get; set; }
        /// <summary>
        /// Represents the colour of the zig-zag down lines.
        /// </summary>
        public Brush ZigZagColorDn { get; set; }
        /// <summary>
        /// Represents the line style of the zig-zag lines.
        /// </summary>
        public DashStyleHelper ZigZagStyle { get; set; }
        /// <summary>
        /// Represents the line width of the zig-zag lines.
        /// </summary>
        public int ZigZagWidth { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for higher highs.
        /// </summary>
        public Brush TextColorHigherHigh { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for lower highs.
        /// </summary>
        public Brush TextColorLowerHigh { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for double tops.
        /// </summary>
        public Brush TextColorDoubleTop { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for higher lows.
        /// </summary>
        public Brush TextColorHigherLow { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for lower lows.
        /// </summary>
        public Brush TextColorLowerLow { get; set; }
        /// <summary>
        /// Represents the colour of the swing value output for double bottems.
        /// </summary>
        public Brush TextColorDoubleBottom { get; set; }
        /// <summary>
        /// Represents the text font for the swing value output.
        /// </summary>
        public NinjaTrader.Gui.Tools.SimpleFont TextFont { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the swing length.
        /// </summary>
        public int TextOffsetLength { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the retracement value.
        /// </summary>
        public int TextOffsetPercent { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the swing price.
        /// </summary>
        public int TextOffsetPrice { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the swing labels.
        /// </summary>
        public int TextOffsetLabel { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the swing time.
        /// </summary>
        public int TextOffsetTime { get; set; }
        /// <summary>
        /// Represents the text offset in pixel for the swing volume.
        /// </summary>
        public int TextOffsetVolume { get; set; }
        /// <summary>
        /// Indicates if high and low prices are used for the swing calculations or close values.
        /// </summary>
        public bool UseCloseValues { get; set; }
    }
    //=============================================================================================
    #endregion

    #region public struct SwingStruct
    //=============================================================================================
    public struct SwingStruct
    {
        /// <summary>
        /// Swing price.
        /// </summary>
        public double price;
        /// <summary>
        /// Swing bar number.
        /// </summary>
        public int barNumber;
        /// <summary>
        /// Swing time.
        /// </summary>
        public DateTime time;
        /// <summary>
        /// Swing duration in bars.
        /// </summary>
        public int duration;
        /// <summary>
        /// Swing length in ticks.
        /// </summary>
        public int length;
        /// <summary>
        /// Swing relation.
        /// -1 = Lower | 0 = Double | 1 = Higher
        /// </summary>
        public int relation;
        /// <summary>
        /// Swing volume.
        /// </summary>
        public long volume;

        public SwingStruct(double swingPrice, int swingBarNumber, DateTime swingTime,
                int swingDuration, int swingLength, int swingRelation, long swingVolume)
        {
            price = swingPrice;
            barNumber = swingBarNumber;
            time = swingTime;
            duration = swingDuration;
            length = swingLength;
            relation = swingRelation;
            volume = swingVolume;
        }
    }
    //=============================================================================================
    #endregion

    #region Enums
    //=============================================================================================
    public enum VisualizationStyle
    {
        False,
        Dots,
        Dots_ZigZag,
        ZigZag,
        ZigZagVolume,
        GannStyle,
    }

    public enum SwingStyle
    {
        Standard,
        Gann,
        Ticks,
        Percent,
    }

    public enum SwingLengthStyle
    {
        False,
        Ticks,
        Ticks_Price,
        Price_Ticks,
        Points,
        Points_Price,
        Price_Points,
        Price,
        Percent,
    }

    public enum SwingDurationStyle
    {
        False,
        Bars,
        MMSS,
        HHMM,
        SecondsTotal,
        MinutesTotal,
        HoursTotal,
        Days,
    }

    public enum SwingTimeStyle
    {
        False,
        Integer,
        HHMM,
        HHMMSS,
        DDMM,
    }
    
    public enum SwingVolumeStyle
    {
        False,
        Absolute,
        Relative,
    }

    public enum AbcPatternMode
    {
        False,
        Long_Short,
        Long,
        Short,
    }

    public enum StatisticPositionStyle
    {
        False,
        Bottom,
        Top,
    }

    public enum RiskManagementStyle
    {
        False,
        ToolStrip,
        Tab,
    }

    public enum DivergenceMode
    {
        Custom,
        False,
        GomCD,
        MACD,
        Stochastics,
    }
    public enum DivergenceDirection
    {
        Long,
        Long_Short,
        Short
    }
    public enum Show
    {
        Trend,
        Relation,
        Volume,
    }
    //=============================================================================================
    #endregion
}