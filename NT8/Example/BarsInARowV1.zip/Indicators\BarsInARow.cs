#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class BarsInARow : Indicator
	{
		private int UpBarCount = 0;
		private int DwnBarCount = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Counts the number of bars going in the same direction before a reversal or doji. Includes user-configurable-period SMAs of both rising and falling bars.";
				Name										= "BarsInARow";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				SMAPeriod					= 10;
				AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Bar, "UpBars");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Bar, "DwnBars");
				AddPlot(Brushes.DodgerBlue, "AvUp");
				AddPlot(Brushes.DodgerBlue, "AvDwn");
				AddLine(Brushes.Black, 0, "ZeroLine");
				AddLine(Brushes.DimGray, 5, "05_Up");
				AddLine(Brushes.DimGray, -5, "05_Dwn");
				AddLine(Brushes.Gray, 10, "10_Up");
				AddLine(Brushes.Gray, -10, "10_Dwn");
				AddLine(Brushes.DarkGray, 15, "15_Up");
				AddLine(Brushes.DarkGray, -15, "15_Dwn");
				AddLine(Brushes.Silver, 20, "20_Up");
				AddLine(Brushes.Silver, -20, "20_Dwn");
				AddLine(Brushes.LightGray, 25, "25_Up");
				AddLine(Brushes.LightGray, -25, "25_Dwn");
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (
				Close[0] > Open[0]
				)
			{
				UpBarCount++;
				DwnBarCount = 0;
			}
			if (
				Open[0] > Close[0]
				)
			{
				UpBarCount = 0;
				DwnBarCount++;
			}
			if (
				Close[0] == Open[0]
				)
			{
				UpBarCount = 0;
				DwnBarCount = 0;
			}
			
			UpBars[0] = UpBarCount;
			DwnBars[0] = -DwnBarCount;
			AvUp[0] = SMA(UpBars, SMAPeriod)[0];
			AvDwn[0] = SMA(DwnBars, SMAPeriod)[0];
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="SMAPeriod", Description="Period of both SMAs", Order=1, GroupName="Parameters")]
		public int SMAPeriod
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpBars
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> DwnBars
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvUp
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> AvDwn
		{
			get { return Values[3]; }
		}











		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BarsInARow[] cacheBarsInARow;
		public BarsInARow BarsInARow(int sMAPeriod)
		{
			return BarsInARow(Input, sMAPeriod);
		}

		public BarsInARow BarsInARow(ISeries<double> input, int sMAPeriod)
		{
			if (cacheBarsInARow != null)
				for (int idx = 0; idx < cacheBarsInARow.Length; idx++)
					if (cacheBarsInARow[idx] != null && cacheBarsInARow[idx].SMAPeriod == sMAPeriod && cacheBarsInARow[idx].EqualsInput(input))
						return cacheBarsInARow[idx];
			return CacheIndicator<BarsInARow>(new BarsInARow(){ SMAPeriod = sMAPeriod }, input, ref cacheBarsInARow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BarsInARow BarsInARow(int sMAPeriod)
		{
			return indicator.BarsInARow(Input, sMAPeriod);
		}

		public Indicators.BarsInARow BarsInARow(ISeries<double> input , int sMAPeriod)
		{
			return indicator.BarsInARow(input, sMAPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BarsInARow BarsInARow(int sMAPeriod)
		{
			return indicator.BarsInARow(Input, sMAPeriod);
		}

		public Indicators.BarsInARow BarsInARow(ISeries<double> input , int sMAPeriod)
		{
			return indicator.BarsInARow(input, sMAPeriod);
		}
	}
}

#endregion
