#region Using declarations
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.IO;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators

{
	public class BarTimerPro : Indicator
	{
		private Chart chartWindow                            = null;
		private System.Windows.Controls.Label myTradeTimer = null;
		private bool IsToolBarLabelAdded;
		private DependencyObject searchObject;
		private string theMenuAutomationID;
		private bool showclock                               = true;
		private bool displayAllTabs                          = false;
		private bool displayIndicatorName                    = false;
		private SimpleFont timerFont;
		private System.Windows.Forms.Timer timer1            = new System.Windows.Forms.Timer();
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{	
			    Description					                = @"";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= false;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				
				timerColor		                            = Brushes.LightGray;
				timerFont	                                = new Gui.Tools.SimpleFont("Tahoma New", 12) { Size = 12, Bold = false };

			}
			else if (State == State.Configure)
			{
				
			}
			
			else if(State == State.Historical)
		    {
				if (ChartControl != null && !IsToolBarLabelAdded && showclock == true)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						addTradeTimerToToolbar();
					}));
				}	
			}
			
			else if (State == State.Terminated)
			{
				disposeCleanUp();
								          
                if (timer1 == null) return;
                timer1.Enabled = false;
                timer1 = null;
				
			}
			else if (State == State.DataLoaded)
			{
			    if (displayIndicatorName)	
		        {
				Name = "BarTimerPro V1.0";
		        }
				else
				{
				Name = "";	
				}
				
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
        base.OnRender(chartControl, chartScale);
        // loop through only the rendered bars on the chart
        for(int barIndex = ChartBars.FromIndex; barIndex <= ChartBars.ToIndex; barIndex++)
         {
         // get the time stamp at the selected bar index value
		 DateTime timeValue = Bars.GetTime(barIndex - 1);
			 
      // Print("Bar #" + barIndex + " time stamp is " + timeValue);
	     executionTime = timeValue;
		 }
        }
		
		private void OnTimedEvent(Object source, EventArgs e)
        {	
		   	DateTime currentTime = DateTime.Now;
			TimeSpan barTimeLeft = currentTime.Subtract(executionTime);
		 
		    string		BtimeLeft	= (barTimeLeft.Hours.ToString("00") + ":" + barTimeLeft.Minutes.ToString("00") + ":" + barTimeLeft.Seconds.ToString("00"));
			myTradeTimer.Content = "BAR TMR" + "\n" + BtimeLeft;	
		}

		protected override void OnBarUpdate()
		{
		}

	    private void addTradeTimerToToolbar()
	    {	 
	          //Obtain the Chart on which the indicator is configured
	          chartWindow = Window.GetWindow(this.ChartControl.Parent) as Chart;
			
			  chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
			
	          if (chartWindow == null)
	          {
	              Print("chartWindow == null");
	              return;
	          }
			  
			 theMenuAutomationID = string.Format("ChartToolbarBarTimer{0}", DateTime.Now.ToString("yyMMddhhmmss"));

			 foreach (System.Windows.DependencyObject item in chartWindow.MainMenu)
				if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == theMenuAutomationID)
					return;
	 
	          // Create a style to apply to the label
	          Style s = new Style();
	          s.TargetType = typeof(System.Windows.Controls.Label);
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontSizeProperty, 10.0));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.BackgroundProperty, Brushes.Transparent));
			  s.Setters.Add(new Setter(System.Windows.Controls.Label.ForegroundProperty, timerColor));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontFamilyProperty, new FontFamily("Tahoma")));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontWeightProperty, FontWeights.Regular));
	 
	          // Instantiate the label
	          myTradeTimer = new System.Windows.Controls.Label();

	          //Set label Style             
	          myTradeTimer.Style = s;
				
		      System.Windows.Automation.AutomationProperties.SetAutomationId(myTradeTimer, theMenuAutomationID);
			  
			  //Override Font Style 
			  timerFont.ApplyTo(myTradeTimer);
	          
			  myTradeTimer.IsEnabled = true;
	 
	          // Add the label to the Chart's Toolbar
	          chartWindow.MainMenu.Add(myTradeTimer);
					
			  // init the timer to one second and set the event handler
			  timer1.Interval = 1000;
        	  timer1.Enabled = true;
			  timer1.Tick += new EventHandler(OnTimedEvent);
	 
	          //Prevent the Label From Displaying when WorkSpace Opens if it is not in an active tab
	          myTradeTimer.Visibility = Visibility.Collapsed;
				
			  myTradeTimer.Content = "BAR TMR" + "\n" + "00:00:00";
			  
	          foreach (TabItem tab in this.chartWindow.MainTabControl.Items)
	          {
	              if ((tab.Content as ChartTab).ChartControl == this.ChartControl
	                   && tab == this.chartWindow.MainTabControl.SelectedItem)
	              {
	                  myTradeTimer.Visibility = Visibility.Visible;
	              }  
	          }
	          IsToolBarLabelAdded = true;
	    }
		
	    private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{	
		if (displayAllTabs == false)	
		{
			if (e.AddedItems.Count <= 0)
				return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab; 
			if (temp != null)
			{
				if (myTradeTimer != null)
					myTradeTimer.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
			}
		}
		}
		
		
		private void disposeCleanUp()
		{
			if(chartWindow != null)
			{
				try
        		{
					if (ChartControl == null) return;
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						//Label Null Check
		              	if (myTradeTimer != null)
		              	{
		                  //Remove Label from Indicator's Chart ToolBar
		                  chartWindow.MainMenu.Remove(myTradeTimer);

			              timer1.Stop();
			              timer1.Dispose();
		              	}
						
					}));
				}
				catch(Exception e)
	           {
		           //Print("TT: "+e.ToString());
		       }
			}
		}		
		
#region Properties

		[NinjaScriptProperty]
		[Display(Name="Prior Bar Date/Time", Order=1, Description="Last Execution", GroupName="Bar Time Stamp")]
		public DateTime executionTime
		{ get; set; }
	
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Font Color", Description="Text Color", Order=1, GroupName="Timer Settings")]
		public Brush timerColor
		{ get; set; }

		[Browsable(false)]
		public string trColorSerializable
		{
			get { return Serialize.BrushToString(timerColor); }
			set { timerColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font Select", Description = "Select font, style, size to display on chart.", GroupName = "Timer Settings", Order = 2)]
		public SimpleFont ClocktFont
	    {
			get{return timerFont;}
			set{timerFont = value;}
		}
		
		[NinjaScriptProperty]
		[Display(Name="Show Timer", Description="True will show timer", Order=3, GroupName="Timer Settings")]
        public bool ShowClock
        {
            get { return showclock; }
			set { showclock = value; }
        }
		
		[Description("Display Timer on All Tabs")]
        [Display(Name="Display All Tabs", Description="Display Timer on All Tabs", Order=4, GroupName="Timer Settings")]
		public bool DisplayAllTabs
		{
			get{ return displayAllTabs;}
			set{displayAllTabs = value;}
		}
		
		[Description("Display Indicator Name On Chart")]
        [Display(Name="Display Indicator Name", Description="Display Indicator Name On Chart", Order=1, GroupName="Indicator Name")]
		public bool DisplayIndicatorName
		{
			get{ return displayIndicatorName;}
			set{displayIndicatorName = value;}
		}
	
#endregion		
	
	}	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private BarTimerPro[] cacheBarTimerPro;
		public BarTimerPro BarTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return BarTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public BarTimerPro BarTimerPro(ISeries<double> input, DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			if (cacheBarTimerPro != null)
				for (int idx = 0; idx < cacheBarTimerPro.Length; idx++)
					if (cacheBarTimerPro[idx] != null && cacheBarTimerPro[idx].executionTime == executionTime && cacheBarTimerPro[idx].timerColor == timerColor && cacheBarTimerPro[idx].ClocktFont == clocktFont && cacheBarTimerPro[idx].ShowClock == showClock && cacheBarTimerPro[idx].EqualsInput(input))
						return cacheBarTimerPro[idx];
			return CacheIndicator<BarTimerPro>(new BarTimerPro(){ executionTime = executionTime, timerColor = timerColor, ClocktFont = clocktFont, ShowClock = showClock }, input, ref cacheBarTimerPro);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.BarTimerPro BarTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.BarTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public Indicators.BarTimerPro BarTimerPro(ISeries<double> input , DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.BarTimerPro(input, executionTime, timerColor, clocktFont, showClock);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.BarTimerPro BarTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.BarTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public Indicators.BarTimerPro BarTimerPro(ISeries<double> input , DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.BarTimerPro(input, executionTime, timerColor, clocktFont, showClock);
		}
	}
}

#endregion
