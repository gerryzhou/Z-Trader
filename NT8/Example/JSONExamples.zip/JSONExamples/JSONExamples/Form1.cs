﻿/*-----------------------------------------------------------------------------
 * JSONExamples
 * This project is intended to demonstrate the process of parsing JSON strings
 * using the .NET JavaScriptSerializer class. 
 * This code is provided for instructional purposes only. No warranty is
 * expressed or implied. 
 * 
 *                         USE THIS CODE AT YOUR OWN RISK
 * 
 * Copyright(c) 2011. Tomas Vera. All rights reserved.
 *---------------------------------------------------------------------------*/
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Web.Script.Serialization;

namespace JSONExamples
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bnParse_Click(object sender, EventArgs e)
        {
            if (tbInput.Text.Length > 0)
            {
                tbOutput.Clear();
                ParseJSONString(tbInput.Text);
            }
        }

        int indentLevel = 0;
        private bool ParseJSONString(string input)
        {
            bool bSuccess = false;
            JavaScriptSerializer ser = new JavaScriptSerializer();
            Dictionary<string, object> dict = ser.Deserialize<Dictionary<string, object>>(input);

            

            bSuccess = DisplayDictionary(dict);


            return true;
        }

        private bool DisplayDictionary(Dictionary<string, object> dict)
        {
            bool bSuccess = false;
            indentLevel++;

            foreach (string strKey in dict.Keys)
            {
                string strOutput = "".PadLeft(indentLevel * 8) + strKey + ":";
                tbOutput.AppendText("\r\n" + strOutput);

                object o = dict[strKey];
                if (o is Dictionary<string, object>)
                {
                    DisplayDictionary((Dictionary<string, object>)o);
                }
                else if (o is ArrayList)
                {
                    foreach (object oChild in ((ArrayList)o))
                    {
                        if (oChild is string)
                        {
                            strOutput = ((string) oChild);
                            tbOutput.AppendText(strOutput + ",");
                        }
                        else if (oChild is Dictionary<string, object>)
                        {
                            DisplayDictionary((Dictionary<string, object>)oChild);
                            tbOutput.AppendText("\r\n");
                        }
                    }
                }
                else
                {
                    strOutput = o.ToString();
                    tbOutput.AppendText(strOutput);
                }
            }

            indentLevel--;

            return bSuccess;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tbOutput.Clear();

            JavaScriptSerializer ser = new JavaScriptSerializer();

            jsonmenuwrapper wrapper = ser.Deserialize<jsonmenuwrapper>(tbInput.Text);


        }

 
    }
}
