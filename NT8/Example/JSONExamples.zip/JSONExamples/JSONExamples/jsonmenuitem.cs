﻿/*-----------------------------------------------------------------------------
 * JSONExamples
 * This project is intended to demonstrate the process of parsing JSON strings
 * using the .NET JavaScriptSerializer class. 
 * This code is provided for instructional purposes only. No warranty is
 * expressed or implied. 
 * 
 *                         USE THIS CODE AT YOUR OWN RISK
 * 
 * Copyright(c) 2011. Tomas Vera. All rights reserved.
 *---------------------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JSONExamples
{
    class jsonmenuitem
    {
        public string value { get; set;}
        public string onclick{get;set;}
    }

    class jsonpopup
    {
        public jsonmenuitem[] menuitem {get;set;}
    }

    class jsonmenu
    {
        public string id {get;set;}
        public string value { get; set; }
        public jsonpopup popup { get; set; }
    }

    class jsonmenuwrapper
    {
        public jsonmenu menu { get; set; }
    }
}
