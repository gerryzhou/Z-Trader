#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RangeRider : Indicator
	{
		 private int fastChannel = 3;
		 [NinjaScriptProperty]
		 [Display(Name = "01. Fast Channel", Description = "Period used in our short term channel", GroupName = "01. Indicator Parameters", Order = 1)]
		        public int PeriodFast
		 		{
		            get { return fastChannel; }
		            set { fastChannel = Math.Max(0, value); }
		        }
		 private int slowChannel = 21;
		 [NinjaScriptProperty]
		 [Display(Name = "02. Slow Channel", Description = "Period used in our long term channel", GroupName = "01. Indicator Parameters", Order = 2)]
		        public int PeriodSlow
		 		{
		            get { return slowChannel; }
		            set { slowChannel = Math.Max(0, value); }
		        }
		private int pivotChannel = 42;
		 [NinjaScriptProperty]
		 [Display(Name = "03. Pivot Channel", Description = "Period used for pivots", GroupName = "01. Indicator Parameters", Order = 3)]
		        public int PivotPeriod
		 		{
		            get { return pivotChannel; }
		            set { pivotChannel = Math.Max(0, value); }
		        }
		 		 
		private MAX fastMax;
		private MIN fastMin;
		private MAX slowMax;
		private MIN slowMin;
		private MAX pivotMax;
		private MIN pivotMin;
 
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Flytrap MIN MAX indicator";
				Name										= "RangeRider";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				IsAutoScale 								= true;
				BarsRequiredToPlot 							= 1;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				IsChartOnly 								= false;
				MaximumBarsLookBack 						= MaximumBarsLookBack.TwoHundredFiftySix;
				
				// Plots
				AddPlot(new Stroke(Brushes.Orange, DashStyleHelper.Solid, 1f), PlotStyle.Dot, "SlowChannelMax"); //Value [0]
				AddPlot(new Stroke(Brushes.Orange, DashStyleHelper.Solid, 1f), PlotStyle.Dot, "SlowChannelMin"); //Value [1]
				AddPlot(new Stroke(Brushes.Lime, DashStyleHelper.Solid, 2f), PlotStyle.Line, "FastChannelMax"); //Value [2]
				AddPlot(new Stroke(Brushes.DeepPink, DashStyleHelper.Solid, 2f), PlotStyle.Line, "FastChannelMin"); //Value [3]
				AddPlot(new Stroke(Brushes.DodgerBlue, DashStyleHelper.Solid, 1f), PlotStyle.Dot, "PivotChannelMax"); //Value [4]
				AddPlot(new Stroke(Brushes.DodgerBlue, DashStyleHelper.Solid, 1f), PlotStyle.Dot, "PivotChannelMin"); //Value [5]
				
			}
			else if (State == State.DataLoaded)
			{
				BarsRequiredToPlot = pivotChannel;
				slowMax = MAX(slowChannel);
				slowMin = MIN(slowChannel);
				fastMax = MAX(fastChannel);
				fastMin = MIN(fastChannel);
				pivotMax = MAX(pivotChannel);
				pivotMin = MIN(pivotChannel);
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar <= BarsRequiredToPlot) //Check for minimum bars required to plot.
 			return;
			
			 Values[0][0] = slowMax[0];
 			 Values[1][0] = slowMin[0];
			 Values[2][0] = fastMax[0];
 			 Values[3][0] = fastMin[0];
			 Values[4][0] = pivotMax[0];
 			 Values[5][0] = pivotMin[0];
			
				Draw.Region(this, "maxregion2", CurrentBar, 0, slowMax, fastMax, null, Brushes.Green, 20);
				Draw.Region(this, "minregion2", CurrentBar, 0, fastMin, slowMin, null, Brushes.DeepPink, 14);
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RangeRider[] cacheRangeRider;
		public RangeRider RangeRider(int periodFast, int periodSlow, int pivotPeriod)
		{
			return RangeRider(Input, periodFast, periodSlow, pivotPeriod);
		}

		public RangeRider RangeRider(ISeries<double> input, int periodFast, int periodSlow, int pivotPeriod)
		{
			if (cacheRangeRider != null)
				for (int idx = 0; idx < cacheRangeRider.Length; idx++)
					if (cacheRangeRider[idx] != null && cacheRangeRider[idx].PeriodFast == periodFast && cacheRangeRider[idx].PeriodSlow == periodSlow && cacheRangeRider[idx].PivotPeriod == pivotPeriod && cacheRangeRider[idx].EqualsInput(input))
						return cacheRangeRider[idx];
			return CacheIndicator<RangeRider>(new RangeRider(){ PeriodFast = periodFast, PeriodSlow = periodSlow, PivotPeriod = pivotPeriod }, input, ref cacheRangeRider);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RangeRider RangeRider(int periodFast, int periodSlow, int pivotPeriod)
		{
			return indicator.RangeRider(Input, periodFast, periodSlow, pivotPeriod);
		}

		public Indicators.RangeRider RangeRider(ISeries<double> input , int periodFast, int periodSlow, int pivotPeriod)
		{
			return indicator.RangeRider(input, periodFast, periodSlow, pivotPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RangeRider RangeRider(int periodFast, int periodSlow, int pivotPeriod)
		{
			return indicator.RangeRider(Input, periodFast, periodSlow, pivotPeriod);
		}

		public Indicators.RangeRider RangeRider(ISeries<double> input , int periodFast, int periodSlow, int pivotPeriod)
		{
			return indicator.RangeRider(input, periodFast, periodSlow, pivotPeriod);
		}
	}
}

#endregion
