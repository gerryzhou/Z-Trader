#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
	/// <summary>
	/// AggregateM 2009 by David Varadi - Ported by Sim22 NT8b10 Mar 2016
	/// http://cssanalytics.wordpress.com/2009/11/05/trend-or-mean-reversion-why-make-a-choice-the-simple-aggregate-m-indicator/
	/// 
	/// I have changed David's original terms to avoid confusion:
	/// 
	/// Long and short periods (252 & 10) now are 'Slow Period and Fast period'.
	/// Back and front weighting (0.0-1.0) is now 'CurrentBarWeighting' (0-100%) ie. front weighting only. 'BackBarWeighting' will default to 100 - CurrentBarWeighting.
	/// I have also added trend weighting to increase/decrease trend/correction emphasis. Set to 50% if you do not want any change to the original.
	/// </summary>
	public class Sim22_AggregateMPlusPlus : Indicator
	{
		private Series<double>	m;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"AggregateM 2009 by David Varadi - Ported by Sim22 NT8b10 Mar 2016";
				Name								= "Sim22_AggregateM++";
				Calculate							= Calculate.OnBarClose;
				IsOverlay							= false;
				DisplayInDataBox					= true;
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= true;
				ScaleJustification					= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive			= true;
				
				SlowPeriod							= 252;
				FastPeriod							= 10;
				CurrentBarWeighting					= 60; //emphasis on currentbar
				//Added:
				TrendWeighting						= 50; //trend favourable
				
				AddPlot(new Stroke(Brushes.Black, 2f), PlotStyle.Line, "AggM");
				AddLine(new Stroke(Brushes.DimGray, DashStyleHelper.Dot, 1f), 50, "ZeroLine");
				AddLine(new Stroke(Brushes.Red, DashStyleHelper.Dot, 2f), 5, "Lower");
				AddLine(new Stroke(Brushes.Green, DashStyleHelper.Dot, 2f), 95, "Upper");	
			}
			else if (State == State.Configure)
			{
				m	= new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
		}
		
		#region	Percent Rank Function
		
		private double	PercentRankHLC(int Period)
		{
			double count = 0.0;
			
			/*
			Explanation: 
		
			Find out of 'n' bars (Period) the number of HLC values that are above and below the Close of the current bar. Includes current bar's HL but not current close.
			Thus there will be (Period*3)-1 values to compare with the Close[0].
			The '-1' occurs because we do not include Close[0] from the number of values.
			Then Rank in % (percentile) where the Close[0] is located among these values.
			
		
			Reference:
			
			http://cssanalytics.wordpress.com/2009/11/05/trend-or-mean-reversion-why-make-a-choice-the-simple-aggregate-m-indicator/
			https://support.office.com/en-us/article/PERCENTRANK-function-f1b5836c-9619-4847-9fc9-080ec9024442
		
			Caveat:
		
			There are several versions of this indicator. However I have actually tested my values using the original PercentRank function in MS Excel.
			Ramon in the above link suggested 'Period + 1' but that is incorrect when starting with 'i = 0'.
			*/
			{
				for (int i = 0; i < Period; i++) 
				{
					// 'count' is the number of values LESS than Close[0] of the last n 'Period' days.
					
					count += (Close[0] > High[i] ? 1 : 0);
					count += (Close[0] > Low[i] ? 1 : 0);
					count += (Close[0] > Close[i] ? 1 : 0);
				}
				
				return 100 * count / (Period * 3 - 1);
			}
		}
		
		#endregion
		
		public override string DisplayName
		{
			get { return Name.ToString() + String.Format("\r\rPeriods \t\t= ({0}/{1})" + "\rTrd Weighting \t= ({2}/{3})" + "\rBar Weighting \t= ({4}/{5})", SlowPeriod, FastPeriod, TrendWeighting, 100 - TrendWeighting, 100 - CurrentBarWeighting, CurrentBarWeighting); }
			
		}
		
		public override string FormatPriceMarker(double price)
		{
		    return price.ToString("N0") + " %";
		}
		
		public override void OnCalculateMinMax()
		{    
			// Maintains a fixed scale to show full range of AM.
			MinValue = 0.0;
		   	MaxValue = 100.00;
		} 
		
		protected override void OnBarUpdate()
		{
			if (CurrentBar <= Math.Max(SlowPeriod, FastPeriod))
			return;
			
			double hlc1	= PercentRankHLC(SlowPeriod);
			double hlc2	= PercentRankHLC(FastPeriod);
			
			//Original is balance between the two
			//m[0]	= (hlc1 + hlc2) * 0.5; 
			
			//Sim22
			m[0]	= (hlc1 * TrendWeighting * 0.01 + hlc2 * (100 - TrendWeighting) * 0.01);
			
			double agm 	= ((100 - CurrentBarWeighting) * 0.01 * m[1]) + (CurrentBarWeighting * 0.01 * m[0]);
			
			Value[0]	= agm;
		}
		
		#region Properties
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> AggM
		{
			get { return Value; }
		}
		
		[Range(2, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Description="Select larger number of bars (Default = 252)", Name = "Slow period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int SlowPeriod
		{ get; set; }
		
		[Range(2, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Description="Select smaller number of bars (Default = 10)", Name = "Fast period", GroupName = "NinjaScriptParameters", Order = 1)]
		public int FastPeriod
		{ get; set; }
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Description="Smoothing between current bar and last bar", Name = "Current bar weighting % (0-100)", GroupName = "NinjaScriptParameters", Order = 2)]
		public int CurrentBarWeighting
		{ get; set; }
		
		[Range(0, 100), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Description="New: Increase for more trend based smoothing (0-100)", Name = "New: Trend weighting % (0-100)", GroupName = "NinjaScriptParameters", Order = 3)]
		public int TrendWeighting
		{ get; set; }
		

		#endregion
	}
	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_AggregateMPlusPlus[] cacheSim22_AggregateMPlusPlus;
		public Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			return Sim22_AggregateMPlusPlus(Input, slowPeriod, fastPeriod, currentBarWeighting, trendWeighting);
		}

		public Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(ISeries<double> input, int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			if (cacheSim22_AggregateMPlusPlus != null)
				for (int idx = 0; idx < cacheSim22_AggregateMPlusPlus.Length; idx++)
					if (cacheSim22_AggregateMPlusPlus[idx] != null && cacheSim22_AggregateMPlusPlus[idx].SlowPeriod == slowPeriod && cacheSim22_AggregateMPlusPlus[idx].FastPeriod == fastPeriod && cacheSim22_AggregateMPlusPlus[idx].CurrentBarWeighting == currentBarWeighting && cacheSim22_AggregateMPlusPlus[idx].TrendWeighting == trendWeighting && cacheSim22_AggregateMPlusPlus[idx].EqualsInput(input))
						return cacheSim22_AggregateMPlusPlus[idx];
			return CacheIndicator<Sim22.Sim22_AggregateMPlusPlus>(new Sim22.Sim22_AggregateMPlusPlus(){ SlowPeriod = slowPeriod, FastPeriod = fastPeriod, CurrentBarWeighting = currentBarWeighting, TrendWeighting = trendWeighting }, input, ref cacheSim22_AggregateMPlusPlus);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			return indicator.Sim22_AggregateMPlusPlus(Input, slowPeriod, fastPeriod, currentBarWeighting, trendWeighting);
		}

		public Indicators.Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(ISeries<double> input , int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			return indicator.Sim22_AggregateMPlusPlus(input, slowPeriod, fastPeriod, currentBarWeighting, trendWeighting);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			return indicator.Sim22_AggregateMPlusPlus(Input, slowPeriod, fastPeriod, currentBarWeighting, trendWeighting);
		}

		public Indicators.Sim22.Sim22_AggregateMPlusPlus Sim22_AggregateMPlusPlus(ISeries<double> input , int slowPeriod, int fastPeriod, int currentBarWeighting, int trendWeighting)
		{
			return indicator.Sim22_AggregateMPlusPlus(input, slowPeriod, fastPeriod, currentBarWeighting, trendWeighting);
		}
	}
}

#endregion
