//###
//### Apply notes to your charts. Requires System.Design.dll and System.Drawing.Design.dll as references.
//###
//### User		Date 		Description
//### ------	-------- 	-------------
//### Gaston	Jun 2010 	Created
//### Gaston	Jan 2011 	Fixed location bug
//### Gaston	Feb 2011 	Added selectable locations, colors, and fonts
//### Brian		Jul 2016 	Moved to NT8, (maybe) simplified.
//###

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion


namespace NinjaTrader.NinjaScript.Indicators
{
	public class ChartNotes : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Display notes in the different corners of the chart.";
				Name										= "Chart Notes";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= true;
				IsSuspendedWhileInactive					= true;
				IsDataSeriesRequired						= false;
				
				trText		= tlText		= brText		= blText		= "";
				trColor		= tlColor		= brColor		= blColor		= Brushes.Black;
				trTextFont	= new Gui.Tools.SimpleFont() { Size = 14 };
				tlTextFont	= new Gui.Tools.SimpleFont() { Size = 14 };
				brTextFont	= new Gui.Tools.SimpleFont() { Size = 14 };
				blTextFont	= new Gui.Tools.SimpleFont() { Size = 14 };
			}
			else if (State == State.Realtime)
			{
				Draw.TextFixed(this, "topRight", trText, TextPosition.TopRight,    trColor, trTextFont, Brushes.Transparent, Brushes.Transparent, 0);
				Draw.TextFixed(this, "btmRight", brText, TextPosition.BottomRight, brColor, brTextFont, Brushes.Transparent, Brushes.Transparent, 0);
				Draw.TextFixed(this, "topLeft",  tlText, TextPosition.TopLeft,     tlColor, tlTextFont, Brushes.Transparent, Brushes.Transparent, 0);
				Draw.TextFixed(this, "btmLeft",  blText, TextPosition.BottomLeft,  blColor, blTextFont, Brushes.Transparent, Brushes.Transparent, 0);
			}
		}

		public override string DisplayName
		{ // Prevent long parameter list from been echo'd as part of the name
		  get { return this.Name;}
		}
		

		#region Properties_TopRight
		
		[Browsable(false)]
		public string trText
        { get; set; }
		
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Text", Description="Notes stored top right.", Order=1, GroupName="Notes Top Right")]
		[EditorAttribute("System.ComponentModel.Design.MultilineStringEditor, System.Design", "System.Drawing.Design.UITypeEditor")] 
		public string trTextDisplay
		{	// Cant get ENTER to work in multiline edit. Temporary work around by simply attaching empty lines and compressing it (dumm algoritm) afterwards.
			get { return trText + "\n\n\n\n\n"; } 
			set { trText = value; for(int idx=0; idx<10; idx++) trText = trText.Replace("\n\n", "\n"); }
		}

		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Color", Description="Text Color", Order=2, GroupName="Notes Top Right")]
		public Brush trColor
		{ get; set; }

		[Browsable(false)]
		public string trColorSerializable
		{
			get { return Serialize.BrushToString(trColor); }
			set { trColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font", Description = "Select font, style, size to display on chart.", GroupName = "Notes Top Right", Order = 3)]
		public SimpleFont trTextFont
		{ get; set; }

		#endregion

		#region Properties_TopLeft
		
		[Browsable(false)]
		public string tlText
        { get; set; }
		
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Text", Description="Notes stored top right.", Order=1, GroupName="Notes Top Left")]
		[EditorAttribute("System.ComponentModel.Design.MultilineStringEditor, System.Design", "System.Drawing.Design.UITypeEditor")] 
		public string tlTextDisplay
		{	// Cant get ENTER to work in multiline edit. Temporary work around by simply attaching empty lines and compressing it (dumm algoritm) afterwards.
			get { return tlText + "\n\n\n\n\n"; } 
			set { tlText = value; for(int idx=0; idx<10; idx++) tlText = tlText.Replace("\n\n", "\n"); }
		}

		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Color", Description="Text Color", Order=2, GroupName="Notes Top Left")]
		public Brush tlColor
		{ get; set; }

		[Browsable(false)]
		public string tlColorSerializable
		{
			get { return Serialize.BrushToString(tlColor); }
			set { tlColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font", Description = "Select font, style, size to display on chart.", GroupName = "Notes Top Left", Order = 3)]
		public SimpleFont tlTextFont
		{ get; set; }

		#endregion

		#region Properties_BottomRight
		
		[Browsable(false)]
		public string brText
        { get; set; }
		
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Text", Description="Notes stored Bottom right.", Order=1, GroupName="Notes Bottom Right")]
		[EditorAttribute("System.ComponentModel.Design.MultilinestringEditor, System.Design", "System.Drawing.Design.UITypeEditor")] 
		public string brTextDisplay
		{	// Cant get ENTER to work in multiline edit. Temporary work around by simply attaching empty lines and compressing it (dumm algoritm) afterwards.
			get { return brText + "\n\n\n\n\n"; } 
			set { brText = value; for(int idx=0; idx<10; idx++) brText = brText.Replace("\n\n", "\n"); }
		}

		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Color", Description="Text Color", Order=2, GroupName="Notes Bottom Right")]
		public Brush brColor
		{ get; set; }

		[Browsable(false)]
		public string brColorSerializable
		{
			get { return Serialize.BrushToString(brColor); }
			set { brColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font", Description = "Select font, style, size to display on chart.", GroupName = "Notes Bottom Right", Order = 3)]
		public SimpleFont brTextFont
		{ get; set; }

		#endregion

		#region Properties_BottomLeft
		
		[Browsable(false)]
		public string blText
        { get; set; }
		
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Text", Description="Notes stored Bottom right.", Order=1, GroupName="Notes Bottom Left")]
		[EditorAttribute("System.ComponentModel.Design.MultilinestringEditor, System.Design", "System.Drawing.Design.UITypeEditor")] 
		public string blTextDisplay
		{	// Cant get ENTER to work in multiline edit. Temporary work around by simply attaching empty lines and compressing it (dumm algoritm) afterwards.
			get { return blText + "\n\n\n\n\n"; } 
			set { blText = value; for(int idx=0; idx<10; idx++) blText = blText.Replace("\n\n", "\n"); }
		}

		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Color", Description="Text Color", Order=2, GroupName="Notes Bottom Left")]
		public Brush blColor
		{ get; set; }

		[Browsable(false)]
		public string blColorSerializable
		{
			get { return Serialize.BrushToString(blColor); }
			set { blColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font", Description = "Select font, style, size to display on chart.", GroupName = "Notes Bottom Left", Order = 3)]
		public SimpleFont blTextFont
		{ get; set; }

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ChartNotes[] cacheChartNotes;
		public ChartNotes ChartNotes(string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			return ChartNotes(Input, trTextDisplay, trColor, trTextFont, tlTextDisplay, tlColor, tlTextFont, brTextDisplay, brColor, brTextFont, blTextDisplay, blColor, blTextFont);
		}

		public ChartNotes ChartNotes(ISeries<double> input, string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			if (cacheChartNotes != null)
				for (int idx = 0; idx < cacheChartNotes.Length; idx++)
					if (cacheChartNotes[idx] != null && cacheChartNotes[idx].trTextDisplay == trTextDisplay && cacheChartNotes[idx].trColor == trColor && cacheChartNotes[idx].trTextFont == trTextFont && cacheChartNotes[idx].tlTextDisplay == tlTextDisplay && cacheChartNotes[idx].tlColor == tlColor && cacheChartNotes[idx].tlTextFont == tlTextFont && cacheChartNotes[idx].brTextDisplay == brTextDisplay && cacheChartNotes[idx].brColor == brColor && cacheChartNotes[idx].brTextFont == brTextFont && cacheChartNotes[idx].blTextDisplay == blTextDisplay && cacheChartNotes[idx].blColor == blColor && cacheChartNotes[idx].blTextFont == blTextFont && cacheChartNotes[idx].EqualsInput(input))
						return cacheChartNotes[idx];
			return CacheIndicator<ChartNotes>(new ChartNotes(){ trTextDisplay = trTextDisplay, trColor = trColor, trTextFont = trTextFont, tlTextDisplay = tlTextDisplay, tlColor = tlColor, tlTextFont = tlTextFont, brTextDisplay = brTextDisplay, brColor = brColor, brTextFont = brTextFont, blTextDisplay = blTextDisplay, blColor = blColor, blTextFont = blTextFont }, input, ref cacheChartNotes);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ChartNotes ChartNotes(string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			return indicator.ChartNotes(Input, trTextDisplay, trColor, trTextFont, tlTextDisplay, tlColor, tlTextFont, brTextDisplay, brColor, brTextFont, blTextDisplay, blColor, blTextFont);
		}

		public Indicators.ChartNotes ChartNotes(ISeries<double> input , string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			return indicator.ChartNotes(input, trTextDisplay, trColor, trTextFont, tlTextDisplay, tlColor, tlTextFont, brTextDisplay, brColor, brTextFont, blTextDisplay, blColor, blTextFont);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ChartNotes ChartNotes(string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			return indicator.ChartNotes(Input, trTextDisplay, trColor, trTextFont, tlTextDisplay, tlColor, tlTextFont, brTextDisplay, brColor, brTextFont, blTextDisplay, blColor, blTextFont);
		}

		public Indicators.ChartNotes ChartNotes(ISeries<double> input , string trTextDisplay, Brush trColor, SimpleFont trTextFont, string tlTextDisplay, Brush tlColor, SimpleFont tlTextFont, string brTextDisplay, Brush brColor, SimpleFont brTextFont, string blTextDisplay, Brush blColor, SimpleFont blTextFont)
		{
			return indicator.ChartNotes(input, trTextDisplay, trColor, trTextFont, tlTextDisplay, tlColor, tlTextFont, brTextDisplay, brColor, brTextFont, blTextDisplay, blColor, blTextFont);
		}
	}
}

#endregion
