// 
// Copyright (C) 2007, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// Add this to your declarations to use StreamWriter and StreamReader
using System.IO;

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Sample indicator demonstrating the use of System.IO's File.AppendAllText and File.ReadAllText methods.
    /// </summary>
    [Description("Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.")]
    public class SampleFileReadWrite : Indicator
    {
        #region Variables
		private int		date				= 0;
		private double	currentOpen			= 0;
		private double	currentHigh			= 0;
		private double	currentLow			= 0;
		private double	currentClose		= 0;
		private bool	currentOpenSaved 	= false;
		private bool	currentLowSaved		= false;
		
		// This sets the path in which the text file will be created.
		private string	path				= Cbi.Core.UserDataDir.ToString() + "SampleFileReadWrite-MyTestFile.txt";
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            CalculateOnBarClose	= true;
            Overlay				= false;
            PriceTypeSupported	= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			// This is the output string that is written to the text file. 'Environment.NewLine' feeds the file to a new line for further writing.
			string ohlc = ToDay(Time[0]) + " " + Open[0] + " " + High[0] + " " + Low[0] + " " + Close[0] + Environment.NewLine;
			
			/* Creates the text file at the location determined in 'path' and puts the line 'ohlc' in.
			If file already exists it will append the line 'ohlc' onto the end. */
			File.AppendAllText(path, ohlc);
			
			// Prevents the NinjaScript from reading the file unless it is on a real-time bar
			if (Historical)
				return;
			
			// Checks to see if the file exists
			else if (File.Exists(path))
			{
				// Opens the text file and reads all lines into a string. It will then close the file.
				string readText = File.ReadAllText(path);
				
				/* Splits the line at every white space and new line. Places each split into the string array.
				' ' represents a space, '\r' represents carriage returns, '\n' represents line feeds */
				string [] split = readText.Split(new Char [] {' ', '\r', '\n'});
				
				// Creates a counter that will mark which string from the split array we are dealing with
				int splitCounter = 0;
				
				// For every string inside the newly created string array...
				foreach (string s in split)
				{
					// Ignores strings that are null (e.g. the strings created from the new lines)
					if (s.Trim() != "")
					{
						splitCounter++;
						
						// First string = Date of the OHLC data on the following 4 strings
						if (splitCounter == 1)
							date = int.Parse(s);
						
						// Check if the date of the data from file is the same as the date of the current bar
						if (ToDay(Time[0]) == date)
						{
							// Saves the first Open value of the current date
							if (splitCounter == 2 && currentOpenSaved == false)
							{
								currentOpen = double.Parse(s);
								
								// Unnecessary to save any other Open value's because they aren't the Open for the current date
								currentOpenSaved = true;
							}
							
							// Saves the High value of the current date. Overwrites old values if new value is higher
							else if (splitCounter == 3 && double.Parse(s) > currentHigh)
								currentHigh = double.Parse(s);
	
							// Saves the Low value of the current date
							else if (splitCounter == 4)
							{
								// Overwrites old values if new value is lower
								if (double.Parse(s) < currentLow)
									currentLow = double.Parse(s);
								
								// Initializes the first Low value because currentLow is defaulted at 0 and nothing will be lower than that
								else if (currentLowSaved == false)
								{
									currentLow = double.Parse(s);
									currentLowSaved = true;
								}
							}
							
							// Saves the Close value of the current date.
							else if (splitCounter == 5)
								currentClose = double.Parse(s);
						}
						
						// Resets the split counter for the next line read from the file
						if (splitCounter == 5)
							splitCounter = 0;
					}
				}
				
				// Print to the Output Window the day's OHLC as calculated from the text file
				Print("Current Day OHLC: " + currentOpen + " " + currentHigh + " " + currentLow + " " + currentClose);
			}
        }

        #region Properties

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private SampleFileReadWrite[] cacheSampleFileReadWrite = null;

        private static SampleFileReadWrite checkSampleFileReadWrite = new SampleFileReadWrite();

        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        public SampleFileReadWrite SampleFileReadWrite()
        {
            return SampleFileReadWrite(Input);
        }

        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        public SampleFileReadWrite SampleFileReadWrite(Data.IDataSeries input)
        {

            if (cacheSampleFileReadWrite != null)
                for (int idx = 0; idx < cacheSampleFileReadWrite.Length; idx++)
                    if (cacheSampleFileReadWrite[idx].EqualsInput(input))
                        return cacheSampleFileReadWrite[idx];

            SampleFileReadWrite indicator = new SampleFileReadWrite();
            indicator.SetUp();
            indicator.BarsRequired = BarsRequired;
            indicator.CalculateOnBarClose = CalculateOnBarClose;
            indicator.Input = input;

            SampleFileReadWrite[] tmp = new SampleFileReadWrite[cacheSampleFileReadWrite == null ? 1 : cacheSampleFileReadWrite.Length + 1];
            if (cacheSampleFileReadWrite != null)
                cacheSampleFileReadWrite.CopyTo(tmp, 0);
            tmp[tmp.Length - 1] = indicator;
            cacheSampleFileReadWrite = tmp;
            Indicators.Add(indicator);

            return indicator;
        }

    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.SampleFileReadWrite SampleFileReadWrite()
        {
            return _indicator.SampleFileReadWrite(Input);
        }

        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        public Indicator.SampleFileReadWrite SampleFileReadWrite(Data.IDataSeries input)
        {
            return _indicator.SampleFileReadWrite(input);
        }

    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.SampleFileReadWrite SampleFileReadWrite()
        {
            return _indicator.SampleFileReadWrite(Input);
        }

        /// <summary>
        /// Sample indicator demonstrating the use o System.IO's File.AppendAllText and File.ReadAllText methods.
        /// </summary>
        /// <returns></returns>
        public Indicator.SampleFileReadWrite SampleFileReadWrite(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.SampleFileReadWrite(input);
        }

    }
}
#endregion
