#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;

using SharpDX.DirectWrite;
using NinjaTrader.Core;
#endregion

namespace NinjaTrader.NinjaScript.DrawingTools
{
	[EditorBrowsable(EditorBrowsableState.Always)]
	public class HorizontalRay : DrawingTool
	{
		protected enum ChartLineType
		{
			HorizontalRay,
		}

		[CLSCompliant(false)]
		protected SharpDX.Direct2D1.PathGeometry	ArrowPathGeometry;
		private const double						cursorSensitivity		= 15;
		private	ChartAnchor							editingAnchor;

		public override IEnumerable<ChartAnchor> Anchors { get { return new[] { StartAnchor }; } }

		[Display(Order = 1)]
		public ChartAnchor StartAnchor { get; set; }
		[Display(Order = 2)]
		public ChartAnchor	EndAnchor		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		protected ChartLineType LineType { get; set; }

		[Display(ResourceType=typeof(Custom.Resource), GroupName = "NinjaScriptGeneral", Name = "NinjaScriptDrawingToolHorizontalRay", Order = 99)]
		public Stroke		Stroke			{ get; set; }

		public override bool SupportsAlerts { get { return true; } }
		
		public override void OnCalculateMinMax()
		{
			MinValue = double.MaxValue;
			MaxValue = double.MinValue;

			if (!IsVisible)
				return;

			// make sure to set good min/max values on single click lines as well, in case anchor left in editing
			MinValue = MaxValue = Anchors.First().Price;
		}

		public override Cursor GetCursor(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, Point point)
		{
			switch (DrawingState)
			{
				case DrawingState.Building:	return Cursors.Pen;
				case DrawingState.Moving:	return IsLocked ? Cursors.No : Cursors.SizeAll;
				case DrawingState.Editing:
					if (IsLocked)
						return Cursors.No;
					return Cursors.SizeAll;
				default:
					// draw move cursor if cursor is near line path anywhere
					Point startPoint = StartAnchor.GetPoint(chartControl, chartPanel, chartScale);

					// just go by single axis since we know the entire lines position
					if (Math.Abs(point.Y - startPoint.Y) <= cursorSensitivity && point.X >= startPoint.X)
						return IsLocked ? Cursors.Arrow : Cursors.SizeAll;
					return null;
			}
		}

		private static SharpDX.Direct2D1.StrokeStyle GetStrokeStyle(Stroke stroke)
		{
			Tuple<SharpDX.Direct2D1.DashStyle, float[]> dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Solid, new float[0]);

			switch (stroke.DashStyleDX)
			{
				case SharpDX.Direct2D1.DashStyle.Dash:
					dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Custom, new float[] { 6, 6 });
					break;
				case SharpDX.Direct2D1.DashStyle.DashDot:
					dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Custom, new float[] { 6, 6, 0, 6 });
					break;
				case SharpDX.Direct2D1.DashStyle.DashDotDot:
					dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Custom, new float[] { 6, 6, 0, 6, 0, 6 });
					break;
				case SharpDX.Direct2D1.DashStyle.Dot:
					dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Dot, new float[0]);
					break;
				case SharpDX.Direct2D1.DashStyle.Solid:
					dashStyle = new Tuple<SharpDX.Direct2D1.DashStyle, float[]>(SharpDX.Direct2D1.DashStyle.Solid, new float[0]);
					break;
			}

			SharpDX.Direct2D1.StrokeStyle strokeStyle = new SharpDX.Direct2D1.StrokeStyle(Core.Globals.D2DFactory, new SharpDX.Direct2D1.StrokeStyleProperties
			{
				DashStyle	= dashStyle.Item1,
				DashCap		= SharpDX.Direct2D1.CapStyle.Square,
				DashOffset	= 0,
				EndCap		= SharpDX.Direct2D1.CapStyle.Flat,
				LineJoin	= SharpDX.Direct2D1.LineJoin.MiterOrBevel,
				MiterLimit	= 2,
				StartCap	= SharpDX.Direct2D1.CapStyle.Flat
			}, dashStyle.Item2);
			return strokeStyle;
		}

		public override IEnumerable<AlertConditionItem> GetAlertConditionItems()
		{
			yield return new AlertConditionItem 
			{
				Name = @"HorizontalRay",
				ShouldOnlyDisplayName = true,
			};
		}
		
		public sealed override Point[] GetSelectionPoints(ChartControl chartControl, ChartScale chartScale)
		{
			ChartPanel	chartPanel	= chartControl.ChartPanels[chartScale.PanelIndex];
			Point		startPoint	= StartAnchor.GetPoint(chartControl, chartPanel, chartScale);
			Point		endPoint	= EndAnchor.GetPoint(chartControl, chartPanel, chartScale);

			int			totalWidth	= chartPanel.W + chartPanel.X;
			int			totalHeight	= chartPanel.Y + chartPanel.H;
			
			//return new[] { new Point(startPoint.X, startPoint.Y), new Point(totalWidth / 2d, startPoint.Y), new Point(totalWidth, startPoint.Y) };
			return new[] { new Point(startPoint.X, startPoint.Y)};
		}

		public override bool IsAlertConditionTrue(AlertConditionItem conditionItem, Condition condition, ChartAlertValue[] values, ChartControl chartControl, ChartScale chartScale)
		{
			if (values.Length < 1)
				return false;
			ChartPanel chartPanel = chartControl.ChartPanels[PanelIndex];
			// h line has much more simple alert handling
			double barVal	= values[0].Value;
			double lineVal	= conditionItem.Offset.Calculate(StartAnchor.Price, AttachedTo.Instrument);

			switch (condition)
			{
				case Condition.Equals:			return barVal == lineVal;
				case Condition.NotEqual:		return barVal != lineVal;
				case Condition.Greater:			return barVal > lineVal;
				case Condition.GreaterEqual:	return barVal >= lineVal;
				case Condition.Less:			return barVal < lineVal;
				case Condition.LessEqual:		return barVal <= lineVal;
				case Condition.CrossAbove:
				case Condition.CrossBelow:
					Predicate<ChartAlertValue> predicate = v =>
					{
						if (condition == Condition.CrossAbove)
							return v.Value > lineVal;
						return v.Value < lineVal;
					};
					return MathHelper.DidPredicateCross(values, predicate);
			}
			return false;
		}

		public override bool IsVisibleOnChart(ChartControl chartControl, ChartScale chartScale, DateTime firstTimeOnChart, DateTime lastTimeOnChart)
		{
			if (DrawingState == DrawingState.Building)
				return true;

			DateTime	minTime = Core.Globals.MaxDate;
			DateTime	maxTime = Core.Globals.MinDate;

			//if (LineType != ChartLineType.ExtendedLine && LineType != ChartLineType.Ray)
			//{
				// make sure our 1 anchor is in time frame 
				//if (LineType == ChartLineType.VerticalLine)
					//return StartAnchor.Time >= firstTimeOnChart && StartAnchor.Time <= lastTimeOnChart;

				// check at least one of our anchors is in horizontal time frame
				foreach (ChartAnchor anchor in Anchors)
				{
					if (anchor.Time < minTime)
						minTime = anchor.Time;
					if (anchor.Time > maxTime)
						maxTime = anchor.Time;
				}
			//}

			// check offscreen vertically. make sure to check the line doesnt cut through the scale, so check both are out
			if ((StartAnchor.Price < chartScale.MinValue || StartAnchor.Price > chartScale.MaxValue) && !IsAutoScale)
				return false; // horizontal line only has one anchor to whiff

			return true;
		}

		public override void OnMouseDown(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			switch (DrawingState)
			{
				case DrawingState.Building:
					if (StartAnchor.IsEditing)
					{
						dataPoint.CopyDataValues(StartAnchor);
						StartAnchor.IsEditing = false;

						// these lines only need one anchor, so stop editing end anchor too
						EndAnchor.IsEditing = false;

						// give end anchor something to start with so we dont try to render it with bad values right away
						dataPoint.CopyDataValues(EndAnchor);
					}
					else if (EndAnchor.IsEditing)
					{
						dataPoint.CopyDataValues(EndAnchor);
						EndAnchor.IsEditing = false;
					}
					
					// is initial building done (both anchors set)
					if (!StartAnchor.IsEditing && !EndAnchor.IsEditing)
					{
						DrawingState = DrawingState.Normal;
						IsSelected = false;
					}
					break;
				case DrawingState.Normal:
					Point point = dataPoint.GetPoint(chartControl, chartPanel, chartScale);
					// see if they clicked near a point to edit, if so start editing
					if (GetCursor(chartControl, chartPanel, chartScale, point) == null)
						IsSelected = false; 
					else
					{
						// we dont care here, since we're moving just one anchor
						editingAnchor = StartAnchor;
					}

					if (editingAnchor != null)
					{
						editingAnchor.IsEditing = true;
						DrawingState = DrawingState.Editing;
					}
					else
					{
						if (GetCursor(chartControl, chartPanel, chartScale, point) != null)
							DrawingState = DrawingState.Moving;
						else
						// user whiffed.
							IsSelected = false;
					}
					break;
			}
		}

		public override void OnMouseMove(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			if (IsLocked && DrawingState != DrawingState.Building)
				return;

			if (DrawingState == DrawingState.Building)
			{
				// start anchor will not be editing here because we start building as soon as user clicks, which
				// plops down a start anchor right away
				if (EndAnchor.IsEditing)
					dataPoint.CopyDataValues(EndAnchor);
			}
			else if (DrawingState == DrawingState.Editing && editingAnchor != null)
			{
				// horizontal line only needs Y value updated
				editingAnchor.Price = dataPoint.Price;
				editingAnchor.Time = dataPoint.Time;

			}
			else if (DrawingState == DrawingState.Moving)
				foreach (ChartAnchor anchor in Anchors)
					// only move anchor values as needed depending on line type
					anchor.MoveAnchorPrice(InitialMouseDownAnchor, dataPoint, chartControl, chartPanel, chartScale, this);
		}

		public override void OnMouseUp(ChartControl chartControl, ChartPanel chartPanel, ChartScale chartScale, ChartAnchor dataPoint)
		{
			// simply end whatever moving
			if (DrawingState == DrawingState.Moving || DrawingState == DrawingState.Editing)
				DrawingState = DrawingState.Normal;
			if (editingAnchor != null)
				editingAnchor.IsEditing = false;
			editingAnchor = null;
		}

		public override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Stroke == null)
				return;
			Stroke.RenderTarget			= RenderTarget;

			// first of all, turn on anti-aliasing to smooth out our line
			RenderTarget.AntialiasMode	= SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
			ChartPanel	panel			= chartControl.ChartPanels[chartScale.PanelIndex];
			Point		startPoint		= StartAnchor.GetPoint(chartControl, panel, chartScale);

			// align to full pixel to avoid unneeded aliasing
			double		strokePixAdj	=	((double)(Stroke.Width % 2)).ApproxCompare(0) == 0 ? 0.5d : 0d;
			Vector		pixelAdjustVec	= new Vector(strokePixAdj, strokePixAdj);
			
			Point startAdj	= new Point(startPoint.X, startPoint.Y);
			Point endAdj	= new Point(panel.X + panel.W, startPoint.Y);
			RenderTarget.DrawLine(startAdj.ToVector2(), endAdj.ToVector2(), Stroke.BrushDX, Stroke.Width, GetStrokeStyle(Stroke));
			
			//draw price label
			if(startPoint.X < panel.W){
				TextFormat	textFormat = chartControl.Properties.LabelFont.ToDirectWriteTextFormat();
				string label = chartControl.Instrument.MasterInstrument.FormatPrice(StartAnchor.Price, false);
				TextLayout textLayout = new TextLayout(Globals.DirectWriteFactory, label, textFormat, 999, textFormat.FontSize);
				Point labelAnchor = new Point(panel.W - textLayout.DetermineMinWidth(), startPoint.Y);
				RenderTarget.DrawTextLayout(labelAnchor.ToVector2(), textLayout, Stroke.BrushDX);
				textLayout.Dispose();
			}
		}
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name						= @"Horizontal Ray";
				LineType					= ChartLineType.HorizontalRay;
				DrawingState				= DrawingState.Building;
				StartAnchor					= new ChartAnchor { IsEditing = true, DrawingTool = this };
				EndAnchor					= new ChartAnchor { IsEditing = true, DrawingTool = this };
				StartAnchor.DisplayName		= Custom.Resource.NinjaScriptDrawingToolAnchorStart;
				EndAnchor.DisplayName		= Custom.Resource.NinjaScriptDrawingToolAnchorEnd;
				// a normal line with both end points has two anchors
				StartAnchor.IsBrowsable		= true;
				EndAnchor.IsBrowsable		= true;
				Stroke						= new Stroke(Brushes.CornflowerBlue, 2f);
				//Name								= Custom.Resource.NinjaScriptDrawingToolHorizontalLine;
				//LineType							= ChartLineType.HorizontalRay;
				StartAnchor.DisplayName				= Custom.Resource.NinjaScriptDrawingToolAnchor;
				StartAnchor.IsXPropertiesVisible	= false;
				EndAnchor.IsBrowsable				= false;
			}
			else if (State == State.Terminated)
			{
				// release any device resources
				Dispose();
			}
		}
//		protected override void OnStateChange()
//		{
//			base.OnStateChange();
//			if (State == State.SetDefaults)
//			{
//				Name								= Custom.Resource.NinjaScriptDrawingToolHorizontalLine;
//				LineType							= ChartLineType.HorizontalLine;
//				StartAnchor.DisplayName				= Custom.Resource.NinjaScriptDrawingToolAnchor;
//				StartAnchor.IsXPropertiesVisible	= false;
//				EndAnchor.IsBrowsable				= false;
//			}
//		}
	}


}
