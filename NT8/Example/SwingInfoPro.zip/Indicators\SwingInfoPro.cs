#region Using declarations
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
//using System.Windows.Forms;
using System.Xml.Serialization;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.IO;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class SwingInfoPro : Indicator
	{
        private Point mousePosition;
		
		private Chart chartWindow                                = null;
		private System.Windows.Controls.Label myToolBarSwingInfo = null;
		private bool IsToolBarLabelAdded;
		private DependencyObject searchObject;
		private string theMenuAutomationID;
		private bool showSwingInfo                               = true;
		private bool displayIndicatorName                        = false;
		private SimpleFont swinginfoFont;

		// OnStateChange
		//
		protected override void OnStateChange()
		{
			if(State == State.SetDefaults)
			{
				Description					= @"";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= false;
				DrawOnPricePanel			= true;
				PaintPriceMarkers			= true;
				ScaleJustification			= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive	= true;
				
				swinginfoColor		        = Brushes.LightGray;
				swinginfoFont	            = new Gui.Tools.SimpleFont("Tahoma New", 12) { Size = 12, Bold = false };
			}
			
		    else if (State == State.DataLoaded)
			{
				if( this.ChartPanel != null )
				this.ChartPanel.MouseMove += new MouseEventHandler(this.OnMouseMove);
				
		    if (displayIndicatorName)	
		        {
				Name = "SwingInfoPro V1";
		        }
				else
				{
				Name = "";	
				}
					
			}

			else if(State == State.Configure)
			{

			} 
			else if(State == State.Historical)
		    {
				if (ChartControl != null && !IsToolBarLabelAdded && showSwingInfo == true)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
					addSwingInfoToToolbar();
					}));
				}	
			}
			
		    else if(State == State.Terminated)
		    {
				disposeCleanUp();
	
			    if( this.ChartPanel != null )
			    this.ChartPanel.MouseMove -= new MouseEventHandler(this.OnMouseMove);
		    }
		 }
		
	     internal void OnMouseMove(object sender, MouseEventArgs e)
    	 {
			 if(showSwingInfo == true)
			 {
			 Bars bars = ChartBars.Bars;
			 
			 this.mousePosition = e.GetPosition( this.ChartPanel );
			 this.ChartControl.InvalidateVisual();	
			 //e.Handled = true;
			 
			 int		X = (int)mousePosition.X;
			 float	Y = (float)mousePosition.Y;

			 DateTime cursorDateTime = ChartControl.GetTimeByX(X);
			 TimeSpan barTimeLeft = Bars.GetTime(Bars.Count - 1).Subtract(cursorDateTime);
				 
			 double	cursorPrice = ChartPanel.Scales[ChartPanel.PanelIndex].GetValueByY(Y);
			 double closeValue = bars.GetClose(bars.Count - 1);
 	 
			 string CurrentSwingTime =	 (barTimeLeft.Ticks < 0 ? "00:00:00" :  barTimeLeft.Hours.ToString("00") + ":" + barTimeLeft.Minutes.ToString("00") + ":" + barTimeLeft.Seconds.ToString("00"));
			 string SwingTick = Math.Abs(Instrument.MasterInstrument.RoundToTickSize((cursorPrice - closeValue)/TickSize)).ToString("0");

		     myToolBarSwingInfo.Content = "SWG TMR: " + CurrentSwingTime + "\n" + "SWG TCK: " + SwingTick;
				 	 
			 }
		}
		
		 private void OnTimedEvent(Object source, EventArgs e)
        {
			DateTime currentTime = DateTime.Now;
	
		}
		
		protected override void OnBarUpdate()
		{
		}

		private void addSwingInfoToToolbar()
	    {	 
	          //Obtain the Chart on which the indicator is configured
	          chartWindow = Window.GetWindow(this.ChartControl.Parent) as Chart;
			
			  chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
			
	          if (chartWindow == null)
	          {
	              Print("chartWindow == null");
	              return;
	          }
			  
			 theMenuAutomationID = string.Format("SwingInfoProToolbar{0}", DateTime.Now.ToString("yyMMddhhmmss"));

			 foreach (System.Windows.DependencyObject item in chartWindow.MainMenu)
				if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == theMenuAutomationID)
					return;
	 
	          // Create a style to apply to the label
	          Style s = new Style();
	          s.TargetType = typeof(System.Windows.Controls.Label);
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontSizeProperty, 10.0));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.BackgroundProperty, Brushes.Transparent));
			  s.Setters.Add(new Setter(System.Windows.Controls.Label.ForegroundProperty, swinginfoColor));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontFamilyProperty, new FontFamily("Tahoma")));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontWeightProperty, FontWeights.Regular));
	 
	          // Instantiate the label
	          myToolBarSwingInfo = new System.Windows.Controls.Label();

	          //Set label Style             
	          myToolBarSwingInfo.Style = s;
				
		      System.Windows.Automation.AutomationProperties.SetAutomationId(myToolBarSwingInfo, theMenuAutomationID);
			  
			  myToolBarSwingInfo.Content = "SWG TMR: 00:00:00" + "\n" + "SWG TCK: 00";
				
			  //Override Font Style 
			  swinginfoFont.ApplyTo(myToolBarSwingInfo);
	          
			  myToolBarSwingInfo.IsEnabled = true;
	 
	          // Add the label to the Chart's Toolbar
	          chartWindow.MainMenu.Add(myToolBarSwingInfo);

	          //Prevent the Label From Displaying when WorkSpace Opens if it is not in an active tab
	          myToolBarSwingInfo.Visibility = Visibility.Collapsed;
			  
	          foreach (TabItem tab in this.chartWindow.MainTabControl.Items)
	          {
	              if ((tab.Content as ChartTab).ChartControl == this.ChartControl
	                   && tab == this.chartWindow.MainTabControl.SelectedItem)
	              {
	                  myToolBarSwingInfo.Visibility = Visibility.Visible;
	              }  
	          }
	          IsToolBarLabelAdded = true;
	  }
		
	    private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{	
			if (e.AddedItems.Count <= 0)
				return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab; 
			if (temp != null)
			{
				if (myToolBarSwingInfo != null)
					myToolBarSwingInfo.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
			}
		}

		private void disposeCleanUp()
		{
			if(chartWindow != null)
			{
				try
        		{
					if (ChartControl == null) return;
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						//Label Null Check
		              	if (myToolBarSwingInfo != null)
		              	{
		                  //Remove Label from Indicator's Chart ToolBar
		                  chartWindow.MainMenu.Remove(myToolBarSwingInfo);

		              	}
						
					}));
				}
				catch(Exception e)
		        {
		            //Print("TT: "+e.ToString());
		        }
			}
		}
		
		#region Properties
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Font Color", Description="Text Color", Order=1, GroupName="Swing Info Settings")]
		public Brush swinginfoColor
		{ get; set; }

		[Browsable(false)]
		public string trColorSerializable
		{
			get { return Serialize.BrushToString(swinginfoColor); }
			set { swinginfoColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font Select", Description = "Select font, style, size to display on chart.", GroupName = "Swing Info Settings", Order = 2)]
		public SimpleFont SwingInfoFont
	    {
			get{return swinginfoFont;}
			set{swinginfoFont = value;}
		}
		
		[NinjaScriptProperty]
		[Display(Name="Show Swing Info", Description="True will show Swing Info", Order=5, GroupName="Swing Info Settings")]
        public bool ShowSwingInfo
        {
            get { return showSwingInfo; }
			set { showSwingInfo = value; }
        }

		[Description("Display Indicator Name On Chart")]
        [Display(Name="Display Indicator Name", Description="Display Indicator Name On Chart", Order=1, GroupName="Indicator Name")]
		public bool DisplayIndicatorName
		{
			get{ return displayIndicatorName;}
			set{displayIndicatorName = value;}
		}

		#endregion
	}

}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SwingInfoPro[] cacheSwingInfoPro;
		public SwingInfoPro SwingInfoPro(Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			return SwingInfoPro(Input, swinginfoColor, swingInfoFont, showSwingInfo);
		}

		public SwingInfoPro SwingInfoPro(ISeries<double> input, Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			if (cacheSwingInfoPro != null)
				for (int idx = 0; idx < cacheSwingInfoPro.Length; idx++)
					if (cacheSwingInfoPro[idx] != null && cacheSwingInfoPro[idx].swinginfoColor == swinginfoColor && cacheSwingInfoPro[idx].SwingInfoFont == swingInfoFont && cacheSwingInfoPro[idx].ShowSwingInfo == showSwingInfo && cacheSwingInfoPro[idx].EqualsInput(input))
						return cacheSwingInfoPro[idx];
			return CacheIndicator<SwingInfoPro>(new SwingInfoPro(){ swinginfoColor = swinginfoColor, SwingInfoFont = swingInfoFont, ShowSwingInfo = showSwingInfo }, input, ref cacheSwingInfoPro);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SwingInfoPro SwingInfoPro(Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			return indicator.SwingInfoPro(Input, swinginfoColor, swingInfoFont, showSwingInfo);
		}

		public Indicators.SwingInfoPro SwingInfoPro(ISeries<double> input , Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			return indicator.SwingInfoPro(input, swinginfoColor, swingInfoFont, showSwingInfo);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SwingInfoPro SwingInfoPro(Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			return indicator.SwingInfoPro(Input, swinginfoColor, swingInfoFont, showSwingInfo);
		}

		public Indicators.SwingInfoPro SwingInfoPro(ISeries<double> input , Brush swinginfoColor, SimpleFont swingInfoFont, bool showSwingInfo)
		{
			return indicator.SwingInfoPro(input, swinginfoColor, swingInfoFont, showSwingInfo);
		}
	}
}

#endregion
