#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class FractalPivots : Indicator
	{
		#region Variables
		private int period		= 30;
		private int barcounter = 0;
		private int markersize = 15;
		private Brush upcolor = Brushes.Red;
		private Brush downcolor = Brushes.Green;
		private	SimpleFont		textFont;
		private	SimpleFont		textFont1;
		private int y ;
		private int Lvls ;
		private double highval = 0;
		private double lowval = 0;
        #endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "FractalPivots";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar == 0)
			{
				textFont = new SimpleFont("Wingdings 3",markersize);
				textFont1 = new SimpleFont("Wingdings",markersize / 3);
			}
			if(IsFirstTickOfBar)
				barcounter++;
			try
			{
				isHighPivot(Period,upcolor);
				isLowPivot(Period,downcolor);
				Draw.Text(this, "High Line" + CurrentBar,false, "n", Period - 1, highval,0, upcolor, textFont1, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 5);
				Draw.Text(this, "Low Line" + CurrentBar, false, "n", Period - 1, lowval,0, downcolor, textFont1, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 5);
			
			}
			catch (Exception ex)
			{}
		}
		
		private void isHighPivot(int period, Brush color)
		{
			#region HighPivot
			y = 0;
			Lvls = 0;
			
			//Four Matching Highs
			if(High[period]==High[period+1] && High[period]==High[period+2] && High[period]==High[period+3])
			{
				y = 1;
				while(y<=period)
				{
					if(y!=period ? High[period+3]>High[period+3+y] : High[period+3]>High[period+3+y])
						Lvls++;
					if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
						Lvls++;
					y++;
				}
			}
			//Three Matching Highs
			else if(High[period]==High[period+1] && High[period]==High[period+2])
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? High[period+2]>High[period+2+y] : High[period+2]>High[period+2+y])
						Lvls++;
					if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
						Lvls++;
					y++;
				}
			}
			//Two Matching Highs
			else if(High[period]==High[period+1])
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? High[period+1]>High[period+1+y] : High[period+1]>High[period+1+y])
						Lvls++;
					if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
						Lvls++;
					y++;
				}
			}
			//Regular Pivot
			else
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? High[period]>High[period+y] : High[period]>High[period+y])
						Lvls++;
					if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
						Lvls++;
					y++;
				}
			}
			
			//Auxiliary Checks
			if(Lvls<period*2)
			{
				Lvls=0;
				//Four Highs - First and Last Matching - Middle 2 are lower
				if(High[period]>=High[period+1] && High[period]>=High[period+2] && High[period]==High[period+3])
				{
					y=1;
					while(y<=period)
					{
						if(y!=period ? High[period+3]>High[period+3+y] : High[period+3]>High[period+3+y])
							Lvls++;
						if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
							Lvls++;
						y++;
					}
				}
			}
			if(Lvls<period*2)
			{
				Lvls=0;
				//Three Highs - Middle is lower than two outside
				if(High[period]>=High[period+1] && High[period]==High[period+2])
				{
					y=1;
					while(y<=period)
					{
						if(y!=period ? High[period+2]>High[period+2+y] : High[period+2]>High[period+2+y])
						Lvls++;
					if(y!=period ? High[period]>High[period-y] : High[period]>High[period-y])
						Lvls++;
					y++;
					}
				}
			}
			if(Lvls>=period*2)
			{
				Draw.Text(this,"High"+barcounter.ToString(),false,"‡",period,High[period]+TickSize,0,color, textFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
				highval = High[period]+TickSize;
			}
			#endregion
		}

		private void isLowPivot(int period, Brush color)
		{
			#region LowPivot
			y = 0;
			Lvls = 0;
			
			//Four Matching Lows
			if(Low[period]==Low[period+1] && Low[period]==Low[period+2] && Low[period]==Low[period+3])
			{
				y = 1;
				while(y<=period)
				{
					if(y!=period ? Low[period+3]<Low[period+3+y] : Low[period+3]<Low[period+3+y])
						Lvls++;
					if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
						Lvls++;
					y++;
				}
			}
			//Three Matching Lows
			else if(Low[period]==Low[period+1] && Low[period]==Low[period+2])
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? Low[period+2]<Low[period+2+y] : Low[period+2]<Low[period+2+y])
						Lvls++;
					if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
						Lvls++;
					y++;
				}
			}
			//Two Matching Lows
			else if(Low[period]==Low[period+1])
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? Low[period+1]<Low[period+1+y] : Low[period+1]<Low[period+1+y])
						Lvls++;
					if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
						Lvls++;
					y++;
				}
			}
			//Regular Pivot
			else
			{
				y=1;
				while(y<=period)
				{
					if(y!=period ? Low[period]<Low[period+y] : Low[period]<Low[period+y])
						Lvls++;
					if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
						Lvls++;
					y++;
				}
			}
			
			//Auxiliary Checks
			if(Lvls<period*2)
			{
				Lvls=0;
				//Four Lows - First and Last Matching - Middle 2 are lower
				if(Low[period]<=Low[period+1] && Low[period]<=Low[period+2] && Low[period]==Low[period+3])
				{
					y=1;
					while(y<=period)
					{
						if(y!=period ? Low[period+3]<Low[period+3+y] : Low[period+3]<Low[period+3+y])
							Lvls++;
						if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
							Lvls++;
						y++;
					}
				}
			}
			if(Lvls<period*2)
			{
				Lvls=0;
				//Three Lows - Middle is lower than two outside
				if(Low[period]<=Low[period+1] && Low[period]==Low[period+2])
				{
					y=1;
					while(y<=period)
					{
						if(y!=period ? Low[period+2]<Low[period+2+y] : Low[period+2]<Low[period+2+y])
						Lvls++;
					if(y!=period ? Low[period]<Low[period-y] : Low[period]<Low[period-y])
						Lvls++;
					y++;
					}
				}
			}
			if(Lvls>=period*2)
			{
				Draw.Text(this,"Low"+barcounter.ToString(),false,"ˆ",period,Low[period]-TickSize,0,color, textFont, TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
				lowval = Low[period]-TickSize;
			}
			#endregion
		}

		 #region Properties
		[NinjaScriptProperty]
		[Description("Period")]
		[Category("Parameters")]
		[DisplayName("Period")]
		public int Period
		{
			get { return period; }
			set { period = Math.Max(1,value); }
		}
		
		[NinjaScriptProperty]
		[Description("Marker Size")]
		[Category("Visual")]
		[DisplayName("Marker Size")]
		public int MarkerSize
		{
			get { return markersize; }
			set { markersize = Math.Max(1,value); }
		}
		
		[XmlIgnore()]
    	[NinjaScriptProperty]
		[Description("Up Fractal Color")]
		[Category("Visual")]
		[DisplayName("Color: Up")]
		public Brush UpColor
		{
			get { return upcolor; }
			set { upcolor = value; }
		}

		[Browsable(false)]
    	public string UpColorSerialize
    	{
        		get { return Serialize.BrushToString(UpColor); }
        		set { UpColor = Serialize.StringToBrush(value); }
    	}
		
		[XmlIgnore()]
    	[NinjaScriptProperty]
		[Description("Down Fractal Color")]
		[Category("Visual")]
		[DisplayName("Color: Down")]
		public Brush DownColor
		{
			get { return downcolor; }
			set { downcolor = value; }
		}

		[Browsable(false)]
    	public string DownColorSerialize
    	{
        		get { return Serialize.BrushToString(DownColor); }
        		set { DownColor = Serialize.StringToBrush(value); }
    	}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FractalPivots[] cacheFractalPivots;
		public FractalPivots FractalPivots(int period, int markerSize, Brush upColor, Brush downColor)
		{
			return FractalPivots(Input, period, markerSize, upColor, downColor);
		}

		public FractalPivots FractalPivots(ISeries<double> input, int period, int markerSize, Brush upColor, Brush downColor)
		{
			if (cacheFractalPivots != null)
				for (int idx = 0; idx < cacheFractalPivots.Length; idx++)
					if (cacheFractalPivots[idx] != null && cacheFractalPivots[idx].Period == period && cacheFractalPivots[idx].MarkerSize == markerSize && cacheFractalPivots[idx].UpColor == upColor && cacheFractalPivots[idx].DownColor == downColor && cacheFractalPivots[idx].EqualsInput(input))
						return cacheFractalPivots[idx];
			return CacheIndicator<FractalPivots>(new FractalPivots(){ Period = period, MarkerSize = markerSize, UpColor = upColor, DownColor = downColor }, input, ref cacheFractalPivots);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FractalPivots FractalPivots(int period, int markerSize, Brush upColor, Brush downColor)
		{
			return indicator.FractalPivots(Input, period, markerSize, upColor, downColor);
		}

		public Indicators.FractalPivots FractalPivots(ISeries<double> input , int period, int markerSize, Brush upColor, Brush downColor)
		{
			return indicator.FractalPivots(input, period, markerSize, upColor, downColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FractalPivots FractalPivots(int period, int markerSize, Brush upColor, Brush downColor)
		{
			return indicator.FractalPivots(Input, period, markerSize, upColor, downColor);
		}

		public Indicators.FractalPivots FractalPivots(ISeries<double> input , int period, int markerSize, Brush upColor, Brush downColor)
		{
			return indicator.FractalPivots(input, period, markerSize, upColor, downColor);
		}
	}
}

#endregion
