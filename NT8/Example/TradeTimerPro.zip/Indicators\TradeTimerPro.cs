#region Using declarations
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.IO;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators

{
	public class TradeTimerPro : Indicator
	{
		private Chart chartWindow                            = null;
		private System.Windows.Controls.Label myTradeTimer = null;
		private bool IsToolBarLabelAdded;
		private DependencyObject searchObject;
		private string theMenuAutomationID;
		private bool showclock                               = true;
		private bool displayAllTabs                          = false;
		private bool displayIndicatorName                    = false;
		private SimpleFont timerFont;
		
		NinjaTrader.Gui.Tools.AccountSelector accountSelector;
		
		private Account account;
		private Account accountFilled;		// used when Entry is filled
		private bool isWorking = false;		// active working Entry orders (not yet filled)

		private System.Windows.Forms.Timer timer1            = new System.Windows.Forms.Timer();
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{	
			    Description					                = @"";
				Calculate									= Calculate.OnEachTick;
				IsOverlay									= true;
				DisplayInDataBox							= false;
				DrawOnPricePanel							= false;
				DrawHorizontalGridLines						= false;
				DrawVerticalGridLines						= false;
				PaintPriceMarkers							= false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive					= true;
				
				Account account                             = new Account();
				Account accountFilled                       = new Account();

				timerColor		                            = Brushes.LightGray;
				timerFont	                                = new Gui.Tools.SimpleFont("Tahoma New", 12) { Size = 12, Bold = false };
			}
			else if (State == State.Configure)
			{
				
			}
			
			else if(State == State.Historical)
		    {
				if (ChartControl != null && !IsToolBarLabelAdded && showclock == true)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						addTradeTimerToToolbar();
					}));
				}	
			}
			
			else if (State == State.Terminated)
			{
				disposeCleanUp();
								          
                if (timer1 == null) return;
                timer1.Enabled = false;
                timer1 = null;
				
				if (account != null)
				{	
	                // Unsubscribe to any prior account subscriptions
					EventHandler(account, -1);
					accountSelector.SelectionChanged 	-= OnSelectionChanged;
				}
			}
			else if (State == State.DataLoaded)
			{
			    if (displayIndicatorName)	
		        {
				Name = "TradeTimerPro V1.0";
		        }
				else
				{
				Name = "";	
				}
				

		    if (ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						accountSelector =	Window.GetWindow(ChartControl.Parent).FindFirst("ChartTraderControlAccountSelector") as AccountSelector;
						account = accountSelector.SelectedAccount;

						// Subscribe to Event Handlers
						EventHandler(account, 1);
						accountSelector.SelectionChanged 	+= OnSelectionChanged;  // event handler for account change

					}));
				}
			}
		}
		
		private void OnTimedEvent(Object source, EventArgs e)
        {
			DateTime currentTime = DateTime.Now;
			TimeSpan tradeTimeLeft = currentTime.Subtract(executionTime);

            string		timeLeft	= (tradeTimeLeft.Hours.ToString("00") + ":" + tradeTimeLeft.Minutes.ToString("00") + ":" + tradeTimeLeft.Seconds.ToString("00"));

			myTradeTimer.Content = "Tr TMR" + "\n" + timeLeft;
		}

		// Event handler for account change in Chart Trader
		private void OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (accountFilled != null)
			{
				account = accountFilled;
				return;
			}
			else if (isWorking)
			{
				account.CancelAllOrders(account.Orders[account.Orders.Count - 1].Instrument);
				isWorking = false;
			}
			
			if (accountSelector != null)
			{
				account = accountSelector.SelectedAccount;
				if (account != null)
				{
					EventHandler(account, 0);
				}
            }
		}
		
		// Event Handler manager - flag: -1=unsubscribe; 0=both; 1=subscribe
		private void EventHandler(Account acct, int flag)
		{
			if (acct == null)
				return;
			
			if (flag == 0 || flag == -1)
			{
                acct.ExecutionUpdate 	-= OnAccountExecutionUpdate;
			}
	                
			if (flag == 0 || flag == 1)
			{
              	acct.ExecutionUpdate     += OnAccountExecutionUpdate;
			}
		}	
		
		protected override void OnBarUpdate()
		{
			
		}

		/// <summary>
		/// http://ninjatrader.com/support/helpGuides/nt8/en-us/account_class.htm
		/// </summary>
		private void OnAccountExecutionUpdate(object sender, ExecutionEventArgs e)
		{
		   executionTime = e.Time;
		}	
		
	    private void addTradeTimerToToolbar()
	    {	 
	          //Obtain the Chart on which the indicator is configured
	          chartWindow = Window.GetWindow(this.ChartControl.Parent) as Chart;
			
			  chartWindow.MainTabControl.SelectionChanged += MySelectionChangedHandler;
			
	          if (chartWindow == null)
	          {
	              Print("chartWindow == null");
	              return;
	          }
			  
			 theMenuAutomationID = string.Format("ChartToolbarTradeTimer{0}", DateTime.Now.ToString("yyMMddhhmmss"));

			 foreach (System.Windows.DependencyObject item in chartWindow.MainMenu)
				if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == theMenuAutomationID)
					return;
	 
	          // Create a style to apply to the label
	          Style s = new Style();
	          s.TargetType = typeof(System.Windows.Controls.Label);
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontSizeProperty, 10.0));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.BackgroundProperty, Brushes.Transparent));
			  s.Setters.Add(new Setter(System.Windows.Controls.Label.ForegroundProperty, timerColor));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontFamilyProperty, new FontFamily("Tahoma")));
	          s.Setters.Add(new Setter(System.Windows.Controls.Label.FontWeightProperty, FontWeights.Regular));
	 
	          // Instantiate the label
	          myTradeTimer = new System.Windows.Controls.Label();

	          //Set label Style             
	          myTradeTimer.Style = s;
				
		      System.Windows.Automation.AutomationProperties.SetAutomationId(myTradeTimer, theMenuAutomationID);
			  
			  //Override Font Style 
			  timerFont.ApplyTo(myTradeTimer);
	          
			  myTradeTimer.IsEnabled = true;
	 
	          // Add the label to the Chart's Toolbar
	          chartWindow.MainMenu.Add(myTradeTimer);
					
			  // init the timer to one second and set the event handler
			  timer1.Interval = 1000;
        	  timer1.Enabled = true;
			  timer1.Tick += new EventHandler(OnTimedEvent);
	 
	          //Prevent the Label From Displaying when WorkSpace Opens if it is not in an active tab
	          myTradeTimer.Visibility = Visibility.Collapsed;
				
			  myTradeTimer.Content = "Tr TMR" + "\n" + "00:00:00";
			  
	          foreach (TabItem tab in this.chartWindow.MainTabControl.Items)
	          {
	              if ((tab.Content as ChartTab).ChartControl == this.ChartControl
	                   && tab == this.chartWindow.MainTabControl.SelectedItem)
	              {
	                  myTradeTimer.Visibility = Visibility.Visible;
	              }  
	          }
	          IsToolBarLabelAdded = true;
	    }
		
	    private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{	
		if (displayAllTabs == false)	
		{
			if (e.AddedItems.Count <= 0)
				return;
			TabItem tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab; 
			if (temp != null)
			{
				if (myTradeTimer != null)
					myTradeTimer.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
			}
		}
		}
		
		
		private void disposeCleanUp()
		{
			if(chartWindow != null)
			{
				try
        		{
					if (ChartControl == null) return;
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
						//Label Null Check
		              	if (myTradeTimer != null)
		              	{
		                  //Remove Label from Indicator's Chart ToolBar
		                  chartWindow.MainMenu.Remove(myTradeTimer);

			              timer1.Stop();
			              timer1.Dispose();
		              	}
						
					}));
				}
				catch(Exception e)
	           {
		           //Print("TT: "+e.ToString());
		       }
			}
		}		
		
#region Properties

		[NinjaScriptProperty]
		[Display(Name="Last Execution Date/Time", Order=1, Description="Last Execution", GroupName="Execution Date & Time")]
		public DateTime executionTime
		{ get; set; }
	
		[XmlIgnore]
		[NinjaScriptProperty, Display(Name="Font Color", Description="Text Color", Order=1, GroupName="Timer Settings")]
		public Brush timerColor
		{ get; set; }

		[Browsable(false)]
		public string trColorSerializable
		{
			get { return Serialize.BrushToString(timerColor); }
			set { timerColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty, Display(ResourceType = typeof(Custom.Resource), Name = "Font Select", Description = "Select font, style, size to display on chart.", GroupName = "Timer Settings", Order = 2)]
		public SimpleFont ClocktFont
	    {
			get{return timerFont;}
			set{timerFont = value;}
		}
		
		[NinjaScriptProperty]
		[Display(Name="Show Timer", Description="True will show timer", Order=3, GroupName="Timer Settings")]
        public bool ShowClock
        {
            get { return showclock; }
			set { showclock = value; }
        }
		
		[Description("Display Timer on All Tabs")]
        [Display(Name="Display All Tabs", Description="Display Timer on All Tabs", Order=4, GroupName="Timer Settings")]
		public bool DisplayAllTabs
		{
			get{ return displayAllTabs;}
			set{displayAllTabs = value;}
		}
		
		[Description("Display Indicator Name On Chart")]
        [Display(Name="Display Indicator Name", Description="Display Indicator Name On Chart", Order=1, GroupName="Indicator Name")]
		public bool DisplayIndicatorName
		{
			get{ return displayIndicatorName;}
			set{displayIndicatorName = value;}
		}
	
#endregion		
	
	}	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private TradeTimerPro[] cacheTradeTimerPro;
		public TradeTimerPro TradeTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return TradeTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public TradeTimerPro TradeTimerPro(ISeries<double> input, DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			if (cacheTradeTimerPro != null)
				for (int idx = 0; idx < cacheTradeTimerPro.Length; idx++)
					if (cacheTradeTimerPro[idx] != null && cacheTradeTimerPro[idx].executionTime == executionTime && cacheTradeTimerPro[idx].timerColor == timerColor && cacheTradeTimerPro[idx].ClocktFont == clocktFont && cacheTradeTimerPro[idx].ShowClock == showClock && cacheTradeTimerPro[idx].EqualsInput(input))
						return cacheTradeTimerPro[idx];
			return CacheIndicator<TradeTimerPro>(new TradeTimerPro(){ executionTime = executionTime, timerColor = timerColor, ClocktFont = clocktFont, ShowClock = showClock }, input, ref cacheTradeTimerPro);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.TradeTimerPro TradeTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.TradeTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public Indicators.TradeTimerPro TradeTimerPro(ISeries<double> input , DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.TradeTimerPro(input, executionTime, timerColor, clocktFont, showClock);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.TradeTimerPro TradeTimerPro(DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.TradeTimerPro(Input, executionTime, timerColor, clocktFont, showClock);
		}

		public Indicators.TradeTimerPro TradeTimerPro(ISeries<double> input , DateTime executionTime, Brush timerColor, SimpleFont clocktFont, bool showClock)
		{
			return indicator.TradeTimerPro(input, executionTime, timerColor, clocktFont, showClock);
		}
	}
}

#endregion
