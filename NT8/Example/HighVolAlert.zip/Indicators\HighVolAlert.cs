// 
// Copyright (C) 2006, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

#region Using declarations
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Reflection;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// Volume is simply the number of shares (or contracts) traded during a specified time frame (e.g. hour, day, week, month, etc).
	/// </summary>
	public class HighVolAlert : Indicator
	{
		#region Variables
		// Wizard generated variables
		private int highVolume = 1000; // Default setting for HighVolume
		// User defined variables (add any user defined variables below)
		#endregion
		
		/// <summary>
		/// This method is used to configure the indicator and is called once before any bar data is loaded.
		/// </summary>
		private void Initialize()
		{
			AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Bar, "Volume");
			AddLine(Brushes.DarkGray, 0, "Zero line");
		}

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    Name = "HighVolAlert";
                    Description = "Volume is simply the number of shares (or contracts) traded during a specified time frame (e.g. hour, day, week, month, etc).";
                    Initialize();
                    break;
             }
        }

        private static SolidColorBrush BrushFromArgb(int argb)
        {
            return new SolidColorBrush(Color.FromArgb(
                (byte)(argb >> 24),
                (byte)(argb >> 16),
                (byte)(argb >> 8),
                (byte)(argb)));
        }

        private static SolidColorBrush BrushFromArgb(int alpha, Brush baseBrush)
        {
            var brush = (SolidColorBrush)baseBrush;

            return new SolidColorBrush(Color.FromArgb(
                (byte)alpha,
                brush.Color.R,
                brush.Color.G,
                brush.Color.B));
        }

		/// <summary>
		/// Called on each bar update event (incoming tick)
		/// </summary>
		protected override void OnBarUpdate()
		{
			Value[0] = Volume[0];
		
            if (Volume[0] >= HighVolume)
            {
                BackBrush = BrushFromArgb(75,Brushes.Gold);
            }
		}
		
		#region Properties
		[NinjaScriptProperty]		
		[Display(Description = "Enter volume threshold", GroupName = "Parameters", Order = 1)]		
		public int HighVolume
        {
            get { return highVolume; }
            set { highVolume = Math.Max(1, value); }
        }
        #endregion
		
		
	}
}

#region Wizard settings, neither change nor remove
/*@
<?xml version="1.0" encoding="utf-16"?>
<NinjaTrader>
  <Name>HighVolumeChurn</Name>
  <CalculateOnBarClose>True</CalculateOnBarClose>
  <Description>Enter the description of your Indicator here</Description>
  <Parameters>
    <Parameter>
      <Default1>
      </Default1>
      <Default2>1500</Default2>
      <Default3>
      </Default3>
      <Description>Enter volume threshold</Description>
      <Minimum>1</Minimum>
      <Name>HighVolume</Name>
      <Type>int</Type>
    </Parameter>
  </Parameters>
  <State>
    <CurrentState>
      <IndicatorWizardState xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
        <Name>Flat</Name>
        <Sets>
          <IndicatorWizardStateSet>
            <Actions>
              <IndicatorWizardAction>
                <DisplayName>Set background color</DisplayName>
                <Help />
                <MemberName>SetBackColor</MemberName>
                <Parameters>
                  <string>BackColor</string>
                </Parameters>
                <Values>
                  <string>Color.Orange</string>
                </Values>
                <WizardItems>
                  <IndicatorWizardItem>
                    <DisplayName />
                    <IsIndicator>false</IsIndicator>
                    <IsInt>false</IsInt>
                    <IsMethod>false</IsMethod>
                    <IsSet>true</IsSet>
                    <MemberName />
                    <Parameters />
                    <Values />
                    <WizardItems />
                  </IndicatorWizardItem>
                </WizardItems>
              </IndicatorWizardAction>
            </Actions>
            <Conditions>
              <IndicatorWizardCondition>
                <AndOr>And</AndOr>
                <Left>
                  <DisplayName>Volume</DisplayName>
                  <IsIndicator>false</IsIndicator>
                  <IsInt>true</IsInt>
                  <IsMethod>false</IsMethod>
                  <IsSet>true</IsSet>
                  <MemberName>Volume</MemberName>
                  <Parameters>
                    <string>	barsAgo</string>
                    <string>	multiplier</string>
                  </Parameters>
                  <Values>
                    <string>0</string>
                    <string>0</string>
                  </Values>
                  <WizardItems>
                    <IndicatorWizardItem>
                      <DisplayName>	barsAgo</DisplayName>
                      <IsIndicator>false</IsIndicator>
                      <IsInt>true</IsInt>
                      <IsMethod>false</IsMethod>
                      <IsSet>false</IsSet>
                      <MemberName>0</MemberName>
                      <Parameters />
                      <Values />
                      <WizardItems />
                    </IndicatorWizardItem>
                    <IndicatorWizardItem>
                      <DisplayName>	multiplier</DisplayName>
                      <IsIndicator>false</IsIndicator>
                      <IsInt>true</IsInt>
                      <IsMethod>false</IsMethod>
                      <IsSet>false</IsSet>
                      <MemberName>1</MemberName>
                      <Parameters />
                      <Values />
                      <WizardItems />
                    </IndicatorWizardItem>
                  </WizardItems>
                </Left>
                <LookBackPeriod>1</LookBackPeriod>
                <Operator>&gt;=</Operator>
                <Right>
                  <DisplayName>HighVolume</DisplayName>
                  <IsIndicator>false</IsIndicator>
                  <IsInt>true</IsInt>
                  <IsMethod>false</IsMethod>
                  <IsSet>true</IsSet>
                  <MemberName>HighVolume</MemberName>
                  <Parameters />
                  <Values />
                  <WizardItems />
                </Right>
              </IndicatorWizardCondition>
            </Conditions>
          </IndicatorWizardStateSet>
        </Sets>
        <StopTargets />
      </IndicatorWizardState>
    </CurrentState>
  </State>
</NinjaTrader>
@*/
#endregion

