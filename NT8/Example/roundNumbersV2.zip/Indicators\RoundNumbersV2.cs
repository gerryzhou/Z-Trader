#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class RoundNumbersV2 : Indicator
	{
		private string tikFmt="";	
		private string numFmt="";	

		private Brush  numLineColor = Brushes.Yellow;	
		private Stroke StrokeLine;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "RoundNumbersV2";
				Calculate									= Calculate.OnPriceChange;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				usrFmt = "";
				LengthLine = 5;
				WidthLine = 2;
				DashStyleLine = DashStyleHelper.Solid;
				numLineColor = Brushes.Yellow;
			}
			else if (State == State.Configure)
			{
				StrokeLine = new Stroke(numLineColor, DashStyleLine, WidthLine); 
			}
		}

		protected override void OnBarUpdate()
		{
			if ( CurrentBar == 1 ) {
				tikFmt = Regex.Replace(TickSize.ToString(".##############"),"([\\d])","0");
				numFmt = "00$";												
				if      ( tikFmt.EndsWith(".0") )     numFmt = "0.0$";		
				else if ( tikFmt.EndsWith(".00000") ) numFmt = "00000$";	
				else if ( tikFmt.EndsWith(".000000") )numFmt = "000000$";	
				else if ( tikFmt.EndsWith(".0000000"))numFmt = "000000$";	

				if ( !String.IsNullOrEmpty(usrFmt) ) {
					numFmt = usrFmt;
					numFmt = Regex.Replace(numFmt,","," ");
					numFmt = Regex.Replace(numFmt,"\\s+"," ");
					numFmt = numFmt.Trim();
					numFmt = Regex.Replace(numFmt," ","$|") + "$";
				}
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			int firstBarPainted = Convert.ToInt32(chartControl.GetSlotIndexByTime(chartControl.FirstTimePainted)); // the first bar that is visible currently, you can draw between the first and last bars only for efficiency.
			int lastBarPainted = Convert.ToInt32(chartControl.GetSlotIndexByTime(chartControl.LastTimePainted)); // the last visible bar on the chart
			if(lastBarPainted>CurrentBar)
				lastBarPainted=CurrentBar;
			
			SharpDX.Vector2 p1 = new SharpDX.Vector2(0, 0);
			SharpDX.Vector2 p2 = new SharpDX.Vector2(0, 0);
			
			SharpDX.Direct2D1.Brush dxLineColor = numLineColor.ToDxBrush(RenderTarget);

			int lastX = chartControl.GetXByBarIndex(chartControl.BarsArray[0], lastBarPainted);
			int barWidth = Math.Abs((chartControl.GetXByBarIndex(chartControl.BarsArray[0], firstBarPainted)-chartControl.GetXByBarIndex(chartControl.BarsArray[0], firstBarPainted+1)));
			int startX = lastX - LengthLine*barWidth;
			
			double d=Bars.Instrument.MasterInstrument.RoundToTickSize(chartScale.MinValue);
			for(; d<chartScale.MaxValue; )
			{
				if(d>0 && Regex.Match(d.ToString(tikFmt), numFmt).Success)
				{
					p1.X = (float)(startX);
					p1.Y = (float)chartScale.GetYByValueWpf(d);
									
					p2.X = (float)(lastX);
					p2.Y = (float)chartScale.GetYByValueWpf(d);
					RenderTarget.DrawLine(p1, p2, dxLineColor, WidthLine, StrokeLine.StrokeStyle);
				}
				
				d = Bars.Instrument.MasterInstrument.RoundToTickSize(d+TickSize);
			}
			
			dxLineColor.Dispose();
		}		

		#region Properties
		
		[NinjaScriptProperty]
		[Display(Name = "Numbers Ending in:", Description = "Mark numbers ending in these digits. Space or comma delimited list Ex: 0, 00, .25, 0.0, .0010", Order = 1, GroupName = "Parameters")]
		public string usrFmt
		{
			get ;
			set ;
		}

		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Line color", Description = "", Order = 2, GroupName = "Parameters")]
		public System.Windows.Media.Brush property_LineColor
		{
			get { return numLineColor; }
			set { numLineColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string property_LineColorSerialize
		{
			get { return Serialize.BrushToString(numLineColor); }
   			set { numLineColor = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Display(Name = "Plot style", Description = "DashStyle", Order =3, GroupName = "Parameters")]
		public DashStyleHelper DashStyleLine
		{
			get;
			set;
		} 

		[NinjaScriptProperty]
		[Display(Name = "Line Width", Description = "Width of line", Order =4, GroupName = "Parameters")]
		public float WidthLine
		{
			get;
			set;
		} 		

		[NinjaScriptProperty]
		[Display(Name = "Line Length", Description = "", Order =5, GroupName = "Parameters")]
		public int LengthLine
		{
			get;
			set;
		} 		
#endregion
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private RoundNumbersV2[] cacheRoundNumbersV2;
		public RoundNumbersV2 RoundNumbersV2(string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			return RoundNumbersV2(Input, usrFmt, property_LineColor, dashStyleLine, widthLine, lengthLine);
		}

		public RoundNumbersV2 RoundNumbersV2(ISeries<double> input, string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			if (cacheRoundNumbersV2 != null)
				for (int idx = 0; idx < cacheRoundNumbersV2.Length; idx++)
					if (cacheRoundNumbersV2[idx] != null && cacheRoundNumbersV2[idx].usrFmt == usrFmt && cacheRoundNumbersV2[idx].property_LineColor == property_LineColor && cacheRoundNumbersV2[idx].DashStyleLine == dashStyleLine && cacheRoundNumbersV2[idx].WidthLine == widthLine && cacheRoundNumbersV2[idx].LengthLine == lengthLine && cacheRoundNumbersV2[idx].EqualsInput(input))
						return cacheRoundNumbersV2[idx];
			return CacheIndicator<RoundNumbersV2>(new RoundNumbersV2(){ usrFmt = usrFmt, property_LineColor = property_LineColor, DashStyleLine = dashStyleLine, WidthLine = widthLine, LengthLine = lengthLine }, input, ref cacheRoundNumbersV2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.RoundNumbersV2 RoundNumbersV2(string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			return indicator.RoundNumbersV2(Input, usrFmt, property_LineColor, dashStyleLine, widthLine, lengthLine);
		}

		public Indicators.RoundNumbersV2 RoundNumbersV2(ISeries<double> input , string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			return indicator.RoundNumbersV2(input, usrFmt, property_LineColor, dashStyleLine, widthLine, lengthLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.RoundNumbersV2 RoundNumbersV2(string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			return indicator.RoundNumbersV2(Input, usrFmt, property_LineColor, dashStyleLine, widthLine, lengthLine);
		}

		public Indicators.RoundNumbersV2 RoundNumbersV2(ISeries<double> input , string usrFmt, System.Windows.Media.Brush property_LineColor, DashStyleHelper dashStyleLine, float widthLine, int lengthLine)
		{
			return indicator.RoundNumbersV2(input, usrFmt, property_LineColor, dashStyleLine, widthLine, lengthLine);
		}
	}
}

#endregion
