////+----------------------------------------------------------------------------------------------+
//| Copyright © <2017>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.LizardIndicators;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Multi MA Cross indicator allows for displaying a fast and a slow moving average. For both averages there are 36 different algorithms to choose from.
	/// The area between the two averages is colored. The color can be used as a trend indication.
	/// </summary>
	[Gui.CategoryOrder("Algorithmic Options", 0)]
	[Gui.CategoryOrder("Input Parameters", 10)]
	[Gui.CategoryOrder("Display Options", 20)]
	[Gui.CategoryOrder("Data Series", 30)]
	[Gui.CategoryOrder("Set up", 40)]
	[Gui.CategoryOrder("Visual", 50)]
	[Gui.CategoryOrder("Plots", 60)]
	[Gui.CategoryOrder("Cloud", 70)]
	[Gui.CategoryOrder("Paint Bars", 80)]
	[Gui.CategoryOrder("Version", 90)]
	[TypeConverter("NinjaTrader.NinjaScript.Indicators.amaMultiMACrossTypeConverter")]
	public class amaMultiMACross : Indicator
	{
		private int 							fastPeriod 					= 21;
		private int								slowPeriod					= 55;
		private int 							fastTrendPeriod				= 21;
		private int								slowTrendPeriod				= 55;
		private int								displacement				= 0;
		private int								shift						= 0;
		private int								totalBarsRequiredToPlot		= 0;
		private int								areaOpacity					= 60;
		private int								barOpacity					= 40;
		private double							fastVFactor					= 0.7;
		private double							slowVFactor					= 0.7;
		private double							maxAverage					= 0.0;
		private double							minAverage					= 0.0;
		private bool							showMovingAverages			= true;
		private bool							fillArea					= true;
		private bool							showPaintBars				= true;
		private bool							areaIsFilled				= true;
		private bool							calculateFromPriceData		= true;
		private bool							indicatorIsOnPricePanel		= true;
		private bool							maTypeNotAllowed			= false;
		private amaMACrossMAType				fastMAType					= amaMACrossMAType.SMA;
		private amaMACrossMAType				slowMAType					= amaMACrossMAType.SMA;
		private amaMACrossTrendDefinition		trendDefinition				= amaMACrossTrendDefinition.Cross;
		private System.Windows.Media.Brush		fastMABrush					= Brushes.Navy;
		private System.Windows.Media.Brush		slowMABrush					= Brushes.Navy;
		private System.Windows.Media.Brush		cloudBrushUpS				= Brushes.LightSkyBlue;
		private System.Windows.Media.Brush		cloudBrushDownS				= Brushes.Salmon;
		private System.Windows.Media.Brush		cloudBrushUp				= Brushes.Transparent;
		private System.Windows.Media.Brush		cloudBrushDown				= Brushes.Transparent;
		private System.Windows.Media.Brush		upBrushUp					= Brushes.LimeGreen;
		private System.Windows.Media.Brush		upBrushDown					= Brushes.DarkGreen;
		private System.Windows.Media.Brush		downBrushUp					= Brushes.DarkRed;
		private System.Windows.Media.Brush		downBrushDown				= Brushes.Red;
		private System.Windows.Media.Brush		upBrushOutline				= Brushes.Black;
		private System.Windows.Media.Brush		downBrushOutline			= Brushes.Black;
		private int								plot0Width					= 2;
		private int								plot1Width					= 2;
		private PlotStyle						plot0Style					= PlotStyle.Line;
		private DashStyleHelper					dash0Style					= DashStyleHelper.DashDot;
		private PlotStyle						plot1Style					= PlotStyle.Line;
		private DashStyleHelper					dash1Style					= DashStyleHelper.Solid;
		private System.Windows.Media.Brush		errorBrush					= Brushes.Black;
		private SimpleFont						errorFont					= null;
		private string							errorText					= "Please select a different moving average or moving median, when selecting an indicator as input series for the amaMultiMACross.";
		private string							versionString				= "v 1.6  -  November 28, 2017";
		private Series<double>					trend;
		private ISeries<double>					fastMA;
		private ISeries<double>					slowMA;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe Multi MA Cross indicator allows for displaying a fast and a slow moving averages. For both averages there are 36 different algorithms to choose from."
												+ " The area between the two averages is colored. The color can be used as a trend indication."; 
				Name						= "amaMultiMACross";
				IsSuspendedWhileInactive	= true;
				IsOverlay					= true;
				ArePlotsConfigurable		= false;
				AddPlot(new Stroke(Brushes.MediumBlue, 2), PlotStyle.Line, "Fast MA");
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Line, "Slow MA");
			}
			else if (State == State.Configure)
			{
				displacement = Displacement;
				shift = Math.Max(0, displacement);
				BarsRequiredToPlot	= Math.Max(fastPeriod + 3 * slowPeriod, -displacement);
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				if(showMovingAverages)
				{	
					Plots[0].Brush = fastMABrush;
					Plots[1].Brush = slowMABrush;
				}
				else
				{	
					Plots[0].Brush = Brushes.Transparent;
					Plots[1].Brush = Brushes.Transparent;
				}
				Plots[0].Width = plot0Width;
				Plots[0].PlotStyle = plot0Style;
				Plots[0].DashStyleHelper = dash0Style;			
				Plots[1].Width = plot1Width;
				Plots[1].PlotStyle = plot1Style;
				Plots[1].DashStyleHelper = dash1Style;
				cloudBrushUp = cloudBrushUpS.Clone();
				cloudBrushUp.Opacity = (float) areaOpacity/100.0;
				cloudBrushUp.Freeze();
				cloudBrushDown = cloudBrushDownS.Clone();
				cloudBrushDown.Opacity = (float) areaOpacity/100.0;
				cloudBrushDown.Freeze();
			}	
			else if (State == State.DataLoaded)
			{
				trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				maTypeNotAllowed = false;
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
				switch (fastMAType)
				{	
					case amaMACrossMAType.Median: 
						fastMA = amaMovingMedian(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.Median_TPO:
						if(calculateFromPriceData)
							fastMA = amaMovingMedianTPO(Inputs[0], fastPeriod, true);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Median_VWTPO: 
						if(calculateFromPriceData)
							fastMA = amaMovingMedianVWTPO(Inputs[0], fastPeriod, true);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Mean_TPO: 
						if(calculateFromPriceData)
							fastMA = amaMovingMeanTPO(Inputs[0], fastPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Mean_VWTPO: 
						if(calculateFromPriceData)
							fastMA = amaMovingMeanVWTPO(Inputs[0], fastPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Adaptive_Laguerre: 
						fastMA = amaAdaptiveLaguerreFilter(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.ADXVMA: 
						fastMA = amaADXVMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.Butterworth_2: 
						fastMA = amaButterworthFilter(Inputs[0], 2, fastPeriod);
						break;
					case amaMACrossMAType.Butterworth_3: 
						fastMA = amaButterworthFilter(Inputs[0], 3, fastPeriod);
						break;
					case amaMACrossMAType.DEMA: 
						fastMA = DEMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.Distant_Coefficient_Filter: 
						fastMA = amaDistantCoefficientFilter(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.DWMA: 
						fastMA = amaDWMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.EHMA: 
						fastMA = amaEHMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.EMA: 
						fastMA = EMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.Gauss_2: 
						fastMA = amaGaussianFilter(Inputs[0], 2, fastPeriod);
						break;
					case amaMACrossMAType.Gauss_3: 
						fastMA = amaGaussianFilter(Inputs[0], 3, fastPeriod);
						break;
					case amaMACrossMAType.Gauss_4: 
						fastMA = amaGaussianFilter(Inputs[0], 4, fastPeriod);
						break;
					case amaMACrossMAType.HMA: 
						if(fastPeriod > 1)
							fastMA = HMA(Inputs[0], fastPeriod);
						else
							fastMA = Inputs[0];
						break;
					case amaMACrossMAType.HoltEMA: 
						fastMA = amaHoltEMA(Inputs[0], fastPeriod, fastTrendPeriod);
						break;
					case amaMACrossMAType.Laguerre: 
						fastMA = amaLaguerreFilter(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.LinReg: 
						if(fastPeriod > 1)
							fastMA = LinReg(Inputs[0], fastPeriod);
						else
							fastMA = Inputs[0];
						break;
					case amaMACrossMAType.RWMA: 
						if(calculateFromPriceData)
							fastMA = amaRWMA(Inputs[0], fastPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.SMA: 
						fastMA = SMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.SuperSmoother_2: 
						fastMA = amaSuperSmoother(Inputs[0], 2, fastPeriod);
						break;
					case amaMACrossMAType.SuperSmoother_3: 
						fastMA = amaSuperSmoother(Inputs[0], 3, fastPeriod);
						break;
					case amaMACrossMAType.SWMA: 
						fastMA = amaSWMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.TEMA: 
						fastMA = TEMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.Tillson_T3: 
						fastMA = amaTillsonT3(Inputs[0], amaT3CalcMode.Tillson, fastPeriod, fastVFactor);
						break;
					case amaMACrossMAType.TMA: 
						fastMA = TMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.TWMA: 
						fastMA = amaTWMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.VWMA: 
						if(calculateFromPriceData)
							fastMA = VWMA(Inputs[0], fastPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Wilder: 
						fastMA = EMA(Inputs[0], 2*fastPeriod - 1);
						break;
					case amaMACrossMAType.WMA: 
						fastMA = WMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.ZerolagHATEMA: 
						if(calculateFromPriceData)
							fastMA = amaZerolagHATEMA(Inputs[0], fastPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.ZerolagTEMA: 
						fastMA = amaZerolagTEMA(Inputs[0], fastPeriod);
						break;
					case amaMACrossMAType.ZLEMA: 
						if(fastPeriod > 1)
							fastMA = ZLEMA(Inputs[0], fastPeriod);
						else
							fastMA = Inputs[0];
						break;
				}				
				switch (slowMAType)
				{	
					case amaMACrossMAType.Median: 
						slowMA = amaMovingMedian(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.Median_TPO:
						if(calculateFromPriceData)
							slowMA = amaMovingMedianTPO(Inputs[0], slowPeriod, true);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Median_VWTPO: 
						if(calculateFromPriceData)
							slowMA = amaMovingMedianVWTPO(Inputs[0], slowPeriod, true);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Mean_TPO: 
						if(calculateFromPriceData)
							slowMA = amaMovingMeanTPO(Inputs[0], slowPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Mean_VWTPO: 
						if(calculateFromPriceData)
							slowMA = amaMovingMeanVWTPO(Inputs[0], slowPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Adaptive_Laguerre: 
						slowMA = amaAdaptiveLaguerreFilter(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.ADXVMA: 
						slowMA = amaADXVMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.Butterworth_2: 
						slowMA = amaButterworthFilter(Inputs[0], 2, slowPeriod);
						break;
					case amaMACrossMAType.Butterworth_3: 
						slowMA = amaButterworthFilter(Inputs[0], 3, slowPeriod);
						break;
					case amaMACrossMAType.DEMA: 
						slowMA = DEMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.Distant_Coefficient_Filter: 
						slowMA = amaDistantCoefficientFilter(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.DWMA: 
						slowMA = amaDWMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.EHMA: 
						slowMA = amaEHMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.EMA: 
						slowMA = EMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.Gauss_2: 
						slowMA = amaGaussianFilter(Inputs[0], 2, slowPeriod);
						break;
					case amaMACrossMAType.Gauss_3: 
						slowMA = amaGaussianFilter(Inputs[0], 3, slowPeriod);
						break;
					case amaMACrossMAType.Gauss_4: 
						slowMA = amaGaussianFilter(Inputs[0], 4, slowPeriod);
						break;
					case amaMACrossMAType.HMA: 
						if(slowPeriod > 1)
							slowMA = HMA(Inputs[0], slowPeriod);
						else
							slowMA = Inputs[0];
						break;
					case amaMACrossMAType.HoltEMA: 
						slowMA = amaHoltEMA(Inputs[0], slowPeriod, slowTrendPeriod);
						break;
					case amaMACrossMAType.Laguerre: 
						slowMA = amaLaguerreFilter(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.LinReg: 
						if(slowPeriod > 1)
							slowMA = LinReg(Inputs[0], slowPeriod);
						else
							slowMA = Inputs[0];
						break;
					case amaMACrossMAType.RWMA: 
						if(calculateFromPriceData)
							slowMA = amaRWMA(Inputs[0], slowPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.SMA: 
						slowMA = SMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.SuperSmoother_2: 
						slowMA = amaSuperSmoother(Inputs[0], 2, slowPeriod);
						break;
					case amaMACrossMAType.SuperSmoother_3: 
						slowMA = amaSuperSmoother(Inputs[0], 3, slowPeriod);
						break;
					case amaMACrossMAType.SWMA: 
						slowMA = amaSWMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.TEMA: 
						slowMA = TEMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.Tillson_T3: 
						slowMA = amaTillsonT3(Inputs[0], amaT3CalcMode.Tillson, slowPeriod, slowVFactor);
						break;
					case amaMACrossMAType.TMA: 
						slowMA = TMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.TWMA: 
						slowMA = amaTWMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.VWMA: 
						if(calculateFromPriceData)
							slowMA = VWMA(Inputs[0], slowPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.Wilder: 
						slowMA = EMA(Inputs[0], 2*slowPeriod - 1);
						break;
					case amaMACrossMAType.WMA: 
						slowMA = WMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.ZerolagHATEMA: 
						if(calculateFromPriceData)
							slowMA = amaZerolagHATEMA(Inputs[0], slowPeriod);
						else
							maTypeNotAllowed = true;
						break;
					case amaMACrossMAType.ZerolagTEMA: 
						slowMA = amaZerolagTEMA(Inputs[0], slowPeriod);
						break;
					case amaMACrossMAType.ZLEMA: 
						if(slowPeriod > 1)
							slowMA = ZLEMA(Inputs[0], slowPeriod);
						else
							slowMA = Inputs[0];
						break;
				}
			}	
			else if (State == State.Historical)
			{
				areaIsFilled = fillArea && areaOpacity > 0;
				if(ChartBars != null)
				{	
					errorBrush = ChartControl.Properties.AxisPen.Brush;
					errorBrush.Freeze();
					errorFont = new SimpleFont("Arial", 24);
					indicatorIsOnPricePanel = (ChartPanel.PanelIndex == ChartBars.Panel);
				}	
				else
					indicatorIsOnPricePanel = false;
				this.ZOrder = -1; //SetZOrder(-1);
			}
		}
		
		protected override void OnBarUpdate()
		{
			if(maTypeNotAllowed)
			{
				DrawOnPricePanel = false;
				Draw.TextFixed(this, "error text", errorText, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
				return;
			}
			
			FastMA[0] = fastMA[0];
			SlowMA[0] = slowMA[0];
			
			if(CurrentBar < BarsRequiredToPlot + shift)
				trend[0] = 0.0;
			else if (trendDefinition == amaMACrossTrendDefinition.Cross)
			{
				if(FastMA[0] > SlowMA[0])
					trend[0] = 1.0;
				else if (FastMA[0] < SlowMA[0])
					trend[0] = -1.0;
				else
					trend[0] = trend[1];
			}
			else if (calculateFromPriceData)
			{
				maxAverage = Math.Max(FastMA[0], SlowMA[0]); 
				minAverage = Math.Min(FastMA[0], SlowMA[0]); 
				if(Close[0] > maxAverage && Median[0] > maxAverage && Close[0] > High[1] && Range()[0] >= Range()[1])
					trend[0] = 1.0;
				else if (Close[0] < minAverage && Median[0] < minAverage && Close[0] < Low[1] && Range()[0] >= Range()[1])
					trend[0] = -1.0;
				else
					trend[0] = trend[1];
			}
			else
			{
				maxAverage = Math.Max(FastMA[0], SlowMA[0]); 
				minAverage = Math.Min(FastMA[0], SlowMA[0]); 
				if(Input[0] > maxAverage && Close[0] > High[1] && Range()[0] >= Range()[1])
					trend[0] = 1.0;
				else if (Input[0] < minAverage && Close[0] < Low[1] && Range()[0] >= Range()[1])
					trend[0] = -1.0;
				else
					trend[0] = trend[1];
			}
			
			// Paint bars
			if(showPaintBars && CurrentBar >= totalBarsRequiredToPlot)
			{
				if(displacement >= 0)
				{
					if(trend[displacement] > 0)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = upBrushUp;
						else
							BarBrushes[0] = upBrushDown;
						CandleOutlineBrushes[0] = upBrushOutline;
					}	
					else if(trend[displacement] < 0) 
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = downBrushUp;
						else
							BarBrushes[0] = downBrushDown;
						CandleOutlineBrushes[0] = downBrushOutline;
					}	
				}
				else 
				{
					if(trend[0] > 0)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = upBrushUp;
						else
							BarBrushes[-displacement] = upBrushDown;
						CandleOutlineBrushes[-displacement] = upBrushOutline;
					}	
					else if(trend[0] < 0)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = downBrushUp;
						else
							BarBrushes[-displacement] = downBrushDown;
						CandleOutlineBrushes[-displacement] = downBrushOutline;
					}	
				}			
			}
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> FastMA
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> SlowMA
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Trend
		{
			get { return trend; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast MA Type", Description = "Select type for the fast moving average", GroupName = "Algorithmic Options", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaMACrossMAType FastMAType
		{	
            get { return fastMAType; }
            set { fastMAType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow MA Type", Description = "Select type for the slow moving average", GroupName = "Algorithmic Options", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaMACrossMAType SlowMAType
		{	
            get { return slowMAType; }
            set { slowMAType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend definition", Description = "Select trend definition for the paint bars", GroupName = "Algorithmic Options", Order = 2)]
		public amaMACrossTrendDefinition TrendDefinition
		{	
            get { return trendDefinition; }
            set { trendDefinition = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast MA period", Description = "Sets the period for the fast moving average", GroupName = "Input Parameters", Order = 0)]
		public int FastPeriod
		{	
            get { return fastPeriod; }
            set { fastPeriod = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast MA trend period", Description = "Sets the trend period for the Holt EMA (fast MA)", GroupName = "Input Parameters", Order = 1)]
		public int FastTrendPeriod
		{	
            get { return fastTrendPeriod; }
            set { fastTrendPeriod = value; }
		}
			
		[Range(0, 1), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast V-factor", Description = "Sets the VFactor for the Tillson T3 (fast MA)", GroupName = "Input Parameters", Order = 2)]
		public double FastVFactor 
		{	
            get { return fastVFactor; }
            set { fastVFactor = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow MA period", Description = "Sets the period for the slow moving average", GroupName = "Input Parameters", Order = 3)]
		public int SlowPeriod
		{	
            get { return slowPeriod; }
            set { slowPeriod = value; }
		}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow MA trend period", Description = "Sets the trend period for the Holt EMA (slow MA)", GroupName = "Input Parameters", Order = 4)]
		public int SlowTrendPeriod
		{	
            get { return slowTrendPeriod; }
            set { slowTrendPeriod = value; }
		}

		[Range(0, 1), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow V-factor", Description = "Sets the VFactor for the Tillson T3 (slow MA)", GroupName = "Input Parameters", Order = 5)]
		public double SlowVFactor 
		{	
            get { return slowVFactor; }
            set { slowVFactor = value; }
		}
			
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show moving averages", Description = "Shows the moving average plots", GroupName = "Display Options", Order = 0)]
        public bool ShowTriggerLines
        {
            get { return showMovingAverages; }
            set { showMovingAverages = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fill area between MAs", Description = "Fills the space between the two moving averages", GroupName = "Display Options", Order = 1)]
        public bool FillArea
        {
            get { return fillArea; }
            set { fillArea = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", Description = "Activates paint bars", GroupName = "Display Options", Order = 2)]
        public bool ShowPaintBars
        {
            get { return showPaintBars; }
            set { showPaintBars = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast MA", Description = "Sets the color for the fast fast moving average", GroupName = "Plots", Order = 0)]
		public System.Windows.Media.Brush TriggerBrush
		{ 
			get {return fastMABrush;}
			set {fastMABrush = value;}
		}

		[Browsable(false)]
		public string TriggerBrushSerializable
		{
			get { return Serialize.BrushToString(fastMABrush); }
			set { fastMABrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style fast MA", Description = "Sets the dash style for the fast fast moving average", GroupName = "Plots", Order = 1)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width fast MA", Description = "Sets the plot width for the fast fast moving average", GroupName = "Plots", Order = 2)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow MA", Description = "Sets the color for the slow moving average", GroupName = "Plots", Order = 3)]
		public System.Windows.Media.Brush AverageBrush
		{ 
			get {return slowMABrush;}
			set {slowMABrush = value;}
		}

		[Browsable(false)]
		public string AverageBrushSerializable
		{
			get { return Serialize.BrushToString(slowMABrush); }
			set { slowMABrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style slow MA", Description = "Sets the dash style for the slow moving average", GroupName = "Plots", Order = 4)]
		public DashStyleHelper Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width slow MA", Description = "Sets the plot width for the slow moving average", GroupName = "Plots", Order = 5)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
				
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish cloud", Description = "Sets the color for a bullish trend", GroupName = "Cloud", Order = 0)]
		public System.Windows.Media.Brush KumoBrushUpS
		{ 
			get {return cloudBrushUpS;}
			set {cloudBrushUpS = value;}
		}

		[Browsable(false)]
		public string KumoBrushUpSSerializable
		{
			get { return Serialize.BrushToString(cloudBrushUpS); }
			set { cloudBrushUpS = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish cloud", Description = "Sets the color for a bullish trend", GroupName = "Cloud", Order = 1)]
		public System.Windows.Media.Brush KumoBrushDownS
		{ 
			get {return cloudBrushDownS;}
			set {cloudBrushDownS = value;}
		}

		[Browsable(false)]
		public string KumoBrushDownSSerializable
		{
			get { return Serialize.BrushToString(cloudBrushDownS); }
			set { cloudBrushDownS = Serialize.StringToBrush(value); }
		}
		
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Cloud opacity", Description = "Sets the opacity for the cloud", GroupName = "Cloud", Order = 2)]
		public int AreaOpacity
		{	
            get { return areaOpacity; }
            set { areaOpacity = value; }
		}
		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Upclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 0)]
		public System.Windows.Media.Brush UpBrushUp
		{ 
			get {return upBrushUp;}
			set {upBrushUp = value;}
		}

		[Browsable(false)]
		public string UpBrushUpSerializable
		{
			get { return Serialize.BrushToString(upBrushUp); }
			set { upBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Downclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 1)]
		public System.Windows.Media.Brush UpBrushDown
		{ 
			get {return upBrushDown;}
			set {upBrushDown = value;}
		}

		[Browsable(false)]
		public string UpBrushDownSerializable
		{
			get { return Serialize.BrushToString(upBrushDown); }
			set { upBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 2)]
		public System.Windows.Media.Brush UpBrushOutline
		{ 
			get {return upBrushOutline;}
			set {upBrushOutline = value;}
		}

		[Browsable(false)]
		public string UpBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(upBrushOutline); }
			set { upBrushOutline = Serialize.StringToBrush(value); }
		}					
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Upclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 3)]
		public System.Windows.Media.Brush DownBrushUp
		{ 
			get {return downBrushUp;}
			set {downBrushUp = value;}
		}

		[Browsable(false)]
		public string DownBrushUpSerializable
		{
			get { return Serialize.BrushToString(downBrushUp); }
			set { downBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Downclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 4)]
		public System.Windows.Media.Brush DownBrushDown
		{ 
			get {return downBrushDown;}
			set {downBrushDown = value;}
		}

		[Browsable(false)]
		public string DownBrushDownSerializable
		{
			get { return Serialize.BrushToString(downBrushDown); }
			set { downBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 5)]
		public System.Windows.Media.Brush DownBrushOutline
		{ 
			get {return downBrushOutline;}
			set {downBrushOutline = value;}
		}

		[Browsable(false)]
		public string DownBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(downBrushOutline); }
			set { downBrushOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		public override string FormatPriceMarker(double price)
		{
			if(indicatorIsOnPricePanel)
				return Instrument.MasterInstrument.FormatPrice(Instrument.MasterInstrument.RoundToTickSize(price));
			else
				return base.FormatPriceMarker(price);
		}			
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (ChartBars == null || BarsArray[0].Count < ChartBars.ToIndex || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;

			SharpDX.Direct2D1.Brush cloudBrushUpDX 	= cloudBrushUp.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush cloudBrushDownDX = cloudBrushDown.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;

	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int	lastBarPainted 	 	= ChartBars.ToIndex;
			int lastBarCounted		= Input.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(BarsRequiredToPlot, firstBarPainted);
			int lastIndex			= 0;
			int x 					= 0;
			int y1 					= 0;
			int y2 					= 0;
			int y 					= 0;
			int lastX 				= 0;
			int lastY1 				= 0;
			int lastY2 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int priorStartBar 		= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			
			bool firstLoop 			= true;
			Vector2[] cloudArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY1	= chartScale.GetYByValue(FastMA.GetValueAt(lastIndex - displacement));
				lastY2	= chartScale.GetYByValue(SlowMA.GetValueAt(lastIndex - displacement));
				
				//Area
				if(areaIsFilled)
				{	
					lastY = Math.Max(lastY1, lastY2);
					if(lastY1 > lastY2)
						lastSign = -1;
					else if (lastY1 < lastY2)
						lastSign = 1;
					else
						lastSign = 0;
					startBar = lastIndex;
					firstLoop = true;
					
					do
					{
						SharpDX.Direct2D1.PathGeometry 	path;
						SharpDX.Direct2D1.GeometrySink 	sink;
						path = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (path)
						{
							priorStartBar = startBar;
							if(firstLoop)
								count = -1;
							else
							{	
								count = 0;
								cloudArray[count] = new Vector2(lastX, lastY);
							}	
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y1 = chartScale.GetYByValue(FastMA.GetValueAt(idx - displacement));   
								y2 = chartScale.GetYByValue(SlowMA.GetValueAt(idx - displacement));   
								count = count + 1;
								if(lastSign < 1 && y1 > y2)
								{
									y = Math.Max(y1,y2);
									sign = -1;
									cloudArray[count] = new Vector2(x,y);
									lastX = x;
									lastY1 = y1;
									lastY2 = y2;
									lastY = y;
									lastSign = -1;
									returnBar = idx;
									startBar = idx - 1;
								}
								else if(lastSign > -1 && y1 < y2)
								{
									y = Math.Max(y1,y2);
									cloudArray[count] = new Vector2(x,y);
									sign = 1;
									lastX = x;
									lastY1 = y1;
									lastY2 = y2;
									lastY = y;
									lastSign = 1;
									returnBar = idx;
									startBar = idx - 1;
								}
								else if (lastSign == 0 && y1 == y2)
								{
									y = y1;
									cloudArray[count] = new Vector2(x,y);
									sign = 0;
									lastX = x;
									lastY1 = y;
									lastY2 = y;
									lastY = y;
									lastSign = 0;
									returnBar = idx;
									startBar = idx - 1;
									break;
								}
								else if (y1 == y2)
								{
									y = y1;
									cloudArray[count] = new Vector2(x,y);
									sign = lastSign;
									lastX = x;
									lastY1 = y;
									lastY2 = y;
									lastY = y;
									lastSign = 0;
									returnBar = idx + 1;
									startBar = idx - 1;
									break;
								}
								else
								{	
									double lastDiff = Convert.ToDouble(lastY2 - lastY1);
									double diff = Convert.ToDouble(y2 - y1);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = Convert.ToInt32((lastY2 * y1 - y2 * lastY1)/denominator);
									cloudArray[count] = new Vector2(x,y);
									sign = lastSign;
									lastX = x;
									lastY1 = y;
									lastY2 = y;
									lastY = y;
									lastSign = 0;
									returnBar = idx + 1;
									startBar = idx;
									break;
								}
								startBar = idx - 1;
							}
							for (int idx = returnBar ; idx <= priorStartBar; idx ++)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y1 = chartScale.GetYByValue(FastMA.GetValueAt(idx - displacement));   
								y2 = chartScale.GetYByValue(SlowMA.GetValueAt(idx - displacement));   
								y = Math.Min(y1, y2);
								count = count + 1;
								cloudArray[count] = new Vector2(x,y);
							}
							sink = path.Open();
							sink.BeginFigure(cloudArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sink.AddLine(cloudArray[i]);
							sink.EndFigure(FigureEnd.Closed);
			        		sink.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(path, cloudBrushUpDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(path, cloudBrushDownDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						path.Dispose();
						sink.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex - 1);
				}
				
				//Plots
				if(showMovingAverages) 
				{	
					SharpDX.Direct2D1.PathGeometry 	pathF;
					SharpDX.Direct2D1.GeometrySink 	sinkF;
					pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathF)
					{
						startBar = lastIndex;
						count = -1;
						for (int idx = startBar; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(FastMA.GetValueAt(idx - displacement));   
							count = count + 1;
							plotArray[count] = new Vector2(x, y);
						}
						sinkF = pathF.Open();
						sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkF.AddLine(plotArray[i]);
						sinkF.EndFigure(FigureEnd.Open);
		        		sinkF.Close();
						RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
						RenderTarget.DrawGeometry(pathF, Plots[0].BrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						RenderTarget.AntialiasMode = oldAntialiasMode;
					}
					pathF.Dispose();
					sinkF.Dispose();
					
					SharpDX.Direct2D1.PathGeometry 	pathS;
					SharpDX.Direct2D1.GeometrySink 	sinkS;
					pathS = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathS)
					{
						startBar = lastIndex;
						count = -1;
						for (int idx = startBar; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(SlowMA.GetValueAt(idx - displacement));   
							count = count + 1;
							plotArray[count] = new Vector2(x, y);
						}
						sinkS = pathS.Open();
						sinkS.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkS.AddLine(plotArray[i]);
						sinkS.EndFigure(FigureEnd.Open);
		        		sinkS.Close();
						RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
						RenderTarget.DrawGeometry(pathS, Plots[1].BrushDX, Plots[1].Width, Plots[1].StrokeStyle);
						RenderTarget.AntialiasMode = oldAntialiasMode;
					}
					pathS.Dispose();
					sinkS.Dispose();
				}
			}			
			cloudBrushUpDX.Dispose();
			cloudBrushDownDX.Dispose();
		}
		#endregion
	}
}

namespace NinjaTrader.NinjaScript.Indicators
{		
	public class amaMultiMACrossTypeConverter : NinjaTrader.NinjaScript.IndicatorBaseConverter
	{
		public override bool GetPropertiesSupported(ITypeDescriptorContext context) { return true; }

		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object value, Attribute[] attributes)
		{
			PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context) ? base.GetProperties(context, value, attributes) : TypeDescriptor.GetProperties(value, attributes);

			amaMultiMACross				thisMultiMACrossInstance		= (amaMultiMACross) value;
			amaMACrossMAType			fastMATypeFromInstance			= thisMultiMACrossInstance.FastMAType;
			amaMACrossMAType			slowMATypeFromInstance			= thisMultiMACrossInstance.SlowMAType;
		
			PropertyDescriptorCollection adjusted = new PropertyDescriptorCollection(null);
			
			foreach (PropertyDescriptor thisDescriptor in propertyDescriptorCollection)
			{
				if (fastMATypeFromInstance != amaMACrossMAType.HoltEMA && thisDescriptor.Name == "FastTrendPeriod") 
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (fastMATypeFromInstance != amaMACrossMAType.Tillson_T3 && thisDescriptor.Name == "FastVFactor") 
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (slowMATypeFromInstance != amaMACrossMAType.HoltEMA && thisDescriptor.Name == "SlowTrendPeriod") 
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (slowMATypeFromInstance != amaMACrossMAType.Tillson_T3 && thisDescriptor.Name == "SlowVFactor") 
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else	
					adjusted.Add(thisDescriptor);
			}
			return adjusted;
		}
	}
}
#region Global Enums

public enum amaMACrossMAType {Median, Median_TPO, Median_VWTPO, Mean_TPO, Mean_VWTPO, Adaptive_Laguerre, ADXVMA, Butterworth_2, Butterworth_3, DEMA, Distant_Coefficient_Filter, DWMA, EHMA, EMA, 
			Gauss_2, Gauss_3, Gauss_4, HMA, HoltEMA, Laguerre, LinReg, RWMA, SMA, SuperSmoother_2, SuperSmoother_3, SWMA, TEMA, Tillson_T3, TMA, TWMA, VWMA, Wilder, WMA, ZerolagHATEMA, ZerolagTEMA, ZLEMA}
public enum amaMACrossTrendDefinition {Cross, Thrust}

#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaMultiMACross[] cacheamaMultiMACross;
		public LizardIndicators.amaMultiMACross amaMultiMACross(amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			return amaMultiMACross(Input, fastMAType, slowMAType, trendDefinition, fastPeriod, fastTrendPeriod, fastVFactor, slowPeriod, slowTrendPeriod, slowVFactor);
		}

		public LizardIndicators.amaMultiMACross amaMultiMACross(ISeries<double> input, amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			if (cacheamaMultiMACross != null)
				for (int idx = 0; idx < cacheamaMultiMACross.Length; idx++)
					if (cacheamaMultiMACross[idx] != null && cacheamaMultiMACross[idx].FastMAType == fastMAType && cacheamaMultiMACross[idx].SlowMAType == slowMAType && cacheamaMultiMACross[idx].TrendDefinition == trendDefinition && cacheamaMultiMACross[idx].FastPeriod == fastPeriod && cacheamaMultiMACross[idx].FastTrendPeriod == fastTrendPeriod && cacheamaMultiMACross[idx].FastVFactor == fastVFactor && cacheamaMultiMACross[idx].SlowPeriod == slowPeriod && cacheamaMultiMACross[idx].SlowTrendPeriod == slowTrendPeriod && cacheamaMultiMACross[idx].SlowVFactor == slowVFactor && cacheamaMultiMACross[idx].EqualsInput(input))
						return cacheamaMultiMACross[idx];
			return CacheIndicator<LizardIndicators.amaMultiMACross>(new LizardIndicators.amaMultiMACross(){ FastMAType = fastMAType, SlowMAType = slowMAType, TrendDefinition = trendDefinition, FastPeriod = fastPeriod, FastTrendPeriod = fastTrendPeriod, FastVFactor = fastVFactor, SlowPeriod = slowPeriod, SlowTrendPeriod = slowTrendPeriod, SlowVFactor = slowVFactor }, input, ref cacheamaMultiMACross);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaMultiMACross amaMultiMACross(amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			return indicator.amaMultiMACross(Input, fastMAType, slowMAType, trendDefinition, fastPeriod, fastTrendPeriod, fastVFactor, slowPeriod, slowTrendPeriod, slowVFactor);
		}

		public Indicators.LizardIndicators.amaMultiMACross amaMultiMACross(ISeries<double> input , amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			return indicator.amaMultiMACross(input, fastMAType, slowMAType, trendDefinition, fastPeriod, fastTrendPeriod, fastVFactor, slowPeriod, slowTrendPeriod, slowVFactor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaMultiMACross amaMultiMACross(amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			return indicator.amaMultiMACross(Input, fastMAType, slowMAType, trendDefinition, fastPeriod, fastTrendPeriod, fastVFactor, slowPeriod, slowTrendPeriod, slowVFactor);
		}

		public Indicators.LizardIndicators.amaMultiMACross amaMultiMACross(ISeries<double> input , amaMACrossMAType fastMAType, amaMACrossMAType slowMAType, amaMACrossTrendDefinition trendDefinition, int fastPeriod, int fastTrendPeriod, double fastVFactor, int slowPeriod, int slowTrendPeriod, double slowVFactor)
		{
			return indicator.amaMultiMACross(input, fastMAType, slowMAType, trendDefinition, fastPeriod, fastTrendPeriod, fastVFactor, slowPeriod, slowTrendPeriod, slowVFactor);
		}
	}
}

#endregion
