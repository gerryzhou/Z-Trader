#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.NinjaScript;
using SharpDX;
using SharpDX.Direct2D1;
using System.Drawing;
using NinjaTrader.Code;
using FlowDirection = System.Windows.FlowDirection;

#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Various methods for drawing objects, such as price markers.
    /// </summary>
    public static class Sim22DrawingUtilities// : AddOnBase
    {
        /// <summary>
        /// Draw a price marker.
        /// </summary>
        [CLSCompliant(false)]
        public static void DrawPriceMarker(RenderTarget renderTarget, ChartControl chartControl, string priceStr, SharpDX.Vector2 startVector2, SimpleFont simpleFont, SharpDX.DirectWrite.TextAlignment textAlignment, SharpDX.Direct2D1.Brush textBrushDx, SharpDX.Direct2D1.Brush markerBrushDx, float markerOpacity, SharpDX.Direct2D1.Brush outlineBrushDx, int outlineWidth)
        {
            // This 'appears' to match the default NT8 price marker, although not the exact same proprietary code!
            GlyphTypeface gtf;
            Typeface tFace = new Typeface(new System.Windows.Media.FontFamily(simpleFont.Family.ToString()), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            tFace.TryGetGlyphTypeface(out gtf);
            float heightF = (float) (gtf.Height * simpleFont.Size);
            float axisWidth = (float) chartControl.AxisYRightWidth;
           
            try
            {
                SharpDX.DirectWrite.TextFormat textFormat = simpleFont.ToDirectWriteTextFormat();
                textFormat.TextAlignment = textAlignment;
                textFormat.WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap;
                SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, priceStr, textFormat, axisWidth - 4f, heightF);

                float rectHeight = textLayout.Metrics.Height + 1.6f;
                //align geometry to whole pixel numbers
                rectHeight = RoundMyNumber(rectHeight);

                float rectY = RoundMyNumber(startVector2.Y - rectHeight*0.5f);

                SharpDX.RectangleF markerRectF = new SharpDX.RectangleF(startVector2.X + 5f, rectY, axisWidth, rectHeight);

                //Combo path
                SharpDX.Direct2D1.PathGeometry pathGeometryCombo = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
                GeometrySink geometrySinkCombo = pathGeometryCombo.Open();

                geometrySinkCombo.BeginFigure(markerRectF.TopLeft, FigureBegin.Filled);
                geometrySinkCombo.AddLine(markerRectF.TopRight);
                geometrySinkCombo.AddLine(markerRectF.BottomRight);
                geometrySinkCombo.AddLine(markerRectF.BottomLeft);
                geometrySinkCombo.AddLine(startVector2);
                geometrySinkCombo.AddLine(markerRectF.TopLeft);

                //Combo plot
                geometrySinkCombo.EndFigure(FigureEnd.Open);
                geometrySinkCombo.Close();

                if (outlineBrushDx != null)
                {
                    // This worked better rather than drawing an outline.

                    //Combo path 2
                    SharpDX.Direct2D1.PathGeometry pathGeometryCombo2 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
                    GeometrySink geometrySinkCombo2 = pathGeometryCombo2.Open();

                    RectangleF outlineRectF = markerRectF;
                    //outlineRectF.Inflate(1f, 1f);
                    Vector2 outlineStart = startVector2;
                    outlineStart.X -= outlineWidth;
                    outlineRectF.X -= outlineWidth * 0.5f;
                    outlineRectF.Y -= outlineWidth;
                    outlineRectF.Height += outlineWidth * 2f;
                    outlineRectF.Width += outlineWidth * 1.5f;

                    geometrySinkCombo2.BeginFigure(outlineRectF.TopLeft, FigureBegin.Filled);
                    geometrySinkCombo2.AddLine(outlineRectF.TopRight);
                    geometrySinkCombo2.AddLine(outlineRectF.BottomRight);
                    geometrySinkCombo2.AddLine(outlineRectF.BottomLeft);
                    geometrySinkCombo2.AddLine(outlineStart);
                    geometrySinkCombo2.AddLine(outlineRectF.TopLeft);

                    //Combo plot 2
                    geometrySinkCombo2.EndFigure(FigureEnd.Open);
                    geometrySinkCombo2.Close();

                    renderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
                    renderTarget.FillGeometry(pathGeometryCombo2, outlineBrushDx);
                    renderTarget.AntialiasMode = AntialiasMode.Aliased;
                }

                if (markerBrushDx != null)
                {
                    renderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
                    markerBrushDx.Opacity = markerOpacity;
                    renderTarget.FillGeometry(pathGeometryCombo, markerBrushDx);
                    renderTarget.AntialiasMode = AntialiasMode.Aliased;
                }

                pathGeometryCombo.Dispose();
                geometrySinkCombo.Dispose();

                renderTarget.DrawTextLayout(new Vector2(markerRectF.X, markerRectF.Y + rectHeight * 0.05f), textLayout, textBrushDx, SharpDX.Direct2D1.DrawTextOptions.None);

                textFormat.Dispose();
                textLayout.Dispose();              
            }
            catch (Exception ex) { Output.Process("Drawing Utilities Draw Price Marker: " + ex, PrintTo.OutputTab1); ; }
        }

       
        /// <summary>
        /// Draw a price marker. Use this one for a custom length marker.
        /// </summary>
        [CLSCompliant(false)]
        public static void DrawPriceMarker(RenderTarget renderTarget, ChartControl chartControl, float totalWidth, string priceStr, SharpDX.Vector2 startVector2, SimpleFont simpleFont, SharpDX.DirectWrite.TextAlignment textAlignment, SharpDX.Direct2D1.Brush textBrushDx, SharpDX.Direct2D1.Brush markerBrushDx, float markerOpacity, SharpDX.Direct2D1.Brush outlineBrushDx, int outlineWidth)
        {
            // This 'appears' to match the default NT8 price marker, although not the exact same proprietary code!
            GlyphTypeface gtf;
            Typeface tFace = new Typeface(new System.Windows.Media.FontFamily(simpleFont.Family.ToString()), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            tFace.TryGetGlyphTypeface(out gtf);
            float heightF = (float)(gtf.Height * simpleFont.Size);
            float axisWidth = (float)chartControl.AxisYRightWidth;

            if (totalWidth < 0)
                totalWidth = 0;

            try
            {
                SharpDX.DirectWrite.TextFormat textFormat = simpleFont.ToDirectWriteTextFormat();
                textFormat.TextAlignment = textAlignment;
                textFormat.WordWrapping = SharpDX.DirectWrite.WordWrapping.NoWrap;
                SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, priceStr, textFormat, totalWidth - 4f, heightF);


                float rectHeight = textLayout.Metrics.Height + 1.6f;
                //align geometry to whole pixel numbers
                rectHeight = RoundMyNumber(rectHeight);

                float rectY = RoundMyNumber(startVector2.Y - rectHeight * 0.5f);

                SharpDX.RectangleF markerRectF = new SharpDX.RectangleF(startVector2.X + 5f, rectY, totalWidth - 5f, rectHeight);

                //Combo path
                SharpDX.Direct2D1.PathGeometry pathGeometryCombo = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
                GeometrySink geometrySinkCombo = pathGeometryCombo.Open();

                geometrySinkCombo.BeginFigure(markerRectF.TopLeft, FigureBegin.Filled);
                geometrySinkCombo.AddLine(markerRectF.TopRight);
                geometrySinkCombo.AddLine(markerRectF.BottomRight);
                geometrySinkCombo.AddLine(markerRectF.BottomLeft);
                geometrySinkCombo.AddLine(startVector2);
                geometrySinkCombo.AddLine(markerRectF.TopLeft);

                //Combo plot
                geometrySinkCombo.EndFigure(FigureEnd.Open);
                geometrySinkCombo.Close();

                if (outlineBrushDx != null)
                {
                    // This worked better rather than drawing an outline.

                    //Combo path 2
                    SharpDX.Direct2D1.PathGeometry pathGeometryCombo2 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
                    GeometrySink geometrySinkCombo2 = pathGeometryCombo2.Open();

                    RectangleF outlineRectF = markerRectF;
                    //outlineRectF.Inflate(1f, 1f);
                    Vector2 outlineStart = startVector2;
                    outlineStart.X -= outlineWidth;
                    outlineRectF.X -= outlineWidth * 0.5f;
                    outlineRectF.Y -= outlineWidth;
                    outlineRectF.Height += outlineWidth * 2f;
                    outlineRectF.Width += outlineWidth * 1.5f;

                    geometrySinkCombo2.BeginFigure(outlineRectF.TopLeft, FigureBegin.Filled);
                    geometrySinkCombo2.AddLine(outlineRectF.TopRight);
                    geometrySinkCombo2.AddLine(outlineRectF.BottomRight);
                    geometrySinkCombo2.AddLine(outlineRectF.BottomLeft);
                    geometrySinkCombo2.AddLine(outlineStart);
                    geometrySinkCombo2.AddLine(outlineRectF.TopLeft);

                    //Combo plot 2
                    geometrySinkCombo2.EndFigure(FigureEnd.Open);
                    geometrySinkCombo2.Close();

                    renderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
                    renderTarget.FillGeometry(pathGeometryCombo2, outlineBrushDx);
                    renderTarget.AntialiasMode = AntialiasMode.Aliased;
                }

                if (markerBrushDx != null)
                {
                    renderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
                    markerBrushDx.Opacity = markerOpacity;
                    renderTarget.FillGeometry(pathGeometryCombo, markerBrushDx);
                    renderTarget.AntialiasMode = AntialiasMode.Aliased;
                }

                pathGeometryCombo.Dispose();
                geometrySinkCombo.Dispose();

                float width = markerRectF.Width - 5f;
                if (width < 0) return;

                renderTarget.DrawTextLayout(new Vector2(markerRectF.X, markerRectF.Y + rectHeight * 0.05f), textLayout, textBrushDx, SharpDX.Direct2D1.DrawTextOptions.None);

                textFormat.Dispose();
                textLayout.Dispose();
            }
            catch (Exception ex) { Output.Process("Drawing Utilities Draw Price Marker: " + ex, PrintTo.OutputTab1); ; }
        }

        private static float RoundMyNumber(float number)
        {
            return number % 1 > 0.5f ? (float)Math.Ceiling(number) : (float)Math.Floor(number);
        }

    }
}
