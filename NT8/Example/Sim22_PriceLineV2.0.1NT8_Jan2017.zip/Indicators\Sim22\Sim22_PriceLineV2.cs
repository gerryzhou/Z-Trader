#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.AddOns;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using DashStyle = SharpDX.Direct2D1.DashStyle;

#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable")]
    /// <summary>
    /// Sim22 - Jan 2017. Added a bar timer to show time, ticks or volume depending on the bar type respectively.
    /// </summary>
	public class Sim22_PriceLineV2 : Indicator
	{
      
        private string timerValueStr = string.Empty;
        private DateTime now = Core.Globals.Now;
        private bool connected;
        private SessionIterator sessionIterator;
        private Timer timer;
        private TimeSpan barTimerValueTimeSpan;
        private double barTimerValue = 0;
        private bool isThresholdReached = false;
        private int tickOrVolumeValue = 0;
        private double tickSize;

        private Brush timerBackgroundBrush;
        private Brush timerOutlineBrush;
        private Brush timerForegroundBrush;
        protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description							= @"Draws a horizontal line or ray across the current Close. V2 includes a timer.";
				Name								= "Sim22_PriceLineV2";
				Calculate							= Calculate.OnPriceChange;
				IsOverlay							= true;
				
				DrawOnPricePanel					= true;
				DrawHorizontalGridLines				= true;
				DrawVerticalGridLines				= true;
				PaintPriceMarkers					= false; 
                IsChartOnly                         = true;
                DisplayInDataBox                    = false;
                ScaleJustification					= ScaleJustification.Right;
				IsSuspendedWhileInactive			= false;
			    IsAutoScale                         = false;
				Length								= 100;
			    Thickness = 6; 
			    ZOrderNumber                        = -1;
			    UseThresholdColor                   = true;
			    ThresholdValue                      = 5;
			    ThresholdBrush                      = Brushes.Red;
			    ThresholdTextBrush                  = Brushes.White;
                TimerValueType                      = PriceLineV2TimerValueTypeEnum.None;
                PlotType                            = PriceLineV2DisplayOptionEnum.FullScreen;
			    UseTickSizeWidth                    = false;
			    Opacity                             = 50;
			    ColorStr                            = "Color = Instrument marker color";
			    VersionStr                          = "V2.0.1";
			}
			else if (State == State.Configure)
			{
				ZOrder = ZOrderNumber; 
                //Use the dataseries marker instead
                PaintPriceMarkers = false;
			    tickSize = TickSize;
                // If using the timer then update every tick
                Calculate = TimerValueType == PriceLineV2TimerValueTypeEnum.None ? Calculate.OnPriceChange : Calculate.OnEachTick;

                ThresholdBrush.Freeze();
                ThresholdTextBrush.Freeze();
			}
            else if (State == State.Historical)
            {
                // Set the price marker for the timer and the price line to chart properties.
                // I could have accessed these via the BrushDX properties within OnRender but this was causing NT8 to crash.

                if (ChartControl != null)
                {
                    timerBackgroundBrush = ChartControl.PrimaryBars.Properties.PriceMarker.Background;
                    timerBackgroundBrush.Freeze();
                    timerOutlineBrush = ChartControl.Properties.AxisPen.Brush;
                    timerOutlineBrush.Freeze();
                    timerForegroundBrush = ChartControl.PrimaryBars.Properties.PriceMarker.Foreground;
                    timerForegroundBrush.Freeze();
                }
            }
            else if (State == State.Terminated)
            {
                if (timer == null) return;

                timer.Enabled = false;
                timer = null;
            }
        }

        public override string FormatPriceMarker(double price)
        {
            return Instrument.MasterInstrument.FormatPrice(price);
        }

        public override string DisplayName
        {
            get
            {
                string typeStr = " (" + TimerValueType + ")";
                if (TimerValueType == PriceLineV2TimerValueTypeEnum.None)
                    typeStr = string.Empty;

                return "Sim22 PriceLine V2" + typeStr;
            }
        }

        protected override void OnBarUpdate()
        {
            try
            {

                //Prevent unnecessary historical calculations when using TickReplay
                if (CurrentBar != Bars.Count - 1)
                    return;
                if (TimerValueType == PriceLineV2TimerValueTypeEnum.None)
                    return;
                // Use timer only for intraday
                if (!Bars.BarsType.IsIntraday)
                    return;
                // If time based bars then allow the timer to display. Copied from the BarTimer indicator
                if (Bars.BarsType.IsTimeBased)
                {
                    if (timer != null) return;

                    if (IsDisplayTimerForTimeBasedBars())
                    {
                        timer = new Timer {Interval = 1000};
                        timer.Tick += OnTimerTick;
                        timer.Enabled = true;
                    }
                    return;
                }

                if (Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Tick && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Volume)
                    return;

                /*Tick or volume bars only from here*/
                string typeStr = string.Empty;

                if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Tick)
                {
                    tickOrVolumeValue = Bars.TickCount;
                    typeStr = "t";
                }
                else if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Volume)
                {
                    tickOrVolumeValue = (int) Volume[0];
                    typeStr = "v";
                }

                isThresholdReached = false;

                switch (TimerValueType)
                {
                    case PriceLineV2TimerValueTypeEnum.Countdown:
                        tickOrVolumeValue = Bars.BarsPeriod.Value - tickOrVolumeValue;
                        if (UseThresholdColor && tickOrVolumeValue < ThresholdValue)
                            isThresholdReached = true;
                        timerValueStr = tickOrVolumeValue.ToString("N0") + " " + typeStr;
                        break;
                    case PriceLineV2TimerValueTypeEnum.ActualValue:
                        if (UseThresholdColor && tickOrVolumeValue >= (Bars.BarsPeriod.Value - ThresholdValue))
                            isThresholdReached = true;
                        timerValueStr = tickOrVolumeValue.ToString("N0") + " " + typeStr;
                        break;
                    case PriceLineV2TimerValueTypeEnum.CountdownPercent:
                        if (UseThresholdColor && tickOrVolumeValue >= (Bars.BarsPeriod.Value - ThresholdValue))
                            isThresholdReached = true;
                        double percentComplete0 = RoundPercentage(Bars.PercentComplete*100);
                        timerValueStr = (100 - percentComplete0).ToString("N0") + " %";
                        break;
                    case PriceLineV2TimerValueTypeEnum.ActualValuePercent:
                        if (UseThresholdColor && tickOrVolumeValue >= (Bars.BarsPeriod.Value - ThresholdValue))
                            isThresholdReached = true;
                        double percentComplete1 = RoundPercentage(Bars.PercentComplete*100);
                        timerValueStr = (percentComplete1).ToString("N0") + " %";
                        break;
                    case PriceLineV2TimerValueTypeEnum.None:
                        break;
                }
            }
            catch (Exception ex)
            {
                Print(Name + " OnBarUpdate: " + ex);
            }
        }

        //Helper method to correctly round to a whole number
        private static double RoundPercentage(double value)
        {
            return value % 1 < 0.5 ? Math.Floor(value) : Math.Ceiling(value);
        }

        protected override void OnConnectionStatusUpdate(ConnectionStatusEventArgs connectionStatusUpdate)
        {
            // Only allow the timer when data is active
            connected = connectionStatusUpdate.PriceStatus == ConnectionStatus.Connected;
        }

        private bool IsDisplayTimerForTimeBasedBars()
        {
            return ChartControl != null && Bars != null && Bars.Count > 0 && SessionIterator.IsInSession(Now, false, true) 
                && Bars.Instrument.MarketData != null && connected && Bars.BarsType.IsTimeBased && Bars.BarsType.IsIntraday;
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            try
            {
                // Basic logic copied from the BarTimer indicator used for time-based bars only
                ForceRefresh();
                if (IsDisplayTimerForTimeBasedBars())
                {

                    if (timer != null && !timer.Enabled)
                        timer.Enabled = true;

                    isThresholdReached = false;

                    if (TimerValueType == PriceLineV2TimerValueTypeEnum.Countdown || TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValue)
                    {
                        if (TimerValueType == PriceLineV2TimerValueTypeEnum.Countdown)
                            barTimerValueTimeSpan = Bars.GetTime(Bars.Count - 1).Subtract(Now);
                        else if (TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValue)
                            barTimerValueTimeSpan = Now.Subtract(Bars.GetTime(Bars.Count - 2));

                        string barTimeLeftHoursStr = barTimerValueTimeSpan.Hours.ToString("0") + ":"; //assuming < 10 hours per bar
                        string barTimeLeftMinutesStr = barTimerValueTimeSpan.Minutes.ToString("00") + ":";
                        string barTimeLeftSecondsStr = barTimerValueTimeSpan.Seconds.ToString("00");

                        if (barTimerValueTimeSpan.Hours != 0)
                        {
                            barTimeLeftHoursStr = barTimerValueTimeSpan.Hours.ToString("0") + ":";
                            barTimeLeftMinutesStr = barTimerValueTimeSpan.Minutes.ToString("00");
                            barTimeLeftSecondsStr = string.Empty;
                        }
                        if (Bars.GetTime(Bars.Count - 1).Subtract(Now).Ticks < 0)
                        {
                            barTimeLeftHoursStr = "00:";
                            barTimeLeftMinutesStr = "00:";
                            barTimeLeftSecondsStr = "00";
                        }

                        if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Minute)
                        {
                            if (Bars.BarsPeriod.Value <= 60)
                                barTimeLeftHoursStr = string.Empty;
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.Countdown)
                            {
                                if (UseThresholdColor && barTimerValueTimeSpan.Minutes < ThresholdValue)
                                    isThresholdReached = true;
                            }
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValue)
                            {
                                if (UseThresholdColor && barTimerValueTimeSpan.Minutes >= (Bars.BarsPeriod.Value - ThresholdValue))
                                    isThresholdReached = true;
                            }
                        }
                        if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Second)
                        {
                            if (Bars.BarsPeriod.Value <= 60)
                            {
                                barTimeLeftHoursStr = string.Empty;
                                barTimeLeftMinutesStr = string.Empty;
                            }
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.Countdown)
                            {
                                if (UseThresholdColor && barTimerValueTimeSpan.Seconds < ThresholdValue)
                                    isThresholdReached = true;
                            }
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValue)
                            {
                                if (UseThresholdColor && barTimerValueTimeSpan.Seconds >= Bars.BarsPeriod.Value - ThresholdValue)
                                    isThresholdReached = true;
                            }
                        }

                        timerValueStr = barTimeLeftHoursStr + barTimeLeftMinutesStr + barTimeLeftSecondsStr;
                    }
                    else if (TimerValueType == PriceLineV2TimerValueTypeEnum.CountdownPercent || TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValuePercent)
                    {
                        TimeSpan barsPeriodTimeSpan = new TimeSpan();

                        if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Minute)
                        {
                            barsPeriodTimeSpan = new TimeSpan(0, 0, Bars.BarsPeriod.Value, 0);
                        }
                        if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Second)
                        {
                            barsPeriodTimeSpan = new TimeSpan(0, 0, 0, Bars.BarsPeriod.Value);
                        }

                        if (TimerValueType == PriceLineV2TimerValueTypeEnum.CountdownPercent)
                        {
                            barTimerValueTimeSpan = Bars.GetTime(Bars.Count - 1).Subtract(Now);
                        }
                        else if (TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValuePercent)
                        {
                            barTimerValueTimeSpan = Now.Subtract(Bars.GetTime(Bars.Count - 2));
                        }

                        if (barsPeriodTimeSpan.Ticks.CompareTo(0) != 0)
                        {
                            barTimerValue = (double) barTimerValueTimeSpan.Ticks*100/barsPeriodTimeSpan.Ticks;
                            barTimerValue = RoundPercentage(barTimerValue);
                        }

                        if (barTimerValue > 100)
                            barTimerValue = 100;
                        if (barTimerValue < 0)
                            barTimerValue = 0;

                        string barTimeValueStr = barTimerValue.ToString("N0") + " %";

                        timerValueStr = barTimeValueStr;

                        if (UseThresholdColor && ThresholdValue <= 100)
                        {
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.CountdownPercent && barTimerValue < ThresholdValue)
                                isThresholdReached = true;
                            if (TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValuePercent && barTimerValue > 100 - ThresholdValue)
                                isThresholdReached = true;
                        }
                    }
                    else //just in case
                        timerValueStr = null;
                }

            }
            catch (Exception ex)
            {
                Print(Name + " OnTimerTick: " + ex);
            }
        }

        private SessionIterator SessionIterator
        {
            get { return sessionIterator ?? (sessionIterator = new SessionIterator(Bars)); }
        }

        private DateTime Now
        {
            get
            {
                now = (Cbi.Connection.PlaybackConnection != null ? Cbi.Connection.PlaybackConnection.Now : Core.Globals.Now);

                if (now.Millisecond > 0)
                    now = Core.Globals.MinDate.AddSeconds((long) Math.Floor(now.Subtract(Core.Globals.MinDate).TotalSeconds));

                return now;
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            try
            {
                if (Bars == null || ChartControl == null || Bars.Instrument == null || !IsVisible)
                {
                    return;
                }

                Bars bars = ChartBars.Bars;
                //Start/End locations
                SharpDX.Vector2 vector0 = new SharpDX.Vector2();
                SharpDX.Vector2 vector1 = new SharpDX.Vector2();

                // round end cap
                SharpDX.Direct2D1.StrokeStyleProperties ssProps = new SharpDX.Direct2D1.StrokeStyleProperties
                {
                    //StartCap = SharpDX.Direct2D1.CapStyle.Round,
                    DashStyle = DashStyle.Solid,
                };

                SharpDX.Direct2D1.StrokeStyle myStyle = new SharpDX.Direct2D1.StrokeStyle(RenderTarget.Factory, ssProps);

                SharpDX.Direct2D1.Brush lineBrushDx = timerBackgroundBrush.ToDxBrush(RenderTarget);
                lineBrushDx.Opacity = Opacity * 0.01f;

                double closeValue = bars.GetClose(bars.Count - 1); //current bar only, not scrolled bars
                //in Pixels
                float closeYByValue = chartScale.GetYByValue(closeValue);
                
                int fullScreenLength = ChartPanel.W;	
                
                float marginX = fullScreenLength - chartControl.Properties.BarMarginRight;
        
                //make sure the data series price marker is displayed
                chartControl.PrimaryBars.Properties.PriceMarker.IsVisible = true;

                float timerMarkerBuffer = TimerValueType != PriceLineV2TimerValueTypeEnum.None ? (float)chartControl.AxisYRightWidth + 5: 0;

                switch (PlotType) 
                {
                    case PriceLineV2DisplayOptionEnum.FullScreen:
                        //vector0 is rightmost
                        vector0.X = fullScreenLength;
                        vector0.Y = closeYByValue;
                        vector1.X = 0;
                        vector1.Y = closeYByValue;
                        break;
                    case PriceLineV2DisplayOptionEnum.MarginOnly:
                        vector0.X = fullScreenLength;
                        vector0.Y = closeYByValue;
                        vector1.X = marginX + 5f;
                        vector1.Y = closeYByValue;
                        break;
                    case PriceLineV2DisplayOptionEnum.FullscreenMinusMargin:
                        vector0.X = marginX + 5f + timerMarkerBuffer;
                        vector0.Y = closeYByValue;
                        vector1.X = 0;
                        vector1.Y = closeYByValue;
                        break;
                    case PriceLineV2DisplayOptionEnum.SetLength:
                        vector0.X = fullScreenLength;
                        vector0.Y = closeYByValue;
                        vector1.X = fullScreenLength - Length;
                        vector1.Y = closeYByValue;
                        break;
                }

                float thickness = Thickness;

                if (UseTickSizeWidth && Bars.BarsType.IsIntraday)
                {
                    double priceLower = closeValue - tickSize*0.5;
                    float yLower = chartScale.GetYByValue(priceLower);
                    float yUpper = chartScale.GetYByValue(priceLower + tickSize);

                    //align geometry to whole pixel numbers
                    if (yLower%1 > 0.5)
                    {
                        yLower = (float) Math.Ceiling(yLower);
                        yUpper = (float) Math.Ceiling(yUpper);
                    }
                    else
                    {
                        yLower = (float) Math.Floor(yLower);
                        yUpper = (float) Math.Floor(yUpper);
                    }

                    thickness = yLower - yUpper;
                }
                
                if (PlotType != PriceLineV2DisplayOptionEnum.ShowOnlyTimerAtMargin)
                {
                    RenderTarget.DrawLine(vector1, vector0, lineBrushDx, thickness, myStyle);
                }
               
                // If using the timer
                if (TimerValueType != PriceLineV2TimerValueTypeEnum.None && Bars.BarsType.IsIntraday)
                {
                    try
                    {

                        SharpDX.Direct2D1.Brush timerBackgroundBrushDx = timerBackgroundBrush.ToDxBrush(RenderTarget);
                        SharpDX.Direct2D1.Brush timerTextBrushDx = timerForegroundBrush.ToDxBrush(RenderTarget);
                        SharpDX.Direct2D1.Brush timerOutlineBrushDx = timerOutlineBrush.ToDxBrush(RenderTarget);
                        SharpDX.Direct2D1.Brush timerThresholdBrushDx = ThresholdBrush.ToDxBrush(RenderTarget);
                        SharpDX.Direct2D1.Brush timerThresholdTextBrushDx = ThresholdTextBrush.ToDxBrush(RenderTarget);

                        if (TimerValueType == PriceLineV2TimerValueTypeEnum.Countdown || TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValue)
                            if (ThresholdValue > Bars.BarsPeriod.Value)
                            {
                                Draw.TextFixed(this, "Percent error", "Sim22 PriceLine V2: Please set your threshold level below the bars period \reg. You are using 15 minute bars but your threshold is set to 30 minutes.", TextPosition.Center, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, ChartControl.Properties.ChartText, null, 0);
                                return;
                            }

                        if (TimerValueType == PriceLineV2TimerValueTypeEnum.CountdownPercent || TimerValueType == PriceLineV2TimerValueTypeEnum.ActualValuePercent)
                            if (ThresholdValue > 100)
                            {
                                Draw.TextFixed(this, "Percent error", "Sim22 PriceLine V2: Please set your threshold level below 100%.", TextPosition.Center, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, ChartControl.Properties.ChartText, null, 0);
                                return;
                            }

                        float timerMarkerWidth = (float)chartControl.AxisYRightWidth + 5f;
                        float timerTotalMarkerWidth = timerMarkerWidth;
                        float priceMarkerX = fullScreenLength - timerTotalMarkerWidth;

                        if (isThresholdReached)
                        {
                            timerBackgroundBrushDx = timerThresholdBrushDx;
                            timerTextBrushDx = timerThresholdTextBrushDx;
                        }

                        if (PlotType == PriceLineV2DisplayOptionEnum.FullscreenMinusMargin || PlotType == PriceLineV2DisplayOptionEnum.ShowOnlyTimerAtMargin)
                        {
                            priceMarkerX = marginX + 5f;
                        }
                        // If the timer value string is not empty then make a marker
                        if (!timerValueStr.IsNullOrEmpty())
                        {
                            var textAlign = PlotType == PriceLineV2DisplayOptionEnum.FullScreen || PlotType == PriceLineV2DisplayOptionEnum.MarginOnly || PlotType == PriceLineV2DisplayOptionEnum.SetLength ? SharpDX.DirectWrite.TextAlignment.Center : SharpDX.DirectWrite.TextAlignment.Trailing;

                            NinjaTrader.NinjaScript.AddOns.Sim22DrawingUtilities.DrawPriceMarker(RenderTarget, chartControl, timerValueStr, new SharpDX.Vector2(priceMarkerX, closeYByValue), chartControl.Properties.LabelFont, textAlign, timerTextBrushDx, timerBackgroundBrushDx, 1.0f, timerOutlineBrushDx, 1);
							if (PlotType != PriceLineV2DisplayOptionEnum.FullscreenMinusMargin)
                                vector0.X -= timerTotalMarkerWidth;
                        }

                        timerBackgroundBrushDx.Dispose();
                        timerTextBrushDx.Dispose();
                        timerOutlineBrushDx.Dispose();
                        timerThresholdBrushDx.Dispose();
                        timerThresholdTextBrushDx.Dispose();

                    }
                    catch (Exception ex)
                    {
                        Print(Name + " OnRender Timer: " + ex);
                    }
                }

                lineBrushDx.Dispose();
                myStyle.Dispose();
            }
            catch (Exception ex)
            {
                Print(Name + " OnRender : " + ex);
            }
        }

        #region Properties

        [NinjaScriptProperty]
        [ReadOnly(true)]
        [Display(Name = "Version", Description = "Version of the indicator.", Order = 0, GroupName = "01 Priceline")]
        public string VersionStr { get; set; }

        [NinjaScriptProperty]
        [ReadOnly(true)]
        [Display(Name = "Color", Description = "Use the instrument marker color", Order = 1, GroupName = "01 Priceline")]
        public string ColorStr { get; set; }
    
        [NinjaScriptProperty]
        [Display(Name = "Plot type", Description = "How would you like it plotted?", Order = 2, GroupName = "01 Priceline")]
        public PriceLineV2DisplayOptionEnum PlotType { get; set; }

        [Range(1, int.MaxValue)]
        [NinjaScriptProperty]
        [Display(Name = "Set length", Description = "Fixed length in pixels", Order = 3, GroupName = "01 Priceline")]
        public int Length { get; set; }

        [Range(1, 30)]
        [NinjaScriptProperty]
        [Display(Name = "Thickness", Description = "Width of the plot", Order = 4, GroupName = "01 Priceline")]
        public int Thickness { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use tick size thickness?", Description = "Use to plot the width of a tick. eg. Use on footprint bars.", GroupName = "01 Priceline", Order = 13)]
        public bool UseTickSizeWidth { get; set; }

        [Range(-1000, 1000), NinjaScriptProperty]
        [Display(Name = "ZOrder", Description = "Set the order of plots. > 0 = Fore of the bars. < 0 = Behind the bars.", GroupName = "01 Priceline", Order = 14)]
        public int ZOrderNumber { get; set; }

        [Range(0, 100), NinjaScriptProperty]
        [Display(Name = "Opacity (0-100%)", Description = "Set the opacity of the line (0-100).", GroupName = "01 Priceline", Order = 15)]
        public int Opacity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plot timer?", Description = "How would you like the bar values plotted?", Order = 0, GroupName = "02 Timer")]
        public PriceLineV2TimerValueTypeEnum TimerValueType { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use threshold color?", Description = "Plot a threshold color when time/ticks/volume reaches a value.", Order = 7, GroupName = "02 Timer")]
        public bool UseThresholdColor { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Threshold value", Description = "Minute bars= in minutes, Tick bars= in ticks.\rPercentage options= in percentage.", Order = 8, GroupName = "02 Timer")]
        public int ThresholdValue { get; set; }

        [XmlIgnore]
        [Display(Name = "Threshold back color", Description = "Color of threshold alert.", Order = 9, GroupName = "02 Timer")]
        public Brush ThresholdBrush { get; set; }

        [Browsable(false)]
        public string ThresholdBrushSerializable
        {
            get { return Serialize.BrushToString(ThresholdBrush); }
            set { ThresholdBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Threshold text color", Description = "Text color of threshold alert.", Order = 10, GroupName = "02 Timer")]
        public Brush ThresholdTextBrush { get; set; }

        [Browsable(false)]
        public string ThresholdTextBrushSerializable
        {
            get { return Serialize.BrushToString(ThresholdTextBrush); }
            set { ThresholdTextBrush = Serialize.StringToBrush(value); }
        }

        #endregion
    }
}

#region Enum

public enum PriceLineV2DisplayOptionEnum
{
    FullScreen,
    MarginOnly,
    FullscreenMinusMargin,
    SetLength,
    ShowOnlyTimerAtMargin
}

public enum PriceLineV2TimerValueTypeEnum
{
    None,
    ActualValue,
    ActualValuePercent,
    Countdown,
    CountdownPercent, 
}

#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_PriceLineV2[] cacheSim22_PriceLineV2;
		public Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			return Sim22_PriceLineV2(Input, versionStr, colorStr, plotType, length, thickness, useTickSizeWidth, zOrderNumber, opacity, timerValueType, useThresholdColor, thresholdValue);
		}

		public Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(ISeries<double> input, string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			if (cacheSim22_PriceLineV2 != null)
				for (int idx = 0; idx < cacheSim22_PriceLineV2.Length; idx++)
					if (cacheSim22_PriceLineV2[idx] != null && cacheSim22_PriceLineV2[idx].VersionStr == versionStr && cacheSim22_PriceLineV2[idx].ColorStr == colorStr && cacheSim22_PriceLineV2[idx].PlotType == plotType && cacheSim22_PriceLineV2[idx].Length == length && cacheSim22_PriceLineV2[idx].Thickness == thickness && cacheSim22_PriceLineV2[idx].UseTickSizeWidth == useTickSizeWidth && cacheSim22_PriceLineV2[idx].ZOrderNumber == zOrderNumber && cacheSim22_PriceLineV2[idx].Opacity == opacity && cacheSim22_PriceLineV2[idx].TimerValueType == timerValueType && cacheSim22_PriceLineV2[idx].UseThresholdColor == useThresholdColor && cacheSim22_PriceLineV2[idx].ThresholdValue == thresholdValue && cacheSim22_PriceLineV2[idx].EqualsInput(input))
						return cacheSim22_PriceLineV2[idx];
			return CacheIndicator<Sim22.Sim22_PriceLineV2>(new Sim22.Sim22_PriceLineV2(){ VersionStr = versionStr, ColorStr = colorStr, PlotType = plotType, Length = length, Thickness = thickness, UseTickSizeWidth = useTickSizeWidth, ZOrderNumber = zOrderNumber, Opacity = opacity, TimerValueType = timerValueType, UseThresholdColor = useThresholdColor, ThresholdValue = thresholdValue }, input, ref cacheSim22_PriceLineV2);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			return indicator.Sim22_PriceLineV2(Input, versionStr, colorStr, plotType, length, thickness, useTickSizeWidth, zOrderNumber, opacity, timerValueType, useThresholdColor, thresholdValue);
		}

		public Indicators.Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(ISeries<double> input , string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			return indicator.Sim22_PriceLineV2(input, versionStr, colorStr, plotType, length, thickness, useTickSizeWidth, zOrderNumber, opacity, timerValueType, useThresholdColor, thresholdValue);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			return indicator.Sim22_PriceLineV2(Input, versionStr, colorStr, plotType, length, thickness, useTickSizeWidth, zOrderNumber, opacity, timerValueType, useThresholdColor, thresholdValue);
		}

		public Indicators.Sim22.Sim22_PriceLineV2 Sim22_PriceLineV2(ISeries<double> input , string versionStr, string colorStr, PriceLineV2DisplayOptionEnum plotType, int length, int thickness, bool useTickSizeWidth, int zOrderNumber, int opacity, PriceLineV2TimerValueTypeEnum timerValueType, bool useThresholdColor, int thresholdValue)
		{
			return indicator.Sim22_PriceLineV2(input, versionStr, colorStr, plotType, length, thickness, useTickSizeWidth, zOrderNumber, opacity, timerValueType, useThresholdColor, thresholdValue);
		}
	}
}

#endregion
