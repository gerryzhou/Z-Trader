#region Using declarations
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Xml.Serialization;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
	/// <summary>
	/// The Moving Median is an indicator that shows the average value of a security's price over a period of time.
	/// </summary>
	[Description("The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.")]
	public class anaMovingMedian : Indicator
	{
		#region Variables
		private int	period			= 20;
		private int lookback		= 0;
		private int mIndex			= 0;
		private bool even			= true;
		private List<double> mList 	= new List<double>();
		#endregion

		/// <summary>
		/// This method is used to configure the indicator and is called once before any bar data is loaded.
		/// </summary>
		protected override void Initialize()
		{
			Add(new Plot(Color.DeepSkyBlue, "anaMovingMedian"));
			Overlay = true;
		}

		protected override void OnStartUp()
		{
			for (int i = 0; i < period; i++)
				mList.Add(0.0);
			if (period % 2 == 0)
			{
				even = true;
				mIndex = period/2;
			}
			else
			{
				even = false;
				mIndex = (period - 1)/2;
			}
		}
		
		/// <summary>
		/// Called on each bar update event (incoming tick).
		/// </summary>
		protected override void OnBarUpdate()
		{
			if(CurrentBar < period)
			{
				int lookback = CurrentBar + 1;
				for (int i = 0; i < lookback; i++)
					mList[i] = Input[i];
				for (int i = lookback; i < period; i++)
					mList[i] = 0.0;
				mList.Sort();
				if (lookback % 2 == 0)
					Value.Set( 0.5 * (mList[period - lookback/2] + mList[period - lookback/2 - 1]));
				else
					Value.Set(mList[period - (lookback + 1)/2]);
			}	
			else
			{
				for (int i = 0; i < period; i++)
					mList[i] = Input[i];
				mList.Sort();
				if (even)
					Value.Set( 0.5 * (mList[mIndex] + mList[mIndex-1]));
				else
					Value.Set( mList[mIndex]);
			}
		}

		#region Properties
		/// <summary>
		/// </summary>
		[Description("Numbers of bars used for calculations")]
		[GridCategory("Parameters")]
		public int Period
		{
			get { return period; }
			set { period = Math.Max(1, value); }
		}
        #endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private anaMovingMedian[] cacheanaMovingMedian = null;

        private static anaMovingMedian checkanaMovingMedian = new anaMovingMedian();

        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        public anaMovingMedian anaMovingMedian(int period)
        {
            return anaMovingMedian(Input, period);
        }

        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        public anaMovingMedian anaMovingMedian(Data.IDataSeries input, int period)
        {
            if (cacheanaMovingMedian != null)
                for (int idx = 0; idx < cacheanaMovingMedian.Length; idx++)
                    if (cacheanaMovingMedian[idx].Period == period && cacheanaMovingMedian[idx].EqualsInput(input))
                        return cacheanaMovingMedian[idx];

            lock (checkanaMovingMedian)
            {
                checkanaMovingMedian.Period = period;
                period = checkanaMovingMedian.Period;

                if (cacheanaMovingMedian != null)
                    for (int idx = 0; idx < cacheanaMovingMedian.Length; idx++)
                        if (cacheanaMovingMedian[idx].Period == period && cacheanaMovingMedian[idx].EqualsInput(input))
                            return cacheanaMovingMedian[idx];

                anaMovingMedian indicator = new anaMovingMedian();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Period = period;
                Indicators.Add(indicator);
                indicator.SetUp();

                anaMovingMedian[] tmp = new anaMovingMedian[cacheanaMovingMedian == null ? 1 : cacheanaMovingMedian.Length + 1];
                if (cacheanaMovingMedian != null)
                    cacheanaMovingMedian.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheanaMovingMedian = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaMovingMedian anaMovingMedian(int period)
        {
            return _indicator.anaMovingMedian(Input, period);
        }

        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaMovingMedian anaMovingMedian(Data.IDataSeries input, int period)
        {
            return _indicator.anaMovingMedian(input, period);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaMovingMedian anaMovingMedian(int period)
        {
            return _indicator.anaMovingMedian(Input, period);
        }

        /// <summary>
        /// The anaMovingMedian (Simple Moving Average) is an indicator that shows the average value of a security's price over a period of time.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaMovingMedian anaMovingMedian(Data.IDataSeries input, int period)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.anaMovingMedian(input, period);
        }
    }
}
#endregion
