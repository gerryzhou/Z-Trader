#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// anaEhlersFilter
    /// </summary>
    [Description("anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf")]
    public class anaEhlersFilter : Indicator
    {
		#region Variables
			private int 			period 		= 15; 
			private int 			length		= 0;
			private int 			count		= 0;       
			private int 			lookback	= 0;    
			private double			distance2	= 0.0;
			private double 			Num 		= 0.0;
			private double 			SumCoef  	= 0.0;
			private List<double> 	Coef		= new List<double>();        
			private TMA 			Smooth;
		#endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded
        /// </summary>	
        protected override void Initialize()			
        {
	     	Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "Filter"));
	     	Overlay				= true;
	      	PriceTypeSupported	= true; 
			if(Period > 256)
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
        }
        
		protected override void OnStartUp()
		{
			Smooth = TMA(Math.Min(period,4));
			for (int i=0; i < period; i++)
				Coef.Add(0.0);
		}
		
		/// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>		
        protected override void OnBarUpdate()		
        {	
			if(CurrentBar < 2)
			{
				Filter.Set(Smooth[0]);
				return;
			}
			if (CurrentBar < 2 * period - 1)
				length = CurrentBar/2 + 1;
			else
				length = period;
	        for (count = 0; count < length; count++)
            {
                distance2 = 0;
                for (lookback = 1; lookback < length; lookback++)						
            	 	distance2 = distance2 + (Smooth[count] - Smooth[count + lookback])*(Smooth[count] - Smooth[count + lookback]);		
				Coef[count] = distance2;                           
			}
			Num 	= 0.0;
            SumCoef = 0.0;	
			for (count = 0; count < length; count++)							
			{						
               	Num = Num + Coef[count]*Smooth[count];
               	SumCoef =  SumCoef + Coef[count];
			}
         	if(SumCoef != 0) 
				Filter.Set( Num/SumCoef );
			else if (period > 1)
				Filter.Set(Filter[1]);
			else
				Filter.Set(Smooth[count]);
		}
        
        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Filter
        {
            get { return Values[0]; }
        }

        [Description("Default setting for Length")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private anaEhlersFilter[] cacheanaEhlersFilter = null;

        private static anaEhlersFilter checkanaEhlersFilter = new anaEhlersFilter();

        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        public anaEhlersFilter anaEhlersFilter(int period)
        {
            return anaEhlersFilter(Input, period);
        }

        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        public anaEhlersFilter anaEhlersFilter(Data.IDataSeries input, int period)
        {
            if (cacheanaEhlersFilter != null)
                for (int idx = 0; idx < cacheanaEhlersFilter.Length; idx++)
                    if (cacheanaEhlersFilter[idx].Period == period && cacheanaEhlersFilter[idx].EqualsInput(input))
                        return cacheanaEhlersFilter[idx];

            lock (checkanaEhlersFilter)
            {
                checkanaEhlersFilter.Period = period;
                period = checkanaEhlersFilter.Period;

                if (cacheanaEhlersFilter != null)
                    for (int idx = 0; idx < cacheanaEhlersFilter.Length; idx++)
                        if (cacheanaEhlersFilter[idx].Period == period && cacheanaEhlersFilter[idx].EqualsInput(input))
                            return cacheanaEhlersFilter[idx];

                anaEhlersFilter indicator = new anaEhlersFilter();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Period = period;
                Indicators.Add(indicator);
                indicator.SetUp();

                anaEhlersFilter[] tmp = new anaEhlersFilter[cacheanaEhlersFilter == null ? 1 : cacheanaEhlersFilter.Length + 1];
                if (cacheanaEhlersFilter != null)
                    cacheanaEhlersFilter.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheanaEhlersFilter = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaEhlersFilter anaEhlersFilter(int period)
        {
            return _indicator.anaEhlersFilter(Input, period);
        }

        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        public Indicator.anaEhlersFilter anaEhlersFilter(Data.IDataSeries input, int period)
        {
            return _indicator.anaEhlersFilter(input, period);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaEhlersFilter anaEhlersFilter(int period)
        {
            return _indicator.anaEhlersFilter(Input, period);
        }

        /// <summary>
        /// anaEhlersFilter, see paper http://www.mesasoftware.com/Papers/Ehlers%20Filters.pdf
        /// </summary>
        /// <returns></returns>
        public Indicator.anaEhlersFilter anaEhlersFilter(Data.IDataSeries input, int period)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.anaEhlersFilter(input, period);
        }
    }
}
#endregion
