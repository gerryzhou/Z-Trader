#region Using declarations
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.ComponentModel;
using System.Collections;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

#region Global Enums

public enum anaVolaBandMAType {Median, ADXVMA, Butterworth_2, Butterworth_3, DEMA, DSMA, DTMA, DWMA, Ehlers, EMA, Gauss_2, Gauss_3, Gauss_4, 
			HMA, HoltEMA, LinReg, SMA, SuperSmoother_2, SuperSmoother_3, TEMA, TMA, TSMA, TWMA, VWMA, WMA, ZeroLagHATEMA, ZeroLagTEMA, ZLEMA}
public enum anaVolaBandRangeType {SimpleRange, TrueRange}

#endregion

//This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
	/// <summary>
	/// Bollinger Bands are plotted at standard deviation levels above and below a moving average. Since standard deviation is a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
	/// </summary>
	[Description("Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.")]
    public class anaVolaChannels : Indicator
	{
		#region Variables
			private	double 				numMultiplier1			= 1.75;
			private	double 				numMultiplier2			= 2.5;
			private	double 				numMultiplier3			= 4.0;
			private double 				middle					= 0.0;
			private double 				upper					= 0.0;
			private double 				lower					= 0.0;
			private int 				period					= 45;
			private int 				bandPeriod				= 45;
			private anaVolaBandMAType 	channelMAType			= anaVolaBandMAType.SMA; 
			private anaVolaBandMAType 	midbandMAType			= anaVolaBandMAType.EMA; 
			private anaVolaBandRangeType selectedRangeType		= anaVolaBandRangeType.TrueRange;
			private bool 				smoothed				= false;
			private int 				channelOpacity			= 5;
			private int					displacement			= 0;
			private int 				plot0Width 				= 2;
			private PlotStyle			plot0Style 				= PlotStyle.Line;
			private DashStyle 			dash0Style 				= DashStyle.Solid;
			private int 				plot1Width 				= 1;
			private PlotStyle 			plot1Style 				= PlotStyle.Line;
			private DashStyle 			dash1Style 				= DashStyle.Dash;
			private Color 				upper1Color 			= Color.Red;
			private Color 				upper2Color 			= Color.Coral;
			private Color 				upper3Color 			= Color.LightSalmon;
			private Color 				midbandColor 			= Color.Yellow;
			private Color 				lower1Color 			= Color.GreenYellow;
			private Color 				lower2Color 			= Color.LightGreen;
			private Color 				lower3Color 			= Color.Lime;
			private Color 				upperChannelColor 		= Color.DarkRed;
			private Color 				midChannelColor			= Color.Goldenrod;
			private Color				lowerChannelColor		= Color.LimeGreen;
			private IDataSeries 		rangeSeries;
			private IDataSeries			average;
			private IDataSeries 		smoothedAverage;
			private IDataSeries 		volatility;
			private IDataSeries 		smoothedVolatility;
			private IDataSeries 		averageTrueRange;
		#endregion

		/// <summary>
		/// This method is used to configure the indicator and is called once before any bar data is loaded.
		/// </summary>
		
		protected override void Initialize()
		{
			Add(new Plot(Color.Gray, "Middle band"));
			Add(new Plot(Color.Gray, "Upper band 3"));
			Add(new Plot(Color.Gray, "Upper band 2"));
			Add(new Plot(Color.Gray, "Upper band 1"));
			Add(new Plot(Color.Gray, "Lower band 1"));
			Add(new Plot(Color.Gray, "Lower midband 2"));
			Add(new Plot(Color.Gray, "Lower midband 3"));
			
			PriceType			= PriceType.Typical;
			Overlay				= true;
			PlotsConfigurable   = false;
		}

		protected override void OnStartUp()
		{
			switch (selectedRangeType)
			{
				case anaVolaBandRangeType.SimpleRange:
					rangeSeries = Range();
					break;
				case anaVolaBandRangeType.TrueRange:
					rangeSeries = ATR(Input,1);
					break;
			}
			switch (midbandMAType)
			{
				case anaVolaBandMAType.Median: 
					average = anaMovingMedian(Typical, Period);
					break;
				case anaVolaBandMAType.ADXVMA: 
					average = anaADXVMA(Typical, Period);
					break;
				case anaVolaBandMAType.Butterworth_2: 
					average = anaButterworthFilter(Typical, Period, 2);
					break;
				case anaVolaBandMAType.Butterworth_3: 
					average = anaButterworthFilter(Typical, Period, 3);
					break;
				case anaVolaBandMAType.DEMA: 
					average = DEMA(Typical, Period);
					break;
				case anaVolaBandMAType.DSMA: 
					average = DSMA(Typical, Period);
					break;
				case anaVolaBandMAType.DTMA: 
					average = DTMA(Typical, Period);
					break;
				case anaVolaBandMAType.DWMA: 
					average = DWMA(Typical, Period);
					break;
				case anaVolaBandMAType.Ehlers: 
					average = anaEhlersFilter(Typical, Period);
					break;
				case anaVolaBandMAType.EMA: 
					average = EMA(Typical, Period);
					break;
				case anaVolaBandMAType.Gauss_2: 
					average = anaGaussianFilter(Typical, Period, 2);
					break;
				case anaVolaBandMAType.Gauss_3: 
					average = anaGaussianFilter(Typical, Period, 3);
					break;
				case anaVolaBandMAType.Gauss_4: 
					average = anaGaussianFilter(Typical, Period, 4);
					break;
				case anaVolaBandMAType.HMA: 
					average = HMA(Typical, Period);
					break;
				case anaVolaBandMAType.HoltEMA: 
					average = anaHoltEMA(Typical, Period, 2*Period);
					break;
				case anaVolaBandMAType.LinReg: 
					average = LinReg(Typical, Period);
					break;
				case anaVolaBandMAType.SMA: 
					average = SMA(Typical, Period);
					break;
				case anaVolaBandMAType.SuperSmoother_2: 
					average = anaSuperSmootherFilter(Typical, Period, 2);
					break;
				case anaVolaBandMAType.SuperSmoother_3: 
					average = anaSuperSmootherFilter(Typical, Period, 3);
					break;
				case anaVolaBandMAType.TEMA: 
					average = TEMA(Typical, Period);
					break;
				case anaVolaBandMAType.TMA: 
					average = TMA(Typical, Period);
					break;
				case anaVolaBandMAType.TSMA: 
					average = TSMA(Typical, Period);
					break;
				case anaVolaBandMAType.TWMA: 
					average = TWMA(Typical, Period);
					break;
				case anaVolaBandMAType.VWMA: 
					average = VWMA(Typical, Period);
					break;
				case anaVolaBandMAType.WMA: 
					average = WMA(Typical, Period);
					break;
				case anaVolaBandMAType.ZeroLagHATEMA: 
					average = anaZeroLagHATEMA(Typical, Period);
					break;
				case anaVolaBandMAType.ZeroLagTEMA: 
					average = ZeroLagTEMA(Typical, Period);
					break;
				case anaVolaBandMAType.ZLEMA: 
					average = ZLEMA(Typical, Period);
					break;
			}
			if(smoothed)
				smoothedAverage = SMA(average,3);
			else
				smoothedAverage = average;
			
			switch (channelMAType)
			{
				case anaVolaBandMAType.Median: 
					volatility = anaMovingMedian(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.ADXVMA: 
					volatility = anaADXVMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.Butterworth_2: 
					volatility = anaButterworthFilter(rangeSeries, BandPeriod, 2);
					break;
				case anaVolaBandMAType.Butterworth_3: 
					volatility = anaButterworthFilter(rangeSeries, BandPeriod, 3);
					break;
				case anaVolaBandMAType.DEMA: 
					volatility = DEMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.DSMA: 
					volatility = DSMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.DTMA: 
					volatility = DTMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.DWMA: 
					volatility = DWMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.Ehlers: 
					volatility = anaEhlersFilter(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.EMA: 
					volatility = EMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.Gauss_2: 
					volatility = anaGaussianFilter(rangeSeries, BandPeriod, 2);
					break;
				case anaVolaBandMAType.Gauss_3: 
					volatility = anaGaussianFilter(rangeSeries, BandPeriod, 3);
					break;
				case anaVolaBandMAType.Gauss_4: 
					volatility = anaGaussianFilter(rangeSeries, BandPeriod, 4);
					break;
				case anaVolaBandMAType.HMA: 
					volatility = HMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.HoltEMA: 
					volatility = anaHoltEMA(rangeSeries, BandPeriod, 2*BandPeriod);
					break;
				case anaVolaBandMAType.LinReg: 
					volatility = LinReg(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.SMA: 
					volatility = SMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.SuperSmoother_2: 
					volatility = anaSuperSmootherFilter(rangeSeries, BandPeriod, 2);
					break;
				case anaVolaBandMAType.SuperSmoother_3: 
					volatility = anaSuperSmootherFilter(rangeSeries, BandPeriod, 3);
					break;
				case anaVolaBandMAType.TEMA: 
					volatility = TEMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.TMA: 
					volatility = TMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.TSMA: 
					volatility = TSMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.TWMA: 
					volatility = TWMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.VWMA: 
					volatility = VWMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.WMA: 
					volatility = WMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.ZeroLagHATEMA: 
					volatility = anaZeroLagHATEMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.ZeroLagTEMA: 
					volatility = ZeroLagTEMA(rangeSeries, BandPeriod);
					break;
				case anaVolaBandMAType.ZLEMA: 
					volatility = ZLEMA(rangeSeries, BandPeriod);
					break;
			}
			if(smoothed)
				smoothedVolatility = SMA(volatility,3);
			else
				smoothedVolatility = volatility;
			
			averageTrueRange = ATR(20);
			Plots[0].Pen.Width = plot0Width;
			Plots[0].PlotStyle = plot0Style;
			Plots[0].Pen.DashStyle = dash0Style;
			Plots[0].Pen.Color = midbandColor;
			Plots[1].Pen.Width= plot0Width;
			Plots[1].PlotStyle = plot0Style;
			Plots[1].Pen.DashStyle = dash0Style;
			Plots[1].Pen.Color = upper3Color;
			Plots[2].Pen.Width = plot1Width;
			Plots[2].PlotStyle = plot1Style;
			Plots[2].Pen.DashStyle = dash1Style;
			Plots[2].Pen.Color = upper2Color;
			Plots[3].Pen.Width = plot1Width;
			Plots[3].PlotStyle = plot1Style;
			Plots[3].Pen.DashStyle = dash1Style;
			Plots[3].Pen.Color = upper1Color;
			Plots[4].Pen.Width = plot1Width;
			Plots[4].PlotStyle = plot1Style;
			Plots[4].Pen.DashStyle = dash1Style;
			Plots[4].Pen.Color = lower1Color;
			Plots[5].Pen.Width = plot1Width;
			Plots[5].PlotStyle = plot1Style;
			Plots[5].Pen.DashStyle = dash1Style;
			Plots[5].Pen.Color = lower2Color;
			Plots[6].Pen.Width = plot0Width;
			Plots[6].PlotStyle = plot0Style;
			Plots[6].Pen.DashStyle = dash0Style;
			Plots[6].Pen.Color = lower3Color;
		}
		
		/// <summary>
		/// Called on each bar update event (incoming tick)
		/// </summary>
		protected override void OnBarUpdate()
		{
			double averageValue = smoothedAverage[0];
			double offset1 = numMultiplier1 * smoothedVolatility[0];
			double offset2 = numMultiplier2 * smoothedVolatility[0];
			double offset3 = numMultiplier3 * smoothedVolatility[0];
			
            Middle.Set(averageValue);
			Upper3.Set(averageValue + offset3);
			Upper2.Set(averageValue + offset2);
			Upper1.Set(averageValue + offset1);
			Lower1.Set(averageValue - offset1);
			Lower2.Set(averageValue - offset2);
			Lower3.Set(averageValue - offset3);
			
			if(channelOpacity > 0)
			{
				DrawRegion("upper channel", CurrentBar, 0, Upper3, Upper1, Color.Transparent, upperChannelColor, channelOpacity);
				DrawRegion("mid channel", CurrentBar, 0, Upper1, Lower1, Color.Transparent, midChannelColor, channelOpacity);
				DrawRegion("lower channel", CurrentBar, 0,Lower1, Lower3, Color.Transparent, lowerChannelColor, channelOpacity);
			}
		}

		#region Properties
		/// <summary>
		/// Get the upper value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Middle
		{
			get { return Values[0]; }
		}

		/// <summary>
		/// Get the middle value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Upper3
		{
			get { return Values[1]; }
		}
		
		/// <summary>
		/// Gets the lower value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Upper2
		{
			get { return Values[2]; }
		}

		/// <summary>
		/// Get the upper value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Upper1
		{
			get { return Values[3]; }
		}

		/// <summary>
		/// Get the upper value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Lower1
		{
			get { return Values[4]; }
		}

		/// <summary>
		/// Get the upper value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Lower2
		{
			get { return Values[5]; }
		}

		/// <summary>
		/// Get the upper value.
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries Lower3
		{
			get { return Values[6]; }
		}

		/// <summary>
		/// </summary>
		[Description("Moving average type for midband")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("MA Type for midband")]
		public anaVolaBandMAType MidbandMAType
		{
			get { return midbandMAType; }
			set { midbandMAType = value; }
		}

		/// <summary>
		/// </summary>
		[Description("Moving average type used to calculate the offset from the true range or simple range.")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("MAType for offset")]
		public anaVolaBandMAType ChannelMAType
		{
			get { return channelMAType; }
			set { channelMAType = value; }
		}

		/// <summary>
		/// </summary>
		[Description("Simple or True Range")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Range type")]
		public anaVolaBandRangeType SelectedRangeType
		{
			get { return selectedRangeType; }
			set { selectedRangeType = value; }
		}

		/// <summary>
		/// </summary>
		[Description("Multiplier for average range or average true range")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Multiplier inner bands")]
		public double NumMultiplier1
		{
			get { return numMultiplier1; }
			set { numMultiplier1 = Math.Max(0, value); }
		}

		/// <summary>
		/// </summary>
		[Description("Multiplier for average range or average true range")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Multiplier middle bands")]
		public double NumMultiplier2
		{
			get { return numMultiplier2; }
			set { numMultiplier2 = Math.Max(0, value); }
		}

		/// <summary>
		/// </summary>
		[Description("Multiplier for average range or average true range")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Multiplier outer bands")]
		public double NumMultiplier3
		{
			get { return numMultiplier3; }
			set { numMultiplier3 = Math.Max(0, value); }
		}

		/// <summary>
		/// </summary>
		[Description("Number of bars used for calculation of midband")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Period for midband")]
		public int Period
		{
			get { return period; }
			set { period = Math.Max(1, value); }
		}

		/// <summary>
		/// </summary>
		[Description("Number of Bars Used for Calculation of Volatility")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Period for offset")]
		public int BandPeriod
		{
			get { return bandPeriod; }
			set { bandPeriod = Math.Max(1, value); }
		}

		/// <summary>
		/// </summary>
		[Description("Smoothing for Center Line and Channels")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Smoothed channels")]
		public bool Smoothed
		{
			get { return smoothed; }
			set { smoothed = value; }
		}

		/// <summary>
		/// </summary>
		[Description("Select color for Upper band 1")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Upper band 1")]
		public Color Upper1Color
		{
			get { return upper1Color; }
			set { upper1Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Upper1ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upper1Color); }
			set { upper1Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Upper band 2")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Upper band 2")]
		public Color Upper2Color
		{
			get { return upper2Color; }
			set { upper2Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Upper2ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upper2Color); }
			set { upper2Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Upper band 3")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Upper band 3")]
		public Color Upper3Color
		{
			get { return upper3Color; }
			set { upper3Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Upper3ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upper3Color); }
			set { upper3Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for midband ")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Midband")]
		public Color MidbandColor
		{
			get { return midbandColor; }
			set { midbandColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string MidbandColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(midbandColor); }
			set { midbandColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Lower band 1")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Lower band 1")]
		public Color Lower1Color
		{
			get { return lower1Color; }
			set { lower1Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Lower1ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(lower1Color); }
			set { lower1Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Lower band 2")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Lower band 2")]
		public Color Lower2Color
		{
			get { return lower2Color; }
			set { lower2Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Lower2ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(lower2Color); }
			set { lower2Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Lower band 3")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Lower band 3")]
		public Color Lower3Color
		{
			get { return lower3Color; }
			set { lower3Color = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string Lower3ColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(lower3Color); }
			set { lower3Color = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Upper Channel")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Upper channel")]
		public Color UpperChannelColor
		{
			get { return upperChannelColor; }
			set { upperChannelColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string UpperChannelColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(upperChannelColor); }
			set { upperChannelColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Select color for Mid Channel")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Mid channel")]
		public Color MidChannelColor
		{
			get { return midChannelColor; }
			set { midChannelColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string MidChannelColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(midChannelColor); }
			set { midChannelColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}		
		
		/// <summary>
		/// </summary>
		[Description("Select color for Lower Channel")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Lower channel")]
		public Color LowerChannelColor
		{
			get { return lowerChannelColor; }
			set { lowerChannelColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string LowerChannelColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(lowerChannelColor); }
			set { lowerChannelColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Width for channel bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Width channel lines")]
		public int Plot0Width
		{
			get { return plot0Width; }
			set { plot0Width = Math.Max(1, value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("PlotStyle for channel bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Plot style channel lines")]
		public PlotStyle Plot0Style
		{
			get { return plot0Style; }
			set { plot0Style = value; }
		}
		
		/// <summary>
		/// </summary>
		[Description("DashStyle for channel bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Dash style channel lines")]
		public DashStyle Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		} 
		/// <summary>
		/// </summary>
		[Description("Width for secondary bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Line width inner bands")]
		public int Plot1Width
		{
			get { return plot1Width; }
			set { plot1Width = Math.Max(1, value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("PlotStyle for secondary bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Plot style inner bands")]
		public PlotStyle Plot1Style
		{
			get { return plot1Style; }
			set { plot1Style = value; }
		}
		
		/// <summary>
		/// </summary>
		[Description("DashStyle for secondary bands.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Dash style inner bands")]
		public DashStyle Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		} 

		/// <summary>
		/// </summary>
		[Description("Select opacity for the area between the upper and lower band of the Vola Bands.")]
		[Category("Plot Parameters")]
		public int ChannelOpacity
		{
			get { return channelOpacity; }
			set { channelOpacity = Math.Max(0, value); }
		}
		#endregion
	}
}		

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private anaVolaChannels[] cacheanaVolaChannels = null;

        private static anaVolaChannels checkanaVolaChannels = new anaVolaChannels();

        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        public anaVolaChannels anaVolaChannels(int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            return anaVolaChannels(Input, bandPeriod, channelMAType, midbandMAType, numMultiplier1, numMultiplier2, numMultiplier3, period, selectedRangeType, smoothed);
        }

        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        public anaVolaChannels anaVolaChannels(Data.IDataSeries input, int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            if (cacheanaVolaChannels != null)
                for (int idx = 0; idx < cacheanaVolaChannels.Length; idx++)
                    if (cacheanaVolaChannels[idx].BandPeriod == bandPeriod && cacheanaVolaChannels[idx].ChannelMAType == channelMAType && cacheanaVolaChannels[idx].MidbandMAType == midbandMAType && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier1 - numMultiplier1) <= double.Epsilon && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier2 - numMultiplier2) <= double.Epsilon && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier3 - numMultiplier3) <= double.Epsilon && cacheanaVolaChannels[idx].Period == period && cacheanaVolaChannels[idx].SelectedRangeType == selectedRangeType && cacheanaVolaChannels[idx].Smoothed == smoothed && cacheanaVolaChannels[idx].EqualsInput(input))
                        return cacheanaVolaChannels[idx];

            lock (checkanaVolaChannels)
            {
                checkanaVolaChannels.BandPeriod = bandPeriod;
                bandPeriod = checkanaVolaChannels.BandPeriod;
                checkanaVolaChannels.ChannelMAType = channelMAType;
                channelMAType = checkanaVolaChannels.ChannelMAType;
                checkanaVolaChannels.MidbandMAType = midbandMAType;
                midbandMAType = checkanaVolaChannels.MidbandMAType;
                checkanaVolaChannels.NumMultiplier1 = numMultiplier1;
                numMultiplier1 = checkanaVolaChannels.NumMultiplier1;
                checkanaVolaChannels.NumMultiplier2 = numMultiplier2;
                numMultiplier2 = checkanaVolaChannels.NumMultiplier2;
                checkanaVolaChannels.NumMultiplier3 = numMultiplier3;
                numMultiplier3 = checkanaVolaChannels.NumMultiplier3;
                checkanaVolaChannels.Period = period;
                period = checkanaVolaChannels.Period;
                checkanaVolaChannels.SelectedRangeType = selectedRangeType;
                selectedRangeType = checkanaVolaChannels.SelectedRangeType;
                checkanaVolaChannels.Smoothed = smoothed;
                smoothed = checkanaVolaChannels.Smoothed;

                if (cacheanaVolaChannels != null)
                    for (int idx = 0; idx < cacheanaVolaChannels.Length; idx++)
                        if (cacheanaVolaChannels[idx].BandPeriod == bandPeriod && cacheanaVolaChannels[idx].ChannelMAType == channelMAType && cacheanaVolaChannels[idx].MidbandMAType == midbandMAType && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier1 - numMultiplier1) <= double.Epsilon && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier2 - numMultiplier2) <= double.Epsilon && Math.Abs(cacheanaVolaChannels[idx].NumMultiplier3 - numMultiplier3) <= double.Epsilon && cacheanaVolaChannels[idx].Period == period && cacheanaVolaChannels[idx].SelectedRangeType == selectedRangeType && cacheanaVolaChannels[idx].Smoothed == smoothed && cacheanaVolaChannels[idx].EqualsInput(input))
                            return cacheanaVolaChannels[idx];

                anaVolaChannels indicator = new anaVolaChannels();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.BandPeriod = bandPeriod;
                indicator.ChannelMAType = channelMAType;
                indicator.MidbandMAType = midbandMAType;
                indicator.NumMultiplier1 = numMultiplier1;
                indicator.NumMultiplier2 = numMultiplier2;
                indicator.NumMultiplier3 = numMultiplier3;
                indicator.Period = period;
                indicator.SelectedRangeType = selectedRangeType;
                indicator.Smoothed = smoothed;
                Indicators.Add(indicator);
                indicator.SetUp();

                anaVolaChannels[] tmp = new anaVolaChannels[cacheanaVolaChannels == null ? 1 : cacheanaVolaChannels.Length + 1];
                if (cacheanaVolaChannels != null)
                    cacheanaVolaChannels.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheanaVolaChannels = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaVolaChannels anaVolaChannels(int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            return _indicator.anaVolaChannels(Input, bandPeriod, channelMAType, midbandMAType, numMultiplier1, numMultiplier2, numMultiplier3, period, selectedRangeType, smoothed);
        }

        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaVolaChannels anaVolaChannels(Data.IDataSeries input, int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            return _indicator.anaVolaChannels(input, bandPeriod, channelMAType, midbandMAType, numMultiplier1, numMultiplier2, numMultiplier3, period, selectedRangeType, smoothed);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaVolaChannels anaVolaChannels(int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            return _indicator.anaVolaChannels(Input, bandPeriod, channelMAType, midbandMAType, numMultiplier1, numMultiplier2, numMultiplier3, period, selectedRangeType, smoothed);
        }

        /// <summary>
        /// Volatility bands are plotted at a multiple of the simple or average true range above and below a moving average. Since range and average true range are a measure of volatility, the bands are self-adjusting: widening during volatile markets and contracting during calmer periods.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaVolaChannels anaVolaChannels(Data.IDataSeries input, int bandPeriod, anaVolaBandMAType channelMAType, anaVolaBandMAType midbandMAType, double numMultiplier1, double numMultiplier2, double numMultiplier3, int period, anaVolaBandRangeType selectedRangeType, bool smoothed)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.anaVolaChannels(input, bandPeriod, channelMAType, midbandMAType, numMultiplier1, numMultiplier2, numMultiplier3, period, selectedRangeType, smoothed);
        }
    }
}
#endregion
