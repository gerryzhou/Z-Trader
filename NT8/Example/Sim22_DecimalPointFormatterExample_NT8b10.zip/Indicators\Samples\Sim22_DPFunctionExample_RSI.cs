// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;

using NinjaTrader.NinjaScript.AddOns;

#endregion

namespace NinjaTrader.NinjaScript.Indicators.Samples
{
	/// <summary>
	/// Using NinjaTrader.NinjaScript.Addons.
	/// This is an example of how to use a function to change the number of decimal places to be displayed on an indicator.
	/// Just cut and paste the code within the 'FormatNumberDecimalPlaces' region.
	/// Make sure you add 'Using NinjaTrader.NinjaScript.Addons;' to your Using declarations at the top of the script.
	/// Sim22 NT8b10 Apr 2016
	/// </summary>
	public class Sim22_DPFunctionExample_RSI : Indicator
	{
		private Series<double>		avgDown;
		private Series<double>		avgUp;
		private double				constant1;
		private double				constant2;
		private double				constant3;
		private Series<double>		down;
		private SMA					smaDown;
		private	SMA					smaUp;
		private Series<double>		up;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionRSI;
				Name						= "Sim22_DPFunctionExample_RSI";
				IsSuspendedWhileInactive	= true;
				BarsRequiredToPlot			= 20;
				Period						= 14;
				Smooth						= 3;
				AddPlot(Brushes.Green, "Sim22_DPFunctionExample_RSI");
				AddPlot(Brushes.Orange, "Avg");

				AddLine(Brushes.DarkViolet, 30, "Lower");
				AddLine(Brushes.YellowGreen, 70, "Upper");
			}
			else if (State == State.Configure)
			{
				avgUp				= new Series<double>(this);
				avgDown				= new Series<double>(this);
				down				= new Series<double>(this);
				up					= new Series<double>(this);
				smaDown				= SMA(down, Period);
				smaUp				= SMA(up, Period);

				constant1 = 2.0 / (1 + Smooth);
				constant2 = (1 - (2.0 / (1 + Smooth)));
				constant3 = (Period - 1);
			}
		}

		#region 	FormatNumberDecimalPlaces
		
		/*Notes:
		I have designed this function this way to be compact and easily copyable. A lot of the code could be included within the indicator otherwise.
		Make sure you add 'using NinjaTrader.NinjaScript.AddOns;' to the Using Declarations up top.
		*/
		Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum	dpEnum		= Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.SameAsInstrument;
		
		/* Although not entirely good practice, I placed this here so you can easily copy and paste into your indicators.
		If you choose to, you can remove the property from this location and place with the other NT properties*/
		[NinjaScriptProperty]
		[Display(Name="# Decimal Places", Description="", Order=0, GroupName="Set up")]
		public  Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum DPEnum
		{
			get { return dpEnum; }
			set { dpEnum = value; }
		}
		
		
		public override string FormatPriceMarker(double value)
		{
			/* using static class Sim22_PriceFormatter in the Addons folder */
			if (dpEnum == Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.SameAsInstrument)
				return Sim22_PriceFormatter.FormatSameAsInstrumentPrice(value, TickSize);
			else
				return value.ToString("N" + Sim22_PriceFormatter.FormatNumberDecimalPlaces(dpEnum).ToString());
		}
		
		#endregion
		
		protected override void OnBarUpdate()
		{
			if (CurrentBar == 0)
			{
				down[0]		= 0;
				up[0]		= 0;

				if (Period < 3)
					Avg[0] = 50;

				return;
			}

			double input0	= Input[0];
			double input1	= Input[1];
			down[0]			= Math.Max(input1 - input0, 0);
			up[0]			= Math.Max(input0 - input1, 0);

			if (CurrentBar + 1 < Period) 
			{
				if (CurrentBar + 1 == Period - 1)
					Avg[0] = 50;
				return;
			}

			if ((CurrentBar + 1) == Period) 
			{
				// First averages 
				avgDown[0]	= smaDown[0];
				avgUp[0]	= smaUp[0];
			}  
			else 
			{
				// Rest of averages are smoothed
				avgDown[0]	= (avgDown[1] * constant3 + down[0]) / Period;
				avgUp[0]	= (avgUp[1] * constant3 + up[0]) / Period;
			}

			double avgDown0	= avgDown[0];
			double value0	= avgDown0 == 0 ? 100 : 100 - 100 / (1 + avgUp[0] / avgDown0);
			Default[0]		= value0;
			Avg[0]			= constant1 * value0 + constant2 * Avg[1];
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Avg
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Default
		{
			get { return Values[0]; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period 
		{ get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smooth", GroupName = "NinjaScriptParameters", Order = 1)]
		public int Smooth 
		{ get; set; }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Samples.Sim22_DPFunctionExample_RSI[] cacheSim22_DPFunctionExample_RSI;
		public Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			return Sim22_DPFunctionExample_RSI(Input, dPEnum, period, smooth);
		}

		public Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(ISeries<double> input, Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			if (cacheSim22_DPFunctionExample_RSI != null)
				for (int idx = 0; idx < cacheSim22_DPFunctionExample_RSI.Length; idx++)
					if (cacheSim22_DPFunctionExample_RSI[idx] != null && cacheSim22_DPFunctionExample_RSI[idx].DPEnum == dPEnum && cacheSim22_DPFunctionExample_RSI[idx].Period == period && cacheSim22_DPFunctionExample_RSI[idx].Smooth == smooth && cacheSim22_DPFunctionExample_RSI[idx].EqualsInput(input))
						return cacheSim22_DPFunctionExample_RSI[idx];
			return CacheIndicator<Samples.Sim22_DPFunctionExample_RSI>(new Samples.Sim22_DPFunctionExample_RSI(){ DPEnum = dPEnum, Period = period, Smooth = smooth }, input, ref cacheSim22_DPFunctionExample_RSI);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			return indicator.Sim22_DPFunctionExample_RSI(Input, dPEnum, period, smooth);
		}

		public Indicators.Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(ISeries<double> input , Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			return indicator.Sim22_DPFunctionExample_RSI(input, dPEnum, period, smooth);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			return indicator.Sim22_DPFunctionExample_RSI(Input, dPEnum, period, smooth);
		}

		public Indicators.Samples.Sim22_DPFunctionExample_RSI Sim22_DPFunctionExample_RSI(ISeries<double> input , Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum dPEnum, int period, int smooth)
		{
			return indicator.Sim22_DPFunctionExample_RSI(input, dPEnum, period, smooth);
		}
	}
}

#endregion
