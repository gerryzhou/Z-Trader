#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;

using System.ComponentModel.DataAnnotations;

#endregion

//This namespace holds Add ons in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.AddOns
{
	/*
	Notes: Version 1.2.
	Was using a string return but thought an int value would be more efficient.
	*/
	public static class Sim22_PriceFormatter
	{
		public enum FormatNumberDecimalPlacesEnum
		{
			SameAsInstrument,
			None,
			One,
			Two,
			Three,
			Four,
			Five,
			Six,
			Seven	
		}
		
		public static int	FormatNumberDecimalPlaces(FormatNumberDecimalPlacesEnum dpe)
		{
			switch (dpe)
			{
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.None:
					return 0;
					break;	
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.One:
					return 1;
					break;
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Two:
					return 2;
					break;	
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Three:
					return 3;
					break;
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Four:
					return 4;
					break;	
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Five:
					return 5;
					break;
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Six:
					return 6;
					break;	
				case Sim22_PriceFormatter.FormatNumberDecimalPlacesEnum.Seven:
					return 7;
					break;
				default:
					return 2;
					break;
			}
		}
			
		public static string	FormatSameAsInstrumentPrice(double value, double tickSize)
		{
			//Thanks to 'pppatil' for this Bond price helper
			//Placed 'trunc' and 'fraction' within the bonds conditions to reduce resource usage for non-bonds.
			double trunc = 0.0;
			int fraction = 0; // rounding down for ZF and ZT
			string priceMarker = "";
			
			if (tickSize == 0.03125) 
			{
				trunc = Math.Truncate(value);
				fraction = Convert.ToInt32(320 * Math.Abs(value - trunc) - 0.0001); 
				
				fraction = fraction/10;
				if (fraction < 10)
					priceMarker = trunc.ToString() + "'0" + fraction.ToString();
				else 
					priceMarker = trunc.ToString() + "'" + fraction.ToString();
			}
			else if (tickSize == 0.015625 || tickSize == 0.0078125)
			{
				trunc = Math.Truncate(value);
				fraction = Convert.ToInt32(320 * Math.Abs(value - trunc) - 0.0001);
				
				if (fraction < 10)
					priceMarker = trunc.ToString() + "'00" + fraction.ToString();
				else if (fraction < 100)
					priceMarker = trunc.ToString() + "'0" + fraction.ToString();
				else	
					priceMarker = trunc.ToString() + "'" + fraction.ToString();
			}
			else
				priceMarker = value.ToString(NinjaTrader.Core.Globals.GetTickFormatString(tickSize));
			return priceMarker;	
		}
	}
}
