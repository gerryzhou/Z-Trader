#region Using Statements
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
    public class Sim22_ChoppinessIndex : Indicator
    {
        private ATR atr;
        private MAX max;
        private MIN min;
        private SUM sum;

        private double logTenPeriodInverse;
		private double high;
		private double low;

        // Coded to NT8 by Calonious. Improved by Sim22 @ www.Futures.io
        protected override void OnStateChange()
        {

            if (State == State.SetDefaults)
            {
                Description					= @"The Choppiness Index (Chop) was created by Australian commodity trader E.W. Dreiss.";
                Name						= "Sim22_ChoppinessIndex";
                Calculate					= Calculate.OnPriceChange;
                IsOverlay					= false;
                DisplayInDataBox			= true;
                DrawOnPricePanel			= false;
                PaintPriceMarkers			= true;
                ScaleJustification			= ScaleJustification.Right;
                ChopPeriod					= 14;
				UpperZoneLevel				= 38.2;
				LowerZoneLevel				= 61.8;
                Opacity                     = 30;
                IndicatorVersion            = "V1.1";
                AddPlot(new Stroke(Brushes.Orange, 2), PlotStyle.Line, "Sim22_ChoppinessIndex");
                AddLine(new Stroke(Brushes.Gold, DashStyleHelper.Dot, 1), 50, "MiddleLine");

                RegionBrush = Brushes.Gold;
            }
            else if (State == State.Configure)
            {
				try
				{
	                RegionBrush.Freeze();

	                // Instantiate once rather than for every bar event
	                max = MAX(High, ChopPeriod);
	                min = MIN(Low, ChopPeriod);
	                atr = ATR(1);
	                sum = SUM(atr, ChopPeriod);
	                // Better to multiply than divide (time wise) - so Calculate this once
	                logTenPeriodInverse = 1 / Math.Log10(ChopPeriod);
				}
				catch (Exception ex) { Print(Name + ": " + ex); }
				
            }
        }

        public override string FormatPriceMarker(double price)
        {
            return price.ToString("N1");
        }

        public override string DisplayName
        {
            get { return "Choppiness Index " + Environment.NewLine + Environment.NewLine + "Period \t= " + ChopPeriod + Environment.NewLine + "Upper \t= " + UpperZoneLevel + Environment.NewLine + "Lower \t= " + LowerZoneLevel; }
        }

        protected override void OnBarUpdate()
        {
			try
			{
	            if (CurrentBar < ChopPeriod) return; 

				if (!IsFirstTickOfBar)
				{
					// If the high or low does not change then do not calculate every bar event.
					// Range bound intrabar
					if (Close[0] <= high && Close[0] >= low) return;				
				}
				
				high = High[0];
				low = Low[0];
				
				double maxMinusMin = max[0] - min[0];
				
	            if (maxMinusMin.ApproxCompare(0) != 0)
	                Values[0][0] = 100 * logTenPeriodInverse *  Math.Log10(sum[0] / (maxMinusMin));

				if (IsFirstTickOfBar)
	            	Draw.RegionHighlightY(this, "ChopZone", false, UpperZoneLevel, LowerZoneLevel, RegionBrush, RegionBrush, Opacity);
			}
			catch (Exception ex) { Print(Name + ": " + ex); }
        }

        #region Properties

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> ChopIndexSeries
        {
            get { return Values[0]; }
        }

        [NinjaScriptProperty]
        [ReadOnly(true)]
        [Display(Name = "Version", GroupName = "1. Parameters", Order = 0)]
        public string IndicatorVersion
        { get; set; }

        [Range(1, int.MaxValue)]
        [NinjaScriptProperty]
        [Display(Name = "ChopPeriod", Description = "Chop Period", Order = 1, GroupName = "1. Parameters")]
        public int ChopPeriod { get; set; }
		
		[Range(0, double.MaxValue)]
        [NinjaScriptProperty]
        [Display(Name = "UpperZoneLevel", Description = "Upper Level for the Chop Zone", Order = 2, GroupName = "1. Parameters")]
        public double UpperZoneLevel { get; set; }
		
		[Range(0, double.MaxValue)]
        [NinjaScriptProperty]
        [Display(Name = "LowerZoneLevel", Description = "Lower Level for the Chop Zone", Order = 3, GroupName = "1. Parameters")]
        public double LowerZoneLevel { get; set; }

       

        [XmlIgnore]
        [Display(Name = "Region color", Description = "Color for the chop region", Order = 1, GroupName = "2. Colors")]
        public Brush RegionBrush
        { get; set; }

        [Browsable(false)]
        public string RegionBrushSerializable
        {
            get { return Serialize.BrushToString(RegionBrush); }
            set { RegionBrush = Serialize.StringToBrush(value); }
        }

        [Range(0, 100)]
        [NinjaScriptProperty]
        [Display(Name = "Region opacity (0-100%)", Description = "Opacity for the chop region", Order = 2, GroupName = "2. Colors")]
        public int Opacity
        { get; set; }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_ChoppinessIndex[] cacheSim22_ChoppinessIndex;
		public Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			return Sim22_ChoppinessIndex(Input, indicatorVersion, chopPeriod, upperZoneLevel, lowerZoneLevel, opacity);
		}

		public Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(ISeries<double> input, string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			if (cacheSim22_ChoppinessIndex != null)
				for (int idx = 0; idx < cacheSim22_ChoppinessIndex.Length; idx++)
					if (cacheSim22_ChoppinessIndex[idx] != null && cacheSim22_ChoppinessIndex[idx].IndicatorVersion == indicatorVersion && cacheSim22_ChoppinessIndex[idx].ChopPeriod == chopPeriod && cacheSim22_ChoppinessIndex[idx].UpperZoneLevel == upperZoneLevel && cacheSim22_ChoppinessIndex[idx].LowerZoneLevel == lowerZoneLevel && cacheSim22_ChoppinessIndex[idx].Opacity == opacity && cacheSim22_ChoppinessIndex[idx].EqualsInput(input))
						return cacheSim22_ChoppinessIndex[idx];
			return CacheIndicator<Sim22.Sim22_ChoppinessIndex>(new Sim22.Sim22_ChoppinessIndex(){ IndicatorVersion = indicatorVersion, ChopPeriod = chopPeriod, UpperZoneLevel = upperZoneLevel, LowerZoneLevel = lowerZoneLevel, Opacity = opacity }, input, ref cacheSim22_ChoppinessIndex);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			return indicator.Sim22_ChoppinessIndex(Input, indicatorVersion, chopPeriod, upperZoneLevel, lowerZoneLevel, opacity);
		}

		public Indicators.Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(ISeries<double> input , string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			return indicator.Sim22_ChoppinessIndex(input, indicatorVersion, chopPeriod, upperZoneLevel, lowerZoneLevel, opacity);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			return indicator.Sim22_ChoppinessIndex(Input, indicatorVersion, chopPeriod, upperZoneLevel, lowerZoneLevel, opacity);
		}

		public Indicators.Sim22.Sim22_ChoppinessIndex Sim22_ChoppinessIndex(ISeries<double> input , string indicatorVersion, int chopPeriod, double upperZoneLevel, double lowerZoneLevel, int opacity)
		{
			return indicator.Sim22_ChoppinessIndex(input, indicatorVersion, chopPeriod, upperZoneLevel, lowerZoneLevel, opacity);
		}
	}
}

#endregion
