#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ColorInputSeriesSlopeChanges : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"applies color changes based on slope change of any input series  - any indicator, value, etc... use Indicator-InputSeries to define what you want to alter";
				Name										= "ColorInputSeriesSlopeChanges";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				AddPlot(Brushes.Orange, "Plot0");
				
				
				DisplayPeak0					= true;
				DisplaySame0					= true;	
				upcolor=Brushes.Green;
				downcolor=Brushes.Red;
				samecolor=Brushes.Yellow;					
								
				
			}
			else if (State == State.Configure)
			{
				upcolor.Freeze();
				downcolor.Freeze();
				samecolor.Freeze();
			}
		}

		protected override void OnBarUpdate()
		{
			
			if( CurrentBar < 2 )
					return;
			
            Plot0[0]= Input[0];
//			Values[0][0] =	 Input[0];		
			
			if( Input[0] > Input[1] )
			{
				PlotBrushes[0][0] = upcolor;				
				if(!DisplaySame0)samecolor = upcolor;				
			}
			else if( Input[0] < Input[1] )
			{
				PlotBrushes[0][0] = downcolor;				

				if(!DisplaySame0)samecolor = downcolor;
			}
			else
			{
				PlotBrushes[0][0] = samecolor;				
			}
			
			
			
			if(DisplayPeak0)
			{
				if( Input[0] > Input[1] && Input[2] > Input[1] )
				{
					PlotBrushes[0][1] = samecolor;				
				}
				else if ( Input[0] < Input[1] && Input[2] < Input[1] )
				{
					PlotBrushes[0][1] = samecolor;				
				}
				
			}
						
			
		}// end of on bar update 

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Plot0
		{
			get { return Values[0]; }
		}
		
		[NinjaScriptProperty]
		[Display(Name="Display Peak", Description="True-Display Peak  False-Do Not Display Peak Point", Order=1, GroupName="Parameters")]
		public bool DisplayPeak0
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Display Same", Description="True-Highlight Same Slope Values  False-Do Not Highlight Same Values", Order=2, GroupName="Parameters")]
		public bool DisplaySame0
		{ get; set; }		
// Upward Color
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upward Color", Description = "Upward slope  color", Order = 1, GroupName = "Colors")]
		public System.Windows.Media.Brush upcolor		
		{ get; set; }
		
		[Browsable(false)]
		public string upcolorSerialize
		{
			get { return Serialize.BrushToString(upcolor); }
   			set { upcolor = Serialize.StringToBrush(value); }
		}
//Same value or Peak Color		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Same/Peak Color", Description = "Color same slope or peak values", Order = 2, GroupName = "Colors")]
		public System.Windows.Media.Brush samecolor		
		{ get; set; }
		
		[Browsable(false)]
		public string samecolorSerialize
		{
			get { return Serialize.BrushToString(samecolor); }
   			set { samecolor = Serialize.StringToBrush(value); }
		}

// Downward Color
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Downward Color", Description = "Downward  slope color", Order = 3, GroupName = "Colors")]
		public System.Windows.Media.Brush downcolor		
		{ get; set; }

		[Browsable(false)]
		public string downcolorSerialize
		{
			get { return Serialize.BrushToString(downcolor); }
			set { downcolor = Serialize.StringToBrush(value); }
		}		
		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ColorInputSeriesSlopeChanges[] cacheColorInputSeriesSlopeChanges;
		public ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(bool displayPeak0, bool displaySame0)
		{
			return ColorInputSeriesSlopeChanges(Input, displayPeak0, displaySame0);
		}

		public ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(ISeries<double> input, bool displayPeak0, bool displaySame0)
		{
			if (cacheColorInputSeriesSlopeChanges != null)
				for (int idx = 0; idx < cacheColorInputSeriesSlopeChanges.Length; idx++)
					if (cacheColorInputSeriesSlopeChanges[idx] != null && cacheColorInputSeriesSlopeChanges[idx].DisplayPeak0 == displayPeak0 && cacheColorInputSeriesSlopeChanges[idx].DisplaySame0 == displaySame0 && cacheColorInputSeriesSlopeChanges[idx].EqualsInput(input))
						return cacheColorInputSeriesSlopeChanges[idx];
			return CacheIndicator<ColorInputSeriesSlopeChanges>(new ColorInputSeriesSlopeChanges(){ DisplayPeak0 = displayPeak0, DisplaySame0 = displaySame0 }, input, ref cacheColorInputSeriesSlopeChanges);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(bool displayPeak0, bool displaySame0)
		{
			return indicator.ColorInputSeriesSlopeChanges(Input, displayPeak0, displaySame0);
		}

		public Indicators.ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(ISeries<double> input , bool displayPeak0, bool displaySame0)
		{
			return indicator.ColorInputSeriesSlopeChanges(input, displayPeak0, displaySame0);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(bool displayPeak0, bool displaySame0)
		{
			return indicator.ColorInputSeriesSlopeChanges(Input, displayPeak0, displaySame0);
		}

		public Indicators.ColorInputSeriesSlopeChanges ColorInputSeriesSlopeChanges(ISeries<double> input , bool displayPeak0, bool displaySame0)
		{
			return indicator.ColorInputSeriesSlopeChanges(input, displayPeak0, displaySame0);
		}
	}
}

#endregion
