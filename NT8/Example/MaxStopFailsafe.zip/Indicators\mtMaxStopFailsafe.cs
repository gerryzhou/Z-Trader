#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.Gui.NinjaScript.AtmStrategy;
using System.Reflection;
using System.Text;
using System.IO;

#endregion

	
namespace NinjaTrader.NinjaScript.Indicators
{
    public class mtMaxStopFailsafe : Indicator
    {		
			
		
		#region RegInputs
		
        private int iMaxStopTicks = 16; 
        [NinjaScriptProperty]        [Display(Name = "01. Max Stoploss Ticks", Description = "", GroupName = "Parameters")]        
		public int MaxStopTicks
        {
            get { return iMaxStopTicks; }
            set { iMaxStopTicks = value; }        	
		}
		
		#endregion
		
		// ChartTrader
		private int iQuantity = 1;
		private bool iControlsSetup = false;
		private TifSelector iTifSelector;
		private QuantityUpDown iQuantityUpDown;
		private AccountSelector iAccountSelector;
		private AtmStrategySelector iAtmStrategySelector;
		
		// Chart / Grid / Tab
		private bool iTabActive = false;
		private Chart iChartWindow;		
		private Grid iChartTraderGrid; 
		private ChartTrader iChartTrader;	
		private bool iRealtime = false;	
		
		private bool bToken;
		
						
        //******************************************************************************
        //******************************************************************************
        //							     -- INITIALIZE --
        //******************************************************************************
        //******************************************************************************
        #region RegInitialize
		
		protected override void OnStateChange()
		{
            switch (State)
            {
                case State.SetDefaults:
					
					// Visuals
					IsOverlay = true;
					IsAutoScale = true;
					DisplayInDataBox = true;
					DrawOnPricePanel = true;
					DrawHorizontalGridLines = true;
					DrawVerticalGridLines = true;
					PaintPriceMarkers = true;
					ShowTransparentPlotsInDataBox = false;
					ScaleJustification = ScaleJustification.Right;
					
					// Misc
					IsChartOnly = false;
					Calculate = Calculate.OnEachTick;
					IsSuspendedWhileInactive = false;
					MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;

					break;
					
				case State.Configure:
								
				
					break;
					
                case State.DataLoaded:	
					
					this.bToken = true;
										
                    break;	
					
				case State.Historical:
					
					if(ChartControl != null)
					{
						ChartControl.Dispatcher.InvokeAsync((Action)(() =>
						{
							iChartWindow 			= System.Windows.Window.GetWindow(ChartControl.Parent) 	as Chart;		
							if(iChartWindow == null) 
								return;
						}));
					}
					
					break;
					
				case State.Transition:
					
					this.iRealtime = true;
					if(!this.iControlsSetup) 
						this.SetupControls();
				
					break;
					
				case State.Terminated:
					
					if (this.ChartControl != null)
					{
						if(this.iControlsSetup)
						{
							ChartControl.Dispatcher.InvokeAsync((Action)(() =>
							{
								this.RemoveControls();							
							}));
						}						
					}
			
					break;					
			}

		}

        #endregion		
		
        protected override void OnBarUpdate()
        {
			if(CurrentBar < 1 || this.State != State.Realtime)
				return;
			
			this.CheckPosition(Close[0]);
        }

		private void CheckPosition(double iPrice)
		{
			ChartControl.Dispatcher.InvokeAsync((Action)(() =>
			{
				double avgPrice = 0;
				if(this.GetMarketPosition(this.iAccountSelector.SelectedAccount, ref avgPrice) == MarketPosition.Long)	
				{
					if(iPrice < avgPrice && Math.Abs(avgPrice - iPrice) >= this.iMaxStopTicks * TickSize && this.bToken)
					{
						this.bToken = false;
						CloseMarketPosition(this.iAccountSelector.SelectedAccount);
					}
					
					return;
				}
								
				if(this.GetMarketPosition(this.iAccountSelector.SelectedAccount, ref avgPrice) == MarketPosition.Short)
				{
					if(iPrice > avgPrice && Math.Abs(avgPrice - iPrice) >= this.iMaxStopTicks * TickSize && this.bToken)
					{
						this.bToken = false;
						CloseMarketPosition(this.iAccountSelector.SelectedAccount);
					}
					return;
				}
				
				this.bToken = true;
				
			}));		
		}		

		private MarketPosition GetMarketPosition(Account iAccount, ref double rAvgPrice)
		{
			rAvgPrice = 0;
			if(iAccount == null)
				return MarketPosition.Flat;
			
			lock(iAccount.Positions)
			{
				foreach(Position pos in iAccount.Positions)
				{
					if(pos.Instrument == this.Instrument)
					{
						rAvgPrice = pos.AveragePrice;
						return pos.MarketPosition;			
					}
				}
			}
			
			return MarketPosition.Flat;
		}		
		
		private void CloseMarketPosition(Account iAccount)
		{
			if(iAccount == null)
				return;
			
			lock(iAccount.Positions)
			{
				foreach(Position pos in iAccount.Positions)
				{
					if(pos.Instrument == this.Instrument)
						pos.Close();				
				}
			}
		}			
					

		#region Setup Controls
		
		private void SetupControls()
		{
			ChartControl.Dispatcher.InvokeAsync((Action)(() =>
			{
				this.iChartWindow 			= System.Windows.Window.GetWindow(ChartControl.Parent) 				as Chart;
				this.iChartTrader 			= iChartWindow.FindFirst("ChartWindowChartTraderControl")			as ChartTrader;
				this.iChartTraderGrid 		= (iChartWindow.FindFirst("ChartWindowChartTraderControl") 			as ChartTrader).Content as Grid;
				
				this.iAccountSelector 		= iChartWindow.FindFirst("ChartTraderControlAccountSelector") 		as AccountSelector;
				this.iAtmStrategySelector	= iChartWindow.FindFirst("ChartTraderControlATMStrategySelector") 	as AtmStrategySelector;
				this.iQuantityUpDown		= iChartWindow.FindFirst("ChartTraderControlQuantitySelector") 		as QuantityUpDown;
				this.iTifSelector			= iChartWindow.FindFirst("ChartTraderControlTIFSelector") 			as TifSelector;
				
				this.iControlsSetup = true;
			}));			
		}
		
		private void RemoveControls()
		{
			try
			{
				this.iChartTraderGrid = null;
				//this.iChartWindow = null;
				this.iQuantityUpDown = null;
				this.iAccountSelector = null;
				this.iAtmStrategySelector = null;
				this.iQuantityUpDown = null;
				this.iTifSelector = null;
			}
			catch (Exception e) {}
		}
		

		
		#endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private mtMaxStopFailsafe[] cachemtMaxStopFailsafe;
		public mtMaxStopFailsafe mtMaxStopFailsafe(int maxStopTicks)
		{
			return mtMaxStopFailsafe(Input, maxStopTicks);
		}

		public mtMaxStopFailsafe mtMaxStopFailsafe(ISeries<double> input, int maxStopTicks)
		{
			if (cachemtMaxStopFailsafe != null)
				for (int idx = 0; idx < cachemtMaxStopFailsafe.Length; idx++)
					if (cachemtMaxStopFailsafe[idx] != null && cachemtMaxStopFailsafe[idx].MaxStopTicks == maxStopTicks && cachemtMaxStopFailsafe[idx].EqualsInput(input))
						return cachemtMaxStopFailsafe[idx];
			return CacheIndicator<mtMaxStopFailsafe>(new mtMaxStopFailsafe(){ MaxStopTicks = maxStopTicks }, input, ref cachemtMaxStopFailsafe);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.mtMaxStopFailsafe mtMaxStopFailsafe(int maxStopTicks)
		{
			return indicator.mtMaxStopFailsafe(Input, maxStopTicks);
		}

		public Indicators.mtMaxStopFailsafe mtMaxStopFailsafe(ISeries<double> input , int maxStopTicks)
		{
			return indicator.mtMaxStopFailsafe(input, maxStopTicks);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.mtMaxStopFailsafe mtMaxStopFailsafe(int maxStopTicks)
		{
			return indicator.mtMaxStopFailsafe(Input, maxStopTicks);
		}

		public Indicators.mtMaxStopFailsafe mtMaxStopFailsafe(ISeries<double> input , int maxStopTicks)
		{
			return indicator.mtMaxStopFailsafe(input, maxStopTicks);
		}
	}
}

#endregion
