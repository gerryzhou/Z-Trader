// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
	/// <summary>
	/// Linear Regression Slope in ticks per bar to compare multiple instruments
	/// </summary>
	public class Sim22_LRS_TicksPerBar : Indicator
	{
		double sumX = 0.0;
		double divisor = 0.0;
	    private double tickSizeInverse;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= NinjaTrader.Custom.Resource.NinjaScriptIndicatorDescriptionLinRegSlope;
				Name						= "Sim22_LRS_TicksPerBar";
				IsSuspendedWhileInactive 	= true;
				Period						= 14;
				
				AddPlot(Brushes.DarkOrange, "LRSticksPerBar");
				AddLine(new Stroke(Brushes.Gray, DashStyleHelper.Dash, 1f), 0d, "ZeroLine");
			}
			else if (State == State.Configure)
			{
				sumX		= (double) Period*(Period - 1)*.5;
				divisor		= sumX*sumX - (double) Period*Period*(Period - 1)*(2*Period - 1)/6;
			    tickSizeInverse = 1/TickSize;
			}
		}
		
		protected override void OnBarUpdate()
		{
			double	sumXY		= 0;
			double	sumY		= 0;
			double stdDeviation = 0.0;
			int	barCount		= Math.Min(Period, CurrentBar);
			
			for (int count = 0; count < barCount; count++)
			{
				sumXY	+= count*Input[count];
				sumY	+= Input[count];
			}
			
			if (divisor.ApproxCompare(0) == 0 && Period == 0) return;

			double slope = (Period*sumXY - sumX*sumY)/divisor;
			
			if (barCount < Period)
				return;

		    Value[0] = slope*tickSizeInverse;


		}

		#region Properties
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> LRSticksPerBar
		{
			get { return Values[0]; }
		}
		
		[Range(2, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "NinjaScriptParameters", Order = 0)]
		public int Period
		{ get; set; }
		
		#endregion
	}
	
	
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_LRS_TicksPerBar[] cacheSim22_LRS_TicksPerBar;
		public Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(int period)
		{
			return Sim22_LRS_TicksPerBar(Input, period);
		}

		public Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(ISeries<double> input, int period)
		{
			if (cacheSim22_LRS_TicksPerBar != null)
				for (int idx = 0; idx < cacheSim22_LRS_TicksPerBar.Length; idx++)
					if (cacheSim22_LRS_TicksPerBar[idx] != null && cacheSim22_LRS_TicksPerBar[idx].Period == period && cacheSim22_LRS_TicksPerBar[idx].EqualsInput(input))
						return cacheSim22_LRS_TicksPerBar[idx];
			return CacheIndicator<Sim22.Sim22_LRS_TicksPerBar>(new Sim22.Sim22_LRS_TicksPerBar(){ Period = period }, input, ref cacheSim22_LRS_TicksPerBar);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(int period)
		{
			return indicator.Sim22_LRS_TicksPerBar(Input, period);
		}

		public Indicators.Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(ISeries<double> input , int period)
		{
			return indicator.Sim22_LRS_TicksPerBar(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(int period)
		{
			return indicator.Sim22_LRS_TicksPerBar(Input, period);
		}

		public Indicators.Sim22.Sim22_LRS_TicksPerBar Sim22_LRS_TicksPerBar(ISeries<double> input , int period)
		{
			return indicator.Sim22_LRS_TicksPerBar(input, period);
		}
	}
}

#endregion
