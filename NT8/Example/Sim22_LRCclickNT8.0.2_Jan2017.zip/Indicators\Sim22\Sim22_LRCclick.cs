// 
// Copyright (C) 2015, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//

#region Using declarations

using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Xml.Serialization;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators.Sim22;
using SharpDX;
using SharpDX.Direct2D1;
using Sim22PriceFormatExtensions;
using Ellipse = SharpDX.Direct2D1.Ellipse;
using Point = System.Windows.Point;
using swm = System.Windows.Media;

#endregion

//This namespace holds indicators in this folder and is required. Do not change it.

namespace NinjaTrader.NinjaScript.Indicators.Sim22
{
    /// <summary>
    ///     Linear regression is used to calculate a best fit line for the price data. In addition an upper and lower band is
    ///     added by calculating the deviation of prices from the regression line.
    ///     Sim22 Dec 2016 NT8.0.2
    ///     Jan 2017 NT8.0.2 Added Mean Absolute Deviation thanks to 'spooz2'
    /// </summary>
    public class Sim22_LRCclick : Indicator
    {
        private readonly Vector2[,] v2 = new Vector2[5, 2];
        private string autoPropertiesIDName = string.Empty;
        private int bars = 0;
        private bool buttonClicked;
        private swm.SolidColorBrush buttonTextBrush;
        private ChartControl cc;

        // adjustable period
        private Point clickPoint;
        private bool clickSet;
        private double divisor;

        // button
        private bool installGrid;

        private Series<double> interceptSeries;
        private bool isPriceSeries = true;
        private int lrcEndNum;
        private Sim22_LRS_TicksPerBar lrsTicksPerBar;

        private Grid myGrid;
        private int period;
        private Series<double> slopeSeries;
        private Series<double> deviationSeries;

        private int sumLength = 0;
        private double sumX;
        private double sumXY;
        private double sumXYi = 0.0;
        private double sumXYs = 0.0;
        private double sumY;
        private double sumYi = 0.0;
        private double sumYs = 0.0;

        private Brush[] tempBrushDx = new Brush[5];
        private int zz1 = 0;

        private double previousInput, currentInput;

        public override string DisplayName
        {
            get { return string.Format("Sim22 LRC V2 ({0},{1}/{2}/{3})", CalculationType, UseFixedStart ? " FixedStart" : Period.ToString(), InnerWidth, OuterWidth); }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = Custom.Resource.NinjaScriptIndicatorDescriptionRegressionChannel;
                Name = "Sim22_LRCV2";
                Version = "LRC V2.1.0";
                IsAutoScale = false;
                IsOverlay = true;
                IsSuspendedWhileInactive = false;
                Period = 50;
                OuterWidth = 2.0;
                InnerWidth = 1.0;
                DisplayInDataBox = false;
                Calculate = Calculate.OnPriceChange;
                DrawOnPricePanel = false;

                UseDirectionalColors = true;
                PlotOuterBands = true;
                PlotInnerBands = true;
                OpacityOuterBands = 20;
                OpacityInnerBands = 10;
                ExtendPlots = false;

                DecimalPlaces = DecimalPlacesEnum.SameAsInstrument;
                PriceMarkerDisplayType = PriceMarkerDisplayLrcClickEnumV2.Price;
                CalculationType = LrcCalculationTypeEnumV2.StandardDeviation;

                AddPlot(new Stroke(swm.Brushes.RoyalBlue, DashStyleHelper.Solid, 1f), PlotStyle.Line, "Upper");
                AddPlot(new Stroke(swm.Brushes.RoyalBlue, DashStyleHelper.Dash, 1f), PlotStyle.Line, "InnerUpper");
                AddPlot(new Stroke(swm.Brushes.RoyalBlue, DashStyleHelper.Dash, 1f), PlotStyle.Line, "Middle");
                AddPlot(new Stroke(swm.Brushes.RoyalBlue, DashStyleHelper.Dash, 1f), PlotStyle.Line, "InnerLower");
                AddPlot(new Stroke(swm.Brushes.RoyalBlue, DashStyleHelper.Solid, 1f), PlotStyle.Line, "Lower");

                UpLRCBrush = swm.Brushes.LimeGreen;
                DownLRCBrush = swm.Brushes.Red;

                ZOrderNum = 1;

                //Button
                ColumnNum = 1;
                installGrid = true;
                ButtonBrush = swm.Brushes.Gold;
                UseFixedStart = false;
                ShowStartMarker = true;

                FixedStartBarDateTime = Core.Globals.Now;
            }

            else if (State == State.Configure)
            {
                ZOrder = ZOrderNum;
                interceptSeries = new Series<double>(this, MaximumBarsLookBack.Infinite);
                slopeSeries = new Series<double>(this, MaximumBarsLookBack.Infinite);
                deviationSeries = new Series<double>(this, MaximumBarsLookBack.Infinite);
               
                UpLRCBrush.Freeze();
                DownLRCBrush.Freeze();
                ButtonBrush.Freeze();

                // Set the text color to white or black depending on the darkness/lightness of the button color
                buttonTextBrush = (swm.SolidColorBrush) ButtonBrush;
                buttonTextBrush = buttonTextBrush.Color.R + buttonTextBrush.Color.G + buttonTextBrush.Color.B > 382f ? swm.Brushes.Black : swm.Brushes.White;
                buttonTextBrush.Freeze();

                //Used to reset pricemarkers to original UI selection
                if (ExtendPlots)
                    PaintPriceMarkers = false;

                // Instrument price type
                isPriceSeries = Input is PriceSeries;

                // button - to generate random number for install ID
                var rnd = new Random();
                autoPropertiesIDName = rnd.Next(100000).ToString();
            }
            else if (State == State.DataLoaded)
            {
                lrsTicksPerBar = Sim22_LRS_TicksPerBar(Period);
            }
            else if (State == State.Historical)
            {
               
                if (UseFixedStart)
                    InstallButton();
                if (ChartControl != null)
                    ChartControl.MouseLeftButtonDown += MouseClicked;
            }
            else if (State == State.Terminated)
            {
                if (UseFixedStart)
                    RemoveButton();
                if (ChartControl != null)
                    ChartControl.MouseLeftButtonDown -= MouseClicked;
            }
        }

        public override void OnCalculateMinMax()
        {
            try
            {
                if (Bars == null)
                    return;
                if (!IsAutoScale)
                    return;

                var lastBar = ChartBars.ToIndex;
                var firstBar = Math.Max(0, lastBar - period);

                var min = double.MaxValue;
                var max = double.MinValue;

                for (var index = firstBar; index <= lastBar; index++)
                {
                    foreach (var value in Values)
                    {
                        // quick fix. Better to use !IsAutoScale or use intercept + stdDev values etc.
                        if (value.GetValueAt(index).ApproxCompare(0) == 0)
                            continue;
                        min = Math.Min(min, value.GetValueAt(index));
                        max = Math.Max(max, value.GetValueAt(index));
                    }
                }

                if (min.ApproxCompare(double.MaxValue) == 0 || max.ApproxCompare(double.MinValue) == 0)
                    return;
                MinValue = min;
                MaxValue = max;
            }
            catch (Exception ex)
            {
                Print(Name + " OnCalculateMinMax():" + ex);
            }
        }

        public override string FormatPriceMarker(double price)
        {
            var tickSize = TickSize;
            var barNum = ChartBars.ToIndex - (Calculate == Calculate.OnBarClose ? 1 : 0);

            if (price.ApproxCompare(Values[2].GetValueAt(barNum)) == 0)
            {
                return price.ToStringDecimalPlaces(tickSize, DecimalPlacesEnum.SameAsInstrument);
            }

            switch (PriceMarkerDisplayType)
            {
                case PriceMarkerDisplayLrcClickEnumV2.TicksFromMiddle:
                {
                    var tickDiff = 0.0;

                    for (var i = 0; i < 5; i++)
                    {
                        if (price.ApproxCompare(Values[i].GetValueAt(barNum)) == 0)
                        {
                            tickDiff = Math.Abs(price - Values[2].GetValueAt(barNum))/tickSize;
                            break;
                        }
                    }
                    return tickDiff.ToStringDecimalPlaces(tickSize, DecimalPlaces);
                }
                case PriceMarkerDisplayLrcClickEnumV2.Deviations:
                {
                    if (price.ApproxCompare(Values[0].GetValueAt(barNum)) == 0 || price.ApproxCompare(Values[4].GetValueAt(barNum)) == 0)
                        return OuterWidth.ToStringDecimalPlaces(tickSize, DecimalPlaces);
                    if (price.ApproxCompare(Values[1].GetValueAt(barNum)) == 0 || price.ApproxCompare(Values[3].GetValueAt(barNum)) == 0)
                        return InnerWidth.ToStringDecimalPlaces(tickSize, DecimalPlaces);

                    return price.ApproxCompare(Values[2].GetValueAt(barNum)) == 0 ? price.ToStringDecimalPlaces(tickSize, DecimalPlacesEnum.SameAsInstrument) : "";
                }
                case PriceMarkerDisplayLrcClickEnumV2.RegressionSlopePerTickSize:
                {
                    if (price.ApproxCompare(Values[2].GetValueAt(barNum)) == 0)
                        price.ToStringDecimalPlaces(tickSize, DecimalPlacesEnum.SameAsInstrument);

                    return lrsTicksPerBar.LRSticksPerBar.GetValueAt(barNum).ToStringDecimalPlaces(tickSize, DecimalPlaces);
                }
                //price
                default:
                    return price.ToStringDecimalPlaces(tickSize, DecimalPlaces);
            }
        }

        protected override void OnBarUpdate()
        {
            try
            {
                if (Bars == null)
                    return;

                if (CurrentBar < 0)
                    return;

                currentInput = Input[0];

                //calculate every price change instead of every tick
                if (!IsFirstTickOfBar && previousInput.ApproxCompare(currentInput) == 0)
                    return;

                previousInput = currentInput;

                // First we calculate the linear regression parameters
                // Sim22: Note I have changed some of the standard NT8 code to 1) Plot on any panel with any input, 2) Plot historically when the chart is scrolled back.
                // The calculation of the standard LRC remains the same.

                var deviation = 0.0;
                period = Period;

                // I chose to use DateTime instead of a bar number just in case you change your chart from intraday to EOD or vice-versa.
                if (UseFixedStart && FixedStartBarDateTime != default(DateTime) && FixedStartBarDateTime <= Bars.GetTime(Bars.Count - 1) && FixedStartBarDateTime >= Bars.GetTime(0))
                {
                    var fixedBarNum = Bars.GetBar(FixedStartBarDateTime);
                    period = CurrentBar - fixedBarNum + 1;
                }

                var barCount = Math.Min(period, CurrentBar);

                // Some calculations have been modified to be more efficient by limiting to the first tick of every new bar.
                // 'sumX' and divisor should be set in State.Configure/DataLoaded instead, but if using 'Fixed Start' the variable 'period' is not constant.
                if (IsFirstTickOfBar)
                {
                    sumXY = 0;
                    sumY = 0;

                    for (var count = 1; count < barCount; count++)
                    {
                        var input = Input[count];

                        sumXY += count*input;
                        sumY += input;
                    }

                    sumX = (double) period*(period - 1)*.5;
                    divisor = sumX*sumX - (double) period*period*(period - 1)*(2*period - 1)/6;

                    if (divisor.ApproxCompare(0) == 0 && period == 0) return;
                }

                var slope = (period*sumXY - sumX*(sumY + Input[0]))/divisor;

                var intercept = (sumY + Input[0] - slope*sumX)/period;


                slopeSeries[0] = slope;
                interceptSeries[0] = intercept;

                var middle = intercept + slope*(period - 1);

                Middle[0] = CurrentBar == 0 ? Input[0] : middle;

                
                switch (CalculationType)
                {
                    case LrcCalculationTypeEnumV2.RaffChannel:
                    {
                        //TASC Oct 1991
                        var maxRaffInput = 0.0;

                        for (var count = 0; count < barCount; count++)
                        {
                            var regressionValue = intercept + slope*(period - 1 - count);
                            maxRaffInput = Math.Max(Math.Abs(Input[count] - regressionValue), maxRaffInput);
                        }
                        deviation = maxRaffInput;
                    }
                        break;

                    case LrcCalculationTypeEnumV2.RaffChannelUsingHighsLows:
                    {
                        var maxRaffInput = 0.0;

                        for (var count = 0; count < barCount; count++)
                        {
                            var input = Input[0];
                            var regressionValue = intercept + slope * (period - 1 - count);

                            //Test if input is a 'price' not an indicator.
                            maxRaffInput = Math.Max(isPriceSeries ? Math.Abs(Math.Max(regressionValue - Low[count], High[count] - regressionValue)) : Math.Abs(Input[count] - regressionValue), maxRaffInput);
                        }
                        deviation = maxRaffInput;
                    }
                        break;

                    case LrcCalculationTypeEnumV2.StandardDeviation:
                    {
                        // Standard LRC
                        // Next we calculate the standard deviation of the 
                        // residuals (vertical distances to the regression line).
                        double sumResiduals = 0;

                        for (var count = 0; count < barCount; count++)
                        {
                            var regressionValue = intercept + slope*(period - 1 - count);
                            var residual = Math.Abs(Input[count] - regressionValue);
                            sumResiduals += residual;
                        }

                        var avgResiduals = sumResiduals/Math.Min(CurrentBar - 1, period);

                        sumResiduals = 0;
                        for (var count = 0; count < barCount; count++)
                        {
                            var regressionValue = intercept + slope*(period - 1 - count);
                            var residual = Math.Abs(Input[count] - regressionValue);
                            sumResiduals += (residual - avgResiduals)*(residual - avgResiduals);
                        }

                        deviation = Math.Sqrt(sumResiduals/Math.Min(CurrentBar + 1, period));
                    }
                        break;

                    case LrcCalculationTypeEnumV2.MeanAbsoluteDeviation:
                    {
                        // MAD LRC
                        // Next we calculate the Mean Absolute Deviation of the 
                        // residuals (vertical distances to the regression line).
                        double sumResiduals = 0;

                        for (var count = 0; count < barCount; count++)
                        {
                            var regressionValue = intercept + slope * (period - 1 - count);
                            var residual = Math.Abs(Input[count] - regressionValue);
                            sumResiduals += residual;
                        }

                        deviation = sumResiduals / Math.Min(CurrentBar - 1, period);
                    }
                        break;
                }

                deviationSeries[0] = deviation;

                Upper[0] = deviation.ApproxCompare(0) == 0 || double.IsInfinity(deviation) ? Input[0] : middle + deviation*OuterWidth;
                InnerUpper[0] = deviation.ApproxCompare(0) == 0 || double.IsInfinity(deviation) ? Input[0] : middle + deviation*InnerWidth;
                InnerLower[0] = deviation.ApproxCompare(0) == 0 || double.IsInfinity(deviation) ? Input[0] : middle - deviation*InnerWidth;
                Lower[0] = deviation.ApproxCompare(0) == 0 || double.IsInfinity(deviation) ? Input[0] : middle - deviation*OuterWidth;

                //Color price markers
                if (UseDirectionalColors && PaintPriceMarkers)
                {
                    for (var i = 0; i < 5; i++)
                    {
                        if (!Plots[i].Brush.IsTransparent())
                        {
                            PlotBrushes[i][0] = slope >= 0.0 ? UpLRCBrush : DownLRCBrush;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Print(Name + " OnBarUpdate: " + ex);
            }
        }

        #region OnRender & Methods

        private int GetXPos(int barsBack)
        {
            return ChartControl.GetXByBarIndex(ChartBars, Math.Max(0, lrcEndNum - barsBack - (Calculate == Calculate.OnBarClose ? 1 : 0)));
        }

        private static int GetYPos(double price, ChartScale chartScale)
        {
            return chartScale.GetYByValue(price);
        }

        private int GetBarIdx(ChartControl chartControl)
        {
            return RoundMyNumber(chartControl.GetSlotIndexByX(RoundMyNumber(clickPoint.X)));
        }

        private DateTime GetBarDateTime(ChartControl chartControl, double index)
        {
            return chartControl.GetTimeBySlotIndex(RoundMyNumber(index));
        }

        private static int RoundMyNumber(double number)
        {
            return Convert.ToInt32(number%1 > 0.5 ? Math.Ceiling(number) : Math.Floor(number));
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            try
            {
                if (Bars == null || ChartControl == null || CurrentBar < Period || IsInHitTest) return;

                RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;

                lrcEndNum = UseFixedStart ? Bars.Count - 1 : ChartBars.ToIndex;

                var idx = lrcEndNum - (Calculate == Calculate.OnBarClose ? 1 : 0);
                var intercept = interceptSeries.GetValueAt(idx);
                var slope = slopeSeries.GetValueAt(idx);
                var stdDev = deviationSeries.GetValueAt(idx);
                var stdDevPixelsInner = (int) Math.Round(stdDev*InnerWidth/chartScale.MaxMinusMin*ChartPanel.H, 0);
                var stdDevPixelsOuter = (int) Math.Round(stdDev*OuterWidth/chartScale.MaxMinusMin*ChartPanel.H, 0);
                var xPos = GetXPos(period - 1);
                var yPos = GetYPos(intercept, chartScale);
                var xPos2 = 0;
                var yPos2 = 0;

                if (UseFixedStart && xPos > ChartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex))
                    return;

                if (ExtendPlots)
                {
                    //double plot length - rough, but works. Better way is to find margin and extrapolate to find Y.
                    xPos2 = GetXPos(-period);
                    yPos2 = GetYPos(intercept + slope*(2*period - 1), chartScale);
                }
                else
                {
                    xPos2 = GetXPos(0);
                    yPos2 = GetYPos(intercept + slope*(period - 1), chartScale);
                }

                //Make double array to hold start/end vectors (0-2) for each line (0-4)
                //For help on arrays/ double arrays and a great general book for reference see:
                // Charles Petzold ".Net Book Zero" p89. This is free from his website.

                v2[0, 0] = new Vector2(xPos, yPos - stdDevPixelsOuter);
                v2[0, 1] = new Vector2(xPos2, yPos2 - stdDevPixelsOuter);
                v2[1, 0] = new Vector2(xPos, yPos - stdDevPixelsInner);
                v2[1, 1] = new Vector2(xPos2, yPos2 - stdDevPixelsInner);
                v2[2, 0] = new Vector2(xPos, yPos);
                v2[2, 1] = new Vector2(xPos2, yPos2);
                v2[3, 0] = new Vector2(xPos, yPos + stdDevPixelsInner);
                v2[3, 1] = new Vector2(xPos2, yPos2 + stdDevPixelsInner);
                v2[4, 0] = new Vector2(xPos, yPos + stdDevPixelsOuter);
                v2[4, 1] = new Vector2(xPos2, yPos2 + stdDevPixelsOuter);

                //set all plot brushes to UI settings
                tempBrushDx = new[] {Plots[0].BrushDX, Plots[1].BrushDX, Plots[2].BrushDX, Plots[3].BrushDX, Plots[4].BrushDX};

                for (var i = 0; i < 5; i++)
                {
                    if (UseDirectionalColors)
                    {
                        if (!Plots[0].Brush.IsTransparent())
                            tempBrushDx[i] = slope >= 0.0 ? UpLRCBrush.ToDxBrush(RenderTarget) : DownLRCBrush.ToDxBrush(RenderTarget);
                    }
                    //Draw lines
                    RenderTarget.DrawLine(v2[i, 0], v2[i, 1], tempBrushDx[i], Plots[i].Width, Plots[i].StrokeStyle);
                }

                //Bands
                if (PlotOuterBands || PlotInnerBands)
                {
                    tempBrushDx[0].Opacity = OpacityOuterBands*0.01f;
                    tempBrushDx[1].Opacity = OpacityInnerBands*0.01f;
                    //middle not included
                    tempBrushDx[3].Opacity = OpacityInnerBands*0.01f;
                    tempBrushDx[4].Opacity = OpacityOuterBands*0.01f;

                    for (var i = 0; i < 5; i++)
                    {
                        if ((PlotOuterBands && i == 0) || (PlotInnerBands && i == 1))
                        {
                            //fill calculation
                            var fillGeometry = new PathGeometry(Globals.D2DFactory);
                            var fillSink = fillGeometry.Open();
                            fillSink.BeginFigure(v2[i, 0], FigureBegin.Filled);
                            fillSink.AddLine(v2[i, 1]);
                            fillSink.AddLine(v2[i + 1, 1]);
                            fillSink.AddLine(v2[i + 1, 0]);
                            fillSink.EndFigure(FigureEnd.Open);
                            fillSink.Close();

                            //fill plot
                            try
                            {
                                RenderTarget.FillGeometry(fillGeometry, tempBrushDx[i]);
                            }
                            catch (Exception ex)
                            {
                                Print(Name + " FillGeometry: " + ex);
                            }

                            fillGeometry.Dispose();
                            fillSink.Dispose();
                        }

                        if ((PlotOuterBands && i == 4) || (PlotInnerBands && i == 3))
                        {
                            //fill calculation
                            var fillGeometry = new PathGeometry(Globals.D2DFactory);
                            var fillSink = fillGeometry.Open();
                            fillSink.BeginFigure(v2[i, 0], FigureBegin.Filled);
                            fillSink.AddLine(v2[i, 1]);
                            fillSink.AddLine(v2[i - 1, 1]);
                            fillSink.AddLine(v2[i - 1, 0]);
                            fillSink.EndFigure(FigureEnd.Open);
                            fillSink.Close();

                            //fill plot
                            try
                            {
                                RenderTarget.FillGeometry(fillGeometry, tempBrushDx[i]);
                            }
                            catch (Exception ex)
                            {
                                Print(Name + " FillGeometry: " + ex);
                            }

                            fillGeometry.Dispose();
                            fillSink.Dispose();
                        }
                    }
                }

                if (UseFixedStart && ShowStartMarker)
                {
                    var ellip = new Ellipse(new Vector2(xPos, yPos), 5f, 5f);

                    var ellipBrushDx = ButtonBrush.ToDxBrush(RenderTarget);
                    
                    if (ellipBrushDx != null)
                    {
                        RenderTarget.FillEllipse(ellip, ellipBrushDx);
                        //use center plot unless transparent
                        if (tempBrushDx[2] != null)
                            RenderTarget.DrawEllipse(ellip, tempBrushDx[2]);
                        ellipBrushDx.Dispose();
                    }
                }
                RenderTarget.AntialiasMode = AntialiasMode.Aliased;

                foreach (var brush in tempBrushDx)
                    brush.Dispose();
            }
            catch (Exception ex)
            {
                Print(Name + " OnRender: " + ex);
            }
        }

        #endregion

        #region	Button

        protected void InstallButton()
        {
            try
            {
                cc = ChartControl;

                if (cc != null)
                {
                    Dispatcher.BeginInvoke((Action) (() =>
                    {
                        // find the chart window and subscribe to the tab control selection change event
                        var myChart = Window.GetWindow(cc.Parent) as Chart;
                        if (myChart != null) myChart.MainTabControl.SelectionChanged += MySelectionChangedHandler;

                        if (installGrid)
                        {
                            if (myChart != null)
                                foreach (DependencyObject item in myChart.MainMenu)
                                {
                                    if (AutomationProperties.GetAutomationId(item) == autoPropertiesIDName)
                                    {
                                        installGrid = false;
                                    }
                                }
                        }
                        if (installGrid)
                        {
                            InstallGrid();
                        }
                    }));
                }
            }
            catch (Exception ex)
            {
                Print(Name + " InstallButton: " + ex);
            }
        }

        protected void RemoveButton()
        {
            Dispatcher.InvokeAsync(() =>
            {
                try
                {
                    if (cc != null)
                    {
                        if (UserControlCollection != null)
                        {
                            cc.Children.Remove(myGrid);
                            UserControlCollection.Remove(myGrid);

                            myGrid.Children.Clear();
                            myGrid = null;
                            // unsubscribe
                            var myChart = Window.GetWindow(cc.Parent) as Chart;
                            if (myChart != null) myChart.MainTabControl.SelectionChanged -= MySelectionChangedHandler;
                        }
                        cc = null;
                    }
                }
                catch (Exception ex)
                {
                    Print(Name + " RemoveButton: " + ex);
                }
            });
        }

        private void InstallGrid()
        {
            try
            {
                // button - to generate random number for install ID
                var rnd = new Random();
                autoPropertiesIDName = rnd.Next(100000).ToString();

                // Create a grid to house the buttons
                myGrid = new Grid
                {
                    Name = "buttonGrid",
                    // Align the control to the top left corner of the chart.
                    HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top
                };

                // Make only as many columns as needed in the grid
                var colDef = new ColumnDefinition[ColumnNum];

                for (var i = 0; i <= colDef.Length - 1; i++)
                {
                    colDef[i] = new ColumnDefinition {Width = new GridLength(60)};
                    //60
                    myGrid.ColumnDefinitions.Add(colDef[i]);
                }

                // Create Rows   
                //RowDefinition gridRow1 = new RowDefinition {Height = new GridLength(37)};

                // Format cell text
                var txtBlock1 = new TextBlock
                {
                    Text = "LRCStart", FontSize = 10, FontWeight = FontWeights.Bold, Foreground = buttonTextBrush, VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center
                };

                // Create button 
                var btn1 = new Button
                {
                    Name = "Button1", Content = txtBlock1, Foreground = buttonTextBrush, Background = ButtonBrush, HorizontalAlignment = HorizontalAlignment.Center, HorizontalContentAlignment = HorizontalAlignment.Center, VerticalContentAlignment = VerticalAlignment.Center,
                    //Margin = new Thickness(1.0,1.0,1.0,1.0),
                    Padding = new Thickness(1.0, 1.0, 1.0, 1.0), MinWidth = 60d //column width
                };
                btn1.Click += btn_Click;

                // Define where the button should appear in the grid
                Grid.SetColumn(btn1, Math.Max(0, colDef.Length));
                //System.Windows.Controls.Grid.SetRow(btn1, Math.Max(0, RowNum - 1)); // set to max 1 at this stage

                // Add the button to the grid
                myGrid.Children.Add(btn1);
                // Add the grid to the chart panel
                UserControlCollection.Add(myGrid);
                //cc.Children.Add(myGrid);

                AutomationProperties.SetAutomationId(myGrid, autoPropertiesIDName);

                cc.InvalidateVisual();
            }
            catch (Exception ex)
            {
                Print(Name + " InstallGrid: " + ex);
            }
        }

        /// <summary>
        ///     When we click on a new tab, make sure the grid/buttons do not appear on the new tabbed chart
        /// </summary>
        private void MySelectionChangedHandler(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
                return;

            var tabItem = e.AddedItems[0] as TabItem;
            if (tabItem != null)
            {
                var temp = tabItem.Content as ChartTab;
                if (temp != null)
                {
                    // set grid/button visiblity based on selected tab
                    if (myGrid != null)
                        myGrid.Visibility = Equals(temp.ChartControl, ChartControl) ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        #endregion

        #region	Click Events

        /// <summary>
        ///     When the button is clicked, allow the mouse to select the bar to start the LRC from
        /// </summary>
        protected void btn_Click(object sender, RoutedEventArgs rea)
        {
            buttonClicked = true;

            if (UseFixedStart && buttonClicked)
                Draw.TextFixed(this, "LRC", "Click on the chart where you would like the LRC to begin.", TextPosition.Center, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, swm.Brushes.Transparent, ChartControl.Properties.ChartBackground, 100);
            ChartControl.InvalidateVisual();
        }

        protected void MouseClicked(object sender, MouseButtonEventArgs e)
        {
            // See ChelseaB's 'ClickDrawExample'
            if (!buttonClicked)
                return;

            buttonClicked = false;

            // convert e.GetPosition for different dpi settings
            clickPoint.X = e.GetPosition(ChartPanel).X.ConvertToHorizontalPixels(ChartControl.PresentationSource);
            clickPoint.Y = e.GetPosition(ChartPanel).Y.ConvertToVerticalPixels(ChartControl.PresentationSource);

            if (clickPoint.Y > 0)
                clickSet = true;

            var barIdx = GetBarIdx(ChartControl);

            FixedStartBarDateTime = GetBarDateTime(ChartControl, barIdx);

            Draw.TextFixed(this, "LRC", "Press F5 to restart the LRC.", TextPosition.Center, ChartControl.Properties.ChartText, ChartControl.Properties.LabelFont, swm.Brushes.Transparent, ChartControl.Properties.ChartBackground, 100);
            // trigger the chart invalidate so that the render loop starts even if there is no data being received
            ChartControl.InvalidateVisual();
            e.Handled = true;
        }

        #endregion

        #region Properties

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Upper
        {
            get { return Values[0]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> InnerUpper
        {
            get { return Values[1]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Middle
        {
            get { return Values[2]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> InnerLower
        {
            get { return Values[3]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> Lower
        {
            get { return Values[4]; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> SlopeSeries
        {
            get { return slopeSeries; }
        }

        [Browsable(false)]
        [XmlIgnore]
        public Series<double> LrsSeries
        {
            get { return lrsTicksPerBar.LRSticksPerBar; }
        }

        [ReadOnly(true)]
        [NinjaScriptProperty]
        [Display(Name = "Version", GroupName = "1. Version", Order = 0)]
        public string Version { get; set; }

        [Range(2, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Period", GroupName = "2. Parameters", Order = 0)]
        public int Period { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Inner width", GroupName = "2. Parameters", Order = 1)]
        public double InnerWidth { get; set; }

        [Range(0, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Outer width", GroupName = "2. Parameters", Order = 2)]
        public double OuterWidth { get; set; }

        [NinjaScriptProperty]
        [TypeConverter(typeof(Sim22EnumUtilities.EnumDescriptionConverter))]
        [PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")]
        [Display(Name = "Channel calculation", GroupName = "2. Parameters", Order = 3)]
        public LrcCalculationTypeEnumV2 CalculationType { get; set; }
       
        [NinjaScriptProperty]
        [Display(Name = "Use fixed start?", GroupName = "3. Fixed Start", Order = 0)]
        public bool UseFixedStart { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show start marker on LRC?", Description = "Shows an ellipse where the LRC starts from. Useful when using multiple LRCs", GroupName = "3. Fixed Start", Order = 1)]
        public bool ShowStartMarker { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Fixed start date time", GroupName = "3. Fixed Start", Order = 2)]
        public DateTime FixedStartBarDateTime { get; set; }

        [Range(1, 10), NinjaScriptProperty]
        [Display(Name = "Button column #", Description = "Where to locate the button from the left.", GroupName = "3. Fixed Start", Order = 3)]
        public int ColumnNum { get; set; }

        [XmlIgnore]
        [Display(Name = "Button color", Description = "Color of button", GroupName = "3. Fixed Start", Order = 4)]
        public swm.Brush ButtonBrush { get; set; }

        [Browsable(false)]
        public string ButtonBrushSerializable
        {
            get { return Serialize.BrushToString(ButtonBrush); }
            set { ButtonBrush = Serialize.StringToBrush(value); }
        }

        [NinjaScriptProperty]
        [Display(Name = "ZOrder", Description = "> 0 plot in front of bars, < 0 behind bars", GroupName = "4. Plots", Order = 2)]
        public int ZOrderNum { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plot inner bands", GroupName = "4. Plots", Order = 1)]
        public bool PlotInnerBands { get; set; }

        [Range(0, 100), NinjaScriptProperty]
        [Display(Name = "Opacity inner bands (0-100)", GroupName = "4. Plots", Order = 2)]
        public int OpacityInnerBands { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Plot outer bands", GroupName = "4. Plots", Order = 3)]
        public bool PlotOuterBands { get; set; }

        [Range(0, 100), NinjaScriptProperty]
        [Display(Name = "Opacity outer bands (0-100)", GroupName = "4. Plots", Order = 4)]
        public int OpacityOuterBands { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Extend plots?", GroupName = "4. Plots", Order = 5)]
        public bool ExtendPlots { get; set; }

        [NinjaScriptProperty]
        [TypeConverter(typeof(Sim22EnumUtilities.EnumDescriptionConverter))]
        [PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")]
        [Display(Name = "Price marker display", Description = "Choose what you want displayed on the markers.", Order = 6, GroupName = "4. Plots")]
        public PriceMarkerDisplayLrcClickEnumV2 PriceMarkerDisplayType { get; set; }

        [NinjaScriptProperty]
        [TypeConverter(typeof(Sim22EnumUtilities.EnumDescriptionConverter))]
        [PropertyEditor("NinjaTrader.Gui.Tools.StringStandardValuesEditorKey")]
        [Display(Name = "Price Marker 'price.xx'", Description = "", Order = 7, GroupName = "4. Plots")]
        public DecimalPlacesEnum DecimalPlaces { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use directional colors?", GroupName = "5. Colors", Order = 0)]
        public bool UseDirectionalColors { get; set; }

        [XmlIgnore]
        [Display(Name = "Up color", Description = "Color when LRC is up.", Order = 1, GroupName = "5. Colors")]
        public swm.Brush UpLRCBrush { get; set; }

        [Browsable(false)]
        public string UpLRCBrushSerializable
        {
            get { return Serialize.BrushToString(UpLRCBrush); }
            set { UpLRCBrush = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Down color", Description = "Color when LRC is down.", Order = 2, GroupName = "5. Colors")]
        public swm.Brush DownLRCBrush { get; set; }

        [Browsable(false)]
        public string DownLRCBrushSerializable
        {
            get { return Serialize.BrushToString(DownLRCBrush); }
            set { DownLRCBrush = Serialize.StringToBrush(value); }
        }

        #endregion
    }
}

public enum PriceMarkerDisplayLrcClickEnumV2
{
    [Description("Price")]
    Price,
    [Description("Deviations")]
    Deviations,
    [Description("Distance from middle line (ticks)")]
    TicksFromMiddle,
    [Description("Slope per tick size")]
    RegressionSlopePerTickSize
}

public enum LrcCalculationTypeEnumV2
{
    [Description("Standard deviation")]
    StandardDeviation,
    [Description("Mean absolute deviation (MAD)")]
    MeanAbsoluteDeviation,
    [Description("Raff channel (Closes)")]
    RaffChannel,
    [Description("Raff channel (Highs & Lows)")]
    RaffChannelUsingHighsLows
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Sim22.Sim22_LRCclick[] cacheSim22_LRCclick;
		public Sim22.Sim22_LRCclick Sim22_LRCclick(string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			return Sim22_LRCclick(Input, version, period, innerWidth, outerWidth, calculationType, useFixedStart, showStartMarker, fixedStartBarDateTime, columnNum, zOrderNum, plotInnerBands, opacityInnerBands, plotOuterBands, opacityOuterBands, extendPlots, priceMarkerDisplayType, decimalPlaces, useDirectionalColors);
		}

		public Sim22.Sim22_LRCclick Sim22_LRCclick(ISeries<double> input, string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			if (cacheSim22_LRCclick != null)
				for (int idx = 0; idx < cacheSim22_LRCclick.Length; idx++)
					if (cacheSim22_LRCclick[idx] != null && cacheSim22_LRCclick[idx].Version == version && cacheSim22_LRCclick[idx].Period == period && cacheSim22_LRCclick[idx].InnerWidth == innerWidth && cacheSim22_LRCclick[idx].OuterWidth == outerWidth && cacheSim22_LRCclick[idx].CalculationType == calculationType && cacheSim22_LRCclick[idx].UseFixedStart == useFixedStart && cacheSim22_LRCclick[idx].ShowStartMarker == showStartMarker && cacheSim22_LRCclick[idx].FixedStartBarDateTime == fixedStartBarDateTime && cacheSim22_LRCclick[idx].ColumnNum == columnNum && cacheSim22_LRCclick[idx].ZOrderNum == zOrderNum && cacheSim22_LRCclick[idx].PlotInnerBands == plotInnerBands && cacheSim22_LRCclick[idx].OpacityInnerBands == opacityInnerBands && cacheSim22_LRCclick[idx].PlotOuterBands == plotOuterBands && cacheSim22_LRCclick[idx].OpacityOuterBands == opacityOuterBands && cacheSim22_LRCclick[idx].ExtendPlots == extendPlots && cacheSim22_LRCclick[idx].PriceMarkerDisplayType == priceMarkerDisplayType && cacheSim22_LRCclick[idx].DecimalPlaces == decimalPlaces && cacheSim22_LRCclick[idx].UseDirectionalColors == useDirectionalColors && cacheSim22_LRCclick[idx].EqualsInput(input))
						return cacheSim22_LRCclick[idx];
			return CacheIndicator<Sim22.Sim22_LRCclick>(new Sim22.Sim22_LRCclick(){ Version = version, Period = period, InnerWidth = innerWidth, OuterWidth = outerWidth, CalculationType = calculationType, UseFixedStart = useFixedStart, ShowStartMarker = showStartMarker, FixedStartBarDateTime = fixedStartBarDateTime, ColumnNum = columnNum, ZOrderNum = zOrderNum, PlotInnerBands = plotInnerBands, OpacityInnerBands = opacityInnerBands, PlotOuterBands = plotOuterBands, OpacityOuterBands = opacityOuterBands, ExtendPlots = extendPlots, PriceMarkerDisplayType = priceMarkerDisplayType, DecimalPlaces = decimalPlaces, UseDirectionalColors = useDirectionalColors }, input, ref cacheSim22_LRCclick);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Sim22.Sim22_LRCclick Sim22_LRCclick(string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			return indicator.Sim22_LRCclick(Input, version, period, innerWidth, outerWidth, calculationType, useFixedStart, showStartMarker, fixedStartBarDateTime, columnNum, zOrderNum, plotInnerBands, opacityInnerBands, plotOuterBands, opacityOuterBands, extendPlots, priceMarkerDisplayType, decimalPlaces, useDirectionalColors);
		}

		public Indicators.Sim22.Sim22_LRCclick Sim22_LRCclick(ISeries<double> input , string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			return indicator.Sim22_LRCclick(input, version, period, innerWidth, outerWidth, calculationType, useFixedStart, showStartMarker, fixedStartBarDateTime, columnNum, zOrderNum, plotInnerBands, opacityInnerBands, plotOuterBands, opacityOuterBands, extendPlots, priceMarkerDisplayType, decimalPlaces, useDirectionalColors);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Sim22.Sim22_LRCclick Sim22_LRCclick(string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			return indicator.Sim22_LRCclick(Input, version, period, innerWidth, outerWidth, calculationType, useFixedStart, showStartMarker, fixedStartBarDateTime, columnNum, zOrderNum, plotInnerBands, opacityInnerBands, plotOuterBands, opacityOuterBands, extendPlots, priceMarkerDisplayType, decimalPlaces, useDirectionalColors);
		}

		public Indicators.Sim22.Sim22_LRCclick Sim22_LRCclick(ISeries<double> input , string version, int period, double innerWidth, double outerWidth, LrcCalculationTypeEnumV2 calculationType, bool useFixedStart, bool showStartMarker, DateTime fixedStartBarDateTime, int columnNum, int zOrderNum, bool plotInnerBands, int opacityInnerBands, bool plotOuterBands, int opacityOuterBands, bool extendPlots, PriceMarkerDisplayLrcClickEnumV2 priceMarkerDisplayType, DecimalPlacesEnum decimalPlaces, bool useDirectionalColors)
		{
			return indicator.Sim22_LRCclick(input, version, period, innerWidth, outerWidth, calculationType, useFixedStart, showStartMarker, fixedStartBarDateTime, columnNum, zOrderNum, plotInnerBands, opacityInnerBands, plotOuterBands, opacityOuterBands, extendPlots, priceMarkerDisplayType, decimalPlaces, useDirectionalColors);
		}
	}
}

#endregion
