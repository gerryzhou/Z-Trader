#region Using declarations
using NinjaTrader.Gui;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class AhrensMA : Indicator
    {
        private int movingAvgPRD = 5;
        private Series<double> OCA;
        private Series<double> SubNum;
        private Series<double> AMA;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Indicator here.";
                Name = "AhrensMA";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;

                MovingAvgPRD = 5;
                AddPlot(new Stroke(Brushes.Orange, 2), PlotStyle.Line, "AhrensHL");

                OCA = new Series<double>(this);
                SubNum = new Series<double>(this);
                AMA = new Series<double>(this);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < MovingAvgPRD)
                Value[0] = Input[0];

            OCA[0] = (High[0] + Low[0]) / 2;
            SubNum[0] = (AMA[1] + AMA[movingAvgPRD]) / 2;
            AMA[0] = (CurrentBar < movingAvgPRD ? Close[0] : AMA[1] + ((OCA[0] - SubNum[0]) / movingAvgPRD));
            AhrensHL[0] = AMA[0];
        }

        #region Properties

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> AhrensHL
        {
            get { return Values[0]; }
        }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "MovingAvgPRD", Order = 1, GroupName = "Parameters")]
        public int MovingAvgPRD
        {
            get { return movingAvgPRD; }
            set { movingAvgPRD = Math.Max(1, value); }
        }
        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AhrensMA[] cacheAhrensMA;
		public AhrensMA AhrensMA(int movingAvgPRD)
		{
			return AhrensMA(Input, movingAvgPRD);
		}

		public AhrensMA AhrensMA(ISeries<double> input, int movingAvgPRD)
		{
			if (cacheAhrensMA != null)
				for (int idx = 0; idx < cacheAhrensMA.Length; idx++)
					if (cacheAhrensMA[idx] != null && cacheAhrensMA[idx].MovingAvgPRD == movingAvgPRD && cacheAhrensMA[idx].EqualsInput(input))
						return cacheAhrensMA[idx];
			return CacheIndicator<AhrensMA>(new AhrensMA(){ MovingAvgPRD = movingAvgPRD }, input, ref cacheAhrensMA);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AhrensMA AhrensMA(int movingAvgPRD)
		{
			return indicator.AhrensMA(Input, movingAvgPRD);
		}

		public Indicators.AhrensMA AhrensMA(ISeries<double> input , int movingAvgPRD)
		{
			return indicator.AhrensMA(input, movingAvgPRD);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AhrensMA AhrensMA(int movingAvgPRD)
		{
			return indicator.AhrensMA(Input, movingAvgPRD);
		}

		public Indicators.AhrensMA AhrensMA(ISeries<double> input , int movingAvgPRD)
		{
			return indicator.AhrensMA(input, movingAvgPRD);
		}
	}
}

#endregion
