#region Using declarations
using NinjaTrader.Gui;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

/*
Excerpt from the book "Trading for a Living"

This oscillator avoids the major flaw of ROC. It responds to each piece of data only once rather than twice. Smoothed
Rate of Change (S-ROC) compares the values of an exponential moving average (EMA) instead of prices at two points in time. 
It gives fewer trading signals, and the quality of these signals is better.

To create S-ROC you must first calculate an exponential moving average of closing prices. The next step is to apply Rate of Change
to the EMA. S-ROC is not very sensitive to the length of its EMA or ROC parts. You can calculate a 13-day EMA of closing prices and then apply a
21-day Rate of Change to it. Some traders calculate the Rate of Change of prices first and then smooth
it with a moving average. Their method produces a much jumpier indicator, which is less useful than S-ROC.

Crowd Behavior:
An exponential moving average reflects the average consensus of value of all market participants during the period of its window. 
It is like a composite photograph that reflects major features of the market crowd rather than its fleeting moods.
S-ROC compares each reading of an EMA to a past reading from your selected period of time. 
It compares the average mass consensus today to the average consensus in the past. 
S-ROC tracks major shifts in the bullishness and bearishness of the market crowd.

Trading Rules
Changes in the direction of S-ROC often identify important market turns.
Upturns of S-ROC mark significant bottoms, and its downturns mark important tops. 
Divergences between S-ROC and prices give especially strong buy and sell signals.

    1. Buy when S-ROC turns up from below its centerline.

    2. Sell when S-ROC stops rising and turns down. Sell short when S-ROC turns down from above its centerline.

    3. If prices reach a new high but S-ROC traces a lower peak, it shows that the market crowd is less enthusiastic even though prices are higher. 
    A bearish divergence between S-ROC and price gives a strong signal to sell short.

    4. If prices fall to a new low but S-ROC traces a higher bottom, it shows that the market crowd is less fearful, even though prices are lower. 
    It shows that the downside pressure has lessened, even though the market has fallen deeper than before. 
    A bullish divergence gives a strong signal to cover shorts and buy.
     
*/

public enum SmoothedRocMaType
{
    AhrensMA,
    EhlersSuperSmoother,
    EMA,
    HMA,
    SMA,
    TEMA,
    WMA,
}

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class ROCSmoothed : Indicator
    {
        private int period = 13;
        private int smooth = 21;
        private Series<double> maSeries;
        private SmoothedRocMaType smoothedRocMaType = SmoothedRocMaType.EMA;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"The ROC Smoothed indicator is a modification of the ROC, as described in Alexander Elder's book Trading for a Living. 
                                It plots two lines: ROC, which is the difference between the current price and the price x-time periods ago, 
                                and SROC which is the difference between an MA of price and the MA of price x-time periods ago";
                Name = "ROC (Smoothed)";
                Calculate = Calculate.OnBarClose;
                IsOverlay = false;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;
                Period = 13;
                Smooth = 21;

                AddPlot(new Stroke(Brushes.CornflowerBlue, 2), PlotStyle.Line, "ROC");
                AddPlot(new Stroke(Brushes.Tomato, 2), PlotStyle.Line, "SROC");
                AddLine(Brushes.Yellow, 0, "Zero line");

            }
            else if (State == State.Configure)
            {
                maSeries = new Series<double>(this);
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < period)
                return;

            int barsAgo = Math.Min(CurrentBar, period);
            ROC[0] = (((Input[0] - Input[barsAgo]) / Input[barsAgo]) * 100);

            switch (smoothedRocMaType)
            {
                case SmoothedRocMaType.AhrensMA:
                    {
                        maSeries[0] = (AhrensMA(Input, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.EhlersSuperSmoother:
                    {
                        maSeries[0] = (EhlersSuperSmootherFilter(Input, 2, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.EMA:
                    {
                        maSeries[0] = (EMA(Input, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.HMA:
                    {
                        maSeries[0] = (HMA(Input, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.SMA:
                    {
                        maSeries[0] = (SMA(Input, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.TEMA:
                    {
                        maSeries[0] = (TEMA(Input, barsAgo)[0]);
                        break;
                    }
                case SmoothedRocMaType.WMA:
                    {
                        maSeries[0] = (TMA(Input, barsAgo)[0]);
                        break;
                    }
            }

            int smoothBarsAgo = Math.Min(CurrentBar, Smooth);
            ROCNormalized[0] = (((maSeries[0] - maSeries[smoothBarsAgo]) / maSeries[smoothBarsAgo]) * 100);
        }

        #region Properties

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ROC
        {
            get { return Values[0]; }
        }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> ROCNormalized
        {
            get { return Values[1]; }
        }

        [NinjaScriptProperty]
        [Display(Name = "Moving Avg Type", Description = "", Order = 0, GroupName = "Parameters")]
        public SmoothedRocMaType Type
        {
            get { return smoothedRocMaType; }
            set { smoothedRocMaType = value; }
        }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Period", Description = "Numbers of bars. For traditional ROC, this will plot current price divided by price this many bars ago. For SROC, this is the number of bars included in the MA", Order = 1, GroupName = "Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(1, value); }
        }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Smooth", Description = "To calculate SROC, the current MA value is divided by the value this many bars ago. This is not used by traditional ROC", Order = 2, GroupName = "Parameters")]
        public int Smooth
        {
            get { return smooth; }
            set { smooth = Math.Max(1, value); }
        }

        #endregion

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ROCSmoothed[] cacheROCSmoothed;
		public ROCSmoothed ROCSmoothed(SmoothedRocMaType type, int period, int smooth)
		{
			return ROCSmoothed(Input, type, period, smooth);
		}

		public ROCSmoothed ROCSmoothed(ISeries<double> input, SmoothedRocMaType type, int period, int smooth)
		{
			if (cacheROCSmoothed != null)
				for (int idx = 0; idx < cacheROCSmoothed.Length; idx++)
					if (cacheROCSmoothed[idx] != null && cacheROCSmoothed[idx].Type == type && cacheROCSmoothed[idx].Period == period && cacheROCSmoothed[idx].Smooth == smooth && cacheROCSmoothed[idx].EqualsInput(input))
						return cacheROCSmoothed[idx];
			return CacheIndicator<ROCSmoothed>(new ROCSmoothed(){ Type = type, Period = period, Smooth = smooth }, input, ref cacheROCSmoothed);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ROCSmoothed ROCSmoothed(SmoothedRocMaType type, int period, int smooth)
		{
			return indicator.ROCSmoothed(Input, type, period, smooth);
		}

		public Indicators.ROCSmoothed ROCSmoothed(ISeries<double> input , SmoothedRocMaType type, int period, int smooth)
		{
			return indicator.ROCSmoothed(input, type, period, smooth);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ROCSmoothed ROCSmoothed(SmoothedRocMaType type, int period, int smooth)
		{
			return indicator.ROCSmoothed(Input, type, period, smooth);
		}

		public Indicators.ROCSmoothed ROCSmoothed(ISeries<double> input , SmoothedRocMaType type, int period, int smooth)
		{
			return indicator.ROCSmoothed(input, type, period, smooth);
		}
	}
}

#endregion
