#region Using declarations
using NinjaTrader.Gui;
using NinjaTrader.Gui.Tools;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
#endregion

public enum StsTrend
{
    Down,
    Up,
    Flat,
    Unknown
}

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
    public class EhlersSuperSmootherFilter : Indicator
    {
        private int period = 30;
        private int poles = 2;
        private double a1 = 0;
        private double b1 = 0;
        private double c1 = 0;
        private double coeff1 = 0;
        private double coeff2 = 0;
        private double coeff3 = 0;
        private double coeff4 = 0;
        private double recurrentPart = 0;

        private SimpleFont fontRt = new SimpleFont("Courier", 10);

        private StsTrend stsTrend = StsTrend.Flat;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Indicator here.";
                Name = "EhlersSuperSmootherFilter";
                //Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = true;
                DrawOnPricePanel = true;
                DrawHorizontalGridLines = true;
                DrawVerticalGridLines = true;
                PaintPriceMarkers = true;
                ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
                //Disable this property if your indicator requires custom values that cumulate with each new market data event. 
                //See Help Guide for additional information.
                IsSuspendedWhileInactive = true;

                AddPlot(new Stroke(Brushes.DeepSkyBlue, 2), PlotStyle.Line, "SuperSmoother");

                //AddPlot(new Stroke(Brushes.Green, 3), PlotStyle.Line, "MARising");
                //AddPlot(new Stroke(Brushes.Red, 3), PlotStyle.Line, "MAFalling");
                //AddPlot(new Stroke(Brushes.Yellow, 3), PlotStyle.Line, "MANeutral");

            }
            else if (State == State.DataLoaded)
            {
                double pi = Math.PI;
                double sq2 = Math.Sqrt(2.0);
                double sq3 = Math.Sqrt(3.0);
                if (Poles == 2)
                {
                    a1 = Math.Exp(-sq2 * pi / period);
                    b1 = 2 * a1 * Math.Cos(sq2 * pi / period);
                    coeff2 = b1;
                    coeff3 = -a1 * a1;
                    coeff1 = 1 - coeff2 - coeff3;
                }
                else if (Poles == 3)
                {
                    a1 = Math.Exp(-pi / Period);
                    b1 = 2 * a1 * Math.Cos(sq3 * pi / period);
                    c1 = a1 * a1;
                    coeff2 = b1 + c1;
                    coeff3 = -(c1 + b1 * c1);
                    coeff4 = c1 * c1;
                    coeff1 = 1 - coeff2 - coeff3 - coeff4;
                }
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < Poles)
            {
                SuperSmoother[0] = Input[0];
                return;
            }

            if (IsFirstTickOfBar)
            {
                if (Poles == 2)
                {
                    recurrentPart = coeff2 * Value[1] + coeff3 * Value[2];
                }
                else if (Poles == 3)
                {
                    recurrentPart = coeff2 * Value[1] + coeff3 * Value[2] + coeff4 * Value[3];
                }
            }

            SuperSmoother[0] = recurrentPart + coeff1 * Input[0];

            //if (IsRising(SuperSmoother))
            //{
            //    MARising[1] = SuperSmoother[1];
            //    MARising[0] = SuperSmoother[0];
            //    stsTrend = StsTrend.Up;
            //}
            //else if (IsFalling(SuperSmoother))
            //{
            //    MAFalling[1] = SuperSmoother[1];
            //    MAFalling[0] = SuperSmoother[0];
            //    stsTrend = StsTrend.Down;
            //}
            //else
            //{
            //    MANeutral[1] = SuperSmoother[1];
            //    MANeutral[0] = SuperSmoother[0];
            //    stsTrend = StsTrend.Flat;
            //}

            //Draw.Text(this, "rv_" + CurrentBar.ToString(), true,
            //        Math.Round(rv, 0).ToString()
            //        + "\n" + Math.Round(lrsHigh, 2)
            //        + "\n" + Math.Round(lrsLow, 2),
            //        0, SuperSmoother[0] - 3, 0, Brushes.Yellow,
            //        fontRt, System.Windows.TextAlignment.Center,
            //        Brushes.Transparent, Brushes.Transparent, 0);

        }

        [Browsable(false)]
        [XmlIgnore()]
        public Series<double> SuperSmoother
        {
            get { return Values[0]; }
        }

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> MARising
        //{
        //    get { return Values[0]; }
        //}

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> MAFalling
        //{
        //    get { return Values[1]; }
        //}

        //[Browsable(false)]
        //[XmlIgnore]
        //public Series<double> MANeutral
        //{
        //    get { return Values[2]; }
        //}

        [NinjaScriptProperty]
        [Display(Name = "Poles", Description = "", Order = 1, GroupName = "Parameters")]
        public int Poles
        {
            get { return poles; }
            set { poles = Math.Min(Math.Max(2, value), 3); }
        }

        [NinjaScriptProperty]
        [Display(Name = "Period", Description = "", Order = 1, GroupName = "Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(1, value); }
        }

    }
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EhlersSuperSmootherFilter[] cacheEhlersSuperSmootherFilter;
		public EhlersSuperSmootherFilter EhlersSuperSmootherFilter(int poles, int period)
		{
			return EhlersSuperSmootherFilter(Input, poles, period);
		}

		public EhlersSuperSmootherFilter EhlersSuperSmootherFilter(ISeries<double> input, int poles, int period)
		{
			if (cacheEhlersSuperSmootherFilter != null)
				for (int idx = 0; idx < cacheEhlersSuperSmootherFilter.Length; idx++)
					if (cacheEhlersSuperSmootherFilter[idx] != null && cacheEhlersSuperSmootherFilter[idx].Poles == poles && cacheEhlersSuperSmootherFilter[idx].Period == period && cacheEhlersSuperSmootherFilter[idx].EqualsInput(input))
						return cacheEhlersSuperSmootherFilter[idx];
			return CacheIndicator<EhlersSuperSmootherFilter>(new EhlersSuperSmootherFilter(){ Poles = poles, Period = period }, input, ref cacheEhlersSuperSmootherFilter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EhlersSuperSmootherFilter EhlersSuperSmootherFilter(int poles, int period)
		{
			return indicator.EhlersSuperSmootherFilter(Input, poles, period);
		}

		public Indicators.EhlersSuperSmootherFilter EhlersSuperSmootherFilter(ISeries<double> input , int poles, int period)
		{
			return indicator.EhlersSuperSmootherFilter(input, poles, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EhlersSuperSmootherFilter EhlersSuperSmootherFilter(int poles, int period)
		{
			return indicator.EhlersSuperSmootherFilter(Input, poles, period);
		}

		public Indicators.EhlersSuperSmootherFilter EhlersSuperSmootherFilter(ISeries<double> input , int poles, int period)
		{
			return indicator.EhlersSuperSmootherFilter(input, poles, period);
		}
	}
}

#endregion
