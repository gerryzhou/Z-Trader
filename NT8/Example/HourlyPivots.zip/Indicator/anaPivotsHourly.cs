#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using System.Collections;
using System.Text;
#endregion

#region Global Enums

public enum anaAlignPH {TradingDay, Session}

#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Plots difference between two user defined instruments.
    /// </summary>
    [Description("The indicator plots intraday pivots based on a customizable period.")]
    public class anaPivotsHourly : Indicator
    {
        #region Variables
           
		private int 		period 					= 60;
		private int			countDown				= 1;
		private int			currentBars1			= 0;
		private int			startBar				= 0;
		private int			shift					= 0;
		private DateTime	currentDate				= Cbi.Globals.MinDate;
		private DateTime	newDate					= Cbi.Globals.MinDate;
		private DateTime	sessionBegin			= Cbi.Globals.MinDate;
		private DateTime	sessionEnd				= Cbi.Globals.MinDate;
		private DateTime	breakTime				= Cbi.Globals.MinDate;
		private TimeSpan	interval				= new TimeSpan(0, 60, 0);
		private anaAlignPH	alignThis				= anaAlignPH.TradingDay;
		private double 		currentHigh				= 0.0;
		private double 		currentLow				= 0.0;
		private double 		priorHigh				= 0.0;
		private double 		priorLow				= 0.0;
		private double 		priorClose				= 0.0;
		private double 		pp 						= 0.0;
		private double 		range 					= 0;
		private double 		r1 						= 0.0;
		private double 		r2 						= 0.0;
		private double 		r3 						= 0.0;
		private double 		r4 						= 0.0;
		private double 		s1 						= 0.0;
		private double 		s2 						= 0.0;
		private double 		s3 						= 0.0;
		private double 		s4						= 0.0;
		private double 		cp						= 0.0;
		private double 		dp						= 0.0;
		private bool 		showLevels34 			= false;
		private bool 		showPivotRange 			= true;
		private bool 		showHighLow 			= true;
		private bool		tickBuilt				= false;
		private bool		gap						= true;
		private bool		initBarSeries0			= false;
		private bool		initBarSeries1			= false;
		private bool		firstLoop				= true;
		private bool		firstBarOfTradingDay 	= false;
		private bool		newValue				= false;
		private PlotStyle	plot0Style				= PlotStyle.Line;
		private int 		plot0Width 				= 1;
		private int 		plot1Width 				= 1;
		private int 		plot2Width 				= 1;
		private int			opacity					= 4;
		private DashStyle 	dash0Style				= DashStyle.Solid;
		private DashStyle 	dash1Style				= DashStyle.Solid;
		private DashStyle 	dash2Style				= DashStyle.Dash;
		private Color 		pivotColor				= Color.CornflowerBlue;
		private Color 		resistanceColor 		= Color.GreenYellow;
		private Color 		supportColor			= Color.DeepPink;
		private Color		pivotRangeColor			= Color.CornflowerBlue;
		private Color 		highColor				= Color.Lime;
		private Color		lowColor				= Color.Red;
		
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"PP "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"R1 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"R2 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"R3 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"R4 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"S1 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"S2 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"S3 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"S4 "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"CP "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"DP "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"High "));
			Add(new Plot(new Pen(Color.Gray,1), PlotStyle.Line,"Low "));
		
			Add(PeriodType.Minute, 1);
			BarsRequired 		= 0;
            Overlay				= true;
			AutoScale			= false;
			PlotsConfigurable  	= false;
        }

 		/// <summary>
		/// </summary>
		protected override void OnStartUp()
		{
			interval = new TimeSpan(0, period, 0);
			Plots[0].PlotStyle = plot0Style;
			Plots[1].PlotStyle = plot0Style;
			Plots[2].PlotStyle = plot0Style;
			Plots[3].PlotStyle = plot0Style;
			Plots[4].PlotStyle = plot0Style;
			Plots[5].PlotStyle = plot0Style;
			Plots[6].PlotStyle = plot0Style;
			Plots[7].PlotStyle = plot0Style;
			Plots[8].PlotStyle = plot0Style;            
			Plots[9].PlotStyle = plot0Style;
			Plots[10].PlotStyle = plot0Style;            
			Plots[11].PlotStyle = plot0Style;
			Plots[12].PlotStyle = plot0Style;            
			Plots[0].Pen.Width = plot0Width;
			Plots[1].Pen.Width = plot1Width;
			Plots[2].Pen.Width = plot1Width;
			Plots[3].Pen.Width = plot1Width;
			Plots[4].Pen.Width = plot1Width;
			Plots[5].Pen.Width = plot1Width;
			Plots[6].Pen.Width = plot1Width;
			Plots[7].Pen.Width = plot1Width;
			Plots[8].Pen.Width = plot1Width;
			Plots[9].Pen.Width = plot1Width;
			Plots[10].Pen.Width = plot1Width;
			Plots[11].Pen.Width = plot2Width;
			Plots[12].Pen.Width = plot2Width;
			Plots[0].Pen.DashStyle = dash0Style;
			Plots[1].Pen.DashStyle = dash1Style;
			Plots[2].Pen.DashStyle = dash1Style;
			Plots[3].Pen.DashStyle = dash1Style;
			Plots[4].Pen.DashStyle = dash1Style;
			Plots[5].Pen.DashStyle = dash1Style;
			Plots[6].Pen.DashStyle = dash1Style;
			Plots[7].Pen.DashStyle = dash1Style;
			Plots[8].Pen.DashStyle = dash1Style;            
			Plots[9].Pen.DashStyle = dash1Style;
			Plots[10].Pen.DashStyle = dash1Style;
			Plots[11].Pen.DashStyle = dash2Style;
			Plots[12].Pen.DashStyle = dash2Style;
			Plots[0].Pen.Color = pivotColor;
			Plots[1].Pen.Color = resistanceColor;
			Plots[2].Pen.Color = resistanceColor;
			Plots[3].Pen.Color = resistanceColor;
			Plots[4].Pen.Color = resistanceColor;
			Plots[5].Pen.Color = supportColor;
			Plots[6].Pen.Color = supportColor;
			Plots[7].Pen.Color = supportColor;
			Plots[8].Pen.Color = supportColor;
			Plots[9].Pen.Color = pivotColor;
			Plots[10].Pen.Color = pivotColor;
			Plots[11].Pen.Color = highColor;
			Plots[12].Pen.Color = lowColor;
			gap = (plot0Style == PlotStyle.Line || plot0Style == PlotStyle.Square);
			
			if (!BarsArray[0].BarsType.IsIntraday || BarsPeriods[0].Id == PeriodType.Minute || BarsPeriods[0].Id == PeriodType.Second)
				tickBuilt = false;
			else
				tickBuilt = true;
			currentBars1 	= -1;
			startBar 		= 0;
			initBarSeries0 	= false;
			initBarSeries1 	= false;
			firstLoop 		= true;
			newValue 		= false;
			countDown 		= 1;
		}
		
      	/// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if(CurrentBars[0] < BarsRequired || CurrentBars[1] < BarsRequired)
				return;
			if(CurrentBars[1] > currentBars1)
			{	
				currentBars1 = CurrentBars[1];
				if (alignThis == anaAlignPH.TradingDay)
				{
					if(!initBarSeries1)
					{
						currentDate = BarsArray[1].GetTradingDayFromLocal(Times[1][0]);
						initBarSeries1 = true;
					}	
					newDate = BarsArray[1].GetTradingDayFromLocal(Times[1][0]);
					if (currentDate != newDate)
					{
						firstBarOfTradingDay = true;
						currentDate = newDate;
					}	
					else
						firstBarOfTradingDay = false;
				}
				if (CurrentBars[1] < 2*period)
					return;
				if(period == 1)
				{
					if(BarsArray[1].FirstBarOfSession)
						countDown = countDown - 1;
					priorHigh = Highs[1][1];
					priorLow = Lows[1][1];
					priorClose = Closes[1][1];
					pp				= (priorHigh + priorLow + priorClose)/3;
					range			= priorHigh - priorLow;
					r1				= 2 * pp - priorLow;		
					r2				= pp + range;
					r3				= r1 + range;
					r4 				= r3 + (pp - priorLow);
					s1				= 2 * pp - priorHigh;
					s2				= pp - range;
					s3				= s1 - range;
					s4				= s3 - (priorHigh - pp);
					cp 				= (priorHigh + priorLow)/2;
					dp				= 2*pp -cp;
					newValue		= true;
					if (countDown < 0)
						initBarSeries0 = true;
				}
				else if	((alignThis == anaAlignPH.TradingDay && firstBarOfTradingDay) || (alignThis == anaAlignPH.Session && BarsArray[1].FirstBarOfSession))
				{
					BarsArray[1].Session.GetNextBeginEnd(BarsArray[1], 0, out sessionBegin, out sessionEnd);
					breakTime 		= sessionBegin.Add(interval);
					countDown 		= countDown - 1;
					priorHigh 		= Math.Max(currentHigh, Highs[1][1]);
					priorLow 		= Math.Min (currentLow, Lows[1][1]);
					priorClose 		= Closes[1][1];
					pp				= (priorHigh + priorLow + priorClose)/3;
					range			= priorHigh - priorLow;
					r1				= 2 * pp - priorLow;		
					r2				= pp + range;
					r3				= r1 + range;
					r4 				= r3 + (pp - priorLow);
					s1				= 2 * pp - priorHigh;
					s2				= pp - range;
					s3				= s1 - range;
					s4				= s3 - (priorHigh - pp);
					cp 				= (priorHigh + priorLow)/2;
					dp				= 2*pp -cp;
					newValue		= true;
					if (countDown < 0)
						initBarSeries0 = true;
					currentHigh 	= Highs[1][0];
					currentLow		= Lows[1][0];
				}
				else
				{
					if(Times[1][0] > breakTime)
					{
						breakTime		= breakTime.Add(interval);
						priorHigh 		= Math.Max(currentHigh, Highs[1][1]);
						priorLow 		= Math.Min (currentLow, Lows[1][1]);
						priorClose 		= Closes[1][1];
						pp				= (priorHigh + priorLow + priorClose)/3;
						range			= priorHigh - priorLow;
						r1				= 2 * pp - priorLow;		
						r2				= pp + range;
						r3				= r1 + range;
						r4 				= r3 + (pp - priorLow);
						s1				= 2 * pp - priorHigh;
						s2				= pp - range;
						s3				= s1 - range;
						s4				= s3 - (priorHigh - pp);
						cp 				= (priorHigh+priorLow)/2;
						dp				= 2*pp -cp;
						newValue 		= true;
						if (countDown < 1)
							initBarSeries0 = true;
						currentHigh 	= Highs[1][0];
						currentLow		= Lows[1][0];
					}
					else
					{	
						currentHigh = Math.Max(currentHigh, Highs[1][1]);
						currentLow = Math.Min(currentLow, Lows[1][1]);
					}
				}
			}
			
			if (BarsInProgress == 0  && (newValue || FirstTickOfBar))
			{
				if (initBarSeries0)
				{	
					if(newValue)
					{
						if(firstLoop)
						{
							startBar = CurrentBars[0];
							firstLoop = false;
						}
						else
						{
							shift = 0;
							if(tickBuilt)
								while(Times[0][shift + 1] >= Times[1][1])
									shift = shift + 1;
							else
								while(Times[0][shift + 1] > Times[1][1])
									shift = shift + 1;
							for (int i = 1; i <= shift; i++)
							{
								PP.Set(i,pp);
								R1.Set(i,r1);
								R2.Set(i,r2);
								S1.Set(i,s1);
								S2.Set(i,s2);
								if(showLevels34)
								{
									R3.Set(i,r3);
									R4.Set(i,r4);
									S3.Set(i,s3);
									S4.Set(i,s4);
								}
								else
								{
									R3.Reset();
									R4.Reset();
									S3.Reset();
									S4.Reset();
								}
								if(showPivotRange)
								{
									CP.Set(i,cp);
									DP.Set(i,dp);
								}
								else
								{
									CP.Reset();
									DP.Reset();
								}
								if(showHighLow)
								{
									PriorHigh.Set(i,priorHigh);
									PriorLow.Set(i,priorLow);
								}
							}
							if(CurrentBars[0] > startBar)
							{
								if(gap && shift > 0)
								{
									PlotColors[0][shift] = Color.Transparent;
									PlotColors[1][shift] = Color.Transparent;
									PlotColors[2][shift] = Color.Transparent;
									PlotColors[3][shift] = Color.Transparent;
									PlotColors[4][shift] = Color.Transparent;
									PlotColors[5][shift] = Color.Transparent;
									PlotColors[6][shift] = Color.Transparent;
									PlotColors[7][shift] = Color.Transparent;
									PlotColors[8][shift] = Color.Transparent;
									PlotColors[9][shift] = Color.Transparent;
									PlotColors[10][shift] = Color.Transparent;
									PlotColors[11][shift] = Color.Transparent;
									PlotColors[12][shift] = Color.Transparent;
								}
								if(showPivotRange && opacity > 0)
									DrawRegion("Pivot Range" + startBar, shift + 1, CurrentBars[0]-startBar, CP, DP, Color.Empty, pivotRangeColor, opacity);
								startBar = CurrentBars[0] - shift;
							}
						}
						newValue = false;
					}	
					PP.Set(pp);
					R1.Set(r1);
					R2.Set(r2);
					S1.Set(s1);
					S2.Set(s2);
					if(showLevels34)
					{
						R3.Set(r3);
						R4.Set(r4);
						S3.Set(s3);
						S4.Set(s4);
					}
					else
					{
						R3.Reset();
						R4.Reset();
						S3.Reset();
						S4.Reset();
					}
					if(showPivotRange)
					{
						CP.Set(cp);
						DP.Set(dp);
						if(opacity > 0)
							DrawRegion("Pivot Range"+ startBar, 0, CurrentBars[0]-startBar, CP, DP, Color.Empty, pivotRangeColor, opacity);
					}
					else
					{
						CP.Reset();
						DP.Reset();
					}
					if(showHighLow)
					{
						PriorHigh.Set(priorHigh);
						PriorLow.Set(priorLow);
					}
					if(gap && startBar == CurrentBars[0])
					{
						PlotColors[0][0] = Color.Transparent;
						PlotColors[1][0] = Color.Transparent;
						PlotColors[2][0] = Color.Transparent;
						PlotColors[3][0] = Color.Transparent;
						PlotColors[4][0] = Color.Transparent;
						PlotColors[5][0] = Color.Transparent;
						PlotColors[6][0] = Color.Transparent;
						PlotColors[7][0] = Color.Transparent;
						PlotColors[8][0] = Color.Transparent;
						PlotColors[9][0] = Color.Transparent;
						PlotColors[10][0] = Color.Transparent;
						PlotColors[11][0] = Color.Transparent;
						PlotColors[12][0] = Color.Transparent;
					}
				}
				else
				{
					startBar = CurrentBars[0];
					PP.Reset();
					R1.Reset();
					R2.Reset();
					S1.Reset();
					S2.Reset();
					R3.Reset();
					R4.Reset();
					S3.Reset();
					S4.Reset();
					R3.Reset();
					R4.Reset();
					S3.Reset();
					S4.Reset();
					CP.Reset();
					DP.Reset();
					PriorHigh.Reset();
					PriorLow.Reset();
				}
			}
		}	
        
		#region Properties
        
		/// <summary>
		/// </summary>
		[Description("Rolling Period in Minutes")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Pivot period (Min)")]
		public int Period
		{
			get { return period; }
			set { period = Math.Max(1, value); }
		}
		
 		/// <summary>
		/// </summary>
		[Description("Align pivots to the start of the trading day or the start of each session")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Pivots alignment")]
		public anaAlignPH AlignThis
		{
			get { return alignThis; }
			set { alignThis = value; }
		}
		
  		/// <summary>
		/// </summary>
		[Description("Show higher levels R3, S3, R4, S4")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Show levels 3 & 4")]
		public bool ShowLevels34
		{
			get { return showLevels34; }
			set { showLevels34 = value; }
		}
		
 		/// <summary>
		/// </summary>
		[Description("Show pivot range around main pivot")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Show pivot range")]
		public bool ShowPivotRange
		{
			get { return showPivotRange; }
			set { showPivotRange = value; }
		}
		
  		/// <summary>
		/// </summary>
		[Description("Show currentHigh and currentLow of prior period")]
		[GridCategory("Parameters")]
		[Gui.Design.DisplayNameAttribute("Show prior HiLo")]
		public bool ShowHighLow
		{
			get { return showHighLow; }
			set { showHighLow = value; }
		}
		
       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries PP
		{
			get { return Values[0]; }
		}

        /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries R1
		{
			get { return Values[1]; }
		}

        /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries R2
		{
			get { return Values[2]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries R3
		{
			get { return Values[3]; }
		}

        /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries R4
		{
			get { return Values[4]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries S1
		{
			get { return Values[5]; }
		}

        /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries S2
		{
			get { return Values[6]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries S3
		{
			get { return Values[7]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries S4
		{
			get { return Values[8]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries CP
		{
			get { return Values[9]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries DP
		{
			get { return Values[10]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries PriorHigh
		{
			get { return Values[11]; }
		}

       /// <summary>
		/// </summary>
		[Browsable(false)]
		[XmlIgnore()]
		public DataSeries PriorLow
		{
			get { return Values[12]; }
		}
		/// <summary>
		/// </summary>
		[Description("PlotStyle for pivots")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Plot style pivots")]
		public PlotStyle Plot0Style
		{
			get { return plot0Style; }
			set { plot0Style = value; }
		}
		
		/// <summary>
		/// </summary>
		[Description("Width for Pivot.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Line width main pivot")]
		public int Plot0Width
		{
			get { return plot0Width; }
			set { plot0Width = Math.Max(1, value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("DashStyle for main pivot")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Dash style main pivot")]
		public DashStyle Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		} 

		/// <summary>
		/// </summary>
		[Description("Width for support and resistance levels")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Line width S/R levels")]
		public int Plot1Width
		{
			get { return plot1Width; }
			set { plot1Width = Math.Max(1, value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("DashStyle for support and resistance levels")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Dash style S/R levels")]
		public DashStyle Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		} 
				
		/// <summary>
		/// </summary>
		[Description("DashStyle for prior currentHigh and currentLow levels")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Dash style prior high/low ")]
		public DashStyle Dash2Style
		{
			get { return dash2Style; }
			set { dash2Style = value; }
		} 
				
		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for main pivot")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Main pivot")]
		public Color PivotColor
		{
			get { return pivotColor; }
			set { pivotColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string PivotColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(pivotColor); }
			set { pivotColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}

		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for resistance pivots")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Resistance")]
		public Color ResistanceColor
		{
			get { return resistanceColor; }
			set { resistanceColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string ResistanceColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(resistanceColor); }
			set { resistanceColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}

		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for support pivots")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Support")]
		public Color SupportColor
		{
			get { return supportColor; }
			set { supportColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string SupportColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(supportColor); }
			set { supportColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[Description("Opacity for pivot range.")]
		[Category("Plot Parameters")]
		[Gui.Design.DisplayNameAttribute("Opacity pivot range")]
		public int Opacity
		{
			get { return opacity; }
			set { opacity = Math.Max(0, value); }
		}
		
		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for pivot range")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Pivot range")]
		public Color PivotRangeColor
		{
			get { return pivotRangeColor; }
			set { pivotRangeColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string PivotRangeColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(pivotRangeColor); }
			set { pivotRangeColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}

		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for prior high")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Prior high")]
		public Color HighColor
		{
			get { return highColor; }
			set { highColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string HighColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(highColor); }
			set { highColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		/// <summary>
		/// </summary>
		[XmlIgnore]
		[Description("Select color for prior low")]
		[Category("Plot Colors")]
		[Gui.Design.DisplayName("Prior low")]
		public Color LowColor
		{
			get { return lowColor; }
			set { lowColor = value; }
		}
		
		// Serialize Color object
		[Browsable(false)]
		public string LowColorSerialize
		{
			get { return NinjaTrader.Gui.Design.SerializableColor.ToString(lowColor); }
			set { lowColor = NinjaTrader.Gui.Design.SerializableColor.FromString(value); }
		}
		
		#endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private anaPivotsHourly[] cacheanaPivotsHourly = null;

        private static anaPivotsHourly checkanaPivotsHourly = new anaPivotsHourly();

        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        public anaPivotsHourly anaPivotsHourly(anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            return anaPivotsHourly(Input, alignThis, period, showHighLow, showLevels34, showPivotRange);
        }

        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        public anaPivotsHourly anaPivotsHourly(Data.IDataSeries input, anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            if (cacheanaPivotsHourly != null)
                for (int idx = 0; idx < cacheanaPivotsHourly.Length; idx++)
                    if (cacheanaPivotsHourly[idx].AlignThis == alignThis && cacheanaPivotsHourly[idx].Period == period && cacheanaPivotsHourly[idx].ShowHighLow == showHighLow && cacheanaPivotsHourly[idx].ShowLevels34 == showLevels34 && cacheanaPivotsHourly[idx].ShowPivotRange == showPivotRange && cacheanaPivotsHourly[idx].EqualsInput(input))
                        return cacheanaPivotsHourly[idx];

            lock (checkanaPivotsHourly)
            {
                checkanaPivotsHourly.AlignThis = alignThis;
                alignThis = checkanaPivotsHourly.AlignThis;
                checkanaPivotsHourly.Period = period;
                period = checkanaPivotsHourly.Period;
                checkanaPivotsHourly.ShowHighLow = showHighLow;
                showHighLow = checkanaPivotsHourly.ShowHighLow;
                checkanaPivotsHourly.ShowLevels34 = showLevels34;
                showLevels34 = checkanaPivotsHourly.ShowLevels34;
                checkanaPivotsHourly.ShowPivotRange = showPivotRange;
                showPivotRange = checkanaPivotsHourly.ShowPivotRange;

                if (cacheanaPivotsHourly != null)
                    for (int idx = 0; idx < cacheanaPivotsHourly.Length; idx++)
                        if (cacheanaPivotsHourly[idx].AlignThis == alignThis && cacheanaPivotsHourly[idx].Period == period && cacheanaPivotsHourly[idx].ShowHighLow == showHighLow && cacheanaPivotsHourly[idx].ShowLevels34 == showLevels34 && cacheanaPivotsHourly[idx].ShowPivotRange == showPivotRange && cacheanaPivotsHourly[idx].EqualsInput(input))
                            return cacheanaPivotsHourly[idx];

                anaPivotsHourly indicator = new anaPivotsHourly();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.AlignThis = alignThis;
                indicator.Period = period;
                indicator.ShowHighLow = showHighLow;
                indicator.ShowLevels34 = showLevels34;
                indicator.ShowPivotRange = showPivotRange;
                Indicators.Add(indicator);
                indicator.SetUp();

                anaPivotsHourly[] tmp = new anaPivotsHourly[cacheanaPivotsHourly == null ? 1 : cacheanaPivotsHourly.Length + 1];
                if (cacheanaPivotsHourly != null)
                    cacheanaPivotsHourly.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheanaPivotsHourly = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaPivotsHourly anaPivotsHourly(anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            return _indicator.anaPivotsHourly(Input, alignThis, period, showHighLow, showLevels34, showPivotRange);
        }

        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaPivotsHourly anaPivotsHourly(Data.IDataSeries input, anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            return _indicator.anaPivotsHourly(input, alignThis, period, showHighLow, showLevels34, showPivotRange);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.anaPivotsHourly anaPivotsHourly(anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            return _indicator.anaPivotsHourly(Input, alignThis, period, showHighLow, showLevels34, showPivotRange);
        }

        /// <summary>
        /// The indicator plots intraday pivots based on a customizable period.
        /// </summary>
        /// <returns></returns>
        public Indicator.anaPivotsHourly anaPivotsHourly(Data.IDataSeries input, anaAlignPH alignThis, int period, bool showHighLow, bool showLevels34, bool showPivotRange)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.anaPivotsHourly(input, alignThis, period, showHighLow, showLevels34, showPivotRange);
        }
    }
}
#endregion
