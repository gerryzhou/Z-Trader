#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.DirectWrite;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.Infinity
{
	public class FootPrint : Indicator
	{
		#region BarItem
		
		public class BarItem
		{
			public double v = 0.0;
			
			public ConcurrentDictionary<double, RowData> l = new ConcurrentDictionary<double, RowData>();
		}
		
		#endregion
		
		#region Profile
		
		public class Profile
		{
			public double v = 0.0;
			
			public ConcurrentDictionary<double, RowData> l = new ConcurrentDictionary<double, RowData>();
		}
		
		#endregion
		
		#region RowData
		
		public class RowData
		{
			public double tv = 0.0; // total volume
			public double av = 0.0; // ask volume
			public double bv = 0.0; // bid volume
		}
		
		#endregion
		
		#region Class Helpers
		
		// getPoc
		//
		private double getPoc(ConcurrentDictionary<double, RowData> dict)
		{
			double poc = 0.0;
			
			if(!dict.IsEmpty)
			{
				poc = dict.Keys.Aggregate((i, j) => dict[i].tv > dict[j].tv ? i : j);
			}
			
			return poc;
		}
		
		// getDelta
		//
		private double getDelta(ConcurrentDictionary<double, RowData> dict)
		{
			double askSum = 0.0;
			double bidSum = 0.0;
			
			if(!dict.IsEmpty)
			{
				foreach(KeyValuePair<double, RowData> rd in dict)
				{
					askSum += rd.Value.av;
					bidSum += rd.Value.bv;
				}
			}
			
			return (askSum - bidSum);
		}
		
		// getVolume
		//
		private double getVolume(ConcurrentDictionary<double, RowData> dict, double key)
		{
			double tv = 0.0;
			
			key = mInst.RoundToTickSize(key);
			
			if(dict.ContainsKey(key))
			{
				tv = dict[key].tv;
			}
			
			return tv;
		}
		
		// getMaxVolume
		//
		private double getMaxVolume(ConcurrentDictionary<double, RowData> dict)
		{
			double mv = 0.0;
			
			if(!dict.IsEmpty)
			{
				foreach(KeyValuePair<double, RowData> rd in dict)
				{
					mv = (rd.Value.av > mv) ? rd.Value.av : mv;
					mv = (rd.Value.bv > mv) ? rd.Value.bv : mv;
				}
			}
			
			return mv;
		}
		
		// getTotalVolume
		//
		private double getTotalVolume(ConcurrentDictionary<double, RowData> dict)
		{
			double tv = 0.0;
			
			if(!dict.IsEmpty)
			{
				foreach(KeyValuePair<double, RowData> rd in dict)
				{
					tv += rd.Value.tv;
				}
			}
			
			return tv;
		}
		
		// getAskImbalanceRatio
		//
		private double getAskImbalanceRatio(ConcurrentDictionary<double, RowData> dict, double key)
		{
			double volRatio = 0.0;
			double askPrice = mInst.RoundToTickSize(key);
			double bidPrice = mInst.RoundToTickSize(key - TickSize);
			
			if(!dict.ContainsKey(askPrice) || !dict.ContainsKey(bidPrice))
			{
				return volRatio;
			}
			
			double askVolume = dict[askPrice].av;
			double bidVolume = dict[bidPrice].bv;
			
			if(askVolume > bidVolume)
			{
				if(askVolume - bidVolume >= minImbalance)
				{
					volRatio = (askVolume - bidVolume) / (askVolume + bidVolume);
				}
			}
			
			return volRatio;
		}
		
		// getBidImbalanceRatio
		//
		private double getBidImbalanceRatio(ConcurrentDictionary<double, RowData> dict, double key)
		{
			double volRatio = 0.0;
			double askPrice = mInst.RoundToTickSize(key + TickSize);
			double bidPrice = mInst.RoundToTickSize(key);
			
			if(!dict.ContainsKey(askPrice) || !dict.ContainsKey(bidPrice))
			{
				return volRatio;
			}
			
			double askVolume = dict[askPrice].av;
			double bidVolume = dict[bidPrice].bv;
			
			if(bidVolume > askVolume)
			{
				if(bidVolume - askVolume >= minImbalance)
				{
					volRatio = (bidVolume - askVolume) / (bidVolume + askVolume);
				}
			}
			
			return volRatio;
		}
		
		// getValueArea
		//
		private double[] getValueArea(ConcurrentDictionary<double, RowData> dict)
		{
			double vah = 0.0;
			double val = 0.0;
			
			double[] ret = {vah,val};
			
			if(!dict.IsEmpty)
			{
				int    iteCnt = 0;
				double maxPrc = dict.Keys.Max();
				double minPrc = dict.Keys.Min();
				double pocPrc = getPoc(dict);
				double volSum = getTotalVolume(dict);
				double maxVol = volSum * 0.7;
				double volTmp = 0.0;
				double upperP = pocPrc + TickSize;
				double lowerP = pocPrc - TickSize;
				double upperV = 0.0;
				double lowerV = 0.0;
				
				volTmp = getVolume(dict, pocPrc);
				
				while(volTmp < maxVol)
				{
					if((upperP == maxPrc && lowerP == minPrc) || iteCnt >= 500) { break; }
					
					upperV = getVolume(dict, upperP) + getVolume(dict, upperP + TickSize);
					lowerV = getVolume(dict, lowerP) + getVolume(dict, lowerP - TickSize);
					
					if(upperV > lowerV)
					{
						vah	   = mInst.RoundToTickSize(upperP + TickSize);
						volTmp = volTmp + upperV; 
						upperP = mInst.RoundToTickSize(vah + TickSize);
					}
					else
					{
						val	   = mInst.RoundToTickSize(lowerP - TickSize);
						volTmp = volTmp + lowerV; 
						lowerP = mInst.RoundToTickSize(val - TickSize);
					}
					
					iteCnt++;
				}
				
				ret[0] = Math.Min(maxPrc, vah);
				ret[1] = Math.Max(minPrc, val);
			}
			
			return ret;
		}
		
		// fillMissingTicks
		//
		private void fillMissingTicks(int index)
		{
			double hi = Bars.GetHigh(CurrentBar - index);
			double lo = Bars.GetLow(CurrentBar - index);
			double pr = mInst.RoundToTickSize(hi);
			
			while(pr > lo)
			{
				BarItems[index].l.TryAdd(pr, new RowData());
				
				pr = mInst.RoundToTickSize(pr - TickSize);
			}
		}
		
		#endregion
		
		#region Variables
		
		private double ask = 0.0;
		private double bid = 0.0;
		private double cls = 0.0;
		private double vol = 0.0;
		private double tmp = 0.0;
		
		private double min = 0.0;
		private double max = 0.0;
		private double rng = 0.0;
		private double off = 0.0;
		private double dif = 0.0;
		
		// ---
		
		private bool 	 setDate = false;
		private DateTime getDate;
		private DateTime lastRender;
		
		// ---
		
		private SimpleFont sf;
		
		// ---
		
		private double 			 tSize = 0.0;
		private MasterInstrument mInst = null;
		
		#endregion
		
		private Series<BarItem> BarItems;
		private Series<Profile> Profiles;
		
		// OnStateChange
		//
		protected override void OnStateChange()
		{
			if(State == State.SetDefaults)
			{
				Description					= @"";
				Name						= "FootPrint";
				Calculate					= Calculate.OnEachTick;
				IsOverlay					= true;
				IsAutoScale 				= false;
				DrawOnPricePanel			= true;
				PaintPriceMarkers			= false;
				IsSuspendedWhileInactive	= false;
				ScaleJustification			= ScaleJustification.Right;
				
				maxDays			 = 3;
				cellColor 		 = new SolidColorBrush(System.Windows.Media.Color.FromRgb(45, 45, 45)); cellColor.Freeze();
				highColor 		 = new SolidColorBrush(System.Windows.Media.Color.FromRgb(72, 72, 72)); highColor.Freeze();
				currColor		 = new SolidColorBrush(System.Windows.Media.Color.FromRgb(130, 130, 130)); currColor.Freeze();
				markColor		 = Brushes.White;	
				markOpacity		 = 0.05f;
				textColor		 = Brushes.Gray;
				textSize		 = 11;
				askColor    	 = Brushes.YellowGreen;
				bidColor    	 = Brushes.Tomato;
				pocColor		 = new SolidColorBrush(System.Windows.Media.Color.FromRgb(50, 154, 205)); pocColor.Freeze();
				minImbalance	 = 100.0;
				minRatio     	 = 0.3;
				autoScroll       = true;
				setOulineColor   = true;
				showDelta		 = true;
				showBidAsk		 = true;
				showProfile		 = true;
				showPoc			 = true;
				showUnfinished	 = false;
				fadeCells		 = false;
				fadeText		 = false;
				indicatorVersion = "1.6 | May 2017";
			}
			else if(State == State.Configure)
			{
				sf = new NinjaTrader.Gui.Tools.SimpleFont("Consolas", textSize);
				
				BarItems = new Series<BarItem>(this, MaximumBarsLookBack.Infinite);
				Profiles = new Series<Profile>(this, MaximumBarsLookBack.Infinite);
				
				if(ChartBars != null)
				{
					ZOrder = ChartBars.ZOrder - 1;
				}
				
				if(!Bars.IsTickReplay)
				{
					Draw.TextFixed(this, "tickReplay", "Please enable Tick Replay!", TextPosition.TopRight);
				}
				
				if(!setDate)
				{
					getDate = getStartDate((maxDays - 1) * -1);
					setDate = true;
				}
			}
			else if(State == State.DataLoaded)
			{
				if(Instrument != null)
				{
					tSize = TickSize;
					mInst = Instrument.MasterInstrument;
				}
			}
			else if(State == State.Terminated)
			{
				System.GC.Collect();
			}
		}
		
		// getStartDate
		//
		private DateTime getStartDate(int workDays)
	    {
			int 			dir = workDays < 0 ? -1 : 1;
			DateTime        now = DateTime.UtcNow;
			SessionIterator sit = new SessionIterator(Bars); sit.GetNextSession(now, true);
			DateTime 		act = sit.ActualSessionBegin;
			
		    while(workDays != 0)
		    {
		     	act = act.AddDays(dir);
				
		      	if(act.DayOfWeek != DayOfWeek.Saturday && act.DayOfWeek != DayOfWeek.Sunday)
		      	{
		        	workDays -= dir;
		      	}
		    }
			
		    return act;
	    }
		
		#region OnMarketData
		
		// OnMarketData
		//
		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if(Bars.Count < 0)   { return; }
			if(CurrentBar < 1)   { return; }
			if(e.Time < getDate) { return; }
			
			if(showBidAsk && State == State.Realtime)
			{
				if((DateTime.Now - lastRender).TotalMilliseconds >= 250)
				{
					ForceRefresh();
				}
			}
			
			if(BarItems[0] == null)
			{
				BarItems[0] = new BarItem();
			}
			
			if(e.MarketDataType == MarketDataType.Last)
			{
				ask = e.Ask;
				bid = e.Bid;
				cls = e.Price;
				vol = e.Volume;
				
				if(!BarItems[0].l.ContainsKey(cls))
				{
					BarItems[0].l.TryAdd(cls, new RowData());
				}
				
				if(cls >= ask)
				{
					BarItems[0].v += vol;
					BarItems[0].l[cls].tv += vol;
					BarItems[0].l[cls].av += vol;
					
					fillMissingTicks(0);
				}
				
				if(cls <= bid)
				{
					BarItems[0].v += vol;
					BarItems[0].l[cls].tv += vol;
					BarItems[0].l[cls].bv += vol;
					
					fillMissingTicks(0);
				}
				
				if(!showProfile && !showPoc) { return; }
				
				if(State == State.Realtime)
				{
					calculateProfile(false);
				}
			}
		}
		
		#endregion
		
		// OnBarUpdate
		//
		protected override void OnBarUpdate()
		{
			if(CurrentBar < 1) { return; }
			
			tmp = Close[0];
			tmp = Volume[0];
			
			if(setOulineColor)
			{
				CandleOutlineBrushes[0] = currColor;
				
				if(Close[0] > Open[0])
				{
					CandleOutlineBrushes[0] = askColor;
					BarBrushes[0] 			= askColor;
				}
				if(Close[0] < Open[0])
				{
					CandleOutlineBrushes[0] = bidColor;
					BarBrushes[0] 			= bidColor;
				}
			}
			
			if(!showProfile && !showPoc) { return; }
			
			if(State == State.Historical)
			{
				if(IsFirstTickOfBar)
				{
					calculateProfile(true);
					
					if(CurrentBar == ChartBars.Count - 1)
					{
						calculateProfile(false);
					}
				}
			}
		}
		
		// calculateProfile
		//
		private void calculateProfile(bool hist)
		{
			int ind  = (hist) ? 1 : 0;
			
			if(Profiles[ind] == null)
			{
				Profiles[ind] = new Profile();
			}
			
			Profiles[ind].v = 0.0;
			Profiles[ind].l.Clear();
			
			if(Bars.IsFirstBarOfSessionByIndex(CurrentBar - ind))
			{
				if(BarItems[ind] == null)   { return; }
				if(BarItems[ind].l.IsEmpty) { return; }
				
				Profiles[ind].v += BarItems[ind].v;
				
				foreach(KeyValuePair<double, RowData> rd in BarItems[ind].l)
				{
					if(!Profiles[ind].l.ContainsKey(rd.Key))
					{
						Profiles[ind].l.TryAdd(rd.Key, new RowData());
					}
					
					Profiles[ind].l[rd.Key].tv += BarItems[ind].l[rd.Key].tv;
					Profiles[ind].l[rd.Key].av += BarItems[ind].l[rd.Key].av;
					Profiles[ind].l[rd.Key].bv += BarItems[ind].l[rd.Key].bv;
				}
			}
			else
			{
				if(Profiles.IsValidDataPoint(ind + 1))
				{
					Profiles[ind].v = Profiles[ind + 1].v;
					
					foreach(KeyValuePair<double, RowData> rd in Profiles[ind + 1].l)
					{
						if(!Profiles[ind].l.ContainsKey(rd.Key))
						{
							Profiles[ind].l.TryAdd(rd.Key, new RowData());
						}
						
						Profiles[ind].l[rd.Key].tv = Profiles[ind + 1].l[rd.Key].tv;
						Profiles[ind].l[rd.Key].av = Profiles[ind + 1].l[rd.Key].av;
						Profiles[ind].l[rd.Key].bv = Profiles[ind + 1].l[rd.Key].bv;
					}
					
					if(BarItems[ind] == null)   { return; }
					if(BarItems[ind].l.IsEmpty) { return; }
					
					Profiles[ind].v += BarItems[ind].v;
					
					foreach(KeyValuePair<double, RowData> rd in BarItems[ind].l)
					{
						if(!Profiles[ind].l.ContainsKey(rd.Key))
						{
							Profiles[ind].l.TryAdd(rd.Key, new RowData());
						}
						
						Profiles[ind].l[rd.Key].tv += BarItems[ind].l[rd.Key].tv;
						Profiles[ind].l[rd.Key].av += BarItems[ind].l[rd.Key].av;
						Profiles[ind].l[rd.Key].bv += BarItems[ind].l[rd.Key].bv;
					}
				}
			}
		}
		
		// OnRender
		//
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if(Bars == null || Bars.Instrument == null || IsInHitTest || CurrentBar < 1 || !isActiveTab(chartControl)) { return; }
			
			lastRender = DateTime.Now;
			
			base.OnRender(chartControl, chartScale);
			
			try
        	{
				drawPOC(chartControl, chartScale);
				drawFootPrint(chartControl, chartScale);
				drawProfile(chartControl, chartScale);
			}
			catch(Exception e)
	        {
	            Console.WriteLine("FootPrint: '{0}'", e);
	        }
		}
		
		// isActiveTab
		//
		private bool isActiveTab(ChartControl cControl)
		{
			if(!cControl.Properties.AreTabsVisible)
			{
				return true;
			}
			
			bool isActive = false;
			
			NinjaTrader.Gui.Chart.Chart	cWindow = System.Windows.Window.GetWindow(ChartControl.Parent) as Chart;
			
			foreach(System.Windows.Controls.TabItem tab in cWindow.MainTabControl.Items)
			{
				if((tab.Content as ChartTab).ChartControl == ChartControl && tab == cWindow.MainTabControl.SelectedItem)
				{
					isActive = true;
					break;
				}
			}
			
			return isActive;
		}
		
		#region Utilities
		
		// getTextWidth
		//
		private int getTextWidth(string text)
		{
			float textWidth = 0f;
			
			if(text.Length > 0)
			{
				TextFormat tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
				TextLayout tl = new TextLayout(Core.Globals.DirectWriteFactory, text, tf, ChartPanel.W, ChartPanel.H);
				
				textWidth = tl.Metrics.Width;
				
				tf.Dispose();
				tl.Dispose();
			}
			
			return (int)textWidth;
		}
		
		// getCellWidth
		//
		private int getCellWidth()
		{
			BarItem currBarItem;
			
			double maxValue = 0.0;
			float  maxWidth = 0f;
			float  curWidth = 0f;
			
			for(int i=ChartBars.FromIndex;i<=ChartBars.ToIndex;i++)
			{
				if(BarItems.IsValidDataPointAt(i))
				{
					currBarItem = BarItems.GetValueAt(i);
				}
				else
				{
					continue;
				}
				
				if(currBarItem == null)   { continue; }
				if(currBarItem.l.IsEmpty) { continue; }
				
				foreach(KeyValuePair<double, RowData> rd in currBarItem.l)
				{
					maxValue = (rd.Value.av > maxValue) ? rd.Value.av : maxValue;
					maxValue = (rd.Value.bv > maxValue) ? rd.Value.bv : maxValue;
				}
			}
			
			if(maxValue > 0.0)
			{
				TextFormat tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
				TextLayout tl = new TextLayout(Core.Globals.DirectWriteFactory, maxValue.ToString(), tf, ChartPanel.W, ChartPanel.H);
				
				maxWidth = tl.Metrics.Width;
				
				tf.Dispose();
				tl.Dispose();
			}
			
			return (int)(maxWidth + 7f);
		}
		
		#endregion
		
		#region drawFootPrint
		
		// drawFootPrint
		//
		private void drawFootPrint(ChartControl chartControl, ChartScale chartScale)
		{
			int cellWidth = getCellWidth();
			int domWidth  = getTextWidth("(99000)") + 6;
			int imbWidth  = getTextWidth("99000") + 6;
			int proWidth  = imbWidth * 4;
			
			int barFullWidth   = chartControl.GetBarPaintWidth(ChartBars);
			int barHalfWidth   = ((barFullWidth - 1) / 2) + 2;
			int minBarDistance = (int)(((cellWidth + barHalfWidth) * 2) + 2);
			
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			
			int   x1 = 0;
			int   x2 = 0;
			float y1 = 0;
			float y2 = 0;
			float tx = 0;
			float ty = 0;
			
			double mv = 0.0;
			
			double poc = 0.0;
			double dta = 0.0;
			double prc = Bars.GetClose(ChartBars.ToIndex);
			
			float opacity;
			
			ChartPanel chartPanel = chartControl.ChartPanels[chartScale.PanelIndex];
			
			BarItem currBarItem;
			
			ChartControlProperties chartProps = chartControl.Properties;
			
			SharpDX.Direct2D1.Brush backBrush = chartProps.ChartBackground.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush cellBrush = cellColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush highBrush = highColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush currBrush = currColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush textBrush = textColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush markBrush = markColor.ToDxBrush(RenderTarget);
			
			SharpDX.Direct2D1.Brush askBrush = askColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush bidBrush = bidColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush pocBrush = pocColor.ToDxBrush(RenderTarget);
			
			SharpDX.RectangleF rect = new SharpDX.RectangleF();
			SharpDX.Vector2    vec1 = new SharpDX.Vector2();
			SharpDX.Vector2    vec2 = new SharpDX.Vector2();
			
			TextLayout tl;
			TextFormat tf;
			SharpDX.DirectWrite.FontWeight fw;
			
			GlyphTypeface gtf 					= new GlyphTypeface();
			System.Windows.Media.Typeface tFace = new System.Windows.Media.Typeface(new System.Windows.Media.FontFamily(sf.Family.ToString()), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            tFace.TryGetGlyphTypeface(out gtf);
			
			// bid & ask
			
			#region bid & ask
			
			if(State == State.Realtime)
			{
				if(showBidAsk && ChartBars.ToIndex == Bars.Count - 1)
				{
					if(State == State.Realtime)
					{
						tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
						
						tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
						
						textBrush.Opacity = 0.66f;
						
						// ask
						
						double askPrc = GetCurrentAsk();
						double askVol = GetCurrentAskVolume();
						
						x1 = chartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex) + barHalfWidth + cellWidth + 2;
						
						y1 = ((chartScale.GetYByValue(askPrc) + chartScale.GetYByValue(askPrc + TickSize)) / 2) + 1;
						y2 = ((chartScale.GetYByValue(askPrc) + chartScale.GetYByValue(askPrc - TickSize)) / 2) - 1;
						
						rect.X      = (float)(x1);
						rect.Y      = (float)y1;
						rect.Width  = (float)domWidth;
						rect.Height = (float)Math.Abs(y1 - y2);
						
						backBrush.Opacity = 0.66f;
						RenderTarget.DrawRectangle(rect, backBrush);
						
						rect.Width  = rect.Width  - 1f;
						rect.Height = rect.Height - 1f;
						
						RenderTarget.FillRectangle(rect, backBrush);
						backBrush.Opacity = 1.0f;
						// ---
						
						tl = new TextLayout(Core.Globals.DirectWriteFactory, "("+askVol.ToString()+")", tf, rect.Width, chartPanel.H);
						
						tx = rect.X + 2;
						ty = (float)(chartScale.GetYByValue(askPrc) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
						
						vec1.X = tx;
						vec1.Y = ty;
						
						textBrush.Opacity = (prc == askPrc) ? 0.88f : 0.66f;
						
						RenderTarget.DrawTextLayout(vec1, tl, textBrush);
						
						// bid
						
						double bidPrc = GetCurrentBid();
						double bidVol = GetCurrentBidVolume();
						
						x1 = chartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex) + barHalfWidth + cellWidth + 2;
						
						y1 = ((chartScale.GetYByValue(bidPrc) + chartScale.GetYByValue(bidPrc + TickSize)) / 2) + 1;
						y2 = ((chartScale.GetYByValue(bidPrc) + chartScale.GetYByValue(bidPrc - TickSize)) / 2) - 1;
						
						rect.X      = (float)(x1);
						rect.Y      = (float)y1;
						rect.Width  = (float)domWidth;
						rect.Height = (float)Math.Abs(y1 - y2);
						
						backBrush.Opacity = 0.66f;
						RenderTarget.DrawRectangle(rect, backBrush);
						
						rect.Width  = rect.Width  - 1f;
						rect.Height = rect.Height - 1f;
						
						RenderTarget.FillRectangle(rect, backBrush);
						backBrush.Opacity = 1.0f;
						
						// ---
						
						tl = new TextLayout(Core.Globals.DirectWriteFactory, "("+bidVol.ToString()+")", tf, rect.Width, chartPanel.H);
						
						tx = rect.X + 2;
						ty = (float)(chartScale.GetYByValue(bidPrc) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
						
						vec1.X = tx;
						vec1.Y = ty;
						
						textBrush.Opacity = (prc == bidPrc) ? 0.88f : 0.66f;
						
						RenderTarget.DrawTextLayout(vec1, tl, textBrush);
						
						// ---
						
						tf.Dispose();
						tl.Dispose();
					}
				}
			}
			
			#endregion
			
			// price marker
			
			#region price marker
			
			if(State == State.Realtime)
			{
				if(ChartBars.ToIndex == Bars.Count - 1)
				{
					x1 = chartPanel.X;
					x2 = chartPanel.W;
					y1 = ((chartScale.GetYByValue(prc) + chartScale.GetYByValue(prc + TickSize)) / 2) + 1;
					y2 = ((chartScale.GetYByValue(prc) + chartScale.GetYByValue(prc - TickSize)) / 2) - 1;
					
					rect.X      = (float)(x1);
					rect.Y      = (float)y1;
					rect.Width  = (float)Math.Abs(x1 - x2);
					rect.Height = (float)Math.Abs(y1 - y2);
					
					markBrush.Opacity = markOpacity;
					
					RenderTarget.DrawRectangle(rect, markBrush);
					
					rect.Width  = rect.Width  - 1;
					rect.Height = rect.Height - 1;
					
					RenderTarget.FillRectangle(rect, markBrush);
				}
			}
			
			#endregion
			
			for(int i=ChartBars.FromIndex;i<=ChartBars.ToIndex;i++)
			{
				if(BarItems.IsValidDataPointAt(i))
				{
					currBarItem = BarItems.GetValueAt(i);
				}
				else
				{
					continue;
				}
				
				if(currBarItem == null)   { continue; }
				if(currBarItem.l.IsEmpty) { continue; }
				
				x1 = chartControl.GetXByBarIndex(ChartBars, i);
				x2 = x1 + 20;
				
				mv = getMaxVolume(currBarItem.l);
				
				poc = getPoc(currBarItem.l);
				dta = 0.0;
				
				foreach(KeyValuePair<double, RowData> rd in currBarItem.l)
				{
					dta += (rd.Value.av - rd.Value.bv);
					
					y1 = ((chartScale.GetYByValue(rd.Key) + chartScale.GetYByValue(rd.Key + TickSize)) / 2) + 1;
					y2 = ((chartScale.GetYByValue(rd.Key) + chartScale.GetYByValue(rd.Key - TickSize)) / 2) - 1;
		 			
					// ask - rect
					
					rect.X      = (float)(x1 + barHalfWidth);
					rect.Y      = (float)y1;
					rect.Width  = (float)cellWidth;
					rect.Height = (float)Math.Abs(y1 - y2);
					
					bool isAskImbalance = (getAskImbalanceRatio(currBarItem.l, rd.Key) >= minRatio) ? true : false;
					bool isBidImbalance = (getBidImbalanceRatio(currBarItem.l, rd.Key) >= minRatio) ? true : false;
					
					if(fadeCells)
					{
						backBrush.Opacity = 1.0f;
						
						RenderTarget.DrawRectangle(rect, backBrush);
						RenderTarget.FillRectangle(rect, backBrush);
						
						opacity = (float)((1.0 / mv) * rd.Value.av);
						opacity = Math.Max(opacity, 0.1f);
						
						highBrush.Opacity = opacity;
						
						RenderTarget.DrawRectangle(rect, highBrush);
						
						rect.Width  = rect.Width  - 1;
						rect.Height = rect.Height - 1;
						
						RenderTarget.FillRectangle(rect, highBrush);
						
						rect.Width  = rect.Width  + 1;
						rect.Height = rect.Height + 1;
						
						highBrush.Opacity = 1.0f;
					}
					else
					{
						if(rd.Key == poc)
						{
							RenderTarget.DrawRectangle(rect, highBrush);
							RenderTarget.FillRectangle(rect, highBrush);
						}
						else
						{
							RenderTarget.DrawRectangle(rect, cellBrush);
							RenderTarget.FillRectangle(rect, cellBrush);
						}
					}
					
					// poc
					
					if(rd.Key == poc)
					{
						pocBrush.Opacity = 0.66f;
						
						vec1.X = rect.X + cellWidth - 1f;
						vec1.Y = y1 - 1f;
						
						vec2.X = rect.X + cellWidth - 1f;
						vec2.Y = y2;
						
						RenderTarget.DrawLine(vec1, vec2, pocBrush, 3);
					}
					
					if(isAskImbalance)
					{
						opacity = 0.66f;
						
						if(fadeText)
						{
							opacity = (float)((1.0 / mv) * rd.Value.av) + 0.25f;
							opacity = Math.Min(1.0f, opacity);
						}
						
						askBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentAsk() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						
						vec1.X = rect.X + cellWidth;
						vec1.Y = y1 - 1f;
						
						vec2.X = rect.X + cellWidth;
						vec2.Y = y2;
						
						RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
					}
					
					// unfinished auction
					
					if(showUnfinished)
					{
						if(rd.Key == currBarItem.l.Keys.Min())
						{
							if(rd.Value.av > 0.0 && rd.Value.bv > 0.0)
							{
								askBrush.Opacity = 0.05f;
								
								RenderTarget.DrawRectangle(rect, askBrush);
								
								rect.Width  = rect.Width  - 1;
								rect.Height = rect.Height - 1;
								
								RenderTarget.FillRectangle(rect, askBrush);
								
								rect.Width  = rect.Width  + 1;
								rect.Height = rect.Height + 1;
								
								vec1.X = rect.X;
								vec1.Y = y1 - 1f;
								
								vec2.X = rect.X;
								vec2.Y = y2;
								
								askBrush.Opacity = 0.44f;
								RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
								
								vec1.X = rect.X + cellWidth;
								vec1.Y = y1 - 1f;
								
								vec2.X = rect.X + cellWidth;
								vec2.Y = y2;
								
								RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
							}
						}
					}
					
					// ask - outline
					
					if(i == Bars.Count-1)
					{
						if(GetCurrentAsk() == rd.Key && rd.Key == prc)
						{
							vec1.X = rect.X - 1;
							vec1.Y = rect.Y;
							
							vec2.X = rect.X + rect.Width;
							vec2.Y = rect.Y;
							
							RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
							
							vec1.X = rect.X - 1;
							vec1.Y = rect.Y + rect.Height;
							
							vec2.X = rect.X + rect.Width;
							vec2.Y = rect.Y + rect.Height;
							
							RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
						}
					}
					
					// ask - text
					
					fw = (rd.Key == poc) ? SharpDX.DirectWrite.FontWeight.UltraBold : SharpDX.DirectWrite.FontWeight.Normal;
					
					tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), fw, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
					
					tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
					
					tl = new TextLayout(Core.Globals.DirectWriteFactory, rd.Value.av.ToString(), tf, rect.Width, chartPanel.H);
					
					tx = rect.X + 2;
					ty = (float)(chartScale.GetYByValue(rd.Key) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
					
					vec1.X = tx;
					vec1.Y = ty;
					
					opacity = 0.66f;
					
					if(fadeText)
					{
						opacity = (float)((1.0 / mv) * rd.Value.av) + 0.25f;
						opacity = Math.Min(1.0f, opacity);
					}
					
					if(isAskImbalance)
					{
						askBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentAsk() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						RenderTarget.DrawTextLayout(vec1, tl, askBrush);
					}
					else
					{
						textBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentAsk() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						RenderTarget.DrawTextLayout(vec1, tl, textBrush);
					}
					
					// ---
					
					tl.Dispose();
					tf.Dispose();
					
					// ------------------------------------------------------------------------------ //
					
					// bid - rect
					
					rect.X      = (float)(x1 - barHalfWidth - cellWidth);
					rect.Y      = (float)y1;
					rect.Width  = (float)cellWidth;
					rect.Height = (float)Math.Abs(y1 - y2);
					
					if(fadeCells)
					{
						backBrush.Opacity = 1.0f;
						
						RenderTarget.DrawRectangle(rect, backBrush);
						RenderTarget.FillRectangle(rect, backBrush);
						
						opacity = (float)((0.9 / mv) * rd.Value.bv);
						opacity = Math.Max(opacity, 0.1f);
						
						highBrush.Opacity = opacity;
						
						RenderTarget.DrawRectangle(rect, highBrush);
						
						rect.Width  = rect.Width  - 1;
						rect.Height = rect.Height - 1;
						
						RenderTarget.FillRectangle(rect, highBrush);
						
						rect.Width  = rect.Width  + 1;
						rect.Height = rect.Height + 1;
						
						highBrush.Opacity = 1.0f;
					}
					else
					{
						if(rd.Key == poc)
						{
							RenderTarget.DrawRectangle(rect, highBrush);
							RenderTarget.FillRectangle(rect, highBrush);
						}
						else
						{
							RenderTarget.DrawRectangle(rect, cellBrush);
							RenderTarget.FillRectangle(rect, cellBrush);
						}
					}
					
					// poc
					
					if(rd.Key == poc)
					{
						pocBrush.Opacity = 0.66f;
						
						vec1.X = rect.X + 1f;
						vec1.Y = y1 - 1f;
						
						vec2.X = rect.X + 1f;
						vec2.Y = y2;
						
						RenderTarget.DrawLine(vec1, vec2, pocBrush, 3);
					}
					
					if(isBidImbalance)
					{
						opacity = 0.66f;
						
						if(fadeText)
						{
							opacity = (float)((1.0 / mv) * rd.Value.bv) + 0.25f;
							opacity = Math.Min(1.0f, opacity);
						}
						
						bidBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentBid() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						
						vec1.X = rect.X;
						vec1.Y = y1 - 1f;
						
						vec2.X = rect.X;
						vec2.Y = y2;
						
						RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
					}
					
					// unfinished auction
					
					if(showUnfinished)
					{
						if(rd.Key == currBarItem.l.Keys.Max())
						{
							if(rd.Value.av > 0.0 && rd.Value.bv > 0.0)
							{
								bidBrush.Opacity = 0.05f;
								
								RenderTarget.DrawRectangle(rect, bidBrush);
								
								rect.Width  = rect.Width  - 1;
								rect.Height = rect.Height - 1;
								
								RenderTarget.FillRectangle(rect, bidBrush);
								
								rect.Width  = rect.Width  + 1;
								rect.Height = rect.Height + 1;
								
								vec1.X = rect.X;
								vec1.Y = y1 - 1f;
								
								vec2.X = rect.X;
								vec2.Y = y2;
								
								bidBrush.Opacity = 0.44f;
								RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
								
								vec1.X = rect.X + cellWidth;
								vec1.Y = y1 - 1f;
								
								vec2.X = rect.X + cellWidth;
								vec2.Y = y2;
								
								RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
							}
						}
					}
					
					// bid - outline
					
					if(i == Bars.Count-1)
					{
						if(GetCurrentBid() == rd.Key && rd.Key == prc)
						{
							vec1.X = rect.X - 1;
							vec1.Y = rect.Y;
							
							vec2.X = rect.X + rect.Width;
							vec2.Y = rect.Y;
							
							RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
							
							vec1.X = rect.X - 1;
							vec1.Y = rect.Y + rect.Height;
							
							vec2.X = rect.X + rect.Width;
							vec2.Y = rect.Y + rect.Height;
							
							RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
						}
					}
					
					// bid - text
					
					fw = (rd.Key == poc) ? SharpDX.DirectWrite.FontWeight.UltraBold : SharpDX.DirectWrite.FontWeight.Normal;
					
					tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), fw, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
					
					tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Trailing;
					
					tl = new TextLayout(Core.Globals.DirectWriteFactory, rd.Value.bv.ToString(), tf, rect.Width, chartPanel.H);
					
					tx = rect.X - 3;
					ty = (float)(chartScale.GetYByValue(rd.Key) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
					
					vec1.X = tx;
					vec1.Y = ty;
					
					opacity = 0.66f;
					
					if(fadeText)
					{
						opacity = (float)((1.0 / mv) * rd.Value.bv) + 0.25f;
						opacity = Math.Min(1.0f, opacity);
					}
					
					if(isBidImbalance)
					{
						bidBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentBid() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						RenderTarget.DrawTextLayout(vec1, tl, bidBrush);
					}
					else
					{
						textBrush.Opacity = (rd.Key == poc || (i == ChartBars.ToIndex && GetCurrentBid() == rd.Key && rd.Key == prc)) ? 1.0f : opacity;
						RenderTarget.DrawTextLayout(vec1, tl, textBrush);
					}
					
					// ---
					
					tl.Dispose();
					tf.Dispose();
				}
				
				// delta
				
				if(showDelta)
				{
					rect.X      = (float)(x1 - barHalfWidth - cellWidth);
					rect.Y      = (float)(chartPanel.H - textSize);
					rect.Width  = (float)((barHalfWidth * 2) + (cellWidth * 2));
					rect.Height = (float)textSize;
					
					tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
					
					tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Center;
					
					max = currBarItem.l.Keys.Max();
					min = currBarItem.l.Keys.Min();
					
					y1 = ((chartScale.GetYByValue(max) + chartScale.GetYByValue(max + TickSize)) / 2) + 1;
					y2 = ((chartScale.GetYByValue(min) + chartScale.GetYByValue(min - TickSize)) / 2) - 1;
					
					vec1.X = rect.X - 1;
					vec1.Y = y1 - 2;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = y1 - 2;
					
					if(dta < 0.0)
					{
						bidBrush.Opacity = 0.33f;
						RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
					}
					else
					{
						askBrush.Opacity = 0.33f;
						RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
					}
					
					vec1.X = rect.X - 1;
					vec1.Y = y2 + 2;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = y2 + 2;
					
					if(dta < 0.0)
					{
						bidBrush.Opacity = 0.33f;
						RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
					}
					else
					{
						askBrush.Opacity = 0.33f;
						RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
					}
					
					// footer
					
					if(dta < 0.0)
					{
						bidBrush.Opacity = 0.2f;
						RenderTarget.DrawRectangle(rect, backBrush);
						RenderTarget.DrawRectangle(rect, bidBrush);
						
						rect.Width = rect.Width - 1;
						rect.Height = rect.Height - 1;
						
						RenderTarget.FillRectangle(rect, backBrush);
						RenderTarget.FillRectangle(rect, bidBrush);
						bidBrush.Opacity = 0.8f;
						
						rect.Y = rect.Y - (float)(textSize * (1.0 - gtf.Baseline));
						
						RenderTarget.DrawText(dta.ToString(), tf, rect, bidBrush);
					}
					else
					{
						askBrush.Opacity = 0.2f;
						RenderTarget.DrawRectangle(rect, backBrush);
						RenderTarget.DrawRectangle(rect, askBrush);
						
						rect.Width = rect.Width - 1;
						rect.Height = rect.Height - 1;
						
						RenderTarget.FillRectangle(rect, backBrush);
						RenderTarget.FillRectangle(rect, askBrush);
						askBrush.Opacity = 0.8f;
						
						rect.Y = rect.Y - (float)(textSize * (1.0 - gtf.Baseline));
						
						RenderTarget.DrawText(dta.ToString(), tf, rect, askBrush);
					}
					
					// ---
					/*
					
					double h = 0.0;
					
					h = ((textSize * 2) / maxVol) * bidSum;
					
					rect.X      = (float)(x1 - barHalfWidth - cellWidth - 1);
					rect.Y      = (float)(chartPanel.H - textSize - h - 2);
					rect.Width  = (float)(cellWidth + barHalfWidth);
					rect.Height = (float)h;
					
					bidBrush.Opacity = 0.2f;
					RenderTarget.FillRectangle(rect, bidBrush);
					
					// ---
					
					h = ((textSize * 2) / maxVol) * askSum;
					
					rect.X      = (float)(x1);
					rect.Y      = (float)(chartPanel.H - textSize - h - 2);
					rect.Width  = (float)(cellWidth + barHalfWidth);
					rect.Height = (float)h;
					
					askBrush.Opacity = 0.2f;
					RenderTarget.FillRectangle(rect, askBrush);
					
					*/
					// ---
					
					tf.Dispose();
				}
			}
			
			askBrush.Dispose();
			bidBrush.Dispose();
			pocBrush.Dispose();
			
			backBrush.Dispose();
			cellBrush.Dispose();
			highBrush.Dispose();
			currBrush.Dispose();
			textBrush.Dispose();
			
			chartPanel	= null;
			chartProps	= null;
			currBarItem	= null;
			gtf			= null;
			tFace		= null;
			
			// ---
			
			int minRightMargin = (int)(minBarDistance / 2);
			    minRightMargin = (showBidAsk)  ? (minRightMargin + domWidth + 2)      			 : minRightMargin;
				minRightMargin = (showProfile) ? (minRightMargin + imbWidth * 2 + 14 + proWidth) : minRightMargin;
			
			if(chartControl.Properties.BarMarginRight < minRightMargin)
			{
				chartControl.Properties.BarMarginRight = minRightMargin;
			}
			
			if(chartControl.Properties.BarDistance < minBarDistance)
			{
				chartControl.Properties.BarDistance = minBarDistance;
			}
			
			if(showDelta && chartScale.Properties.AutoScaleMarginLower < 8)
			{
				chartScale.Properties.AutoScaleMarginLower = 8;
			}
			
			// ---
			
			if(autoScroll && chartScale.Properties.YAxisRangeType == YAxisRangeType.Fixed)
			{
				rng = chartScale.MaxMinusMin;
				off = TickSize * 3;
				dif = TickSize * 4;
				
				if(prc >= chartScale.MaxValue - off)
				{
					chartScale.Properties.FixedScaleMax = prc + dif;
					chartScale.Properties.FixedScaleMin = (prc + dif) - rng;
				}
				
				if(prc <= chartScale.MinValue + off)
				{
					chartScale.Properties.FixedScaleMin = (prc - dif);
					chartScale.Properties.FixedScaleMax = (prc - dif) + rng;
				}
			}
			
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}
		
		#endregion
		
		#region drawPOC
		
		// drawPOC
		//
		private void drawPOC(ChartControl chartControl, ChartScale chartScale)
		{
			if(!showPoc) { return; }
			
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			
			SharpDX.Direct2D1.Brush pocBrush = pocColor.ToDxBrush(RenderTarget);
			
			SharpDX.Direct2D1.StrokeStyleProperties sp = new SharpDX.Direct2D1.StrokeStyleProperties() { DashOffset = 0.1f, DashStyle = SharpDX.Direct2D1.DashStyle.Dash };
			SharpDX.Direct2D1.StrokeStyle 			ss = new SharpDX.Direct2D1.StrokeStyle(RenderTarget.Factory, sp);
			
			int x1 = 0;
			int x2 = 0;
			int y1 = 0;
			int y2 = 0;
			
			double poc = 0.0;
			
			double[] vav = {0.0, 0.0};
			double   vah = 0.0;
			double   val = 0.0;
			
			Profile currProfile;
			
			SharpDX.RectangleF rect = new SharpDX.RectangleF();
			SharpDX.Vector2    vec1 = new SharpDX.Vector2();
			SharpDX.Vector2    vec2 = new SharpDX.Vector2();
			
			for(int i=ChartBars.FromIndex;i<=ChartBars.ToIndex;i++)
			{
				if(Profiles.IsValidDataPointAt(i))
				{
					currProfile = Profiles.GetValueAt(i);
				}
				else
				{
					return;
				}
				
				if(currProfile == null)   { continue; }
				if(currProfile.l.IsEmpty) { continue; }
				
				x2 = (i == ChartBars.ToIndex) ? chartControl.CanvasRight : chartControl.GetXByBarIndex(ChartBars, i);
				x1 = (x1 == 0) ? chartControl.GetXByBarIndex(ChartBars, i-1) : x1;
				
				poc = getPoc(currProfile.l);
				
				vav = getValueArea(currProfile.l);
				vah = vav[0];
				val = vav[1];
				
				if(poc != 0.0)
				{
					y1 = ((chartScale.GetYByValue(poc) + chartScale.GetYByValue(poc + TickSize)) / 2);
					y2 = ((chartScale.GetYByValue(poc) + chartScale.GetYByValue(poc - TickSize)) / 2);
					
					rect.X      = (float)x1;
					rect.Y      = (float)y1;
					rect.Width  = (float)Math.Abs(x1 - x2) - 1f;
					rect.Height = (float)Math.Abs(y1 - y2);
					
					pocBrush.Opacity = 0.22f;
					
					RenderTarget.DrawRectangle(rect, pocBrush);
					
					rect.Width  = rect.Width  - 1f;
					rect.Height = rect.Height - 1f;
					
					RenderTarget.FillRectangle(rect, pocBrush);
					
					// ---
					
					if(vah != 0.0)
					{
						y1 = chartScale.GetYByValue(vah);
						
						vec1.X = (float)x1;
						vec1.Y = (float)y1;
						vec2.X = (float)x2;
						vec2.Y = (float)y1;
						
						pocBrush.Opacity = 0.33f;
						
						RenderTarget.DrawLine(vec1, vec2, pocBrush, 2, ss);
					}
					
					if(val != 0.0)
					{
						y1 = chartScale.GetYByValue(val);
						
						vec1.X = (float)x1;
						vec1.Y = (float)y1;
						vec2.X = (float)x2;
						vec2.Y = (float)y1;
						

						pocBrush.Opacity = 0.33f;
						RenderTarget.DrawLine(vec1, vec2, pocBrush, 2, ss);
					}
				}
				
				x1 = x2;
			}
			
			pocBrush.Dispose();
			
			ss.Dispose();
			
			currProfile	= null;
			
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}
		
		#endregion
		
		#region drawProfile
		
		// drawProfile
		//
		private void drawProfile(ChartControl chartControl, ChartScale chartScale)
		{
			if(!showProfile) { return; }
			
			Profile currProfile;
			
			if(Profiles.IsValidDataPointAt(ChartBars.ToIndex))
			{
				currProfile = Profiles.GetValueAt(ChartBars.ToIndex);
			}
			else
			{
				return;
			}
			
			if(currProfile == null)   { return; }
			if(currProfile.l.IsEmpty) { return; }
			
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
			
			int imbWidth = getTextWidth("99000") + 6;
			int proWidth = imbWidth * 4;
			
			int   rx = chartControl.CanvasRight;
			int   x1 = 0;
			int   x2 = 0;
			float y1 = 0;
			float y2 = 0;
			float tx = 0;
			float ty = 0;
			
			double poc = getPoc(currProfile.l);
			double dta = getDelta(currProfile.l);
			double prc = Bars.GetClose(ChartBars.ToIndex);
			
			double maxPrc = currProfile.l.Keys.Max();
			double minPrc = currProfile.l.Keys.Min();
			double curPrc = maxPrc;
			double maxVol = 0.0;
			
			foreach(KeyValuePair<double, RowData> rd in currProfile.l)
			{
				maxVol = (currProfile.l[rd.Key].tv > maxVol) ? currProfile.l[rd.Key].tv : maxVol;
			}
			
			if(maxVol == 0.0) { return; }
			
			double currRatio = 0.0;
			double prevRatio = 0.0;
			
			ChartControlProperties chartProps = chartControl.Properties;
			ChartPanel 			   chartPanel = chartControl.ChartPanels[chartScale.PanelIndex];
			
			SharpDX.Direct2D1.Brush backBrush = chartProps.ChartBackground.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush cellBrush = cellColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush highBrush = highColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush currBrush = currColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush textBrush = textColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush markBrush = markColor.ToDxBrush(RenderTarget);
			
			SharpDX.Direct2D1.Brush askBrush = askColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush bidBrush = bidColor.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush pocBrush = pocColor.ToDxBrush(RenderTarget);
			
			SharpDX.RectangleF rect = new SharpDX.RectangleF();
			SharpDX.Vector2    vec1 = new SharpDX.Vector2();
			SharpDX.Vector2    vec2 = new SharpDX.Vector2();
			
			TextLayout tl;
			TextFormat tf;
			SharpDX.DirectWrite.FontWeight fw;
			
			GlyphTypeface gtf 					= new GlyphTypeface();
			System.Windows.Media.Typeface tFace = new System.Windows.Media.Typeface(new System.Windows.Media.FontFamily(sf.Family.ToString()), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            tFace.TryGetGlyphTypeface(out gtf);
			
			foreach(KeyValuePair<double, RowData> rd in currProfile.l)
			{
				curPrc = mInst.RoundToTickSize(rd.Key);
				
				if(!currProfile.l.ContainsKey(curPrc))
				{
					curPrc -= TickSize;
					continue;
				}
				
				y1 = ((chartScale.GetYByValue(curPrc) + chartScale.GetYByValue(curPrc + TickSize)) / 2) + 1;
				y2 = ((chartScale.GetYByValue(curPrc) + chartScale.GetYByValue(curPrc - TickSize)) / 2) - 1;
	 			
				// ask - rect
				
				rect.X      = (float)(rx - imbWidth);
				rect.Y      = (float)y1;
				rect.Width  = (float)imbWidth;
				rect.Height = (float)Math.Abs(y1 - y2);
				
				if(curPrc == poc)
				{
					RenderTarget.DrawRectangle(rect, highBrush);
					RenderTarget.FillRectangle(rect, highBrush);
				}
				else
				{
					RenderTarget.DrawRectangle(rect, cellBrush);
					RenderTarget.FillRectangle(rect, cellBrush);
				}
				
				if(curPrc == prc)
				{
					highBrush.Opacity = 0.33f;
					RenderTarget.DrawRectangle(rect, highBrush);
					
					rect.Width  = rect.Width  - 1f;
					rect.Height = rect.Height - 1f;
					
					RenderTarget.FillRectangle(rect, highBrush);
					highBrush.Opacity = 1.0f;
					
					rect.Width  = rect.Width  + 1f;
					rect.Height = rect.Height + 1f;
				}
				
				// ask - outline
				
				if(GetCurrentAsk() == curPrc && curPrc == prc)
				{
					vec1.X = rect.X - 1;
					vec1.Y = rect.Y;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = rect.Y;
					
					RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
					
					vec1.X = rect.X - 1;
					vec1.Y = rect.Y + rect.Height;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = rect.Y + rect.Height;
					
					RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
				}
				
				// ask - text
				
				fw = (curPrc == poc) ? SharpDX.DirectWrite.FontWeight.UltraBold : SharpDX.DirectWrite.FontWeight.Normal;
				
				tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), fw, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
				
				tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
				
				tl = new TextLayout(Core.Globals.DirectWriteFactory, currProfile.l[curPrc].av.ToString(), tf, rect.Width, chartPanel.H);
				
				tx = rect.X + 2;
				ty = (float)(chartScale.GetYByValue(curPrc) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
				
				vec1.X = tx;
				vec1.Y = ty;
				
				if(getAskImbalanceRatio(currProfile.l, curPrc) >= minRatio)
				{
					askBrush.Opacity = (curPrc == poc || (GetCurrentAsk() == curPrc && curPrc == prc)) ? 1.0f : 0.66f;
					RenderTarget.DrawTextLayout(vec1, tl, askBrush);
				}
				else
				{
					textBrush.Opacity = (curPrc == poc || (GetCurrentAsk() == curPrc && curPrc == prc)) ? 1.0f : 0.55f;
					RenderTarget.DrawTextLayout(vec1, tl, textBrush);
				}
				
				// ---
				
				tl.Dispose();
				tf.Dispose();
				
				// ------------------------------------------------------------------------------ //
				
				// bid - rect
				
				rect.X      = (float)(rx - (imbWidth * 2) - 2);
				rect.Y      = (float)y1;
				rect.Width  = (float)imbWidth;
				rect.Height = (float)Math.Abs(y1 - y2);
				
				if(curPrc == poc)
				{
					RenderTarget.DrawRectangle(rect, highBrush);
					RenderTarget.FillRectangle(rect, highBrush);
				}
				else
				{
					RenderTarget.DrawRectangle(rect, cellBrush);
					RenderTarget.FillRectangle(rect, cellBrush);
				}
				
				if(curPrc == prc)
				{
					highBrush.Opacity = 0.33f;
					RenderTarget.DrawRectangle(rect, highBrush);
					
					rect.Width  = rect.Width  - 1f;
					rect.Height = rect.Height - 1f;
					
					RenderTarget.FillRectangle(rect, highBrush);
					highBrush.Opacity = 1.0f;
					
					rect.Width  = rect.Width  + 1f;
					rect.Height = rect.Height + 1f;
				}
				
				// bid - outline
				
				if(GetCurrentBid() == curPrc && curPrc == prc)
				{
					vec1.X = rect.X - 1;
					vec1.Y = rect.Y;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = rect.Y;
					
					RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
					
					vec1.X = rect.X - 1;
					vec1.Y = rect.Y + rect.Height;
					
					vec2.X = rect.X + rect.Width;
					vec2.Y = rect.Y + rect.Height;
					
					RenderTarget.DrawLine(vec1, vec2, currBrush, 1);
				}
				
				// bid - text
				
				fw = (curPrc == poc) ? SharpDX.DirectWrite.FontWeight.UltraBold : SharpDX.DirectWrite.FontWeight.Normal;
				
				tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), fw, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
				
				tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Trailing;
				
				tl = new TextLayout(Core.Globals.DirectWriteFactory, currProfile.l[curPrc].bv.ToString(), tf, rect.Width, chartPanel.H);
				
				tx = rect.X - 3;
				ty = (float)(chartScale.GetYByValue(curPrc) - (textSize * gtf.Baseline) + ((textSize * gtf.CapsHeight) / 2) - 1);
				
				vec1.X = tx;
				vec1.Y = ty;
				
				if(getBidImbalanceRatio(currProfile.l, curPrc) >= minRatio)
				{
					bidBrush.Opacity = (curPrc == poc || (GetCurrentBid() == curPrc && curPrc == prc)) ? 1.0f : 0.66f;
					RenderTarget.DrawTextLayout(vec1, tl, bidBrush);
				}
				else
				{
					textBrush.Opacity = (curPrc == poc || (GetCurrentBid() == curPrc && curPrc == prc)) ? 1.0f : 0.55f;
					RenderTarget.DrawTextLayout(vec1, tl, textBrush);
				}
				
				// ---
				
				tl.Dispose();
				tf.Dispose();
				
				// profile
				
				int w = 0;
				
				if(currProfile.l.ContainsKey(curPrc))
				{
					w = (int)((proWidth / maxVol) * currProfile.l[curPrc].tv);
				}
				
				if(w > 0)
				{
					rect.X      = (float)(rx - (imbWidth * 2 + 2) - (w + 2));
					rect.Y      = (float)y1;
					rect.Width  = (float)w;
					rect.Height = (float)Math.Abs(y1 - y2);
					
					if(curPrc == poc)
					{
						RenderTarget.DrawRectangle(rect, highBrush);
						RenderTarget.FillRectangle(rect, highBrush);
					}
					else
					{
						RenderTarget.DrawRectangle(rect, cellBrush);
						RenderTarget.FillRectangle(rect, cellBrush);
					}
					
					if(curPrc == prc)
					{
						highBrush.Opacity = 0.33f;
						RenderTarget.DrawRectangle(rect, highBrush);
						
						rect.Width  = rect.Width  - 1f;
						rect.Height = rect.Height - 1f;
						
						RenderTarget.FillRectangle(rect, highBrush);
						highBrush.Opacity = 1.0f;
						
						rect.Width  = rect.Width  + 1f;
						rect.Height = rect.Height + 1f;
					}
				}
				
				// lines
				
				vec1.X = (float)rect.X - 2f;
				vec1.Y = (float)y1 - 1f;
				vec2.X = (float)rx - 1f;
				vec2.Y = (float)y1 - 1f;
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				vec1.X = (float)rect.X - 2f;
				vec1.Y = (float)y2 + 1f;
				vec2.X = (float)rx - 1f;
				vec2.Y = (float)y2 + 1f;
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				vec1.X = (float)rect.X - 1f;
				vec1.Y = (float)y1 - 1f;
				vec2.X = (float)rect.X - 1f;
				vec2.Y = (float)y2 + 1f;
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				vec1.X = (float)(rx - (imbWidth * 2 + 3));
				vec1.Y = (float)y1 - 1f;
				vec2.X = (float)(rx - (imbWidth * 2 + 3));
				vec2.Y = (float)y2 + 1f;
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				vec1.X = (float)(rx - (imbWidth + 1));
				vec1.Y = (float)y1 - 1f;
				vec2.X = (float)(rx - (imbWidth + 1));
				vec2.Y = (float)y2 + 1f;
				
				RenderTarget.DrawLine(vec1, vec2, backBrush, 1);
				
				// delta
				
				if(w > 0)
				{
					// delta
					
					if(currProfile.l[curPrc].tv == 0.0) { continue; }
					
					int askWidth = (int)((w / currProfile.l[curPrc].tv) * currProfile.l[curPrc].av);
					int bidWidth = (int)((w / currProfile.l[curPrc].tv) * currProfile.l[curPrc].bv);
					int dtaWidth = Math.Abs(askWidth - bidWidth);
					
					if(dtaWidth > 0 && askWidth > bidWidth)
					{
						rect.X      = (float)(rx - (imbWidth * 2 + 4) - dtaWidth);
						rect.Y      = (float)y1;
						rect.Width  = (float)dtaWidth;
						rect.Height = (float)Math.Abs(y2 - y1);
						
						askBrush.Opacity = (cls == curPrc) ? 0.33f : 0.22f;
						
						RenderTarget.DrawRectangle(rect, askBrush);
						
						rect.Width  = rect.Width  - 1f;
						rect.Height = rect.Height - 1f;
						
						RenderTarget.FillRectangle(rect, askBrush);
					}
					
					if(dtaWidth > 0 && bidWidth > askWidth)
					{
						rect.X      = (float)(rx - (imbWidth * 2 + 4) - dtaWidth);
						rect.Y      = (float)y1;
						rect.Width  = (float)Math.Abs(dtaWidth);
						rect.Height = (float)Math.Abs(y2 - y1);
						
						bidBrush.Opacity = (cls == curPrc) ? 0.33f : 0.22f;
						
						RenderTarget.DrawRectangle(rect, bidBrush);
						
						rect.Width  = rect.Width  - 1f;
						rect.Height = rect.Height - 1f;
						
						RenderTarget.FillRectangle(rect, bidBrush);
					}
				}
			}
			
			// totals
			
			double maxY = currProfile.l.Keys.Max();
			double minY = currProfile.l.Keys.Min();
			
			y1 = ((chartScale.GetYByValue(maxY) + chartScale.GetYByValue(maxY + TickSize)) / 2) + 1;
			y2 = ((chartScale.GetYByValue(minY) + chartScale.GetYByValue(minY - TickSize)) / 2) - 1;
			
			tf = new TextFormat(new SharpDX.DirectWrite.Factory(), sf.Family.ToString(), SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, (float)sf.Size);
			
			tf.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
			
			tl = new TextLayout(Core.Globals.DirectWriteFactory, "V: "+currProfile.v.ToString("n0"), tf, chartPanel.W, chartPanel.H);
			
			vec1.X = rx - tl.Metrics.Width;
			vec1.Y = (float)y2 + 3f;
			
			textBrush.Opacity = 0.5f;
			RenderTarget.DrawTextLayout(vec1, tl, textBrush);
			
			// ---
			
			vec1.Y = (float)(y1 - textSize - (textSize * (1.0 - gtf.CapsHeight)) - 3f);
			
			RenderTarget.DrawTextLayout(vec1, tl, textBrush);
			
			// ---
			
			tl = new TextLayout(Core.Globals.DirectWriteFactory, dta.ToString("n0"), tf, chartPanel.W, chartPanel.H);
			
			vec1.X = rx - tl.Metrics.Width;
			vec1.Y = (float)(y2 + 3f + textSize);
			
			if(dta < 0.0)
			{
				bidBrush.Opacity = 0.4f;
				RenderTarget.DrawTextLayout(vec1, tl, bidBrush);
			}
			else
			{
				askBrush.Opacity = 0.4f;
				RenderTarget.DrawTextLayout(vec1, tl, askBrush);
			}
			
			// ---
			
			vec1.Y = (float)(y1 - textSize - (textSize * (1.0 - gtf.CapsHeight)) - 3f - textSize);
			
			if(dta < 0.0)
			{
				bidBrush.Opacity = 0.4f;
				RenderTarget.DrawTextLayout(vec1, tl, bidBrush);
			}
			else
			{
				askBrush.Opacity = 0.4f;
				RenderTarget.DrawTextLayout(vec1, tl, askBrush);
			}
			
			tf.Dispose();
			tl.Dispose();
			
			// delta line
			
			vec1.X = rx;
			vec1.Y = y1;
			
			vec2.X = rx;
			vec2.Y = y2;
			
			if(dta > 0.0)
			{
				askBrush.Opacity = 0.66f;
				RenderTarget.DrawLine(vec1, vec2, askBrush, 1);
			}
			if(dta < 0.0)
			{
				bidBrush.Opacity = 0.66f;
				RenderTarget.DrawLine(vec1, vec2, bidBrush, 1);
			}
			
			// poc
			
			if(showPoc && currProfile.l.ContainsKey(poc))
			{
				y1 = ((chartScale.GetYByValue(poc) + chartScale.GetYByValue(poc + TickSize)) / 2);
				y2 = ((chartScale.GetYByValue(poc) + chartScale.GetYByValue(poc - TickSize)) / 2);
				
				rect.X      = (float)(rx - (imbWidth * 2 + 4) - proWidth);
				rect.Y      = (float)y1;
				rect.Width  = (float)proWidth + 1f;
				rect.Height = (float)Math.Abs(y2 - y1);
				
				SharpDX.Direct2D1.LinearGradientBrush gradBrush = new SharpDX.Direct2D1.LinearGradientBrush(RenderTarget, new SharpDX.Direct2D1.LinearGradientBrushProperties()
				{
					StartPoint = new SharpDX.Vector2(rect.X - (proWidth / 2), 0),
					EndPoint   = new SharpDX.Vector2(rect.X + proWidth, 0),
				},
				new SharpDX.Direct2D1.GradientStopCollection(RenderTarget, new SharpDX.Direct2D1.GradientStop[]
				{
					new	SharpDX.Direct2D1.GradientStop()
					{
						Color = (SharpDX.Color)((SharpDX.Direct2D1.SolidColorBrush)pocBrush).Color,
						Position = 0,
					},
					new SharpDX.Direct2D1.GradientStop()
					{
						Color = (SharpDX.Color)((SharpDX.Direct2D1.SolidColorBrush)backBrush).Color,
						Position = 1,
					}
				}));
				
				RenderTarget.DrawRectangle(rect, gradBrush);
				
				gradBrush.Dispose();
			}
			
			// ---
			
			askBrush.Dispose();
			bidBrush.Dispose();
			
			backBrush.Dispose();
			cellBrush.Dispose();
			highBrush.Dispose();
			currBrush.Dispose();
			textBrush.Dispose();
			
			currProfile = null;
			chartProps	= null;
			chartPanel	= null;
			gtf			= null;
			tFace		= null;
			
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}
		
		#endregion
		
		#region Properties
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Max. Days", GroupName = "Parameters", Order = 0)]
		public int maxDays
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Cell Color", GroupName = "Parameters", Order = 1)]
		public Brush cellColor
		{ get; set; }
		
		[Browsable(false)]
		public string cellColorSerializable
		{
			get { return Serialize.BrushToString(cellColor); }
			set { cellColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Highlight Color", GroupName = "Parameters", Order = 2)]
		public Brush highColor
		{ get; set; }
		
		[Browsable(false)]
		public string highColorSerializable
		{
			get { return Serialize.BrushToString(highColor); }
			set { highColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Current Close Color", GroupName = "Parameters", Order = 3)]
		public Brush currColor
		{ get; set; }
		
		[Browsable(false)]
		public string currColorSerializable
		{
			get { return Serialize.BrushToString(currColor); }
			set { currColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Close Marker Color", GroupName = "Parameters", Order = 4)]
		public Brush markColor
		{ get; set; }
		
		[Browsable(false)]
		public string markColorSerializable
		{
			get { return Serialize.BrushToString(markColor); }
			set { markColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[Range(0f, 1f)]
		[Display(Name = "Close Marker Opacity", GroupName = "Parameters", Order = 5)]
		public float markOpacity
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Text Color", GroupName = "Parameters", Order = 6)]
		public Brush textColor
		{ get; set; }
		
		[Browsable(false)]
		public string textColorSerializable
		{
			get { return Serialize.BrushToString(textColor); }
			set { textColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Text Size", GroupName = "Parameters", Order = 7)]
		public int textSize
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Ask Color", GroupName = "Parameters", Order = 8)]
		public Brush askColor
		{ get; set; }
		
		[Browsable(false)]
		public string askColorSerializable
		{
			get { return Serialize.BrushToString(askColor); }
			set { askColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Bid Color", GroupName = "Parameters", Order = 9)]
		public Brush bidColor
		{ get; set; }
		
		[Browsable(false)]
		public string bidColorSerializable
		{
			get { return Serialize.BrushToString(bidColor); }
			set { bidColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "POC Color", GroupName = "Parameters", Order = 10)]
		public Brush pocColor
		{ get; set; }
		
		[Browsable(false)]
		public string pocColorSerializable
		{
			get { return Serialize.BrushToString(pocColor); }
			set { pocColor = Serialize.StringToBrush(value); }
		}
		
		// ---
		
		[NinjaScriptProperty]
		[Range(1.0, double.MaxValue)]
		[Display(Name = "Min. Imbalance Volume", GroupName = "Parameters", Order = 11)]
		public double minImbalance
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Range(0.1, 1.0)]
		[Display(Name = "Min. Imbalance Ratio", GroupName = "Parameters", Order = 12)]
		public double minRatio
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Auto Scroll", GroupName = "Parameters", Order = 13)]
		public bool autoScroll
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Set Outline Color", GroupName = "Parameters", Order = 14)]
		public bool setOulineColor
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Show Delta", GroupName = "Parameters", Order = 15)]
		public bool showDelta
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Show Bid and Ask", GroupName = "Parameters", Order = 16)]
		public bool showBidAsk
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Show Profile", GroupName = "Parameters", Order = 17)]
		public bool showProfile
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Show POC", GroupName = "Parameters", Order = 18)]
		public bool showPoc
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Show Unfinished Auction", GroupName = "Parameters", Order = 19)]
		public bool showUnfinished
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Fade Cells", GroupName = "Parameters", Order = 20)]
		public bool fadeCells
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[Display(Name = "Fade Text", GroupName = "Parameters", Order = 21)]
		public bool fadeText
		{ get; set; }
		
		// ---
		
		[NinjaScriptProperty]
		[ReadOnly(true)]
		[Display(Name = "Indicator Version", GroupName = "Parameters", Order = 22)]
		public string indicatorVersion
		{ get; set; }
		
		#endregion;
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private Infinity.FootPrint[] cacheFootPrint;
		public Infinity.FootPrint FootPrint(int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			return FootPrint(Input, maxDays, cellColor, highColor, currColor, markColor, markOpacity, textColor, textSize, askColor, bidColor, pocColor, minImbalance, minRatio, autoScroll, setOulineColor, showDelta, showBidAsk, showProfile, showPoc, showUnfinished, fadeCells, fadeText, indicatorVersion);
		}

		public Infinity.FootPrint FootPrint(ISeries<double> input, int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			if (cacheFootPrint != null)
				for (int idx = 0; idx < cacheFootPrint.Length; idx++)
					if (cacheFootPrint[idx] != null && cacheFootPrint[idx].maxDays == maxDays && cacheFootPrint[idx].cellColor == cellColor && cacheFootPrint[idx].highColor == highColor && cacheFootPrint[idx].currColor == currColor && cacheFootPrint[idx].markColor == markColor && cacheFootPrint[idx].markOpacity == markOpacity && cacheFootPrint[idx].textColor == textColor && cacheFootPrint[idx].textSize == textSize && cacheFootPrint[idx].askColor == askColor && cacheFootPrint[idx].bidColor == bidColor && cacheFootPrint[idx].pocColor == pocColor && cacheFootPrint[idx].minImbalance == minImbalance && cacheFootPrint[idx].minRatio == minRatio && cacheFootPrint[idx].autoScroll == autoScroll && cacheFootPrint[idx].setOulineColor == setOulineColor && cacheFootPrint[idx].showDelta == showDelta && cacheFootPrint[idx].showBidAsk == showBidAsk && cacheFootPrint[idx].showProfile == showProfile && cacheFootPrint[idx].showPoc == showPoc && cacheFootPrint[idx].showUnfinished == showUnfinished && cacheFootPrint[idx].fadeCells == fadeCells && cacheFootPrint[idx].fadeText == fadeText && cacheFootPrint[idx].indicatorVersion == indicatorVersion && cacheFootPrint[idx].EqualsInput(input))
						return cacheFootPrint[idx];
			return CacheIndicator<Infinity.FootPrint>(new Infinity.FootPrint(){ maxDays = maxDays, cellColor = cellColor, highColor = highColor, currColor = currColor, markColor = markColor, markOpacity = markOpacity, textColor = textColor, textSize = textSize, askColor = askColor, bidColor = bidColor, pocColor = pocColor, minImbalance = minImbalance, minRatio = minRatio, autoScroll = autoScroll, setOulineColor = setOulineColor, showDelta = showDelta, showBidAsk = showBidAsk, showProfile = showProfile, showPoc = showPoc, showUnfinished = showUnfinished, fadeCells = fadeCells, fadeText = fadeText, indicatorVersion = indicatorVersion }, input, ref cacheFootPrint);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.Infinity.FootPrint FootPrint(int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			return indicator.FootPrint(Input, maxDays, cellColor, highColor, currColor, markColor, markOpacity, textColor, textSize, askColor, bidColor, pocColor, minImbalance, minRatio, autoScroll, setOulineColor, showDelta, showBidAsk, showProfile, showPoc, showUnfinished, fadeCells, fadeText, indicatorVersion);
		}

		public Indicators.Infinity.FootPrint FootPrint(ISeries<double> input , int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			return indicator.FootPrint(input, maxDays, cellColor, highColor, currColor, markColor, markOpacity, textColor, textSize, askColor, bidColor, pocColor, minImbalance, minRatio, autoScroll, setOulineColor, showDelta, showBidAsk, showProfile, showPoc, showUnfinished, fadeCells, fadeText, indicatorVersion);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.Infinity.FootPrint FootPrint(int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			return indicator.FootPrint(Input, maxDays, cellColor, highColor, currColor, markColor, markOpacity, textColor, textSize, askColor, bidColor, pocColor, minImbalance, minRatio, autoScroll, setOulineColor, showDelta, showBidAsk, showProfile, showPoc, showUnfinished, fadeCells, fadeText, indicatorVersion);
		}

		public Indicators.Infinity.FootPrint FootPrint(ISeries<double> input , int maxDays, Brush cellColor, Brush highColor, Brush currColor, Brush markColor, float markOpacity, Brush textColor, int textSize, Brush askColor, Brush bidColor, Brush pocColor, double minImbalance, double minRatio, bool autoScroll, bool setOulineColor, bool showDelta, bool showBidAsk, bool showProfile, bool showPoc, bool showUnfinished, bool fadeCells, bool fadeText, string indicatorVersion)
		{
			return indicator.FootPrint(input, maxDays, cellColor, highColor, currColor, markColor, markOpacity, textColor, textSize, askColor, bidColor, pocColor, minImbalance, minRatio, autoScroll, setOulineColor, showDelta, showBidAsk, showProfile, showPoc, showUnfinished, fadeCells, fadeText, indicatorVersion);
		}
	}
}

#endregion
