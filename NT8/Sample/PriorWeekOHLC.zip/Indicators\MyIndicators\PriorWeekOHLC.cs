#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.MyIndicators
{
	public class PriorWeekOHLC : Indicator
	{
		private DayOfWeek 				startWeekFromDay 	= 	DayOfWeek.Monday;
		private DateTime 				currentDate 		=	Core.Globals.MinDate;
		private DateTime				lastDate			= 	Core.Globals.MinDate;
		private double					currentWeekOpen		=	0;
		private double					currentWeekClose	=	0;
		private double					currentWeekHigh		=	0;
		private double					currentWeekLow		=	0;
		private double					priorWeekOpen		=	0;
		private double					priorWeekClose		=	0;
		private double					priorWeekHigh		=	0;
		private double					priorWeekLow		=	0;
		private	Data.SessionIterator	sessionIterator;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"PriorWeekOHLC based on PriorDayOHL indicator";
				Name										= "PriorWeekOHLC";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				IsAutoScale									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				// Parameters
				ShowPriorWeekOpen							= true;
				ShowPriorWeekClose							= true;
				ShowPriorWeekHigh							= true;
				ShowPriorWeekLow							= true;
				StartWeekFromDay							= DayOfWeek.Monday;
				// Plots
				AddPlot(new Stroke(Brushes.SteelBlue, DashStyleHelper.Solid, 3), PlotStyle.Square, "PriorWeekOpen");
				AddPlot(new Stroke(Brushes.DarkCyan, DashStyleHelper.Solid, 3), PlotStyle.Square, "PriorWeekClose");
				AddPlot(new Stroke(Brushes.Crimson, DashStyleHelper.Solid, 3), PlotStyle.Square, "PriorWeekHigh");
				AddPlot(new Stroke(Brushes.SlateBlue, DashStyleHelper.Solid, 3), PlotStyle.Square, "PriorWeekLow");
				
			}
			else if (State == State.Configure)
			{
				currentDate 	    = Core.Globals.MinDate;
				currentWeekOpen		= 0;
				currentWeekClose	= 0;
				currentWeekHigh		= 0;
				currentWeekLow		= 0;
				priorWeekOpen		= 0;
				priorWeekClose		= 0;
				priorWeekHigh		= 0;
				priorWeekLow		= 0;
				sessionIterator		= null;
			}
			else if (State == State.DataLoaded)
			{
				sessionIterator = new Data.SessionIterator(Bars);
			}
		}

		protected override void OnBarUpdate()
		{
			if (!Bars.BarsType.IsIntraday) { return; }
			lastDate = currentDate;
			if (sessionIterator.GetTradingDay(Time[0]).DayOfWeek == startWeekFromDay) {
				currentDate = sessionIterator.GetTradingDay(Time[0]);
			}
			if ( lastDate != currentDate || currentWeekOpen == 0 ){
				priorWeekOpen = currentWeekOpen;
				priorWeekClose = currentWeekClose;
				priorWeekHigh = currentWeekHigh;
				priorWeekLow = currentWeekLow;
				if (ShowPriorWeekOpen) { PriorWeekOpen[0] = priorWeekOpen; }
				if (ShowPriorWeekClose) { PriorWeekClose[0] = priorWeekClose; }
				if (ShowPriorWeekHigh) { PriorWeekHigh[0] = priorWeekHigh; }
				if (ShowPriorWeekLow)  { PriorWeekLow[0] = priorWeekLow; }
				currentWeekOpen = Open[0];
				currentWeekClose = Close[0];
				currentWeekHigh	= High[0];
				currentWeekLow	= Low[0];
				if (ShowPriorWeekOpen) { PriorWeekOpen[0] = priorWeekOpen; }
				if (ShowPriorWeekClose) { PriorWeekClose[0] = priorWeekClose; }
				if (ShowPriorWeekHigh) { PriorWeekHigh[0] = priorWeekHigh; }
				if (ShowPriorWeekLow)  { PriorWeekLow[0] = priorWeekLow; }
			} else {
				currentWeekHigh = Math.Max(currentWeekHigh, High[0]);
				currentWeekLow = Math.Min(currentWeekLow, Low[0]);
				if (ShowPriorWeekOpen) { PriorWeekOpen[0] = priorWeekOpen; }
				if (ShowPriorWeekClose) { PriorWeekClose[0] = priorWeekClose; }
				if (ShowPriorWeekHigh) { PriorWeekHigh[0] = priorWeekHigh; }
				if (ShowPriorWeekLow)  { PriorWeekLow[0] = priorWeekLow; }
			}
		}
		
		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriorWeekOpen
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriorWeekClose
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriorWeekHigh
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> PriorWeekLow
		{
			get { return Values[3]; }
		}
		
		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekOpen", Order=1, GroupName="Parameters")]
		public bool ShowPriorWeekOpen
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekHigh", Order=2, GroupName="Parameters")]
		public bool ShowPriorWeekHigh
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekLow", Order=3, GroupName="Parameters")]
		public bool ShowPriorWeekLow
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="ShowPriorWeekClose", Order=4, GroupName="Parameters")]
		public bool ShowPriorWeekClose
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="StartWeekFromDay", Order=5, GroupName="Parameters")]
		public DayOfWeek StartWeekFromDay
		{
			get { return startWeekFromDay; }
			set { startWeekFromDay = value; }
		}
		
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyIndicators.PriorWeekOHLC[] cachePriorWeekOHLC;
		public MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			return PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose, startWeekFromDay);
		}

		public MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input, bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			if (cachePriorWeekOHLC != null)
				for (int idx = 0; idx < cachePriorWeekOHLC.Length; idx++)
					if (cachePriorWeekOHLC[idx] != null && cachePriorWeekOHLC[idx].ShowPriorWeekOpen == showPriorWeekOpen && cachePriorWeekOHLC[idx].ShowPriorWeekHigh == showPriorWeekHigh && cachePriorWeekOHLC[idx].ShowPriorWeekLow == showPriorWeekLow && cachePriorWeekOHLC[idx].ShowPriorWeekClose == showPriorWeekClose && cachePriorWeekOHLC[idx].StartWeekFromDay == startWeekFromDay && cachePriorWeekOHLC[idx].EqualsInput(input))
						return cachePriorWeekOHLC[idx];
			return CacheIndicator<MyIndicators.PriorWeekOHLC>(new MyIndicators.PriorWeekOHLC(){ ShowPriorWeekOpen = showPriorWeekOpen, ShowPriorWeekHigh = showPriorWeekHigh, ShowPriorWeekLow = showPriorWeekLow, ShowPriorWeekClose = showPriorWeekClose, StartWeekFromDay = startWeekFromDay }, input, ref cachePriorWeekOHLC);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			return indicator.PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose, startWeekFromDay);
		}

		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input , bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			return indicator.PriorWeekOHLC(input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose, startWeekFromDay);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			return indicator.PriorWeekOHLC(Input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose, startWeekFromDay);
		}

		public Indicators.MyIndicators.PriorWeekOHLC PriorWeekOHLC(ISeries<double> input , bool showPriorWeekOpen, bool showPriorWeekHigh, bool showPriorWeekLow, bool showPriorWeekClose, DayOfWeek startWeekFromDay)
		{
			return indicator.PriorWeekOHLC(input, showPriorWeekOpen, showPriorWeekHigh, showPriorWeekLow, showPriorWeekClose, startWeekFromDay);
		}
	}
}

#endregion
