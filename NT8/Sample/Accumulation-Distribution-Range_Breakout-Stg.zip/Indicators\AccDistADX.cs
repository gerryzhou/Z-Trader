#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AccDistADX : Indicator
	{
		private bool Consolidation = false;
		private double Top = 0, Bot = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Accumulation/Distribution ADX Indicator as published in the Auguest 2018 Stocks and Commodities Article titled 'Portfolio Strategy Based On Accumulation/Distribution' by Domenic D’Errico.";
				Name										= "AccDistADX";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				// Default Parameters
				ADXLength									= 4;
				ADXTrigger									= 30;
				HighlightBrush								= Brushes.LimeGreen;
				
				// Plots
				AddPlot(new Stroke(Brushes.LightGray, 2), PlotStyle.Bar, "ADXRatioPlot");
				AddPlot(new Stroke(Brushes.DarkGray, 2), PlotStyle.Line, "ADXTriggerPlot");
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < ADXLength)
				return;
			
			Consolidation = false;
			
			if (ADX(ADXLength)[0] < ADXTrigger)
			{
				Consolidation = true;
				Top = MAX(High, ADXLength)[0];
				Bot = MIN(Low, ADXLength)[0];
			}
			
			if (Consolidation)
				Draw.Rectangle(this, "AccDistADXBox_"+CurrentBar, true, ADXLength, Top, 0, Bot, HighlightBrush, HighlightBrush, 15);
			
			Values[0][0] = ADX(ADXLength)[0];
			Values[1][0] = ADXTrigger;
			
			if (ADX(ADXLength)[0] < ADXTrigger)
				PlotBrushes[0][0] = HighlightBrush;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ADXLength", Order=1, GroupName="Parameters")]
		public int ADXLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="ADXTrigger", Order=2, GroupName="Parameters")]
		public double ADXTrigger
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighlightBrush", Order=3, GroupName="Parameters")]
		public Brush HighlightBrush
		{ get; set; }

		[Browsable(false)]
		public string HighlightBrushSerializable
		{
			get { return Serialize.BrushToString(HighlightBrush); }
			set { HighlightBrush = Serialize.StringToBrush(value); }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RangeRatioPlot
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ADXTriggerPlot
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AccDistADX[] cacheAccDistADX;
		public AccDistADX AccDistADX(int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			return AccDistADX(Input, aDXLength, aDXTrigger, highlightBrush);
		}

		public AccDistADX AccDistADX(ISeries<double> input, int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			if (cacheAccDistADX != null)
				for (int idx = 0; idx < cacheAccDistADX.Length; idx++)
					if (cacheAccDistADX[idx] != null && cacheAccDistADX[idx].ADXLength == aDXLength && cacheAccDistADX[idx].ADXTrigger == aDXTrigger && cacheAccDistADX[idx].HighlightBrush == highlightBrush && cacheAccDistADX[idx].EqualsInput(input))
						return cacheAccDistADX[idx];
			return CacheIndicator<AccDistADX>(new AccDistADX(){ ADXLength = aDXLength, ADXTrigger = aDXTrigger, HighlightBrush = highlightBrush }, input, ref cacheAccDistADX);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AccDistADX AccDistADX(int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			return indicator.AccDistADX(Input, aDXLength, aDXTrigger, highlightBrush);
		}

		public Indicators.AccDistADX AccDistADX(ISeries<double> input , int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			return indicator.AccDistADX(input, aDXLength, aDXTrigger, highlightBrush);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AccDistADX AccDistADX(int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			return indicator.AccDistADX(Input, aDXLength, aDXTrigger, highlightBrush);
		}

		public Indicators.AccDistADX AccDistADX(ISeries<double> input , int aDXLength, double aDXTrigger, Brush highlightBrush)
		{
			return indicator.AccDistADX(input, aDXLength, aDXTrigger, highlightBrush);
		}
	}
}

#endregion
