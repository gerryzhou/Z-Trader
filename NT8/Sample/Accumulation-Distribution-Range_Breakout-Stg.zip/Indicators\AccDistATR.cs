#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AccDistATR : Indicator
	{
		private bool Consolidation = false;
		private double Top = 0, Bot = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Accumulation/Distribution ATR Indicator as published in the August 2018 Stocks and Commodities Article titled 'Portfolio Strategy Based On Accumulation/Distribution' by Domenic D’Errico.";
				Name										= "AccDistATR";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				BarsRequiredToPlot							= 0;
				
				// Default Parameters
				ATRLength									= 4;
				ATRFactor									= 0.75;
				HighlightBrush								= Brushes.RoyalBlue;
				
				// Plots
				AddPlot(new Stroke(Brushes.LightGray, 2), PlotStyle.Bar, "ATRRatioPlot");
				AddPlot(new Stroke(Brushes.DarkGray, 2), PlotStyle.Line, "ATRFactorPlot");
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < ATRLength)
				return;
			
			Consolidation = false;
			
			if (ATR(ATRLength)[0] < ATRFactor * ATR(ATRLength)[ATRLength])
			{
				Consolidation = true;
				Top = MAX(High, ATRLength)[0];
				Bot = MIN(Low, ATRLength)[0];
			}
			
			if (Consolidation)
				Draw.Rectangle(this, "AccDistATRBox_"+CurrentBar, true, ATRLength, Top, 0, Bot, HighlightBrush, HighlightBrush, 15);
			
			Values[0][0] = ATR(ATRLength)[0] / ATR(ATRLength)[ATRLength];
			Values[1][0] = ATRFactor;
			
			if (ATR(ATRLength)[0] / ATR(ATRLength)[ATRLength] < ATRFactor)
				PlotBrushes[0][0] = HighlightBrush;
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ATRLength", Order=1, GroupName="Parameters")]
		public int ATRLength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="ATRFactor", Order=2, GroupName="Parameters")]
		public double ATRFactor
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighlightBrush", Order=3, GroupName="Parameters")]
		public Brush HighlightBrush
		{ get; set; }

		[Browsable(false)]
		public string HighlightBrushSerializable
		{
			get { return Serialize.BrushToString(HighlightBrush); }
			set { HighlightBrush = Serialize.StringToBrush(value); }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RangeRatioPlot
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ATRFactorPlot
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AccDistATR[] cacheAccDistATR;
		public AccDistATR AccDistATR(int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			return AccDistATR(Input, aTRLength, aTRFactor, highlightBrush);
		}

		public AccDistATR AccDistATR(ISeries<double> input, int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			if (cacheAccDistATR != null)
				for (int idx = 0; idx < cacheAccDistATR.Length; idx++)
					if (cacheAccDistATR[idx] != null && cacheAccDistATR[idx].ATRLength == aTRLength && cacheAccDistATR[idx].ATRFactor == aTRFactor && cacheAccDistATR[idx].HighlightBrush == highlightBrush && cacheAccDistATR[idx].EqualsInput(input))
						return cacheAccDistATR[idx];
			return CacheIndicator<AccDistATR>(new AccDistATR(){ ATRLength = aTRLength, ATRFactor = aTRFactor, HighlightBrush = highlightBrush }, input, ref cacheAccDistATR);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AccDistATR AccDistATR(int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			return indicator.AccDistATR(Input, aTRLength, aTRFactor, highlightBrush);
		}

		public Indicators.AccDistATR AccDistATR(ISeries<double> input , int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			return indicator.AccDistATR(input, aTRLength, aTRFactor, highlightBrush);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AccDistATR AccDistATR(int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			return indicator.AccDistATR(Input, aTRLength, aTRFactor, highlightBrush);
		}

		public Indicators.AccDistATR AccDistATR(ISeries<double> input , int aTRLength, double aTRFactor, Brush highlightBrush)
		{
			return indicator.AccDistATR(input, aTRLength, aTRFactor, highlightBrush);
		}
	}
}

#endregion
