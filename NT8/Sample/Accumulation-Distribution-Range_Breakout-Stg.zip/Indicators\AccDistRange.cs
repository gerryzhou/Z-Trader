#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AccDistRange : Indicator
	{
		private bool Consolidation = false;
		private double Top = 0, Bot = 0;
		private Series<double> Range_;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Accumulation/Distribution Range Indicator as published in the August 2018 Stocks and Commodities Article titled 'Portfolio Strategy Based On Accumulation/Distribution' by Domenic D’Errico.";
				Name										= "AccDistRange";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				// Default Parameters
				Length										= 4;
				ConsolidationFactor							= 0.75;
				HighlightBrush								= Brushes.LimeGreen;
				
				// Plots
				AddPlot(new Stroke(Brushes.LightGray, 2), PlotStyle.Bar, "RangeRatioPlot");
				AddPlot(new Stroke(Brushes.DarkGray, 2), PlotStyle.Line, "ConsolidationFactorPlot");
			}
			else if (State == State.DataLoaded)
			{
				Range_ = new Series<double>(this);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < Length)
				return;
			
			Consolidation = false;
			Range_[0] = MAX(High,Length)[0] - MIN(Low,Length)[0];
			
			if (Range_[0] < ConsolidationFactor * Range_[Length])
			{
				Consolidation = true;
				Top = MAX(High, Length)[0];
				Bot = MIN(Low, Length)[0];
			}
			
			if (Consolidation)
				Draw.Rectangle(this, "AccDistRangeBox_"+CurrentBar, true, Length, Top, 0, Bot, HighlightBrush, HighlightBrush, 15);
			
			if (Range_[Length] > 0)
			{
				Values[0][0] = Range_[0] / Range_[Length];
				Values[1][0] = ConsolidationFactor;
				
				if (Range_[0] / Range_[Length] < ConsolidationFactor)
					PlotBrushes[0][0] = HighlightBrush;
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="ConsolidationFactor", Order=2, GroupName="Parameters")]
		public double ConsolidationFactor
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighlightBrush", Order=3, GroupName="Parameters")]
		public Brush HighlightBrush
		{ get; set; }

		[Browsable(false)]
		public string HighlightBrushSerializable
		{
			get { return Serialize.BrushToString(HighlightBrush); }
			set { HighlightBrush = Serialize.StringToBrush(value); }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RangeRatioPlot
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ConsolidationFactorPlot
		{
			get { return Values[1]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AccDistRange[] cacheAccDistRange;
		public AccDistRange AccDistRange(int length, double consolidationFactor, Brush highlightBrush)
		{
			return AccDistRange(Input, length, consolidationFactor, highlightBrush);
		}

		public AccDistRange AccDistRange(ISeries<double> input, int length, double consolidationFactor, Brush highlightBrush)
		{
			if (cacheAccDistRange != null)
				for (int idx = 0; idx < cacheAccDistRange.Length; idx++)
					if (cacheAccDistRange[idx] != null && cacheAccDistRange[idx].Length == length && cacheAccDistRange[idx].ConsolidationFactor == consolidationFactor && cacheAccDistRange[idx].HighlightBrush == highlightBrush && cacheAccDistRange[idx].EqualsInput(input))
						return cacheAccDistRange[idx];
			return CacheIndicator<AccDistRange>(new AccDistRange(){ Length = length, ConsolidationFactor = consolidationFactor, HighlightBrush = highlightBrush }, input, ref cacheAccDistRange);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AccDistRange AccDistRange(int length, double consolidationFactor, Brush highlightBrush)
		{
			return indicator.AccDistRange(Input, length, consolidationFactor, highlightBrush);
		}

		public Indicators.AccDistRange AccDistRange(ISeries<double> input , int length, double consolidationFactor, Brush highlightBrush)
		{
			return indicator.AccDistRange(input, length, consolidationFactor, highlightBrush);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AccDistRange AccDistRange(int length, double consolidationFactor, Brush highlightBrush)
		{
			return indicator.AccDistRange(Input, length, consolidationFactor, highlightBrush);
		}

		public Indicators.AccDistRange AccDistRange(ISeries<double> input , int length, double consolidationFactor, Brush highlightBrush)
		{
			return indicator.AccDistRange(input, length, consolidationFactor, highlightBrush);
		}
	}
}

#endregion
