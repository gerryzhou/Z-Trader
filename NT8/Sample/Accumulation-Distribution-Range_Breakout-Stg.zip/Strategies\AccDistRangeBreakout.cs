#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class AccDistRangeBreakout : Strategy
	{
		private AccDistRange ADR;
		private Series<double> Top, Bot, Range_;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Accumulation/Distribution Range Breakout Strategy as published in the August 2018 Stocks and Commodities Article titled 'Portfolio Strategy Based On Accumulation/Distribution' by Domenic D’Errico.";
				Name										= "AccDistRangeBreakout";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Length										= 4;
				ConsolidationFactor							= 0.75;
				VolRatio									= 1;
				VolAvg										= 4;
				VolDelay									= 4;
				TradeProfit									= true;
				AmountToBuy									= 10000;
				HighlightBrush								= Brushes.LimeGreen;
			}
			else if (State == State.DataLoaded)
			{
				Top		= new Series<double>(this);
				Bot		= new Series<double>(this);
				Range_	= new Series<double>(this);
				ADR 	= AccDistRange(Length, ConsolidationFactor, HighlightBrush);
				AddChartIndicator(ADR);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < Length || CurrentBar < 12 || CurrentBar < VolAvg || CurrentBar < VolDelay)
				return;
			
			// Persist previous Top and Bot
			Top[0] = Top[1];
			Bot[0] = Bot[1];
			
			Range_[0] = MAX(High,Length)[0] - MIN(Low,Length)[0];
			
			if (Range_[0] < ConsolidationFactor * Range_[Length])
			{
				Top[0] = MAX(High, Length)[0];
				Bot[0] = MIN(Low, Length)[0];
			}
			
			if (ToDay(Time[0]) > 20030101 && Close[0] > Top[0] && Bot[0] > Bot[12] 
				&& SMA(Volume, VolAvg)[VolDelay] > VolRatio * SMA(Volume, VolAvg)[VolAvg + VolDelay])
			{
				int ProfitQuantity = 0;
				if (TradeProfit)
					ProfitQuantity =  (int)Math.Floor(SystemPerformance.RealTimeTrades.TradesPerformance.NetProfit / Close[0]);
				EnterLong((int)Math.Floor(AmountToBuy/Close[0]) + ProfitQuantity);
			}
			if (Position.MarketPosition == MarketPosition.Long && Close[0] < Bot[0])
				ExitLong();
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, double.MaxValue)]
		[Display(Name="ConsolidationFactor", Order=2, GroupName="Parameters")]
		public double ConsolidationFactor
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="VolRatio", Order=3, GroupName="Parameters")]
		public int VolRatio
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="VolAvg", Order=4, GroupName="Parameters")]
		public int VolAvg
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="VolDelay", Order=5, GroupName="Parameters")]
		public int VolDelay
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="TradeProfit", Order=6, GroupName="Parameters")]
		public bool TradeProfit
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="AmountToBuy", Order=7, GroupName="Parameters")]
		public int AmountToBuy
		{ get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="HighlightBrush", Order=8, GroupName="Parameters")]
		public Brush HighlightBrush
		{ get; set; }

		[Browsable(false)]
		public string HighlightBrushSerializable
		{
			get { return Serialize.BrushToString(HighlightBrush); }
			set { HighlightBrush = Serialize.StringToBrush(value); }
		}
		#endregion

	}
}
