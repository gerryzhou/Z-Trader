﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace configurationfiles
{
    class Program
    {
        static ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
        static int period = 0;
        static Configuration config = null;
        //static string appfile = @"C:\Users\tom\Documents\Visual Studio 2008\Projects\configurationfiles\configurationfiles\test.config";
        static string appfile = @"test.config";  //must be next to exe to work or specifiy a full path like above...

        static void Main(string[] args)
        {
            fileMap.ExeConfigFilename = appfile;
            config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            ShowConfig();

            Console.WriteLine("Press a key to continue");
            Console.Read();

            loadSettings();
            Console.Write(Period);
            Console.Write(ModTest);
            ModTest = DateTime.Now.ToString();
            Console.Write(ModTest);

            saveSettings();
            ShowConfig();

            Console.WriteLine("Press a key to exit");
            Console.Read();


        }

        /// <summary>
        /// display to the console
        /// </summary>
        static void ShowConfig()
        {

            // For read access you do not need to call OpenExeConfiguraton
            foreach (KeyValueConfigurationElement keyPair in config.AppSettings.Settings)
            {
                string value = keyPair.Value;
                Console.WriteLine("Key: {0}, Value: {1}", keyPair.Key, value);
            }
        }



        /// <summary>
        /// load the period property value from file 
        /// </summary>
        static void loadSettings()
        {
            if (config.AppSettings.Settings["Period"] != null)
            {
                period = Convert.ToInt32(config.AppSettings.Settings["Period"].Value);
            }
        }

        /// <summary>
        /// write to the config file
        /// </summary>
        static void saveSettings()
        {
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

        }

        //period is unbound
        static public int Period
        {
            get
            {
                return period;
            }
            set { period = value; }
        }

        /// <summary>
        /// mod test is phsically bound to the config file
        /// </summary>
        static public string ModTest
        {
            get
            {
                if (config.AppSettings.Settings["ModTest"] == null)
                {
                    config.AppSettings.Settings.Add("ModTest", DateTime.Now.ToString());
                }
                return config.AppSettings.Settings["ModTest"].Value;
            }
            set { config.AppSettings.Settings["ModTest"].Value = value; }
        }



    }
}
