#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class SVAPO : Indicator
	{
		private Series<double> AvgPrice;
		private Series<double> HAOpen;
		private Series<double> HAClose;
		private Series<double> HASmooth;
		private Series<double> ValueToSum;
		private Series<double> ValueToTema;
		
		private SMA VAve;
		private LinRegSlope LinReg;
		private TEMA VTR;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Short-Term Volume And Price Oscillator as published in the November 2007 Stocks and Commodities article titled Buy and Sell Triggers: Short-Term Volume And Price Oscillator by Sylvain Vervoort.";
				Name										= "SVAPO";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				Period										= 8;
				Cutoff										= 1;
				DevH										= 1.5;
				DevL										= 1.3;
				StdDevPer									= 100;
				AddPlot(Brushes.RoyalBlue, "SVAPO_Plot");
				AddPlot(Brushes.Orange, "STDH_Plot");
				AddPlot(Brushes.Orange, "STDL_Plot");
				AddLine(Brushes.DarkGray, 0, "Zero");
			}
			else if (State == State.Configure)
			{
				AvgPrice 	= new Series<double>(this);
				HAOpen   	= new Series<double>(this);
				HAClose 	= new Series<double>(this);
				HASmooth 	= new Series<double>(this);
				ValueToSum 	= new Series<double>(this);
				ValueToTema = new Series<double>(this);
				
				VAve 	= SMA(Volume, Period*5);
				LinReg 	= LinRegSlope(Volume, Period);
				VTR 	= TEMA(LinReg, Period);
			}
		}

		protected override void OnBarUpdate()
		{
			AvgPrice[0] = (Open[0] + High[0] + Low[0] + Close[0]) / 4;
			
			if (CurrentBar < 2) return;
			
			HAOpen[0] = (AvgPrice[1] + HAOpen[1])/2;
			HAClose[0] = (AvgPrice[0] + HAOpen[0] + 
						Math.Max(AvgPrice[0], Math.Max(High[0], HAOpen[0])) + 
						Math.Min(AvgPrice[0], Math.Min(Low[0], HAOpen[0])))/4;
			
			HASmooth[0] = TEMA(HAClose,Convert.ToInt32(Period / 1.6))[0];
			
			double VC = Volume[0] < VAve[1] * 2 ? Volume[0] : VAve[1] * 2;
			
			if (HASmooth[0] > HASmooth[1] * (1+Cutoff/1000) 
				&& (VTR[0] >= VTR[1] || VTR[1] >= VTR[2]))
				ValueToSum[0] = VC;
			else if (HASmooth[0] < HASmooth[1] * (1-Cutoff/1000) 
				&& (VTR[0] > VTR[1] || VTR[1] > VTR[2]))
				ValueToSum[0] = -VC;
			else 
				ValueToSum[0] = 0;
			
			ValueToTema[0] = SUM(ValueToSum, Period)[0] / (VAve[1] + 1);
			Values[0][0] = TEMA(ValueToTema, Period)[0];
			
			Values[1][0] = DevH * StdDev(Value, StdDevPer)[0];
			Values[2][0] = -DevL * StdDev(Value, StdDevPer)[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name="Period", Description="SVAPO Period", Order=1, GroupName="Parameters")]
		public int Period
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Cutoff", Description="Minimum %o price change", Order=2, GroupName="Parameters")]
		public int Cutoff
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name="DevH", Description="Stadard Deviation High", Order=3, GroupName="Parameters")]
		public double DevH
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name="DevL", Description="Standard Deviation Low", Order=4, GroupName="Parameters")]
		public double DevL
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="StdDevPer", Description="Standard Deviation Period", Order=5, GroupName="Parameters")]
		public int StdDevPer
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SVAPO_Plot
		{
			get { return Values[0]; }
		}

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private SVAPO[] cacheSVAPO;
		public SVAPO SVAPO(int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			return SVAPO(Input, period, cutoff, devH, devL, stdDevPer);
		}

		public SVAPO SVAPO(ISeries<double> input, int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			if (cacheSVAPO != null)
				for (int idx = 0; idx < cacheSVAPO.Length; idx++)
					if (cacheSVAPO[idx] != null && cacheSVAPO[idx].Period == period && cacheSVAPO[idx].Cutoff == cutoff && cacheSVAPO[idx].DevH == devH && cacheSVAPO[idx].DevL == devL && cacheSVAPO[idx].StdDevPer == stdDevPer && cacheSVAPO[idx].EqualsInput(input))
						return cacheSVAPO[idx];
			return CacheIndicator<SVAPO>(new SVAPO(){ Period = period, Cutoff = cutoff, DevH = devH, DevL = devL, StdDevPer = stdDevPer }, input, ref cacheSVAPO);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.SVAPO SVAPO(int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			return indicator.SVAPO(Input, period, cutoff, devH, devL, stdDevPer);
		}

		public Indicators.SVAPO SVAPO(ISeries<double> input , int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			return indicator.SVAPO(input, period, cutoff, devH, devL, stdDevPer);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.SVAPO SVAPO(int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			return indicator.SVAPO(Input, period, cutoff, devH, devL, stdDevPer);
		}

		public Indicators.SVAPO SVAPO(ISeries<double> input , int period, int cutoff, double devH, double devL, int stdDevPer)
		{
			return indicator.SVAPO(input, period, cutoff, devH, devL, stdDevPer);
		}
	}
}

#endregion
